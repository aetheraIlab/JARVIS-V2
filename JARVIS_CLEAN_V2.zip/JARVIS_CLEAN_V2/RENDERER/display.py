# ================================================================
# JARVIS AETHER-CORE V2.0 — PRISM (LAYER 5)
# ================================================================
# Codename : PRISM
# Role     : HUD UI Agent — Iron Man HUD via Eel
# Tech     : Python Eel + HTML5/CSS3/JS
# ================================================================

import sys
import os
import threading
import json

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Eel ফোল্ডারের পাথ
HUD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")


class Prism:
    """
    JARVIS PRISM — HUD ডিসপ্লে এজেন্ট।
    Iron Man স্টাইল UI চালু করে এবং Python-JS ব্রিজ তৈরি করে।
    """

    def __init__(self):
        self._eel = None
        self._running = False
        self._sentinel = None
        self._init_eel()
        print("[PRISM] HUD display agent initialized.")

    def _init_eel(self):
        """Eel লাইব্রেরি লোড করে।"""
        try:
            import eel
            self._eel = eel
            # Eel-এর ওয়েব ফোল্ডার সেটআপ
            if os.path.exists(HUD_DIR):
                eel.init(HUD_DIR)
                print(f"[PRISM] Eel initialized with: {HUD_DIR}")
            else:
                print(f"[PRISM] [WARN] HUD directory not found: {HUD_DIR}")
        except ImportError:
            print("[PRISM] [WARN] Eel not installed. Run: pip install Eel")

    def launch_hud(self, port=8080):
        """HUD ওয়েব ইন্টারফেস ব্রাউজারে চালু করে।"""
        if not self._eel:
            print("[PRISM] [WARN] Cannot launch — Eel not available.")
            return

        self._running = True

        # Python → JS ফাংশনগুলো Expose করা হচ্ছে
        self._register_exposed_functions()

        try:
            print(f"[PRISM] Launching HUD on http://localhost:{port}")
            self._eel.start('index.html', size=(1280, 800), port=port, block=False)
        except Exception as e:
            print(f"[PRISM] HUD launch error: {e}")
            # Chrome না থাকলে Edge বা ডিফল্ট ব্রাউজারে খুলবে
            try:
                self._eel.start('index.html', size=(1280, 800), port=port,
                                mode='edge', block=False)
            except Exception:
                print("[PRISM] [WARN] No compatible browser found. Install Chrome or Edge.")

    def _register_exposed_functions(self):
        """Eel-এর মাধ্যমে Python ফাংশন JS থেকে কল করা যাবে।"""
        eel = self._eel

        @eel.expose
        def py_get_system_stats():
            """JS থেকে সিস্টেম স্ট্যাটস নেওয়ার জন্য।"""
            try:
                if not getattr(self, '_sentinel', None):
                    from EXECUTOR.monitor import Sentinel
                    self._sentinel = Sentinel()
                return self._sentinel.get_full_report()
            except Exception as e:
                return {"error": str(e)}

        @eel.expose
        def py_send_command(command):
            """JS থেকে কমান্ড পাঠানোর জন্য।"""
            print(f"[PRISM] HUD Command: {command}")
            return {"status": "received", "command": command}

        @eel.expose
        def py_get_ai_status():
            """AI সিস্টেমের স্ট্যাটাস চেক।"""
            return {"online": True, "provider": "ARBITER"}

    def update_hud(self, element_id, data):
        """Python থেকে HUD-এর কোনো এলিমেন্ট আপডেট করে।"""
        if self._eel and self._running:
            try:
                self._eel.js_update_element(element_id, json.dumps(data))
            except Exception:
                pass  # HUD বন্ধ থাকলে এরর ইগনোর

    def push_notification(self, title, message):
        """HUD-এ নোটিফিকেশন পাঠায়।"""
        if self._eel and self._running:
            try:
                self._eel.js_show_notification(title, message)
            except Exception:
                pass

    def stop(self):
        """HUD বন্ধ করে।"""
        self._running = False
        print("[PRISM] HUD display offline.")


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 50)
    print("  PRISM — Unit Test")
    print("=" * 50)

    prism = Prism()
    print(f"[TEST] HUD Dir exists: {os.path.exists(HUD_DIR)}")
    print(f"[TEST] Eel loaded: {prism._eel is not None}")

    # HUD লঞ্চ করতে চাইলে নিচের লাইন আনকমেন্ট করুন:
    # prism.launch_hud()
    # import time
    # time.sleep(60)  # ৬০ সেকেন্ড HUD চালু থাকবে

    print("\n[PRISM] Unit test complete. ✓")
