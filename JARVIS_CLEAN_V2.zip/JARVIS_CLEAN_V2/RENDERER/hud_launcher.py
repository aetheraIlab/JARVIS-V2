# ================================================================
# JARVIS AETHER-CORE V2.0 — HUD LAUNCHER
# ================================================================
import sys
import os
import time

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from RENDERER.display import Prism

def launch():
    print("=" * 60)
    print("  JARVIS AETHER-CORE — PRISM HUD Launcher")
    print("=" * 60)
    
    prism_app = Prism()
    prism_app.launch_hud(port=8888)
    return prism_app

if __name__ == "__main__":
    app = launch()
    try:
        import eel
        while True:
            eel.sleep(1)
    except KeyboardInterrupt:
        print("[PRISM] Shutting down HUD...")
        app.stop()
        sys.exit(0)
