// ================================================================
// JARVIS AETHER-CORE V3.0 — EXACT REPRODUCTION SCENE 
// Pure Vanilla JS. Three.js r128 CDN. Custom Shader Material.
// ================================================================

let scene, camera, renderer;
let sphere, ring1, ring2, ring3;
let isProcessing = false;

document.addEventListener("DOMContentLoaded", () => {
    initThreeJS();
    initSpikes();
    initEKG();
    initEqualizer();
    startHUDLoops();
    
    // Auto-update system via Eel polling if connected
    if(typeof eel !== 'undefined') {
        setInterval(async () => {
            try {
                let stats = await eel.py_get_system_stats()();
                if(!stats.error) {
                    updateCPU(stats.cpu);
                    updateRAM(stats.ram.percent);
                }
            } catch(e) {}
        }, 1000);
    }
});

// ----------------------------------------------------------------
// 1. THREE.JS SPHERE ENGINE (CUSTOM SHADER)
// ----------------------------------------------------------------
function initThreeJS() {
    const container = document.getElementById('threeCanvas');
    const w = container.clientWidth;
    const h = container.clientHeight;

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 100);
    camera.position.z = 8.5;

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(w, h);
    renderer.setPixelRatio(window.devicePixelRatio);
    container.appendChild(renderer.domElement);

    // --- SPHERE: Custom Shader for Dark Core + Intense Fresnel Edge ---
    const vertexShader = `
        varying vec3 vNormal;
        varying vec3 vViewPosition;
        void main() {
            vNormal = normalize(normalMatrix * normal);
            vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
            vViewPosition = -mvPosition.xyz;
            gl_Position = projectionMatrix * mvPosition;
        }
    `;

    const fragmentShader = `
        uniform vec3 colorCore;
        uniform vec3 colorEdge;
        uniform float intensity;
        uniform float time;
        
        varying vec3 vNormal;
        varying vec3 vViewPosition;
        
        void main() {
            vec3 normal = normalize(vNormal);
            vec3 viewDir = normalize(vViewPosition);

            float dotProduct = max(dot(normal, viewDir), 0.0);
            float fresnel = pow(1.0 - dotProduct, intensity);

            // Subtle pulse on edge glow
            float pulse = 0.85 + 0.15 * sin(time * 1.5);
            fresnel *= pulse;

            vec3 finalColor = mix(colorCore, colorEdge, fresnel);

            // Darken center further
            float centerDark = smoothstep(0.0, 0.6, dotProduct);
            finalColor *= mix(1.0, 0.15, centerDark);

            gl_FragColor = vec4(finalColor, 0.92);
        }
    `;

    const customMat = new THREE.ShaderMaterial({
        uniforms: {
            colorCore: { value: new THREE.Color(0x010208) }, // Near-black core
            colorEdge: { value: new THREE.Color(0x00FFD1) }, // Cyan edge
            intensity: { value: 4.5 }, // Sharper fresnel
            time: { value: 0.0 }
        },
        vertexShader: vertexShader,
        fragmentShader: fragmentShader,
        transparent: true,
        blending: THREE.AdditiveBlending
    });

    const sphereGeo = new THREE.SphereGeometry(2.3, 64, 64);
    sphere = new THREE.Mesh(sphereGeo, customMat);
    scene.add(sphere);

    // --- ATMOSPHERE GLOW (outer translucent shell) ---
    const atmosVS = `
        varying vec3 vNormal;
        varying vec3 vViewPosition;
        void main() {
            vNormal = normalize(normalMatrix * normal);
            vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
            vViewPosition = -mvPos.xyz;
            gl_Position = projectionMatrix * mvPos;
        }
    `;
    const atmosFS = `
        varying vec3 vNormal;
        varying vec3 vViewPosition;
        void main() {
            vec3 n = normalize(vNormal);
            vec3 v = normalize(vViewPosition);
            float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0);
            vec3 col = vec3(0.0, 1.0, 0.82) * rim * 1.2;
            gl_FragColor = vec4(col, rim * 0.45);
        }
    `;
    const atmosMat = new THREE.ShaderMaterial({
        vertexShader: atmosVS,
        fragmentShader: atmosFS,
        transparent: true,
        blending: THREE.AdditiveBlending,
        side: THREE.BackSide,
        depthWrite: false
    });
    const atmosMesh = new THREE.Mesh(new THREE.SphereGeometry(2.55, 64, 64), atmosMat);
    scene.add(atmosMesh);

    // --- RINGS (ultra-thin + additive glow) ---
    const matPink = new THREE.MeshBasicMaterial({ color: 0xFF006E, transparent: true, opacity: 1.0, blending: THREE.AdditiveBlending, depthWrite: false });
    const matPurple = new THREE.MeshBasicMaterial({ color: 0x9D00FF, transparent: true, opacity: 1.0, blending: THREE.AdditiveBlending, depthWrite: false });
    const matCyan = new THREE.MeshBasicMaterial({ color: 0x00FFD1, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });

    // Ring 1: Pink horizontal
    ring1 = new THREE.Mesh(new THREE.TorusGeometry(3.0, 0.005, 8, 200), matPink);
    ring1.rotation.x = Math.PI / 2;
    scene.add(ring1);

    // Ring 2: Purple 70deg tilt, very large
    ring2 = new THREE.Mesh(new THREE.TorusGeometry(3.8, 0.005, 8, 200), matPurple);
    ring2.rotation.x = THREE.MathUtils.degToRad(70);
    scene.add(ring2);

    // Ring 3: Cyan slight tilt
    ring3 = new THREE.Mesh(new THREE.TorusGeometry(2.6, 0.005, 8, 200), matCyan);
    ring3.rotation.x = THREE.MathUtils.degToRad(15);
    scene.add(ring3);

    // Handle Window Resize
    window.addEventListener('resize', () => {
        camera.aspect = container.clientWidth / container.clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(container.clientWidth, container.clientHeight);
    });

    animateScene();
}

function animateScene() {
    requestAnimationFrame(animateScene);
    
    // Update time uniform for sphere pulse
    if(sphere && sphere.material.uniforms && sphere.material.uniforms.time) {
        sphere.material.uniforms.time.value = performance.now() * 0.001;
    }
    
    // Auto rotation speeds
    sphere.rotation.y += 0.002;
    
    let speedMult = isProcessing ? 3.0 : 1.0;
    
    ring1.rotation.z -= 0.004 * speedMult;
    ring2.rotation.z += 0.002 * speedMult;
    ring3.rotation.z -= 0.003 * speedMult;

    renderer.render(scene, camera);
}

// ----------------------------------------------------------------
// 2. EQUALIZER BARS (Below Sphere)
// ----------------------------------------------------------------
const NUM_EQ = 32;
let eqIdleInterval = null;
let eqActiveInterval = null;

function initEqualizer() {
    const rig = document.getElementById('eq-rig');
    if(!rig) return;
    
    for(let i=0; i<NUM_EQ; i++) {
        let b = document.createElement('div');
        b.className = 'eq-b';
        b.id = `eqb-${i}`;
        
        let h = Math.floor(Math.random() * 60) + 15;
        setEqualizerBar(b, h);
        rig.appendChild(b);
    }
    
    startEqualizerIdle();
}

function startEqualizerIdle() {
    if(eqIdleInterval) clearInterval(eqIdleInterval);
    eqIdleInterval = setInterval(() => {
        for(let i=0; i<NUM_EQ; i++) {
            let b = document.getElementById(`eqb-${i}`);
            let h = Math.floor(Math.random() * 70) + 15;
            setEqualizerBar(b, h);
            b.style.transition = `height ${(Math.random() * 0.9 + 0.3).toFixed(2)}s ease, background 0.2s ease`;
        }
    }, 800);
}

function setEqualizerBar(bar, hPercent) {
    bar.style.height = hPercent + '%';
    
    let color = 'var(--green)';
    if(hPercent > 30) color = 'var(--cyan)';
    if(hPercent > 70) color = 'var(--yellow)';
    if(hPercent > 90) color = 'var(--red)';
    
    bar.style.background = color;
    bar.style.boxShadow = `0 0 5px ${color}`;
}


// ----------------------------------------------------------------
// 3. CSS NEURAL SPIKE LINES
// ----------------------------------------------------------------
function initSpikes() {
    const rig = document.getElementById('spike-container');
    if(!rig) return;
    const colors = ['c-cyan','c-red','c-white','c-cyan','c-white'];
    
    for(let i=0; i<16; i++) {
        let spike = document.createElement('div');
        let col = colors[i % colors.length];
        spike.className = `spk ${col}`;
        
        let deg = (i * (360/16)) + (Math.random() * 10 - 5);
        spike.style.transform = `rotateZ(${deg}deg)`;
        
        let part = document.createElement('div');
        part.className = 'part';
        part.style.animationDelay = `${(Math.random() * 2).toFixed(2)}s`;
        
        spike.appendChild(part);
        rig.appendChild(spike);
    }
}

// ----------------------------------------------------------------
// 4. BIOMETRIC EKG WAVE
// ----------------------------------------------------------------
let ekgCv, ekgCt;
let tick = 0;

function initEKG() {
    const box = document.querySelector('.wave-box');
    if(!box) return;
    ekgCv = document.getElementById('canvas-wave');
    ekgCv.width = box.clientWidth;
    ekgCv.height = box.clientHeight;
    ekgCt = ekgCv.getContext('2d');
    
    window.addEventListener('resize', () => {
        ekgCv.width = box.clientWidth;
        ekgCv.height = box.clientHeight;
    });
    
    drawEKG();
}

function drawEKG() {
    if(!ekgCt) return;
    ekgCt.clearRect(0, 0, ekgCv.width, ekgCv.height);
    
    ekgCt.strokeStyle = "rgba(0,255,209,0.1)";
    ekgCt.lineWidth = 1;
    ekgCt.beginPath();
    for(let i=0; i<ekgCv.width; i+=20) { ekgCt.moveTo(i,0); ekgCt.lineTo(i,ekgCv.height); }
    for(let j=0; j<ekgCv.height; j+=20) { ekgCt.moveTo(0,j); ekgCt.lineTo(ekgCv.width,j); }
    ekgCt.stroke();

    ekgCt.beginPath();
    ekgCt.moveTo(0, ekgCv.height/2);
    
    for (let x = 0; x < ekgCv.width; x++) {
        let y = ekgCv.height/2;
        y += Math.sin((x + tick)*0.05) * 10;
        if (Math.abs(Math.sin((x + tick)*0.08)) > 0.99) y -= 40; 
        if(x===0) ekgCt.moveTo(x,y); else ekgCt.lineTo(x,y);
    }
    
    ekgCt.strokeStyle = "#00FFD1";
    ekgCt.lineWidth = 2;
    ekgCt.stroke();
    
    tick += 2;
    requestAnimationFrame(drawEKG);
}

// ----------------------------------------------------------------
// 5. RANDOM FLICKERS & LOOPS
// ----------------------------------------------------------------
function startHUDLoops() {
    setInterval(() => {
        ['t-l1','t-l2','t-l3','t-r1','t-r2','t-r3','b-l1','b-l2','b-l3'].forEach(id => {
            let el = document.getElementById(id);
            if(el) {
                let cur = parseInt(el.innerText);
                let nv = Math.abs(cur + (Math.floor(Math.random()*15)-7));
                el.innerText = String(nv).padStart(3, '0');
            }
        });
    }, 3000);

    setInterval(() => {
        ['d-1','d-2','d-3'].forEach(id => {
            let el = document.getElementById(id);
            if(el) {
                let cur = parseInt(el.innerText);
                el.innerText = String(Math.abs(cur + (Math.floor(Math.random()*11)-5))).padStart(3, '0');
            }
        });
    }, 2000);
}


// ================================================================
// EEL PYTHON HOOKS
// ================================================================

eel.expose(updateAgentLog);
function updateAgentLog(text, level='green') {
    const box = document.getElementById('term-box');
    const lines = box.getElementsByClassName('t-line');
    
    if(lines.length > 0) {
        let c = lines[lines.length-1].querySelector('.cursor');
        if(c) c.remove();
    }
    
    const ln = document.createElement('div');
    ln.className = `t-line ${level}`;
    ln.innerHTML = `> ${text.toUpperCase()}<span class="cursor"></span>`;
    
    box.appendChild(ln);
    if(box.children.length > 8) box.removeChild(box.children[0]);
    box.scrollTop = box.scrollHeight;
}

eel.expose(updateCPU);
function updateCPU(percent) {
    percent = Math.floor(percent);
    let txt = document.getElementById('cpu-txt');
    let arc = document.getElementById('cpu-arc');
    if(!txt) return;
    
    txt.innerText = percent + "%";
    
    let offset = 200 - (200 * (percent / 100));
    arc.style.strokeDashoffset = offset;
    
    let color = 'var(--green)';
    if(percent >= 70) color = 'var(--yellow)';
    if(percent >= 90) color = 'var(--red)';
    
    arc.style.stroke = color;
    txt.style.color = color;
    txt.style.textShadow = `0 0 5px ${color}`;
}

eel.expose(updateRAM);
function updateRAM(percent) {
    let p = Math.floor(percent);
    document.getElementById('ram-bar').style.width = p + "%";
    document.getElementById('ram-txt').innerText = p + "%";
}

eel.expose(setAlertStatus);
function setAlertStatus(msg, type='ok') {
    const ui = document.getElementById('alert-ui');
    const txt = document.getElementById('alert-txt');
    const tri = document.getElementById('tri-icon');
    
    ui.className = 'panel alert-ui'; 
    tri.style.borderBottomColor = 'var(--cyan)';
    tri.style.filter = `drop-shadow(0 0 5px var(--cyan))`;
    txt.style.color = 'var(--green)';
    txt.style.textShadow = '0 0 5px var(--green)';
    
    txt.innerText = msg.toUpperCase();
    
    if(type === 'error') {
        ui.classList.add('error');
        tri.style.borderBottomColor = 'var(--red)';
        tri.style.filter = `drop-shadow(0 0 10px var(--red))`;
    } else if(type === 'warn') {
        tri.style.borderBottomColor = 'var(--yellow)';
        tri.style.filter = `drop-shadow(0 0 10px var(--yellow))`;
        txt.style.color = 'var(--yellow)';
        txt.style.textShadow = '0 0 5px var(--yellow)';
    }
}

eel.expose(setCortexStatus);
function setCortexStatus(status) {
    let c = 'var(--cyan)';
    if(status==='ONLINE') c='var(--green)';
    else if(status==='ERROR') c='var(--red)';
    document.getElementById('st-cortex').innerHTML = `CORTEX  [    <span style="color:${c}">${status.padEnd(8, ' ')}</span>]`;
}

eel.expose(setApexStatus);
function setApexStatus(status) {
    let c = 'var(--cyan)';
    if(status==='ACTIVE') c='var(--cyan)';
    document.getElementById('st-apex').innerHTML = `APEX    [    <span style="color:${c}">${status.padEnd(8, ' ')}</span>]`;
}

eel.expose(updateSphereState);
function updateSphereState(state) {
    if(state === 'processing') {
        isProcessing = true;
        document.querySelector('.main-logo').style.textShadow = '0 0 30px var(--cyan), 0 0 20px #fff';
    } else {
        isProcessing = false;
        document.querySelector('.main-logo').style.textShadow = '0 0 20px var(--cyan)';
    }
}

eel.expose(triggerVoiceWave);
function triggerVoiceWave(isActive) {
    if(isActive) {
        clearInterval(eqIdleInterval);
        if(!eqActiveInterval) {
            eqActiveInterval = setInterval(() => {
                for(let i=0; i<NUM_EQ; i++) {
                    let b = document.getElementById(`eqb-${i}`);
                    b.style.transition = 'height 0.1s linear';
                    setEqualizerBar(b, Math.floor(Math.random() * 10) + 90); 
                }
            }, 100);
        }
    } else {
        if(eqActiveInterval) {
            clearInterval(eqActiveInterval);
            eqActiveInterval = null;
            startEqualizerIdle();
        }
    }
}

eel.expose(addRadarBlip);
function addRadarBlip(type) {
    const radar = document.getElementById('sonar-rig');
    let color = 'var(--cyan)';
    if(type==='warn') color='var(--yellow)';
    if(type==='critical') color='var(--red)';
    if(type==='ok') color='var(--green)';

    let blip = document.createElement('div');
    blip.style.position = 'absolute';
    blip.style.width = '5px'; blip.style.height = '5px';
    blip.style.borderRadius = '50%';
    blip.style.background = color;
    blip.style.boxShadow = `0 0 8px ${color}`;
    
    blip.style.top = `${Math.floor(Math.random() * 60) + 20}%`;
    blip.style.left = `${Math.floor(Math.random() * 60) + 20}%`;
    
    radar.appendChild(blip);
    setTimeout(() => { if(radar.contains(blip)) radar.removeChild(blip); }, 2500);
}
