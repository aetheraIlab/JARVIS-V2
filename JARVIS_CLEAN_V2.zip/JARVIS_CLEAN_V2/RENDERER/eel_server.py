# ================================================================
# JARVIS AETHER-CORE V2.0 — EEL WEB BACKEND (RENDERER LAYER)
# ================================================================
# Codename : NEURAL-INTERFACE
# Role     : REST/WebSocket API server for React frontend
# Tech     : Flask + WebSocket for real-time updates
# Platform : Windows 11 / Aether Core OS
# ================================================================

import sys
import logging
import threading
import time
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

# ── Project root path ──────────────────────────────────────────
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

try:
    from flask import Flask, request, jsonify
    from flask_cors import CORS
    from flask_socketio import SocketIO, emit
    FLASK_AVAILABLE = True
except ImportError:
    FLASK_AVAILABLE = False

try:
    from KERNEL.president_agent import PresidentAgent
    from KERNEL.scheduler import SignalBus
    from HEAP.database import Atlas
    from HEAP.cache import CacheNode
    AGENT_AVAILABLE = True
except ImportError:
    AGENT_AVAILABLE = False

# ── Module logger ──────────────────────────────────────────────
logger = logging.getLogger("NEURAL-INTERFACE")
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(
        logging.Formatter("[%(name)s] %(levelname)s  %(message)s")
    )
    logger.addHandler(_handler)
    logger.setLevel(logging.INFO)


class NeuralInterface:
    """
    JARVIS NEURAL-INTERFACE — Web Interface and API Server.
    
    Communicates with React frontend:
    - REST API endpoints
    - WebSocket real-time updates (flask-socketio)
    - Chat history management
    - System status monitoring
    - Settings persistence
    """
    
    def __init__(self, host="0.0.0.0", port=5000, debug=False):
        self.host = host
        self.port = port
        self.debug = debug
        
        self.app = None
        self.socketio = None
        self.president = None
        self.pipeline = None
        
        # State
        self.running = False
        self.message_history = []
        self.max_history = 100
        self.session_start = time.time()
        self.total_messages = 0
        self.total_errors = 0
        
        # Settings
        self.settings = {
            "tts_enabled": True,
            "voice_enabled": True,
            "theme": "dark",
            "language": "en",
        }
        
        if FLASK_AVAILABLE:
            self.app = Flask(__name__, static_folder="web", static_url_path="/")
            CORS(self.app)
            # async_mode='threading' to avoid eventlet/gevent dependencies
            self.socketio = SocketIO(self.app, cors_allowed_origins="*", async_mode='threading')
            self._setup_routes()
            self._setup_sockets()
        else:
            logger.warning("Flask / Flask-SocketIO not installed.")

        logger.info("Web interface initialized.")

    def _setup_routes(self):
        @self.app.route("/")
        def index():
            return self.app.send_static_file("index.html")

        @self.app.route("/api/health", methods=["GET"])
        def health_check():
            return jsonify({
                "status": "online",
                "version": "2.0",
                "codename": "AETHER-CORE",
                "timestamp": datetime.now().isoformat(),
            })
        
        @self.app.route("/api/status", methods=["GET"])
        def get_status():
            status_data = self._get_system_status()
            return jsonify(status_data)
            
        @self.app.route("/api/nodes", methods=["GET"])
        def get_nodes():
            try:
                if self.president and hasattr(self.president, 'network_hub'):
                    nodes = self.president.network_hub._get_all_nodes()
                    return jsonify({"nodes": nodes})
                return jsonify({"nodes": []})
            except Exception as e:
                logger.error(f"Error fetching nodes: {e}")
                return jsonify({"nodes": []}), 500
        
        @self.app.route("/api/message", methods=["POST"])
        def send_message():
            try:
                data = request.get_json()
                if not data:
                    return jsonify({"error": "Invalid JSON payload"}), 400
                
                user_input = data.get("message", "").strip()
                
                if not user_input:
                    return jsonify({"error": "Empty message"}), 400
                
                if not self.president:
                    return jsonify({"error": "PresidentAgent not available"}), 503
                
                start_time = time.time()
                
                # process_input_safe returns a dict (e.g. {"response": str, "intent": str, ...})
                result_dict = self.president.process_input_safe(user_input, source="WEB")
                
                # Extract the actual string response
                response_str = result_dict.get("response", "No response generated.")
                intent = result_dict.get("intent", "unknown")
                elapsed = time.time() - start_time
                
                exchange = {
                    "timestamp": datetime.now().isoformat(),
                    "user": user_input,
                    "assistant": response_str,
                    "elapsed_ms": int(elapsed * 1000),
                }
                
                self.message_history.append(exchange)
                if len(self.message_history) > self.max_history:
                    self.message_history = self.message_history[-self.max_history:]
                
                self.total_messages += 1
                
                # Emit WebSocket event on new message
                if self.socketio:
                    self.socketio.emit("jarvis_response", {
                        "text": response_str,
                        "intent": intent,
                        "elapsed_ms": int(elapsed * 1000),
                        "query": user_input
                    })
                
                return jsonify({
                    "success": True,
                    "response": response_str,  # Plain string returned to frontend
                    "elapsed_ms": int(elapsed * 1000),
                })
            
            except Exception as e:
                self.total_errors += 1
                logger.error(f"Message processing error: {e}", exc_info=True)
                return jsonify({"error": str(e)}), 500
        
        @self.app.route("/api/history", methods=["GET"])
        def get_history():
            limit = request.args.get("limit", default=50, type=int)
            return jsonify({
                "history": self.message_history[-limit:],
                "total": len(self.message_history),
            })
        
        @self.app.route("/api/history", methods=["DELETE"])
        def clear_history():
            count = len(self.message_history)
            self.message_history = []
            return jsonify({"cleared": count})
            
        @self.app.route("/api/settings", methods=["GET"])
        def get_settings():
            return jsonify(self.settings)
        
        @self.app.route("/api/settings", methods=["POST"])
        def update_settings():
            try:
                data = request.get_json()
                if not data:
                    return jsonify({"error": "Invalid payload"}), 400
                    
                for key, value in data.items():
                    if key in self.settings:
                        self.settings[key] = value
                return jsonify({"success": True, "settings": self.settings})
            except Exception as e:
                return jsonify({"error": str(e)}), 400

        @self.app.route("/api/traces", methods=["GET"])
        def get_live_traces():
            try:
                from MONITOR.tracer import Tracer
                # Get the last 10 traces
                traces = list(Tracer._traces.values())[-10:]
                return jsonify({"traces": [t.to_dict() for t in traces]})
            except ImportError:
                return jsonify({"traces": []})
                
        @self.app.route("/api/metrics", methods=["GET"])
        def get_live_metrics():
            try:
                from MONITOR.health_dashboard import get_dashboard_data
                data = get_dashboard_data()
                return jsonify(data)
            except ImportError:
                return jsonify({})

        @self.app.route("/api/agent_status", methods=["GET"])
        def get_agent_status():
            try:
                from AGENT.registry import agent_registry
                active = agent_registry.list_active()
                all_agents = agent_registry.list_agents()
                return jsonify({"active": list(active), "registered": list(all_agents)})
            except ImportError:
                return jsonify({"active": [], "registered": []})

        @self.app.route("/api/conversation_state", methods=["GET"])
        def get_conversation_state():
            try:
                if self.pipeline and hasattr(self.pipeline, 'state'):
                    state_str = self.pipeline.state
                else:
                    state_str = "IDLE"
                return jsonify({"state": state_str})
            except Exception:
                return jsonify({"state": "ERROR"})

        @self.app.errorhandler(404)
        def not_found(e):
            return jsonify({"error": "Endpoint not found"}), 404
        
        @self.app.errorhandler(500)
        def server_error(e):
            return jsonify({"error": "Internal server error"}), 500

    def _setup_sockets(self):
        @self.socketio.on("connect")
        def handle_connect():
            logger.info("Client connected to WebSocket")
            self.socketio.emit("status_update", self._get_system_status())

        @self.socketio.on("disconnect")
        def handle_disconnect():
            logger.info("Client disconnected from WebSocket")

    def _get_system_status(self):
        """Helper to get system status dictionary"""
        agent_status = "unavailable"
        if self.president:
            try:
                agent_status = "online" if getattr(self.president, 'is_online', True) else "offline"
            except Exception:
                pass
                
        cpu = 0
        ram = 0
        disk = 0
        if PSUTIL_AVAILABLE:
            try:
                cpu = psutil.cpu_percent()
                ram = psutil.virtual_memory().percent
                disk = psutil.disk_usage('/').percent
            except Exception:
                pass
                
        return {
            "uptime": time.time() - self.session_start,
            "messages_processed": self.total_messages,
            "errors": self.total_errors,
            "agent_status": agent_status,
            "cpu": cpu,
            "ram": ram,
            "disk": disk,
            "timestamp": datetime.now().isoformat()
        }

    def _status_broadcast_loop(self):
        """Background thread pushing status updates every 5 seconds"""
        while self.running:
            try:
                if self.socketio:
                    self.socketio.emit("status_update", self._get_system_status())
            except Exception as e:
                logger.error(f"Status broadcast error: {e}")
            time.sleep(5)

    def start(self):
        """Start web server and background tasks"""
        if not self.app or not self.socketio:
            logger.error("Cannot start - Flask or SocketIO not available")
            return False
            
        self.running = True
        
        # Start background broadcaster
        self.broadcast_thread = threading.Thread(target=self._status_broadcast_loop, daemon=True)
        self.broadcast_thread.start()
        
        logger.info(f"Starting API + WebSocket server on {self.host}:{self.port}")
        
        try:
            # allow_unsafe_werkzeug to run in thread if not main thread
            self.socketio.run(self.app, host=self.host, port=self.port, debug=self.debug, allow_unsafe_werkzeug=True)
        except Exception as e:
            logger.error(f"Server error: {e}")
            self.running = False

    def stop(self):
        """Stop web server"""
        self.running = False
        if self.socketio:
            try:
                self.socketio.stop()
            except Exception:
                pass
        logger.info("Web server stopped.")


# ================================================================
# UNIT TESTS
# ================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("  NEURAL-INTERFACE — Server Startup")
    print("=" * 60)
    
    interface = NeuralInterface(host="0.0.0.0", port=5000, debug=False)
    print("  [OK] Interface created")
    
    if interface.app:
        print("  [OK] Flask app & endpoints configured")
    else:
        print("  [WARNING] Flask not available")
        
    if interface.socketio:
        print("  [OK] WebSocket support ready")
    else:
        print("  [WARNING] SocketIO not available")
        
    print(f"  Current settings: {interface.settings}")
    
    print("\n[INFO] Starting Server...")
    print("[INFO] Frontend should connect to REST at: /api/*")
    print("[INFO] WebSocket connect to: ws://localhost:5000")
    print("\n" + "=" * 60)
    
    # Actually start the server so the command doesn't exit immediately
    interface.start()
