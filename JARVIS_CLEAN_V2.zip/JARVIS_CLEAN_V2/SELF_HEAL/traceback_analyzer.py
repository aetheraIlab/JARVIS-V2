# ================================================================
# JARVIS AETHER-CORE V2.0 — TRACEBACK ANALYZER
# ================================================================
import re
import os

class TracebackAnalyzer:
    """Parses raw tracebacks to locate the precise failing file and line."""

    def __init__(self, project_root):
        self.project_root = project_root

    def analyze(self, traceback_str: str, exception_msg: str) -> dict:
        """
        Returns a dictionary with parsed error details.
        """
        # Look for the last File "...", line N, in <module>
        # Example: File "d:\Claude Ai Jarvis making\JARVIS\DAEMON\tracker.py", line 42, in check
        
        file_pattern = re.compile(r'File "(.*?)", line (\d+), in (.*)')
        matches = file_pattern.findall(traceback_str)
        
        target_file = None
        target_line = None
        target_func = None
        
        # Traverse backwards to find the last file that belongs to our project
        # This ignores library internals
        for match in reversed(matches):
            file_path = match[0]
            if self.project_root.lower() in file_path.lower():
                target_file = file_path
                target_line = int(match[1])
                target_func = match[2]
                break
                
        # Fallback to the very last match if none belong to project
        if not target_file and matches:
            target_file, target_line, target_func = matches[-1]
            target_line = int(target_line)

        return {
            "target_file": target_file,
            "target_line": target_line,
            "target_func": target_func,
            "exception": exception_msg,
            "raw_traceback": traceback_str
        }
