# ================================================================
# JARVIS AETHER-CORE V2.0 — FAILURE CLASSIFIER
# ================================================================
import re

class FailureClassifier:
    """Categorizes Python tracebacks into distinct failure domains."""

    CATEGORIES = [
        "SYNTAX", "RUNTIME", "DEPENDENCY", "TIMEOUT",
        "RESOURCE", "PERMISSION", "NETWORK", "LOGIC", "UNKNOWN"
    ]

    @staticmethod
    def classify(traceback_str: str, exception_msg: str) -> str:
        tb_lower = traceback_str.lower()
        exc_lower = exception_msg.lower()

        if any(err in exc_lower for err in ["syntaxerror", "indentationerror"]):
            return "SYNTAX"
            
        if any(err in exc_lower for err in ["modulenotfounderror", "importerror"]):
            return "DEPENDENCY"
            
        if any(err in exc_lower for err in ["timeouterror", "readtimeout", "connectiontimeout"]):
            return "TIMEOUT"
            
        if any(err in exc_lower for err in ["memoryerror", "outofmemory"]):
            return "RESOURCE"
            
        if any(err in exc_lower for err in ["permissionerror", "access denied"]):
            return "PERMISSION"
            
        if any(err in exc_lower for err in ["connectionerror", "requests.exceptions"]):
            return "NETWORK"
            
        if any(err in exc_lower for err in ["typeerror", "valueerror", "keyerror", "indexerror", "attributeerror", "nameerror"]):
            return "RUNTIME"
            
        return "UNKNOWN"
