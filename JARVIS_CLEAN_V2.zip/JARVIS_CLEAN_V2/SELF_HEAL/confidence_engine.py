# ================================================================
# JARVIS AETHER-CORE V2.0 — CONFIDENCE ENGINE
# ================================================================
import logging

logger = logging.getLogger("CONFIDENCE-ENGINE")

class ConfidenceEngine:
    """Evaluates the risk of a proposed patch."""

    def __init__(self):
        self.approval_threshold = 90.0

    def score_patch(self, category: str, original_code: str, new_code: str) -> float:
        """
        Returns a confidence score from 0.0 to 100.0.
        """
        score = 100.0
        
        # Category risk
        if category == "SYNTAX":
            score -= 5.0  # Usually safe
        elif category == "RUNTIME":
            score -= 15.0 # Moderate risk
        elif category == "LOGIC":
            score -= 30.0 # High risk, usually needs human
            
        # Diff size risk
        lines_orig = len(original_code.split("\n"))
        lines_new = len(new_code.split("\n"))
        diff_ratio = abs(lines_orig - lines_new) / max(1, lines_orig)
        
        if diff_ratio > 0.5:
            score -= 40.0 # Massive rewrite, high risk
        elif diff_ratio > 0.1:
            score -= 10.0
            
        # Dangerous imports risk
        if "import os" in new_code and "import os" not in original_code:
            score -= 20.0
        if "import subprocess" in new_code and "import subprocess" not in original_code:
            score -= 40.0

        return max(0.0, score)

    def requires_human_approval(self, score: float) -> bool:
        return score < self.approval_threshold
