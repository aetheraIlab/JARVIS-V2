# ================================================================
# JARVIS AETHER-CORE V2.0 — SELF-HEAL OBSERVABILITY
# ================================================================
# Role     : Telemetry and Event Tracking for Self-Healing Engine
# ================================================================

import logging
import sys
import json
import os
from datetime import datetime
from threading import Lock

class HealObserver:
    _instance = None
    _lock = Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(HealObserver, cls).__new__(cls)
                cls._instance._init_logger()
            return cls._instance

    def _init_logger(self):
        self.logger = logging.getLogger("SELF-HEAL")
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(logging.Formatter('[%(asctime)s] [HEAL-ENGINE] [%(levelname)s] %(message)s'))
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
            
        # Log File
        self.log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "HEAP", "logs")
        os.makedirs(self.log_dir, exist_ok=True)
        self.audit_file = os.path.join(self.log_dir, "heal_audit.json")
        
    def log_event(self, event_type, details):
        """
        Valid Events:
        REPAIR_STARTED, REPAIR_FAILED, REPAIR_SUCCESS, PATCH_APPLIED, ROLLBACK_TRIGGERED
        """
        self.logger.info(f"[{event_type}] {details.get('message', '')}")
        
        entry = {
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            "details": details
        }
        
        try:
            with open(self.audit_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception as e:
            self.logger.error(f"Failed to write audit log: {e}")
            
# Singleton Export
observer = HealObserver()
