# ================================================================
# JARVIS AETHER-CORE V2.0 — DEPENDENCY REPAIR
# ================================================================
import logging
import subprocess
import re
import sys

logger = logging.getLogger("DEPENDENCY-REPAIR")

class DependencyRepair:
    """Attempts to auto-heal MissingModule exceptions."""

    def __init__(self):
        pass

    def extract_module_name(self, exception_msg: str) -> str:
        """Extracts the missing module name from the exception."""
        # e.g., ModuleNotFoundError: No module named 'requests'
        match = re.search(r"No module named '(\w+)'", exception_msg)
        if match:
            return match.group(1)
        return None

    def attempt_repair(self, exception_msg: str) -> bool:
        """Runs pip install for the missing module safely."""
        module_name = self.extract_module_name(exception_msg)
        if not module_name:
            logger.error("Could not extract module name from exception.")
            return False

        logger.info(f"Attempting autonomous install of missing dependency: {module_name}")
        
        try:
            # Run pip install safely
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", module_name],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if result.returncode == 0:
                logger.info(f"Successfully installed '{module_name}'.")
                return True
            else:
                logger.error(f"Failed to install '{module_name}': {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"Dependency repair crashed: {e}")
            return False
