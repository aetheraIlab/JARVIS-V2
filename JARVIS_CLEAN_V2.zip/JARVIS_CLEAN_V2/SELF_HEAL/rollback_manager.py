# ================================================================
# JARVIS AETHER-CORE V2.0 — ROLLBACK MANAGER
# ================================================================
import os
import shutil
import logging
from datetime import datetime

logger = logging.getLogger("ROLLBACK-MANAGER")

class RollbackManager:
    """Manages file snapshots and recovery rollbacks."""

    def __init__(self, project_root):
        self.project_root = project_root
        self.backup_dir = os.path.join(project_root, "HEAP", "backups")
        os.makedirs(self.backup_dir, exist_ok=True)
        self.active_snapshots = {}

    def create_snapshot(self, target_file: str) -> str:
        """Copies the target file to a timestamped backup."""
        if not os.path.exists(target_file):
            logger.error(f"Cannot snapshot missing file: {target_file}")
            return None
            
        filename = os.path.basename(target_file)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(self.backup_dir, f"{filename}.{timestamp}.bak")
        
        try:
            shutil.copy2(target_file, backup_path)
            self.active_snapshots[target_file] = backup_path
            logger.info(f"Snapshot created for {filename}")
            return backup_path
        except Exception as e:
            logger.error(f"Snapshot failed: {e}")
            return None

    def rollback(self, target_file: str) -> bool:
        """Restores the target file from its latest snapshot."""
        backup_path = self.active_snapshots.get(target_file)
        if not backup_path or not os.path.exists(backup_path):
            logger.error(f"No valid snapshot found to rollback {target_file}")
            return False
            
        try:
            shutil.copy2(backup_path, target_file)
            logger.warning(f"ROLLBACK SUCCESSFUL: Restored {target_file} from snapshot.")
            return True
        except Exception as e:
            logger.error(f"ROLLBACK FAILED: {e}")
            return False
