# ================================================================
# JARVIS AETHER-CORE V2.0 — CRASH MONITOR
# ================================================================
import sys
import os
import logging
import asyncio
import threading
import time

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from KERNEL.scheduler import SignalBus
from SELF_HEAL.observability import observer
from SELF_HEAL.traceback_analyzer import TracebackAnalyzer
from SELF_HEAL.failure_classifier import FailureClassifier
from SELF_HEAL.repair_planner import RepairPlanner
from MONITOR.tracer import TraceManager

logger = logging.getLogger("CRASH-MONITOR")

class CrashMonitor:
    """Listens for exceptions on the Universal Event Bus and triggers healing."""

    def __init__(self, bus: SignalBus):
        self.bus = bus
        self.project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        self.analyzer = TracebackAnalyzer(self.project_root)
        self.classifier = FailureClassifier()
        self.planner = RepairPlanner(self.project_root)
        
        # Debounce mechanism to prevent cascading loops
        self.recent_crashes = {}
        self.cooldown_seconds = 60

    def start(self):
        """Starts the crash listener on the bus."""
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self.bus.subscribe("EXCEPTION_CAUGHT", self._on_crash_detected))
        except RuntimeError:
            asyncio.run(self.bus.subscribe("EXCEPTION_CAUGHT", self._on_crash_detected))
            
        logger.info("[CRASH-MONITOR] Online. Listening for critical exceptions...")
        observer.log_event("MONITOR_STARTED", {"message": "Crash Monitor is active."})

    async def _on_crash_detected(self, signal: dict):
        """Callback when an exception is broadcasted on the bus."""
        sender = signal.get("sender", "UNKNOWN")
        payload = signal.get("data", {})
        traceback_str = payload.get("traceback", "")
        exception_msg = payload.get("exception", "")
        
        if not traceback_str:
            return

        # Anti-Cascading Check
        crash_hash = hash(traceback_str)
        now = time.time()
        if crash_hash in self.recent_crashes:
            if now - self.recent_crashes[crash_hash] < self.cooldown_seconds:
                logger.warning(f"Ignored cascading crash from {sender} (in cooldown).")
                return
                
        self.recent_crashes[crash_hash] = now

        logger.error(f"[CRASH DETECTED] Source: {sender} | Error: {exception_msg}")
        observer.log_event("CRASH_DETECTED", {"sender": sender, "exception": exception_msg})

        # Offload repair to a separate thread to prevent blocking the bus
        trace_id = TraceManager.generate_trace_id()
        threading.Thread(
            target=self._initiate_repair_protocol_with_timeout, 
            args=(traceback_str, exception_msg, trace_id), 
            daemon=True
        ).start()

    def _initiate_repair_protocol_with_timeout(self, traceback_str: str, exception_msg: str, trace_id: str):
        """Wrapper to enforce a hard timeout on the repair protocol."""
        span = TraceManager.start_span(
            name="crash_monitor_repair",
            metadata={"exception": exception_msg}
        )
        try:
            # We use an asyncio event loop here because PatchGenerator relies on Arbiter (which is async)
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            # Run with a strict 5-minute timeout
            task = loop.create_task(self._async_repair_protocol(traceback_str, exception_msg, trace_id))
            loop.run_until_complete(asyncio.wait_for(task, timeout=300))
            
            span.end("SUCCESS")
        except asyncio.TimeoutError:
            logger.error("Repair protocol timed out after 300 seconds.")
            span.end("FAILED", error="TimeoutError: Repair protocol exceeded 300s limit")
        except Exception as e:
            logger.error(f"Critical failure inside Repair Protocol: {e}")
            observer.log_event("REPAIR_PROTOCOL_FAILED", {"exception": str(e)})
            span.end("FAILED", error=str(e))
        finally:
            try:
                loop.close()
            except Exception:
                pass

    async def _async_repair_protocol(self, traceback_str: str, exception_msg: str, trace_id: str):
        """The core repair pipeline workflow."""
        try:
            # 1. Analyze
            analysis = self.analyzer.analyze(traceback_str, exception_msg)
            if not analysis["target_file"]:
                logger.error("Could not locate project file in traceback. Aborting repair.")
                return
                
            # 2. Classify
            category = self.classifier.classify(traceback_str, exception_msg)
            logger.info(f"Crash Classified as: {category} in {os.path.basename(analysis['target_file'])}")
            
            # 3. Plan & Execute
            await self.planner.execute_repair_plan(category, analysis)
            
        except Exception as e:
            logger.error(f"Critical failure inside Repair Protocol: {e}")
            observer.log_event("REPAIR_PROTOCOL_FAILED", {"exception": str(e)})

# To run standalone for testing:
if __name__ == "__main__":
    async def run_test():
        bus = SignalBus()
        monitor = CrashMonitor(bus)
        monitor.start()
        
        # Simulate a crash
        await asyncio.sleep(1)
        await bus.emit("TEST_AGENT", "EXCEPTION_CAUGHT", {
            "exception": "ZeroDivisionError: division by zero",
            "traceback": 'Traceback (most recent call last):\n  File "d:\\Claude Ai Jarvis making\\JARVIS\\DAEMON\\tracker.py", line 42, in check\n    result = 10 / 0\nZeroDivisionError: division by zero'
        })
        
        await asyncio.sleep(5)
        
    asyncio.run(run_test())
