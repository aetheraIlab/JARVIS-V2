# ================================================================
# JARVIS AETHER-CORE V2.0 — SANDBOX RUNNER
# ================================================================
# [V2] Now delegates ALL patch testing to SafeExecutorV2 for full
#       subprocess isolation. No code executes in the Kernel process.
# ================================================================
import os
import shutil
import logging

logger = logging.getLogger("SANDBOX-RUNNER")

class SandboxRunner:
    """
    Provides an isolated environment to test generated patches.
    
    [V2] All validation now runs in a SafeExecutorV2 subprocess.
    The Kernel process is never exposed to untrusted patch code.
    """

    def __init__(self, project_root):
        self.project_root = project_root
        self.sandbox_dir = os.path.join(project_root, "HEAP", "sandbox")
        os.makedirs(self.sandbox_dir, exist_ok=True)
        
        # Lazy-init SafeExecutorV2 to avoid circular imports at boot
        self._executor = None

    def _get_executor(self):
        """Lazy-load SafeExecutorV2."""
        if self._executor is None:
            from AGENT.safe_executor_v2 import SafeExecutorV2
            self._executor = SafeExecutorV2(project_root=self.project_root)
        return self._executor

    def prepare_sandbox(self, target_file: str, new_content: str) -> str:
        """Copies the target file to the sandbox and applies the new content."""
        filename = os.path.basename(target_file)
        sandbox_path = os.path.join(self.sandbox_dir, filename)
        
        try:
            with open(sandbox_path, "w", encoding="utf-8") as f:
                f.write(new_content)
            return sandbox_path
        except Exception as e:
            logger.error(f"Sandbox preparation failed: {e}")
            return None

    def test_syntax(self, sandbox_path: str) -> tuple:
        """
        Runs syntax + import validation in a fully isolated subprocess.
        
        [V2] No longer uses py_compile in-process. Delegates to
        SafeExecutorV2.test_patch() which runs in a separate process
        with hard timeouts and memory limits.
        """
        try:
            # Read the content from the sandbox file
            with open(sandbox_path, "r", encoding="utf-8") as f:
                content = f.read()
            
            executor = self._get_executor()
            result = executor.test_patch(
                target_file=sandbox_path,
                new_content=content,
                timeout=15,
            )
            
            if result.success:
                return True, "Syntax OK (validated in isolated subprocess)"
            else:
                error_msg = result.error_summary or result.stderr or "Unknown validation error"
                return False, f"Patch validation failed: {error_msg}"
                
        except Exception as e:
            return False, f"Sandbox test error: {e}"

    def test_full(self, target_file: str, new_content: str) -> tuple:
        """
        Full patch validation: prepare + test in one call.
        
        Returns:
            (success: bool, message: str)
        """
        sandbox_path = self.prepare_sandbox(target_file, new_content)
        if not sandbox_path:
            return False, "Failed to prepare sandbox"
        
        return self.test_syntax(sandbox_path)

    def clean_sandbox(self):
        """Removes all files from the sandbox."""
        for filename in os.listdir(self.sandbox_dir):
            file_path = os.path.join(self.sandbox_dir, filename)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
            except Exception:
                pass

