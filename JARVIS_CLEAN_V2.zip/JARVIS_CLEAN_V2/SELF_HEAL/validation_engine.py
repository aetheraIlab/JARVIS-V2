# ================================================================
# JARVIS AETHER-CORE V2.0 — VALIDATION ENGINE
# ================================================================
import logging
import importlib.util
import os
import sys

logger = logging.getLogger("VALIDATION-ENGINE")

class ValidationEngine:
    """Validates patched code before it goes live."""

    def __init__(self):
        pass

    def validate_import(self, sandbox_path: str, module_name: str) -> tuple[bool, str]:
        """Attempts to dynamically load the module to ensure no import-time crashes."""
        try:
            spec = importlib.util.spec_from_file_location(module_name, sandbox_path)
            if spec is None:
                return False, "Failed to create module spec."
                
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
            
            # Clean up sys.modules
            del sys.modules[module_name]
            
            return True, "Import Validation Successful"
            
        except Exception as e:
            return False, f"Import Validation Failed: {e}"

    def validate_patch(self, sandbox_path: str) -> tuple[bool, str]:
        """Runs the suite of validations."""
        logger.info(f"Validating patch in sandbox: {sandbox_path}")
        
        # We use a dummy module name
        module_name = "sandbox_module_" + os.path.basename(sandbox_path).split('.')[0]
        
        success, msg = self.validate_import(sandbox_path, module_name)
        return success, msg
