# ================================================================
# JARVIS AETHER-CORE V2.0 — REPAIR MEMORY
# ================================================================
import json
import os
import logging
from datetime import datetime

logger = logging.getLogger("REPAIR-MEMORY")

class RepairMemory:
    """Stores past successful and failed repairs to prevent loops."""

    def __init__(self, project_root):
        self.memory_dir = os.path.join(project_root, "HEAP", "repair_memory")
        os.makedirs(self.memory_dir, exist_ok=True)
        self.db_file = os.path.join(self.memory_dir, "repair_history.json")
        self._ensure_db()

    def _ensure_db(self):
        if not os.path.exists(self.db_file):
            with open(self.db_file, "w", encoding="utf-8") as f:
                json.dump([], f)

    def record_repair(self, traceback_hash: str, file_path: str, category: str, success: bool, patch_diff: str = ""):
        """Records a repair attempt."""
        try:
            with open(self.db_file, "r", encoding="utf-8") as f:
                history = json.load(f)
                
            entry = {
                "timestamp": datetime.now().isoformat(),
                "traceback_hash": traceback_hash,
                "file": file_path,
                "category": category,
                "success": success,
                "patch": patch_diff
            }
            history.append(entry)
            
            with open(self.db_file, "w", encoding="utf-8") as f:
                json.dump(history, f, indent=4)
                
        except Exception as e:
            logger.error(f"Failed to record repair memory: {e}")

    def check_previous_failure(self, traceback_hash: str) -> bool:
        """Returns True if this exact crash failed to repair recently."""
        try:
            with open(self.db_file, "r", encoding="utf-8") as f:
                history = json.load(f)
                
            failed_attempts = [e for e in history if e["traceback_hash"] == traceback_hash and not e["success"]]
            
            # If we failed to fix this exact error 2+ times, return True (loop detected)
            return len(failed_attempts) >= 2
            
        except Exception:
            return False
