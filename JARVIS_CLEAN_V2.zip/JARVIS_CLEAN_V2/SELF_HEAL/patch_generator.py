# ================================================================
# JARVIS AETHER-CORE V2.0 — PATCH GENERATOR
# ================================================================
import sys
import os
import logging
import asyncio

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from INFERENCE.pipeline import Arbiter

logger = logging.getLogger("PATCH-GENERATOR")

class PatchGenerator:
    """Uses LLM to autonomously write code patches for crashed modules."""

    def __init__(self):
        self.arbiter = Arbiter()

    async def generate_patch(self, file_path: str, traceback_info: dict, file_content: str) -> str:
        """
        Asks the Arbiter to fix the code based on the traceback.
        Returns the entire updated file content.
        """
        logger.info(f"Generating AI patch for {os.path.basename(file_path)}...")
        
        prompt = f"""You are JARVIS's internal Self-Healing Engine.
A critical crash occurred in one of your modules.

Target File: {file_path}
Exception: {traceback_info['exception']}
Raw Traceback:
{traceback_info['raw_traceback']}

Current Source Code:
```python
{file_content}
```

Task:
Fix the bug causing the crash. Provide the FULL, complete corrected python code.
Do not add markdown formatting to the final output, just output the raw python code.
Ensure you maintain all existing functionality and only fix the specific bug.
If it's an import error, add the import. If it's a runtime error, add safety checks or try/except blocks.
"""
        
        try:
            # We use Arbiter's internal generation
            # Arbiter expects context_history. We'll pass empty and just use the prompt.
            # We assume think() handles this.
            response, provider = self.arbiter.think(prompt, [])
            
            # Clean up potential markdown formatting from LLM
            clean_code = response.replace("```python\n", "").replace("```python", "").replace("```\n", "").replace("```", "")
            
            # Additional cleanup for safety
            if clean_code.startswith("Here is"):
                lines = clean_code.split("\n")
                clean_lines = [l for l in lines if not l.startswith("Here is") and not l.startswith("I have")]
                clean_code = "\n".join(clean_lines)

            logger.info(f"Patch generated successfully via {provider}.")
            return clean_code.strip() + "\n"

        except Exception as e:
            logger.error(f"Patch generation failed: {e}")
            return None
