# ================================================================
# JARVIS AETHER-CORE V2.0 — REPAIR PLANNER
# ================================================================
import os
import logging
import asyncio
import shutil

from SELF_HEAL.dependency_repair import DependencyRepair
from SELF_HEAL.patch_generator import PatchGenerator
from SELF_HEAL.sandbox_runner import SandboxRunner
from SELF_HEAL.validation_engine import ValidationEngine
from SELF_HEAL.confidence_engine import ConfidenceEngine
from SELF_HEAL.rollback_manager import RollbackManager
from SELF_HEAL.repair_memory import RepairMemory
from SELF_HEAL.observability import observer

logger = logging.getLogger("REPAIR-PLANNER")

class RepairPlanner:
    """The central strategy engine orchestrating the Self-Healing process."""

    def __init__(self, project_root):
        self.project_root = project_root
        
        self.dep_repair = DependencyRepair()
        self.patch_gen = PatchGenerator()
        self.sandbox = SandboxRunner(project_root)
        self.validator = ValidationEngine()
        self.confidence = ConfidenceEngine()
        self.rollback = RollbackManager(project_root)
        self.memory = RepairMemory(project_root)

    async def execute_repair_plan(self, category: str, analysis: dict):
        """Executes the autonomous repair sequence based on category."""
        target_file = analysis["target_file"]
        exception_msg = analysis["exception"]
        raw_traceback = analysis["raw_traceback"]
        
        traceback_hash = str(hash(raw_traceback))
        
        # 1. Anti-Loop Memory Check
        if self.memory.check_previous_failure(traceback_hash):
            logger.error("Infinite Repair Loop Detected. Aborting autonomous repair.")
            observer.log_event("REPAIR_ABORTED", {"reason": "Infinite loop detected."})
            return

        observer.log_event("REPAIR_STARTED", {"category": category, "file": target_file})
        logger.info(f"Initiating Repair Protocol for {category} error in {os.path.basename(target_file)}")

        # 2. Strategy Routing
        if category == "DEPENDENCY":
            success = self.dep_repair.attempt_repair(exception_msg)
            self.memory.record_repair(traceback_hash, target_file, category, success)
            if success:
                observer.log_event("REPAIR_SUCCESS", {"strategy": "DEPENDENCY_REPAIR"})
            else:
                observer.log_event("REPAIR_FAILED", {"strategy": "DEPENDENCY_REPAIR"})
            return

        elif category in ["SYNTAX", "RUNTIME", "LOGIC"]:
            # Perform Code Repair
            await self._code_repair_protocol(target_file, exception_msg, raw_traceback, category, traceback_hash)
            
        else:
            logger.warning(f"Category {category} cannot be auto-healed yet.")
            observer.log_event("REPAIR_SKIPPED", {"category": category})

    async def _code_repair_protocol(self, target_file: str, exception_msg: str, raw_traceback: str, category: str, traceback_hash: str):
        """The workflow for patching, sandboxing, and rolling back code."""
        # A. Read Original Code
        try:
            with open(target_file, "r", encoding="utf-8") as f:
                original_code = f.read()
        except Exception as e:
            logger.error(f"Failed to read target file: {e}")
            return

        # B. AI Patch Generation
        traceback_info = {"exception": exception_msg, "raw_traceback": raw_traceback}
        new_code = await self.patch_gen.generate_patch(target_file, traceback_info, original_code)
        
        if not new_code:
            logger.error("Failed to generate patch.")
            return

        # C. Confidence Scoring
        score = self.confidence.score_patch(category, original_code, new_code)
        logger.info(f"Patch Confidence Score: {score}/100")
        
        if self.confidence.requires_human_approval(score):
            logger.warning(f"Patch score {score} is below approval threshold. Manual intervention required.")
            observer.log_event("REPAIR_BLOCKED", {"reason": "Confidence too low", "score": score})
            self.memory.record_repair(traceback_hash, target_file, category, False, "Blocked by ConfidenceEngine")
            return

        # D. Sandbox Testing
        sandbox_path = self.sandbox.prepare_sandbox(target_file, new_code)
        if not sandbox_path:
            return

        # Syntax Test
        syn_ok, syn_msg = self.sandbox.test_syntax(sandbox_path)
        if not syn_ok:
            logger.error(f"Sandbox Syntax Test Failed: {syn_msg}")
            self.memory.record_repair(traceback_hash, target_file, category, False, "Syntax validation failed")
            return

        # Import/Validation Test
        val_ok, val_msg = self.validator.validate_patch(sandbox_path)
        if not val_ok:
            logger.error(f"Sandbox Validation Test Failed: {val_msg}")
            self.memory.record_repair(traceback_hash, target_file, category, False, "Runtime validation failed")
            return

        # E. Rollback Snapshot & Apply
        logger.info("Sandbox validations passed. Applying patch to production...")
        self.rollback.create_snapshot(target_file)
        
        try:
            shutil.copy2(sandbox_path, target_file)
            logger.info("Patch applied successfully. Resuming operations.")
            observer.log_event("PATCH_APPLIED", {"file": target_file, "score": score})
            self.memory.record_repair(traceback_hash, target_file, category, True)
            
            # Clean up
            self.sandbox.clean_sandbox()
            
        except Exception as e:
            logger.error(f"Failed to write patch to {target_file}: {e}")
            self.rollback.rollback(target_file)
