# ================================================================
# JARVIS AETHER-CORE V2.0 — HEALTH DASHBOARD
# ================================================================
# Role     : Console & JSON health reporting for all UAF agents
# Layer    : MONITOR (Observability)
# ================================================================

import logging
from datetime import datetime, timezone
from typing import Dict, Any

from AGENT.heartbeat import heartbeat_monitor
from AGENT.state_machine import AgentState

logger = logging.getLogger("HEALTH_DASHBOARD")

# ── ANSI Colour Codes (Windows 10+ supports these) ───────────
_GREEN = "\033[92m"
_YELLOW = "\033[93m"
_RED = "\033[91m"
_CYAN = "\033[96m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_RESET = "\033[0m"

_STATE_COLOURS = {
    "idle": _GREEN,
    "busy": _CYAN,
    "degraded": _YELLOW,
    "error": _RED,
    "offline": _RED,
    "initializing": _CYAN,
    "created": _DIM,
    "shutting_down": _YELLOW,
}


def get_dashboard_data() -> Dict[str, Any]:
    """
    Return a JSON-serializable health dashboard dictionary.

    Structure::

        {
            "timestamp": "2026-05-03T...",
            "summary": {
                "total": 10, "healthy": 8,
                "degraded": 1, "errored": 0, "offline": 1
            },
            "agents": {
                "BROWSER_AGENT": {
                    "state": "idle",
                    "beat_count": 42,
                    "last_beat_age_seconds": 3.12,
                    ...
                }, ...
            }
        }
    """
    status = heartbeat_monitor.get_health_status()
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "summary": {
            "total": status.get("total_agents", 0),
            "healthy": status.get("healthy", 0),
            "degraded": status.get("degraded", 0),
            "errored": status.get("errored", 0),
            "offline": status.get("offline", 0),
            "monitor_running": status.get("monitor_running", False),
        },
        "agents": status.get("agents", {}),
    }


def print_health_dashboard() -> None:
    """
    Print a formatted console health dashboard showing the
    current state of all registered agents.

    Example output::

        ╔══════════════════════════════════════════════════════════════╗
        ║           JARVIS SWARM — HEALTH DASHBOARD                  ║
        ╠══════════════════════════════════════════════════════════════╣
        ║  Total: 10  │  Healthy: 8  │  Degraded: 1  │  Offline: 1  ║
        ╠══════════════════════════════════════════════════════════════╣
        ║  BROWSER_AGENT       │ ● IDLE         │ beats: 42          ║
        ║  RESEARCH_AGENT      │ ● IDLE         │ beats: 38          ║
        ║  EMAIL_AGENT         │ ● DEGRADED     │ beats: 12          ║
        ╚══════════════════════════════════════════════════════════════╝
    """
    data = get_dashboard_data()
    summary = data["summary"]
    agents = data["agents"]

    # Enable ANSI on Windows
    try:
        import os
        os.system("")  # Enables ANSI escape codes on Windows 10+
    except Exception:
        pass

    width = 62

    print()
    print(f"╔{'═' * width}╗")
    print(f"║{_BOLD}{_CYAN}{'JARVIS SWARM — HEALTH DASHBOARD':^{width}}{_RESET}║")
    print(f"╠{'═' * width}╣")

    # Summary row
    total = summary["total"]
    healthy = summary["healthy"]
    degraded = summary["degraded"]
    errored = summary["errored"]
    offline = summary["offline"]

    summary_line = (
        f"  Total: {_BOLD}{total}{_RESET}  │  "
        f"{_GREEN}Healthy: {healthy}{_RESET}  │  "
        f"{_YELLOW}Degraded: {degraded}{_RESET}  │  "
        f"{_RED}Offline: {offline}{_RESET}"
    )
    # Pad to width (ANSI codes are zero-width so we pad manually)
    print(f"║{summary_line}{'':>{width - 54}}║")
    print(f"╠{'═' * width}╣")

    if not agents:
        empty_msg = "  No agents registered"
        print(f"║{empty_msg:<{width}}║")
    else:
        for agent_id, info in sorted(agents.items()):
            if info is None:
                state_str = "unknown"
                beat_count = 0
            else:
                state_str = info.get("current_state", "unknown")
                beat_count = info.get("beat_count", 0)

            colour = _STATE_COLOURS.get(state_str, _DIM)
            state_display = state_str.upper()

            # Build the line (manually handle padding for ANSI)
            agent_col = f"  {agent_id:<22}"
            state_col = f"│ {colour}● {state_display:<14}{_RESET}"
            beats_col = f"│ beats: {beat_count}"

            # Raw character count (without ANSI)
            raw_len = 2 + 22 + 2 + 2 + 14 + 2 + 8 + len(str(beat_count))
            padding = width - raw_len
            if padding < 0:
                padding = 0

            print(f"║{agent_col}{state_col}{beats_col}{' ' * padding}║")

    print(f"╚{'═' * width}╝")
    print()


def print_compact_status() -> None:
    """Print a single-line swarm health summary for the boot sequence."""
    data = get_dashboard_data()
    s = data["summary"]
    total = s["total"]
    healthy = s["healthy"]
    degraded = s["degraded"]
    offline = s["offline"]

    if total == 0:
        print(f"[HEALTH] Swarm Health: No agents registered")
    elif healthy == total:
        print(f"[HEALTH] Swarm Health: {_GREEN}{healthy}/{total} agents healthy{_RESET} [OK]")
    else:
        print(
            f"[HEALTH] Swarm Health: {_GREEN}{healthy}{_RESET} healthy, "
            f"{_YELLOW}{degraded}{_RESET} degraded, "
            f"{_RED}{offline}{_RESET} offline "
            f"(out of {total})"
        )
