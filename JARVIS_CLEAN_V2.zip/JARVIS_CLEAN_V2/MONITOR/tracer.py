import os
import json
import uuid
import time
import logging
import collections
from datetime import datetime, timezone
from contextvars import ContextVar
from typing import Dict, Any, Optional, List

# Context variable to hold the current trace_id implicitly across async bounds
_trace_id_var: ContextVar[str] = ContextVar("trace_id", default="")

class Span:
    def __init__(self, trace_id: str, span_id: str, parent_id: Optional[str], name: str, metadata: Dict[str, Any]):
        self.trace_id = trace_id
        self.span_id = span_id
        self.parent_id = parent_id
        self.name = name
        self.metadata = metadata
        self.start_time = time.time()
        self.end_time = None
        self.status = "running"
        self.error = None
        self.result = None

    def end(self, status: str = "success", error: str = None, result: Any = None, metadata: Dict[str, Any] = None):
        self.end_time = time.time()
        self.status = status
        self.error = error
        self.result = result
        if metadata:
            self.metadata.update(metadata)
        
        # Calculate execution time in milliseconds
        execution_time_ms = round((self.end_time - self.start_time) * 1000, 2)
        
        # Prepare the structured log payload
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "parent_id": self.parent_id,
            "name": self.name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "execution_time_ms": execution_time_ms,
            "status": self.status,
            "error": self.error,
            "metadata": self.metadata,
        }
        
        # Remove empty result or error
        if self.result is not None:
            try:
                payload["result"] = str(self.result)[:500]
            except Exception:
                payload["result"] = "Unserializable Result"
        
        # Submit to TraceManager
        TraceManager._record_span(payload)
        
        # Integrate with MetricsManager
        try:
            from MONITOR.metrics import metrics_manager
            
            agent_id = self.metadata.get("agent", self.name)
            metrics_manager.record(
                agent_id=agent_id,
                action=self.name,
                success=self.status.lower() == "success",
                duration_ms=execution_time_ms,
                retries=self.metadata.get("retries", 0),
                used_fallback=self.metadata.get("used_fallback", False),
                error=self.error
            )
        except Exception as e:
            logging.getLogger("TRACER").error(f"Failed to update metrics: {e}")


class TraceManager:
    """Distributed tracing for JARVIS request lifecycle with in-memory buffering."""
    
    LOG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs", "traces.jsonl")
    
    # In-memory buffer: trace_id -> list of span payloads
    MAX_TRACES = 100
    _traces_in_memory: collections.OrderedDict = collections.OrderedDict()
    
    @classmethod
    def setup(cls):
        os.makedirs(os.path.dirname(cls.LOG_FILE), exist_ok=True)
        
    @classmethod
    def generate_trace_id(cls) -> str:
        """Generates a new trace ID and sets it in the current context."""
        new_trace_id = f"trace_{uuid.uuid4().hex}"
        _trace_id_var.set(new_trace_id)
        
        # Initialize trace list in memory
        if new_trace_id not in cls._traces_in_memory:
            cls._traces_in_memory[new_trace_id] = []
            
        # Maintain bounds
        if len(cls._traces_in_memory) > cls.MAX_TRACES:
            cls._traces_in_memory.popitem(last=False)
            
        return new_trace_id
        
    @classmethod
    def get_current_trace_id(cls) -> str:
        """Retrieves the current trace ID from context."""
        return _trace_id_var.get()

    @classmethod
    def set_trace_id(cls, trace_id: str):
        """Manually sets the trace ID in context."""
        _trace_id_var.set(trace_id)

    @classmethod
    def start_span(cls, name: str, parent_id: str = None, metadata: Dict[str, Any] = None) -> Span:
        """Starts a new observability span."""
        trace_id = cls.get_current_trace_id()
        if not trace_id:
            # Ensure we always have a trace_id if none exists in context
            trace_id = cls.generate_trace_id()
            
        span_id = f"span_{uuid.uuid4().hex[:12]}"
        
        return Span(
            trace_id=trace_id,
            span_id=span_id,
            parent_id=parent_id,
            name=name,
            metadata=metadata or {}
        )

    @classmethod
    def _record_span(cls, payload: dict):
        """Append the structured JSON log entry and store in memory."""
        # 1. Write to memory
        trace_id = payload.get("trace_id")
        if trace_id:
            if trace_id not in cls._traces_in_memory:
                cls._traces_in_memory[trace_id] = []
                if len(cls._traces_in_memory) > cls.MAX_TRACES:
                    cls._traces_in_memory.popitem(last=False)
            
            cls._traces_in_memory[trace_id].append(payload)

        # 2. Write to disk
        try:
            with open(cls.LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(payload) + "\n")
        except Exception as e:
            logging.getLogger("TRACER").error(f"Failed to write trace log: {e}")

    @classmethod
    def get_trace(cls, trace_id: str) -> List[dict]:
        """Returns all spans for a given trace_id."""
        return cls._traces_in_memory.get(trace_id, [])

    @classmethod
    def get_last_trace_id(cls) -> Optional[str]:
        """Returns the most recent trace_id."""
        if not cls._traces_in_memory:
            return None
        # In OrderedDict, the last item is at the end
        return list(cls._traces_in_memory.keys())[-1]

    @classmethod
    def format_trace_output(cls, trace_id: str) -> str:
        """Formats a trace into a readable text summary."""
        spans = cls.get_trace(trace_id)
        if not spans:
            return f"Trace '{trace_id}' not found in memory."
            
        # Sort by start_time
        spans.sort(key=lambda s: s.get("start_time", 0))
        
        lines = [f"[TRACE: {trace_id}]"]
        for i, span in enumerate(spans):
            name = span.get("name", "UNKNOWN")
            duration = span.get("execution_time_ms", 0)
            status = span.get("status", "unknown").upper()
            
            meta = span.get("metadata", {})
            meta_str = ""
            if meta:
                # Highlight key metrics
                parts = []
                if "retries" in meta: parts.append(f"retries={meta['retries']}")
                if "used_fallback" in meta: parts.append(f"fallback={meta['used_fallback']}")
                if "agent" in meta: parts.append(f"agent={meta['agent']}")
                if parts:
                    meta_str = f" ({', '.join(parts)})"
            
            error_str = f" - ERROR: {span.get('error')}" if status == "FAILED" else ""
            
            lines.append(f"  {i+1}. {name} [{status}] -> {duration}ms{meta_str}{error_str}")
            
        return "\n".join(lines)


# Alias for backward compatibility across the codebase
Tracer = TraceManager

# Ensure log dir exists
TraceManager.setup()
