# ================================================================
# JARVIS AETHER-CORE V2.0 — METRICS MANAGER
# ================================================================
# Codename: PULSE
# Role: Runtime performance metrics with rolling window analytics
# Layer: MONITOR
# ================================================================

import time
import collections
import threading
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timezone

logger = logging.getLogger("METRICS")


class RequestRecord:
    """Immutable record of a single request's execution metrics."""
    __slots__ = (
        "timestamp", "agent_id", "action", "success",
        "duration_ms", "retries", "used_fallback", "error"
    )

    def __init__(self, agent_id: str, action: str, success: bool,
                 duration_ms: float, retries: int = 0,
                 used_fallback: bool = False, error: str = None):
        self.timestamp = time.time()
        self.agent_id = agent_id
        self.action = action
        self.success = success
        self.duration_ms = round(duration_ms, 2)
        self.retries = retries
        self.used_fallback = used_fallback
        self.error = error

    def to_dict(self) -> dict:
        return {
            "timestamp": datetime.fromtimestamp(self.timestamp, tz=timezone.utc).isoformat(),
            "agent_id": self.agent_id,
            "action": self.action,
            "success": self.success,
            "duration_ms": self.duration_ms,
            "retries": self.retries,
            "used_fallback": self.used_fallback,
            "error": self.error,
        }


class MetricsManager:
    """
    Runtime performance analytics engine for JARVIS.

    Maintains a rolling window of the last N request records and
    computes aggregate statistics on demand. Thread-safe.
    """

    def __init__(self, window_size: int = 100):
        self._window_size = window_size
        self._records: collections.deque = collections.deque(maxlen=window_size)
        self._lock = threading.Lock()

        # Lifetime counters (never reset)
        self._lifetime_total: int = 0
        self._lifetime_success: int = 0
        self._lifetime_failure: int = 0

    # ── Recording ─────────────────────────────────────────────

    def record(self, agent_id: str, action: str, success: bool,
               duration_ms: float, retries: int = 0,
               used_fallback: bool = False, error: str = None):
        """Record a completed request into the rolling window."""
        rec = RequestRecord(
            agent_id=agent_id,
            action=action,
            success=success,
            duration_ms=duration_ms,
            retries=retries,
            used_fallback=used_fallback,
            error=error,
        )
        with self._lock:
            self._records.append(rec)
            self._lifetime_total += 1
            if success:
                self._lifetime_success += 1
            else:
                self._lifetime_failure += 1

    # ── Aggregation ───────────────────────────────────────────

    def get_metrics(self) -> Dict[str, Any]:
        """
        Compute and return all runtime metrics.

        Returns a dict with:
        - total_requests (lifetime)
        - window_requests (in current rolling window)
        - success_rate (0.0 - 1.0)
        - failure_rate (0.0 - 1.0)
        - avg_response_time_ms
        - p95_response_time_ms
        - max_response_time_ms
        - slowest_agents (top 5 by avg duration)
        - retry_frequency (retries / total)
        - fallback_frequency (fallbacks / total)
        - recent_errors (last 5 errors)
        """
        with self._lock:
            records = list(self._records)

        total = len(records)
        if total == 0:
            return {
                "total_requests": self._lifetime_total,
                "success_count": self._lifetime_success,
                "failure_count": self._lifetime_failure,
                "window_requests": 0,
                "success_rate": 0.0,
                "failure_rate": 0.0,
                "avg_response_time_ms": 0.0,
                "p95_response_time_ms": 0.0,
                "max_response_time_ms": 0.0,
                "slowest_agents": [],
                "retry_count": 0,
                "retry_frequency": 0.0,
                "fallback_frequency": 0.0,
                "recent_errors": [],
            }

        successes = sum(1 for r in records if r.success)
        failures = total - successes
        durations = [r.duration_ms for r in records]
        durations_sorted = sorted(durations)
        total_retries = sum(r.retries for r in records)
        total_fallbacks = sum(1 for r in records if r.used_fallback)

        # P95 latency and Max latency
        p95_idx = int(len(durations_sorted) * 0.95)
        p95 = durations_sorted[min(p95_idx, len(durations_sorted) - 1)]
        max_response = durations_sorted[-1]

        # Slowest agents (top 5 by average duration)
        agent_durations: Dict[str, List[float]] = {}
        for r in records:
            agent_durations.setdefault(r.agent_id, []).append(r.duration_ms)

        slowest = sorted(
            [
                {"agent_id": aid, "avg_ms": round(sum(durs) / len(durs), 2), "calls": len(durs)}
                for aid, durs in agent_durations.items()
            ],
            key=lambda x: x["avg_ms"],
            reverse=True,
        )[:5]

        # Recent errors (last 5)
        errors = [
            {"agent_id": r.agent_id, "action": r.action, "error": r.error}
            for r in reversed(records) if r.error
        ][:5]

        return {
            "total_requests": self._lifetime_total,
            "success_count": self._lifetime_success,
            "failure_count": self._lifetime_failure,
            "window_requests": total,
            "success_rate": round(successes / total, 4),
            "failure_rate": round(failures / total, 4),
            "avg_response_time_ms": round(sum(durations) / total, 2),
            "p95_response_time_ms": round(p95, 2),
            "max_response_time_ms": round(max_response, 2),
            "slowest_agents": slowest,
            "retry_count": total_retries,
            "retry_frequency": round(total_retries / total, 4),
            "fallback_frequency": round(total_fallbacks / total, 4),
            "recent_errors": errors,
        }

    def get_agent_stats(self) -> Dict[str, Any]:
        """
        Compute and return per-agent stats within the rolling window.
        """
        with self._lock:
            records = list(self._records)
            
        agent_stats = {}
        for r in records:
            if r.agent_id not in agent_stats:
                agent_stats[r.agent_id] = {
                    "execution_count": 0,
                    "failures": 0,
                    "total_time_ms": 0.0
                }
            
            stats = agent_stats[r.agent_id]
            stats["execution_count"] += 1
            if not r.success:
                stats["failures"] += 1
            stats["total_time_ms"] += r.duration_ms
            
        result = {}
        for aid, stats in agent_stats.items():
            exec_count = stats["execution_count"]
            result[aid] = {
                "execution_count": exec_count,
                "avg_time": round(stats["total_time_ms"] / exec_count, 2),
                "failure_rate": round(stats["failures"] / exec_count, 4)
            }
            
        return result

    # ── Display ───────────────────────────────────────────────

    def print_metrics(self) -> str:
        """Return a formatted string of the current metrics dashboard."""
        m = self.get_metrics()

        lines = [
            "╔══════════════════════════════════════════════════╗",
            "║        JARVIS RUNTIME METRICS (PULSE)            ║",
            "╠══════════════════════════════════════════════════╣",
            f"║  Total Requests (Lifetime)  : {m['total_requests']:<18} ║",
            f"║  Window Requests (Last {self._window_size})  : {m['window_requests']:<18} ║",
            f"║  Success Count              : {m['success_count']:<18} ║",
            f"║  Failure Count              : {m['failure_count']:<18} ║",
            f"║  Avg Response Time          : {m['avg_response_time_ms']:.1f}ms{'':<13}║",
            f"║  Max Response Time          : {m['max_response_time_ms']:.1f}ms{'':<13}║",
            f"║  Retry Count                : {m['retry_count']:<18} ║",
            "╠══════════════════════════════════════════════════╣",
            "║  SLOWEST AGENTS (Top 5)                          ║",
        ]

        if m["slowest_agents"]:
            for i, agent in enumerate(m["slowest_agents"]):
                lines.append(f"║   {i+1}. {agent['agent_id']:<20} {agent['avg_ms']:>8.1f}ms  ({agent['calls']} calls) ║")
        else:
            lines.append("║   No agent data yet.                             ║")

        lines.append("╠══════════════════════════════════════════════════╣")
        lines.append("║  RECENT ERRORS                                   ║")

        if m["recent_errors"]:
            for err in m["recent_errors"]:
                err_msg = (err["error"] or "Unknown")[:30]
                lines.append(f"║   [{err['agent_id']}] {err_msg:<35}║")
        else:
            lines.append("║   No errors recorded.                            ║")

        lines.append("╚══════════════════════════════════════════════════╝")

        return "\n".join(lines)

    def print_agent_stats(self) -> str:
        """Return a formatted string of per-agent statistics."""
        stats = self.get_agent_stats()
        
        lines = [
            "╔══════════════════════════════════════════════════╗",
            "║        JARVIS AGENT STATS (PULSE)                ║",
            "╠══════════════════════════════════════════════════╣",
        ]
        
        if not stats:
            lines.append("║   No agent data yet.                             ║")
        else:
            for aid, st in stats.items():
                lines.append(f"║  [{aid[:15]:<15}]                          ║")
                lines.append(f"║   Execution Count : {st['execution_count']:<28} ║")
                lines.append(f"║   Avg Time        : {st['avg_time']:.1f}ms{'':<22} ║")
                lines.append(f"║   Failure Rate    : {st['failure_rate']*100:.1f}%{'':<23} ║")
                lines.append("╠══════════════════════════════════════════════════╣")
                
        lines.append("╚══════════════════════════════════════════════════╝")
        return "\n".join(lines)

    # ── Utilities ─────────────────────────────────────────────

    def reset(self):
        """Clear all records and counters."""
        with self._lock:
            self._records.clear()
            self._lifetime_total = 0
            self._lifetime_success = 0
            self._lifetime_failure = 0


# Global singleton
metrics_manager = MetricsManager()
