# ⚡ J.A.R.V.I.S
### Joint Autonomous Responsive Virtual Intelligent System
**Owner:** Ajmain Adil | **Platform:** Aether Core OS | **Version:** 2.0 (AETHER-CORE)

---

## 📁 Full Folder Structure

```
JARVIS/
│
├── main.py                          ← Entry point — run this to start
├── requirements.txt                 ← All Python dependencies
│
├── KERNEL/                          ⚙️  Core Controller (Master Brain)
│   ├── kernel.py                    ← Master orchestrator — routes everything
│   ├── scheduler.py                 ← Middleware base class (like RAM)
│   └── router.py                    ← Intent classifier & task router
│
├── SENSOR/                          📡 Input/Output Pipeline (Senses)
│   ├── vision.py                    ← Camera feed, face detection, object recognition
│   ├── microphone.py                ← Voice input, wake word, stop command
│   ├── tts.py                       ← Text-to-speech output
│   └── logger.py                    ← Real-time event recorder
│
├── INFERENCE/                       🧠 AI Engine (Thinking)
│   ├── online.py                    ← Groq API + Gemini API
│   ├── offline.py                   ← Ollama + Qwen2.5 (no internet needed)
│   └── pipeline.py                  ← Picks best AI response automatically
│
├── EXECUTOR/                        🖥️  System Command Handler (Hands)
│   ├── monitor.py                   ← CPU, RAM, disk, battery live stats
│   ├── syscall.py                   ← Volume, brightness, WiFi, Bluetooth
│   ├── filesystem.py                ← Create, move, delete, search files
│   └── process.py                   ← Start, kill, list running processes
│
├── CRAWLER/                         🌐 Web Engine (Eyes on the Internet)
│   ├── search.py                    ← DuckDuckGo web search
│   └── parser.py                    ← Fetch & summarize web pages
│
├── RENDERER/                        🖼️  UI / HUD Display (Face)
│   ├── display.py                   ← Controls the HUD interface via Eel
│   └── web/
│       ├── index.html               ← Iron Man HUD layout
│       ├── style.css                ← Cinematic dark UI styles
│       └── app.js                   ← Real-time updates & animations
│
├── DAEMON/                          🔔 Background Services (Subconscious)
│   ├── tracker.py                   ← Monitors active apps & user behavior
│   ├── reminder.py                  ← Task scheduler & deadline alerts
│   ├── watchdog.py                  ← Reads OS notifications, asks before showing
│   └── synthesizer.py               ← Context-aware speech generator
│
├── DRIVER/                          🚀 Action Executor (Motor System)
│   ├── launcher.py                  ← Opens/closes apps by voice command
│   └── gmail.py                     ← Read inbox, send emails, alert on new mail
│
├── HEAP/                            💾 Memory & Storage (Long-term Memory)
│   ├── database.py                  ← SQLite permanent DB (conversations, tasks, knowledge)
│   ├── cache.py                     ← Fast JSON session cache
│   └── vault.py                     ← Owner's private secure database
│
├── TRAINER/                         📚 Self-Learning Engine (Plasticity)
│   ├── learner.py                   ← Learns patterns from past conversations
│   ├── updater.py                   ← Auto-checks & applies model/library updates
│   └── indexer.py                   ← Stores & indexes new knowledge over time
│
├── GATEWAY/                         🔐 Access Control (Identity & Security)
│   ├── auth.py                      ← Recognizes owner via face + voice
│   ├── guest.py                     ← Limited guest interaction mode
│   └── firewall.py                  ← Permission rules for all agents
│
└── CONFIG/                          ⚙️  Settings (System Config)
    ├── config.py                    ← OS auto-detect, paths, API keys, all settings
    └── .env                         ← Secret API keys (never share this file)
```

---

## 🗺️ Phase-by-Phase Build Plan

---

### ✅ PHASE 1 — Foundation (KERNEL + HEAP + CONFIG)
> **Goal:** System boots, memory works, commands route correctly

| File | কাজ |
|---|---|
| `CONFIG/config.py` | OS auto-detect (Windows/Ubuntu), all paths & API keys |
| `HEAP/database.py` | SQLite schema — conversations, tasks, knowledge, agent logs |
| `HEAP/cache.py` | Fast JSON session cache |
| `HEAP/vault.py` | Owner private secure database |
| `KERNEL/scheduler.py` | Base middleware class — all managers inherit from this |
| `KERNEL/kernel.py` | Master controller — registers managers, routes tasks |
| `KERNEL/router.py` | Intent classifier — figures out what user wants |
| `main.py` | Entry point — boots system, starts text input loop |

**Phase 1 End Result:** JARVIS boots, accepts text commands, logs everything to DB ✓

---

### 🔄 PHASE 2 — Sensory Layer (SENSOR)
> **Goal:** JARVIS can hear, speak, and see

| File | কাজ |
|---|---|
| `SENSOR/microphone.py` | Wake word detection + Whisper speech-to-text |
| `SENSOR/tts.py` | pyttsx3 text-to-speech + stop interrupt |
| `SENSOR/vision.py` | OpenCV camera feed + face_recognition for owner |
| `SENSOR/logger.py` | Real-time event logging to HEAP/database |

**Phase 2 End Result:** JARVIS listens for "Hey JARVIS", responds by voice, sees through camera ✓

---

### 🔄 PHASE 3 — Intelligence Layer (INFERENCE)
> **Goal:** JARVIS can think and answer using AI

| File | কাজ |
|---|---|
| `INFERENCE/online.py` | Groq API + Gemini API integration |
| `INFERENCE/offline.py` | Ollama + Qwen2.5 local model |
| `INFERENCE/pipeline.py` | Auto-switch online/offline, pick best response |

**Phase 3 End Result:** JARVIS answers questions online & offline, auto-switches if internet is gone ✓

---

### 🔄 PHASE 4 — PC Control + HUD (EXECUTOR + RENDERER)
> **Goal:** JARVIS controls the PC and shows cinematic HUD

| File | কাজ |
|---|---|
| `EXECUTOR/monitor.py` | Live CPU, RAM, disk, battery stats |
| `EXECUTOR/syscall.py` | Volume, brightness, WiFi by voice |
| `EXECUTOR/filesystem.py` | File operations by command |
| `EXECUTOR/process.py` | Kill/start processes |
| `RENDERER/display.py` | Eel bridge — Python talks to HUD |
| `RENDERER/web/index.html` | Iron Man style HUD layout |
| `RENDERER/web/style.css` | Dark cinematic UI |
| `RENDERER/web/app.js` | Real-time data updates on HUD |

**Phase 4 End Result:** Full Iron Man HUD showing live stats, JARVIS controls PC by voice ✓

---

### 🔄 PHASE 5 — Awareness + Actions (DAEMON + DRIVER + CRAWLER)
> **Goal:** JARVIS is proactive, handles email, browses web

| File | কাজ |
|---|---|
| `DAEMON/tracker.py` | Monitors active windows & behavior |
| `DAEMON/reminder.py` | Set & announce reminders |
| `DAEMON/watchdog.py` | Reads notifications, asks before showing |
| `DAEMON/synthesizer.py` | Context-aware speech with vision data |
| `DRIVER/launcher.py` | Open/close any app by voice |
| `DRIVER/gmail.py` | Gmail OAuth2 — read, send, alert |
| `CRAWLER/search.py` | DuckDuckGo search |
| `CRAWLER/parser.py` | Web page fetch & summarize |

**Phase 5 End Result:** JARVIS manages notifications, emails, reminders, and browses web ✓

---

### 🔄 PHASE 6 — Identity + Learning (GATEWAY + TRAINER)
> **Goal:** JARVIS knows its owner, learns over time

| File | কাজ |
|---|---|
| `GATEWAY/auth.py` | Face + voice owner recognition |
| `GATEWAY/guest.py` | Guest limited mode |
| `GATEWAY/firewall.py` | Permission system for all agents |
| `TRAINER/learner.py` | Learns from conversation history |
| `TRAINER/updater.py` | Auto-updates models & libraries |
| `TRAINER/indexer.py` | Indexes new knowledge to HEAP |

**Phase 6 End Result:** JARVIS recognizes owner vs guest, grows smarter every day ✓

---

## 📊 Current Build Status

| Phase | Module | Status |
|-------|--------|--------|
| Phase 1 | KERNEL + HEAP + CONFIG | 🔄 In Progress |
| Phase 2 | SENSOR | ⏳ Planned |
| Phase 3 | INFERENCE | ⏳ Planned |
| Phase 4 | EXECUTOR + RENDERER | ⏳ Planned |
| Phase 5 | DAEMON + DRIVER + CRAWLER | ⏳ Planned |
| Phase 6 | GATEWAY + TRAINER | ⏳ Planned |

---

## 🧠 Architecture Summary

```
           ┌─────────────────────────┐
           │     KERNEL/kernel.py    │  ← Master (CPU)
           └──────────┬──────────────┘
                      │
         ┌────────────┼────────────┐
         │            │            │
   KERNEL/         KERNEL/      KERNEL/
   scheduler.py    router.py   (managers)
         │
   ┌─────┴──────────────────────────────┐
   │                                    │
SENSOR    INFERENCE    EXECUTOR    CRAWLER
DAEMON    DRIVER       GATEWAY     TRAINER
   │                                    │
   └──────────────┬─────────────────────┘
                  │
            HEAP/ (database)
            CONFIG/ (settings)
            RENDERER/ (HUD)
```

---

## 🚀 How to Run (Phase 1)

```bash
# Step 1 — Go to project folder
cd ~/JARVIS

# Step 2 — Install dependencies
pip3 install -r requirements.txt

# Step 3 — Run JARVIS
python3 main.py
```

---

## ⚙️ Tech Stack

| Layer | Technology |
|---|---|
| Online AI | Groq (llama-3.3-70b) + Gemini API |
| Offline AI | Ollama + Qwen2.5:7b |
| Voice Input | Whisper + SpeechRecognition |
| Voice Output | pyttsx3 |
| Vision | OpenCV + face_recognition |
| UI | Python Eel + HTML/CSS/JS |
| Database | SQLite3 |
| Email | Gmail API (OAuth2) |
| Web | duckduckgo-search + BeautifulSoup4 |
| PC Control | psutil + pyautogui + subprocess |
| Language | Python 3.12+ |

---

*"You did not just design an AI assistant. You designed an AI Operating System."*
