@echo off
title JARVIS Restart
color 0E

echo ================================================================
echo    J.A.R.V.I.S  —  RESTART SEQUENCE
echo ================================================================
echo.

echo [1/3] Stopping JARVIS...
call "%~dp0stop.bat" <nul

echo [2/3] Cooldown...
timeout /t 2 /nobreak >nul

echo [3/3] Rebooting...
call "%~dp0start.bat"
