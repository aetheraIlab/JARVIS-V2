# ================================================================
# JARVIS AETHER-CORE V2.0 — SECURE CONFIGURATION
# ================================================================
# Role     : Production-grade environment-based config loader
# Security : All secrets loaded from .env — NEVER hardcoded
# Usage    : from CONFIG.secure_config import config
# ================================================================

import os
import logging
from pathlib import Path
from dotenv import load_dotenv

logger = logging.getLogger("SECURE-CONFIG")


class SecureConfig:
    """
    Centralized, class-based configuration manager for JARVIS.

    Loads all secrets from the project-root .env file and exposes them
    as validated, read-only properties. Replaces the legacy
    CONFIG/api_keys.py and CONFIG/api_keys_secure.py modules.

    Usage:
        from CONFIG.secure_config import config
        key = config.groq_key
    """

    _PLACEHOLDER_VALUES = frozenset({
        "your_groq_api_key_here",
        "your_gemini_api_key_here",
        "your_elevenlabs_api_key_here",
        "your_serpapi_key_here",
        "your_pushbullet_token_here",
        "",
        None,
    })

    def __init__(self):
        env_path = Path(__file__).resolve().parent.parent / ".env"
        if env_path.exists():
            load_dotenv(env_path, override=False)
            logger.info(f"[SECURE-CONFIG] Loaded .env from {env_path}")
        else:
            logger.warning(
                f"[SECURE-CONFIG] No .env file found at {env_path}. "
                "Using system environment variables only."
            )
        self._validate()

    # ── Validation ────────────────────────────────────────────────
    def _validate(self):
        """Check that critical keys are present and not placeholders."""
        required = ["GROQ_API_KEY", "GEMINI_API_KEY"]
        missing = [
            k for k in required
            if os.getenv(k) in self._PLACEHOLDER_VALUES
        ]
        if missing:
            logger.warning(
                f"[SECURE-CONFIG] [WARN] Missing or placeholder API keys: "
                f"{', '.join(missing)}. Some features will be degraded."
            )
            
        # Log specific keys for debugging as requested
        for key in ["OPENWEATHER_API_KEY", "NEWS_API_KEY"]:
            status = "LOADED" if self._is_real(key) else "MISSING"
            print(f"[CONFIG] {key}: {status}")

    # ── Helper ────────────────────────────────────────────────────
    def _get(self, key: str, default: str = "") -> str:
        """Get a value, returning default if missing or placeholder."""
        val = os.getenv(key, default)
        return val if val not in self._PLACEHOLDER_VALUES else default

    def _is_real(self, key: str) -> bool:
        """True if the key is set and is NOT a placeholder."""
        return os.getenv(key) not in self._PLACEHOLDER_VALUES

    # ── AI Service Keys ───────────────────────────────────────────
    @property
    def groq_key(self) -> str:
        return self._get("GROQ_API_KEY")

    @property
    def gemini_key(self) -> str:
        return self._get("GEMINI_API_KEY")

    @property
    def has_groq(self) -> bool:
        return self._is_real("GROQ_API_KEY")

    @property
    def has_gemini(self) -> bool:
        return self._is_real("GEMINI_API_KEY")

    # ── Optional Service Keys ─────────────────────────────────────
    @property
    def elevenlabs_key(self) -> str:
        return self._get("ELEVENLABS_API_KEY")

    @property
    def serpapi_key(self) -> str:
        return self._get("SERPAPI_KEY")

    @property
    def openweather_api_key(self) -> str:
        return self._get("OPENWEATHER_API_KEY")
        
    @property
    def news_api_key(self) -> str:
        return self._get("NEWS_API_KEY")
        
    @property
    def alpha_vantage_api_key(self) -> str:
        return self._get("ALPHA_VANTAGE_API_KEY")

    @property
    def pushbullet_token(self) -> str:
        return self._get("PUSHBULLET_TOKEN")

    # ── Model Configuration ───────────────────────────────────────
    @property
    def groq_model(self) -> str:
        return os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

    @property
    def gemini_model(self) -> str:
        return os.getenv("GEMINI_MODEL", "gemini-1.5-pro")

    @property
    def offline_model(self) -> str:
        return os.getenv("OFFLINE_MODEL", "gemma3:4b")

    @property
    def ollama_url(self) -> str:
        return os.getenv("OLLAMA_URL", "http://localhost:11434")

    # ── System Configuration ──────────────────────────────────────
    @property
    def vault_password(self) -> str:
        return os.getenv("VAULT_MASTER_PASSWORD", "")

    @property
    def vault_salt(self) -> str:
        return os.getenv("VAULT_SALT", "")

    @property
    def atlas_db_path(self) -> str:
        return os.getenv("ATLAS_DB_PATH", "HEAP/atlas.db")

    @property
    def debug(self) -> bool:
        return os.getenv("DEBUG_MODE", "False").lower() in ("true", "1", "yes")

    @property
    def log_level(self) -> str:
        return os.getenv("JARVIS_LOG_LEVEL", "INFO").upper()

    # ── Backward Compatibility ────────────────────────────────────
    # These properties allow old code to use config.GROQ_API_KEY style
    @property
    def GROQ_API_KEY(self) -> str:
        return self.groq_key

    @property
    def GEMINI_API_KEY(self) -> str:
        return self.gemini_key

    @property
    def ELEVENLABS_API_KEY(self) -> str:
        return self.elevenlabs_key

    @property
    def SERPAPI_KEY(self) -> str:
        return self.serpapi_key

    @property
    def PUSHBULLET_TOKEN(self) -> str:
        return self.pushbullet_token

    def __repr__(self):
        return (
            f"SecureConfig(groq={'[OK]' if self.has_groq else '[FAIL]'}, "
            f"gemini={'[OK]' if self.has_gemini else '[FAIL]'}, "
            f"debug={self.debug})"
        )


# ── Singleton Instance ────────────────────────────────────────────
# Import this directly:  from CONFIG.secure_config import config
config = SecureConfig()

# ── Legacy Compatibility Exports ──────────────────────────────────
# These allow:  from CONFIG.secure_config import GROQ_API_KEY
GROQ_API_KEY = config.groq_key
GEMINI_API_KEY = config.gemini_key
ELEVENLABS_API_KEY = config.elevenlabs_key
SERPAPI_KEY = config.serpapi_key
PUSHBULLET_TOKEN = config.pushbullet_token
