# ================================================================
# JARVIS AETHER-CORE V2.0 — CONSTANTS
# ================================================================

# --- System Identity ---
NAME     = "JARVIS"
FULL_NAME = "Joint Autonomous Responsive Virtual Intelligent System"
VERSION  = "2.0"
CODENAME = "AETHER-CORE"
DESIGNER = "Adil"

# --- AI Model Stack ---
ONLINE_MODELS = {
    "primary":   "llama-3.3-70b-versatile",     # Groq — FAST & FREE
    "secondary": "gemini-3-flash-preview",       # Gemini 3 Flash — fallback
}

OFFLINE_MODELS = {
    "primary":   "gemma4:4b",                    # Gemma 4 — tool-calling native
    "secondary": "qwen2.5:7b",                   # Qwen backup
}

VOICE_MODEL  = "gemini-3.1-flash-live-preview"   # Voice-only model
IMAGE_MODEL  = "gemini-3-pro-image-preview"      # Image generation model

# Legacy aliases (backward compat)
PRIMARY_ONLINE_MODEL    = ONLINE_MODELS["primary"]
SECONDARY_ONLINE_MODEL  = ONLINE_MODELS["secondary"]
PRIMARY_OFFLINE_MODEL   = OFFLINE_MODELS["primary"]
SECONDARY_OFFLINE_MODEL = OFFLINE_MODELS["secondary"]

# --- Sensory Settings ---
WAKE_WORD  = "jarvis"
STOP_WORDS = ["stop", "quiet", "chup", "thamo", "bas"]
TTS_RATE   = 180      # কথা বলার গতি
VISION_FPS = 10       # ক্যামেরা ফ্রেম রেট

# --- Performance ---
MAX_CONVERSATION_HISTORY = 20 # লাস্ট ২০টি মেসেজ মেমরিতে রাখা হবে
BUS_TICK_RATE = 0.1           # APEX সিগন্যাল চেক ইন্টারভ্যাল (সেকেন্ড)

# --- UI Branding ---
HUD_THEME = "dark_cyan"
HUD_UI_SCALE = 1.0
