# ================================================================
# JARVIS AETHER-CORE V2.0 — CONFIG (PATH-RESOLVER)
# ================================================================
import os
import platform
from pathlib import Path

# --- OS Detection ---
SYSTEM = platform.system()

# --- Base Data Path Logic (Cross-Platform) ---
# উইন্ডোজ এবং উবুন্টুর জন্য আলাদা পাথ সেট করা হয় যেন একই কোড উভয় জায়গায় চলে
if SYSTEM == "Windows":
    BASE_DIR = Path.home() / "AppData" / "Local" / "JARVIS_DATA"
elif SYSTEM == "Darwin":
    BASE_DIR = Path.home() / "Library" / "Application Support" / "JARVIS_DATA"
else:
    BASE_DIR = Path.home() / ".local" / "share" / "jarvis_data"

# --- Sub-Directory Structure ---
LOG_DIR       = BASE_DIR / "logs"
VOICE_DIR     = BASE_DIR / "voice_cache"
VISION_DIR    = BASE_DIR / "vision_data"
KNOWLEDGE_DIR = BASE_DIR / "knowledge"
VAULT_DIR     = BASE_DIR / "vault"

# প্রয়োজনীয় ফোল্ডারগুলো অটোমেটিক তৈরি করা হয়
for folder in [BASE_DIR, LOG_DIR, VOICE_DIR, VISION_DIR, KNOWLEDGE_DIR, VAULT_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

# --- File Paths ---
DB_PATH    = BASE_DIR / "jarvis_memory.db"
CACHE_PATH = BASE_DIR / "cache.json"

if __name__ == "__main__":
    print(f"[CONFIG] Detected System : {SYSTEM}")
    print(f"[CONFIG] Base Directory  : {BASE_DIR}")
    print("[CONFIG] All directories verified/created.")
