# ================================================================
# JARVIS AETHER-CORE V2.0 — EXECUTOR-CODE (LAYER 3 / FORGE)
# ================================================================
# Codename : EXECUTOR-CODE
# Role     : Python Code Execution & Analysis Agent
# Tech     : ast + exec + restricted eval 
# ================================================================

import sys
import os
import ast
import time
import re
import io
import logging
from contextlib import redirect_stdout, redirect_stderr
from textwrap import dedent

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if project_root not in sys.path:
    sys.path.insert(0, project_root)


class ExecutorCode:
    """
    JARVIS EXECUTOR-CODE — Python কোড এক্সিকিউটর।
    সীমিত এবং নিরাপদ পরিবেশে Python কোড চালায়।
    
    সাপোর্টেড:
    - সাধারণ Python কোড: ভেরিয়েবল, ফাংশন, লুপ, ইত্যাদি
    - গণনা: math অপারেশন
    - স্ট্রিং ম্যানিপুলেশন
    - ডেটা স্ট্রাকচার: list, dict, set, tuple
    
    ব্লক করা:
    - ফাইল সিস্টেম অ্যাক্সেস (open, os.remove, etc.)
    - নেটওয়ার্ক অপারেশন (socket, requests, etc.)
    - সিস্টেম কল (os.system, subprocess, etc.)
    - ডানজারাস মডিউল ইমপোর্ট (pickle, ctypes, etc.)
    """

    def __init__(self):
        self.logger = logging.getLogger("EXECUTOR-CODE")
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
            
        self._timeout = 30  
        self._max_output = 10000 
        self._blacklist_imports = {
            "os", "sys", "subprocess", "socket", "requests",
            "urllib", "http", "ftplib", "pickle", "ctypes",
            "shutil", "glob", "tempfile", "pathlib",
        }
        self.logger.info("Python code execution agent initialized.")

    def execute(self, code, timeout=None, context=None):
        """
        Python কোড এক্সিকিউট করে এবং আউটপুট রিটার্ন করে।
        
        Args:
            code (str): এক্সিকিউট করার Python কোড
            timeout (int): টাইমআউট সেকেন্ডে (ডিফল্ট: 30)
            context (dict): এক্সিকিউশন কনটেক্সট ভেরিয়েবল
        
        রিটার্ন: {
            "success": bool,
            "output": str,
            "error": str,
            "result": any,
            "duration": float,
            "lines": int
        }
        """
        timeout = timeout or self._timeout
        context = context or {}

        # কোড ভ্যালিডেশন
        validation = self._validate_code(code)
        if not validation["safe"]:
            return self._error_response(validation["reason"])

        # এক্সিকিউশন
        return self._execute_safe(code, timeout, context)

    def _validate_code(self, code):
        """কোড নিরাপত্তা বিশ্লেষণ করে (Hardened AST Sandbox)।"""
        if not code or len(code) > 100000:
            return {"safe": False, "reason": "Code too large or empty."}

        if "__subclasses__" in code:
            return {"safe": False, "reason": "Direct reference to __subclasses__ is blocked for security."}

        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return {"safe": False, "reason": f"Syntax error: {e}"}

        # নিরাপত্তা চেক
        for node in ast.walk(tree):
            # ইমপোর্ট স্টেটমেন্ট চেক
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                module_names = []
                if isinstance(node, ast.Import):
                    module_names = [alias.name for alias in node.names]
                elif isinstance(node, ast.ImportFrom):
                    module_names = [node.module] if node.module else []

                # ব্ল্যাকলিস্ট চেক
                for name in module_names:
                    if name and any(
                        name.startswith(bla) or bla in name
                        for bla in self._blacklist_imports
                    ):
                        return {
                            "safe": False,
                            "reason": f"Module '{name}' is blocked for security."
                        }

            # SECURITY FIX: Block ALL dunder attribute access (__subclasses__, __globals__, etc.)
            # This prevents type().__subclasses__() and obj.__globals__ escape chains.
            if isinstance(node, ast.Attribute):
                if '__' in node.attr:
                    return {
                        "safe": False,
                        "reason": f"Dunder attribute '{node.attr}' access is blocked for security."
                    }

            # ডেঞ্জারাস ফাংশন কল চেক
            if isinstance(node, ast.Call):
                # Case 1: method call → obj.dangerous_method()
                if isinstance(node.func, ast.Attribute):
                    attr_name = node.func.attr
                    dangerous_attrs = {
                        "system", "exec", "eval", "compile", "open",
                        "remove", "popen", "unlink", "rmdir", "rmtree",
                    }
                    if attr_name in dangerous_attrs:
                        return {
                            "safe": False,
                            "reason": f"Function '{attr_name}' is blocked."
                        }

                # Case 2: direct builtin call → exec(), eval(), open() etc.
                if isinstance(node.func, ast.Name):
                    dangerous_builtins = {
                        "exec", "eval", "compile", "open", "__import__",
                        "globals", "locals", "getattr", "setattr", "delattr",
                        "breakpoint", "exit", "quit", "input",
                        # SECURITY FIX: Additional blocked builtins
                        "dir", "vars", "type", "super", "classmethod",
                        "staticmethod", "memoryview", "bytearray",
                    }
                    if node.func.id in dangerous_builtins:
                        return {
                            "safe": False,
                            "reason": f"Builtin '{node.func.id}()' is blocked for security."
                        }

        return {"safe": True, "reason": ""}

    def _execute_safe(self, code, timeout, context):
        """Execute code via SafeExecutorV2 (full subprocess isolation)."""
        from AGENT.safe_executor_v2 import SafeExecutorV2
        
        start = time.time()
        
        if not hasattr(self, '_safe_executor'):
            self._safe_executor = SafeExecutorV2()
        
        result = self._safe_executor.execute_python(
            code=code,
            timeout=timeout,
            allow_network=False,
            context=context,
        )
        
        duration = time.time() - start
        
        return {
            "success": result.success,
            "output": result.stdout.strip() if result.stdout else "",
            "error": result.stderr.strip() if result.stderr else (result.error_summary or ""),
            "result": None,
            "duration": round(duration, 3),
            "lines": len(result.stdout.split("\n")) if result.stdout else 0,
        }

    def _error_response(self, error_msg):
        """ত্রুটি রেসপন্স তৈরি করে।"""
        return {
            "success": False,
            "output": "",
            "error": error_msg,
            "result": None,
            "duration": 0.0,
            "lines": 0,
        }

    def evaluate_expression(self, expression, context=None):
        """
        একটি Python অভিব্যক্তি মূল্যায়ন করে এবং ফলাফল রিটার্ন করে।
        
        যেমন: evaluate_expression("2 ** 10")  → 1024
        """
        context = context or {}
        try:
            # Wrap the expression in a print statement so SafeExecutor can capture the output
            # Import math explicitly for the expression since eval previously had it
            safe_code = f"import math\nprint({expression})"
            
            result = self._execute_safe(safe_code, timeout=5, context=context)
            
            # Since the expression result was printed, it's in the output
            if result["success"]:
                try:
                    # Attempt to parse the printed output back into a python literal
                    import ast
                    val = ast.literal_eval(result["output"])
                except (ValueError, SyntaxError):
                    # Fallback to string representation if it's not a literal
                    val = result["output"]
                    
                return {
                    "success": True,
                    "result": val,
                    "error": "",
                }
            else:
                return {
                    "success": False,
                    "result": None,
                    "error": result["error"],
                }
        except Exception as e:
            return {
                "success": False,
                "result": None,
                "error": str(e),
            }


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  EXECUTOR-CODE — Unit Test")
    print("=" * 60)

    executor = ExecutorCode()

    tests = [
        # মৌলিক গণনা
        ("print(2 + 2)", "Basic arithmetic"),
        ("print([i**2 for i in range(5)])", "List comprehension"),
        ("x = 10\nprint(f'x={x}')", "Variable assignment"),
        
        # স্ট্রিং অপারেশন
        ("text = 'Hello JARVIS'\nprint(text.upper())", "String manipulation"),
        
        # ডেটা স্ট্রাকচার
        ("data = {'name': 'Adil', 'lang': 'Bangla'}\nprint(data)", "Dictionary"),
        
        # ফাংশন সংজ্ঞা
        ("def factorial(n):\n    return 1 if n <= 1 else n * factorial(n-1)\nprint(factorial(5))", "Function definition"),
    ]

    for code, description in tests:
        print(f"\n[TEST] {description}")
        print(f"Code: {code[:50]}...")
        result = executor.execute(code)
        print(f"Success: {result['success']}")
        if result['output']:
            print(f"Output: {result['output'][:100]}")
        print(f"Duration: {result['duration']}s")

    # নিরাপত্তা পরীক্ষা
    print(f"\n[TEST] Security: Blocking file access")
    result = executor.execute("open('/etc/passwd').read()")
    print(f"Blocked: {not result['success']}")
    print(f"Error: {result['error'][:60]}...")

    # অভিব্যক্তি মূল্যায়ন
    print(f"\n[TEST] Expression evaluation: '2 ** 10'")
    result = executor.evaluate_expression("2 ** 10")
    print(f"Result: {result['result']}")

    print("\n" + "=" * 60)
    print("  EXECUTOR-CODE All unit tests complete. ✓")
    print("=" * 60)
