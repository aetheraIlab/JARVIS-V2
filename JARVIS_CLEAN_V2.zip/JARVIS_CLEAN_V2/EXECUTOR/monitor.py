# ================================================================
# JARVIS AETHER-CORE V2.0 — SENTINEL (LAYER 3 / FORGE)
# ================================================================
# Codename : SENTINEL
# Role     : System Monitor Agent — CPU, RAM, Disk, Battery, Network
# Tech     : psutil + platform
# ================================================================

import sys
import os
import platform
import time

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class Sentinel:
    """
    JARVIS SENTINEL — সিস্টেম মনিটরিং এজেন্ট।
    CPU, RAM, ডিস্ক, ব্যাটারি, নেটওয়ার্ক — সবকিছুর লাইভ তথ্য দেয়।
    """

    def __init__(self):
        self._psutil = None
        self._init_monitor()
        print("[SENTINEL] System monitor agent initialized.")

    def _init_monitor(self):
        """psutil লোড করা হচ্ছে।"""
        try:
            import psutil
            self._psutil = psutil
            print("[SENTINEL] psutil loaded.")
        except ImportError:
            print("[SENTINEL] [WARN] psutil not installed. Run: pip install psutil")

    def get_cpu(self):
        """CPU ব্যবহারের শতাংশ।"""
        if not self._psutil:
            return {"error": "psutil unavailable"}
        return {
            "percent": self._psutil.cpu_percent(interval=0.5),
            "cores_physical": self._psutil.cpu_count(logical=False),
            "cores_logical": self._psutil.cpu_count(logical=True),
            "freq_mhz": self._psutil.cpu_freq().current if self._psutil.cpu_freq() else 0,
        }

    def get_ram(self):
        """RAM ব্যবহারের তথ্য।"""
        if not self._psutil:
            return {"error": "psutil unavailable"}
        mem = self._psutil.virtual_memory()
        return {
            "total_gb": round(mem.total / (1024**3), 2),
            "used_gb": round(mem.used / (1024**3), 2),
            "available_gb": round(mem.available / (1024**3), 2),
            "percent": mem.percent,
        }

    def get_disk(self):
        """ডিস্ক স্পেসের তথ্য।"""
        if not self._psutil:
            return {"error": "psutil unavailable"}
        partitions = []
        for p in self._psutil.disk_partitions():
            try:
                usage = self._psutil.disk_usage(p.mountpoint)
                partitions.append({
                    "device": p.device,
                    "mountpoint": p.mountpoint,
                    "total_gb": round(usage.total / (1024**3), 2),
                    "used_gb": round(usage.used / (1024**3), 2),
                    "free_gb": round(usage.free / (1024**3), 2),
                    "percent": usage.percent,
                })
            except PermissionError:
                continue
        return partitions

    def get_battery(self):
        """ব্যাটারি স্ট্যাটাস (ল্যাপটপের জন্য)।"""
        if not self._psutil:
            return {"error": "psutil unavailable"}
        battery = self._psutil.sensors_battery()
        if battery is None:
            return {"status": "no_battery", "plugged": True}
        return {
            "percent": battery.percent,
            "plugged": battery.power_plugged,
            "time_left_min": battery.secsleft // 60 if battery.secsleft > 0 else -1,
        }

    def get_network(self):
        """নেটওয়ার্ক I/O স্ট্যাটিস্টিক্স।"""
        if not self._psutil:
            return {"error": "psutil unavailable"}
        net = self._psutil.net_io_counters()
        return {
            "bytes_sent_mb": round(net.bytes_sent / (1024**2), 2),
            "bytes_recv_mb": round(net.bytes_recv / (1024**2), 2),
        }

    def get_system_info(self):
        """সিস্টেমের সামগ্রিক তথ্য।"""
        return {
            "os": platform.system(),
            "os_version": platform.version(),
            "machine": platform.machine(),
            "hostname": platform.node(),
            "python": platform.python_version(),
        }

    def get_full_report(self):
        """সব তথ্য একসাথে।"""
        return {
            "system": self.get_system_info(),
            "cpu": self.get_cpu(),
            "ram": self.get_ram(),
            "disk": self.get_disk(),
            "battery": self.get_battery(),
            "network": self.get_network(),
        }

    def get_top_processes(self, count=5):
        """সবচেয়ে বেশি CPU ব্যবহারকারী প্রসেস।"""
        if not self._psutil:
            return []
        procs = []
        for proc in self._psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
            try:
                procs.append(proc.info)
            except (self._psutil.NoSuchProcess, self._psutil.AccessDenied):
                continue
        procs.sort(key=lambda x: x.get('cpu_percent', 0), reverse=True)
        return procs[:count]


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 50)
    print("  SENTINEL — Unit Test")
    print("=" * 50)

    s = Sentinel()
    report = s.get_full_report()

    print(f"\n[SYS] OS: {report['system']['os']} {report['system']['os_version']}")
    print(f"[CPU] Usage: {report['cpu']['percent']}% | Cores: {report['cpu']['cores_logical']}")
    print(f"[RAM] {report['ram']['used_gb']}GB / {report['ram']['total_gb']}GB ({report['ram']['percent']}%)")
    print(f"[BAT] {report['battery']}")
    print(f"[NET] Sent: {report['network']['bytes_sent_mb']}MB | Recv: {report['network']['bytes_recv_mb']}MB")

    print(f"\n[TOP PROCESSES]")
    for p in s.get_top_processes(3):
        print(f"  {p['name']} (PID: {p['pid']}) — CPU: {p['cpu_percent']}%")

    print("\n[SENTINEL] Unit test complete. ✓")
