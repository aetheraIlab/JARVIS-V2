# ================================================================
# JARVIS AETHER-CORE V2.0 — FORGE-PROC (LAYER 3 / FORGE)
# ================================================================
# Codename : FORGE-PROC
# Role     : Process Control Agent — List, Kill, Start processes
# Tech     : psutil + subprocess
# ================================================================

import sys
import os
import subprocess
import platform
import time
import logging
import shlex

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

IS_WINDOWS = platform.system() == "Windows"

# Protected system processes that should NOT be killed
PROTECTED_PROCESSES = [
    'svchost', 'explorer', 'winlogon', 'csrss', 'system', 
    'registry', 'dwm', 'lsass', 'services', 'systemd',
    'kernel', 'launchd', 'loginwindow', 'python', 'jarvis',
    'powershell', 'cmd', 'bash', 'zsh', 'terminal'
]


class ForgeProc:
    """
    JARVIS FORGE-PROC — প্রসেস কন্ট্রোল এজেন্ট।
    চলমান প্রসেস দেখা, বন্ধ করা, এবং নতুন প্রসেস শুরু করা।
    """

    def __init__(self):
        self.logger = logging.getLogger("FORGE-PROC")
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
            
        self._psutil = None
        try:
            import psutil
            self._psutil = psutil
        except ImportError:
            self.logger.warning("psutil not installed. Process module degraded.")
        self.logger.info("Process control agent initialized with protected sets.")

    def list_processes(self, count=20):
        """চলমান প্রসেসের তালিকা (CPU usage অনুসারে সাজানো)।"""
        if not self._psutil:
            return []
        procs = []
        for p in self._psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'status']):
            try:
                procs.append(p.info)
            except (self._psutil.NoSuchProcess, self._psutil.AccessDenied):
                continue
        procs.sort(key=lambda x: x.get('cpu_percent', 0), reverse=True)
        return procs[:count]

    def find_process(self, name):
        """নাম দিয়ে প্রসেস খুঁজে বের করে।"""
        if not self._psutil:
            return []
        found = []
        for p in self._psutil.process_iter(['pid', 'name', 'cpu_percent']):
            try:
                if name.lower() in p.info['name'].lower():
                    found.append(p.info)
            except (self._psutil.NoSuchProcess, self._psutil.AccessDenied):
                continue
        return found

    def _is_protected(self, proc_name):
        """চেক করে যে প্রসেসটি সিস্টেম-প্রটেক্টেড কিনা।"""
        name_lower = proc_name.lower().replace('.exe', '')
        return name_lower in [p.lower() for p in PROTECTED_PROCESSES]

    def _safe_kill(self, proc):
        """প্রথমে terminate এবং ব্যর্থ হলে kill করে।"""
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except self._psutil.TimeoutExpired:
            self.logger.warning(f"Process {proc.name()} ignored SIGTERM, escalating to SIGKILL.")
            proc.kill()

    def kill_process(self, pid=None, name=None):
        """PID বা নাম দিয়ে প্রসেস বন্ধ করে (সিস্টেম প্রসেস সুরক্ষা সহ)।"""
        if not self._psutil:
            return "psutil unavailable."

        if name and self._is_protected(name):
            self.logger.warning(f"SECURITY BLOCKED: Attempted to kill protected system process: {name}")
            return f"Cannot kill protected system process: {name}"

        try:
            if pid:
                proc = self._psutil.Process(pid)
                proc_name = proc.name()
                
                if self._is_protected(proc_name):
                    self.logger.warning(f"SECURITY BLOCKED: Attempted to kill protected PID: {pid} ({proc_name})")
                    return f"Cannot kill protected system process: {proc_name}"
                
                self._safe_kill(proc)
                self.logger.info(f"Process terminated: {proc_name} (PID: {pid})")
                return f"Process terminated: {proc_name} (PID: {pid})"

            if name:
                killed = 0
                # SECURITY FIX: Exact match only (case-insensitive, .exe normalized)
                target = name.lower().strip()
                if not target.endswith('.exe'):
                    target_with_exe = target + '.exe'
                else:
                    target_with_exe = target
                    target = target.replace('.exe', '')

                for p in self._psutil.process_iter(['pid', 'name']):
                    try:
                        proc_name_lower = p.info['name'].lower()
                        # EXACT match: "chrome" matches "chrome.exe" but NOT "chromedriver.exe"
                        if proc_name_lower == target or proc_name_lower == target_with_exe:
                            if not self._is_protected(p.info['name']):
                                proc_obj = self._psutil.Process(p.info['pid'])
                                self._safe_kill(proc_obj)
                                killed += 1
                    except (self._psutil.NoSuchProcess, self._psutil.AccessDenied):
                        continue
                self.logger.info(f"Terminated {killed} process(es) exactly matching '{name}'.")
                return f"Terminated {killed} process(es) exactly matching '{name}'."

            return "Please provide PID or process name."
        except Exception as e:
            self.logger.error(f"Kill error: {e}")
            return f"Kill error: {e}"

    def start_process(self, command):
        """নতুন প্রসেস শুরু করে নিরাপদ স্যান্ডবক্সে (No shell=True)।"""
        try:
            parsed_cmd = shlex.split(command)
            if IS_WINDOWS:
                subprocess.Popen(parsed_cmd, shell=False, 
                                creationflags=subprocess.CREATE_NO_WINDOW)
            else:
                subprocess.Popen(parsed_cmd, shell=False)
            self.logger.info(f"Background process started: {parsed_cmd[0]}")
            return f"Process started: {parsed_cmd[0]}"
        except Exception as e:
            self.logger.error(f"Start process error: {e}")
            return f"Start error: {e}"

    def get_process_count(self):
        """মোট চলমান প্রসেসের সংখ্যা।"""
        if not self._psutil:
            return 0
        return len(list(self._psutil.process_iter()))

    def is_running(self, name):
        """নির্দিষ্ট প্রসেস চলছে কিনা চেক করে।"""
        found = self.find_process(name)
        return len(found) > 0


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 50)
    print("  FORGE-PROC — Unit Test")
    print("=" * 50)

    fp = ForgeProc()

    print(f"\n[TEST] Total running processes: {fp.get_process_count()}")

    print("\n[TEST] Top 5 CPU consumers:")
    for p in fp.list_processes(5):
        print(f"  {p['name']} (PID: {p['pid']}) — CPU: {p['cpu_percent']}%")

    print(f"\n[TEST] Is 'python' running? {fp.is_running('python')}")
    print(f"[TEST] Is 'chrome' running? {fp.is_running('chrome')}")

    print("\n[FORGE-PROC] Unit test complete. ✓")
