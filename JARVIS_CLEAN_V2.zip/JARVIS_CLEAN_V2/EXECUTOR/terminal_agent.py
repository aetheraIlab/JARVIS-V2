import os
import logging
import shlex
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from KERNEL.defense_layer import DefenseLayer
from AGENT.safe_executor_v2 import SafeExecutorV2

logger = logging.getLogger("TERMINAL-AGENT")

WHITELIST = ["ping", "dir", "echo", "python", "pip", "whoami", "ipconfig", "cd", "ls", "npm", "npx"]

class TerminalAgent:
    """
    JARVIS TERMINAL-AGENT — Hardened Command Execution Sandbox
    
    [V2] All execution now delegated to SafeExecutorV2 for full
    subprocess isolation with hard timeouts, memory limits, and
    sandboxed working directories. DefenseLayer trust gate preserved.
    """
    
    def __init__(self):
        self.project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.max_cmd_length = 200
        self.defense = DefenseLayer()
        self.executor = SafeExecutorV2(project_root=self.project_dir)

    def _is_safe(self, command, source_id="UNKNOWN"):
        """Security Policy Enforcer — Trust gate before SafeExecutorV2."""
        
        if not self.defense.authorize(source_id, "EXECUTE", "TERMINAL"):
            return False, "Command execution denied by DefenseLayer Trust Matrix."
            
        cmd_str = str(command).strip()
        
        # Length check (Buffer overflow protection)
        if len(cmd_str) > self.max_cmd_length:
            return False, "Command too long."

        try:
            args = shlex.split(cmd_str)
        except ValueError:
            return False, "Malformed command."
            
        if not args:
            return False, "Empty command."
            
        base_cmd = args[0].lower()
        
        # Strict Whitelist check (Applies to EVERYONE, even SYSTEM)
        if base_cmd not in WHITELIST:
            self.defense._log_audit("WHITELIST_VIOLATION", source_id, "TERMINAL", "EXECUTE", "BLOCKED", f"Command '{base_cmd}' is not whitelisted")
            return False, f"Command '{base_cmd}' is not whitelisted. Strict Sandboxing Enforced."
                    
        return True, "Safe"

    def execute(self, command, source_id="UNKNOWN"):
        """Executes command via SafeExecutorV2 after DefenseLayer gate."""
        is_safe, reason = self._is_safe(command, source_id)
        
        if not is_safe:
            logger.warning(f"Security blocked command from {source_id}: {command} ({reason})")
            return f"Error: Command blocked by security policy. Reason: {reason}"
        
        # Delegate to SafeExecutorV2 (subprocess isolation)
        result = self.executor.execute_shell(
            command=command,
            timeout=10,
            source_id=source_id,
        )
        
        if result.success:
            self.defense._log_audit("EXECUTE_COMMAND", source_id, "TERMINAL", "EXECUTE", "SUCCESS", f"RC: {result.exit_code}")
            return result.stdout if result.stdout else "Command executed successfully with no output."
        else:
            self.defense._log_audit("ERROR", source_id, "TERMINAL", "EXECUTE", "FAILED", result.error_summary or "Unknown")
            if result.timed_out:
                return "Error: Command timed out. Execution forcefully stopped."
            return f"Error: {result.error_summary or result.stderr}"

if __name__ == "__main__":
    ta = TerminalAgent()
    print("[TERMINAL] Running secure test...")
    print(ta.execute("echo Sandbox Operational"))
