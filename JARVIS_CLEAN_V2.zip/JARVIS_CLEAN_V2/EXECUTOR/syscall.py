# ================================================================
# JARVIS AETHER-CORE V2.0 — FORGE-SYS (LAYER 3 / FORGE)
# ================================================================
# Codename : FORGE-SYS
# Role     : System Settings Agent — Volume, Brightness, WiFi
# Tech     : subprocess + pyautogui (Windows 11)
# ================================================================

import sys
import os
import subprocess
import platform

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

IS_WINDOWS = platform.system() == "Windows"


class ForgeSys:
    """
    JARVIS FORGE-SYS — সিস্টেম সেটিংস এজেন্ট।
    ভয়েস কমান্ডে ভলিউম, ব্রাইটনেস, WiFi নিয়ন্ত্রণ করে।
    """

    def __init__(self):
        self._pyautogui = None
        try:
            import pyautogui
            self._pyautogui = pyautogui
            pyautogui.FAILSAFE = False  # কোণায় গেলে এরর হবে না
        except ImportError:
            print("[FORGE-SYS] [WARN] pyautogui not installed.")
        print("[FORGE-SYS] System settings agent initialized.")

    # ── Volume Control ──────────────────────────────
    def volume_up(self, steps=5):
        """ভলিউম বাড়ায়।"""
        if not IS_WINDOWS or not self._pyautogui:
            return "Volume control unavailable"
        for _ in range(steps):
            self._pyautogui.press('volumeup')
        return f"Volume increased by {steps} steps."

    def volume_down(self, steps=5):
        """ভলিউম কমায়।"""
        if not IS_WINDOWS or not self._pyautogui:
            return "Volume control unavailable"
        for _ in range(steps):
            self._pyautogui.press('volumedown')
        return f"Volume decreased by {steps} steps."

    def mute(self):
        """মিউট/আনমিউট টগল করে।"""
        if not IS_WINDOWS or not self._pyautogui:
            return "Mute control unavailable"
        self._pyautogui.press('volumemute')
        return "Volume mute toggled."

    # ── Brightness Control (Windows PowerShell) ────
    def set_brightness(self, level):
        """ব্রাইটনেস সেট করে (0-100)।"""
        if not IS_WINDOWS:
            return "Brightness control only on Windows."
        level = max(0, min(100, int(level)))
        try:
            cmd = f'(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{level})'
            subprocess.run(["powershell", "-Command", cmd],
                           capture_output=True, timeout=10)
            return f"Brightness set to {level}%."
        except Exception as e:
            return f"Brightness error: {e}"

    # ── WiFi Control ────────────────────────────────
    def wifi_status(self):
        """WiFi সংযোগের অবস্থা চেক করে।"""
        if not IS_WINDOWS:
            return "WiFi check is Windows-only."
        try:
            result = subprocess.run(
                ["netsh", "wlan", "show", "interfaces"],
                capture_output=True, text=True, timeout=10
            )
            if "connected" in result.stdout.lower():
                # SSID বের করা হচ্ছে
                for line in result.stdout.split("\n"):
                    if "SSID" in line and "BSSID" not in line:
                        ssid = line.split(":")[1].strip()
                        return f"Connected to: {ssid}"
            return "WiFi disconnected."
        except Exception as e:
            return f"WiFi check error: {e}"

    def wifi_disconnect(self):
        """WiFi সংযোগ বিচ্ছিন্ন করে।"""
        if not IS_WINDOWS:
            return "WiFi only on Windows."
        try:
            subprocess.run(["netsh", "wlan", "disconnect"],
                           capture_output=True, timeout=10)
            return "WiFi disconnected."
        except Exception as e:
            return f"WiFi disconnect error: {e}"

    # ── Screenshot ──────────────────────────────────
    def take_screenshot(self, save_path=None):
        """স্ক্রিনশট নেয়।"""
        if not self._pyautogui:
            return "Screenshot unavailable (pyautogui missing)."
        try:
            if save_path is None:
                save_path = os.path.join(os.path.expanduser("~"), "Desktop", "jarvis_screenshot.png")
            img = self._pyautogui.screenshot()
            img.save(save_path)
            return f"Screenshot saved: {save_path}"
        except Exception as e:
            return f"Screenshot error: {e}"

    # ── System Power ────────────────────────────────
    def shutdown(self, delay=30):
        """সিস্টেম শাটডাউন করে।"""
        if not IS_WINDOWS:
            return "Shutdown is Windows-only."
        try:
            subprocess.run(["shutdown", "/s", "/t", str(delay)], timeout=5)
            return f"System shutting down in {delay} seconds."
        except Exception as e:
            return f"Shutdown error: {e}"

    def restart(self, delay=30):
        """সিস্টেম রিস্টার্ট করে।"""
        if not IS_WINDOWS:
            return "Restart is Windows-only."
        try:
            subprocess.run(["shutdown", "/r", "/t", str(delay)], timeout=5)
            return f"System restarting in {delay} seconds."
        except Exception as e:
            return f"Restart error: {e}"

    def cancel_shutdown(self):
        """শাটডাউন বাতিল করে।"""
        if not IS_WINDOWS:
            return "Cancel shutdown is Windows-only."
        try:
            subprocess.run(["shutdown", "/a"], timeout=5)
            return "Shutdown cancelled."
        except Exception as e:
            return f"Cancel error: {e}"


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 50)
    print("  FORGE-SYS — Unit Test")
    print("=" * 50)

    fs = ForgeSys()
    print(f"\n[TEST] WiFi: {fs.wifi_status()}")
    print(f"[TEST] Volume up: {fs.volume_up(2)}")
    print(f"[TEST] Mute toggle: {fs.mute()}")
    # ব্রাইটনেস টেস্ট (ল্যাপটপে কাজ করে)
    # print(f"[TEST] Brightness: {fs.set_brightness(70)}")

    print("\n[FORGE-SYS] Unit test complete. ✓")
