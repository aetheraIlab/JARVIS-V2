# ================================================================
# JARVIS AETHER-CORE V2.0 — FORGE-FILE (LAYER 3 / FORGE)
# ================================================================
# Codename : FORGE-FILE
# Role     : File Management Agent — Create, Move, Delete, Search
# Tech     : os + shutil + pathlib
# ================================================================

import sys
import os
import shutil
import glob
import logging
from pathlib import Path

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from KERNEL.defense_layer import DefenseLayer

class ForgeFile:
    """
    JARVIS FORGE-FILE — File Management Agent (Hardened)
    Enforces strict Military-Grade File Access Controls.
    """

    def __init__(self):
        self.logger = logging.getLogger("FORGE-FILE")
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
            
        self.defense = DefenseLayer()
        self.project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.user_docs = os.path.join(os.path.expanduser("~"), "Documents")
        
        self.logger.info("File management agent initialized in ZERO-TRUST sandboxed state.")

    def _is_safe_path(self, target_path, action="READ", source_id="UNKNOWN"):
        """Verify path is inside sandbox and authorized by DefenseLayer."""
        try:
            if not self.defense.authorize(source_id, action, target_path):
                self.logger.warning(f"SECURITY BLOCKED: {action} on {target_path} denied by DefenseLayer.")
                return False

            real_path = os.path.realpath(target_path)

            if real_path == "C:\\" or real_path == "/" or real_path.startswith("C:\\Windows"):
                self.logger.warning(f"SECURITY BLOCKED: Attempted to access system root: {real_path}")
                return False

            if os.path.islink(target_path):
                self.logger.warning(f"SECURITY BLOCKED: Symlink detected: {target_path}")
                return False

            is_in_project = os.path.commonpath([real_path, self.project_root]) == self.project_root
            is_in_docs = os.path.commonpath([real_path, self.user_docs]) == self.user_docs
            
            if not (is_in_project or is_in_docs):
                self.logger.warning(f"SECURITY BLOCKED: Out-of-bounds path: {real_path}")
                return False
                
            return True
        except Exception as e:
            self.logger.error(f"Path validation failed: {e}")
            return False

    def create_file(self, path, content="", source_id="UNKNOWN"):
        if not self._is_safe_path(path, "WRITE", source_id):
            return "Error: Path traversal or authorization blocked."
        try:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding='utf-8')
            self.logger.info(f"File created securely: {path}")
            return f"File created: {path}"
        except Exception as e:
            return f"Error creating file: {e}"

    def create_folder(self, path, source_id="UNKNOWN"):
        if not self._is_safe_path(path, "WRITE", source_id):
            return "Error: Path traversal or authorization blocked."
        try:
            Path(path).mkdir(parents=True, exist_ok=True)
            return f"Folder created: {path}"
        except Exception as e:
            return f"Error creating folder: {e}"

    def delete_file(self, path, source_id="UNKNOWN"):
        if not self._is_safe_path(path, "DELETE", source_id):
            return "Error: Path traversal or authorization blocked."
        try:
            if os.path.isfile(path):
                os.remove(path)
                self.logger.warning(f"File deleted: {path}")
                return f"File deleted: {path}"
            return f"Not a file: {path}"
        except Exception as e:
            return f"Error deleting file: {e}"

    def delete_folder(self, path, force=False, source_id="UNKNOWN"):
        if not self._is_safe_path(path, "DELETE", source_id):
            return "Error: Path traversal or authorization blocked."
        try:
            if os.path.isdir(path):
                if force:
                    shutil.rmtree(path)
                else:
                    os.rmdir(path)
                self.logger.warning(f"Folder deleted: {path}")
                return f"Folder deleted: {path}"
            return f"Not a folder: {path}"
        except Exception as e:
            return f"Error deleting folder: {e}"

    def move(self, source, destination, source_id="UNKNOWN"):
        if not self._is_safe_path(source, "READ", source_id) or not self._is_safe_path(destination, "WRITE", source_id):
            return "Error: Path traversal or authorization blocked."
        try:
            shutil.move(source, destination)
            return f"Moved: {source} → {destination}"
        except Exception as e:
            return f"Error moving: {e}"

    def copy(self, source, destination, source_id="UNKNOWN"):
        if not self._is_safe_path(source, "READ", source_id) or not self._is_safe_path(destination, "WRITE", source_id):
            return "Error: Path traversal or authorization blocked."
        try:
            if os.path.isdir(source):
                shutil.copytree(source, destination)
            else:
                shutil.copy2(source, destination)
            return f"Copied: {source} → {destination}"
        except Exception as e:
            return f"Error copying: {e}"

    def rename(self, old_path, new_name, source_id="UNKNOWN"):
        if not self._is_safe_path(old_path, "WRITE", source_id) or ".." in new_name or "/" in new_name or "\\" in new_name:
            return "Error: Unsafe rename parameters."
        try:
            parent = os.path.dirname(old_path)
            new_path = os.path.join(parent, new_name)
            os.rename(old_path, new_path)
            return f"Renamed: {old_path} → {new_path}"
        except Exception as e:
            return f"Error renaming: {e}"

    def search(self, directory, pattern="*", recursive=True, source_id="UNKNOWN"):
        if not self._is_safe_path(directory, "READ", source_id):
            return "Error: Path traversal or authorization blocked."
        try:
            if recursive:
                results = glob.glob(os.path.join(directory, "**", pattern), recursive=True)
            else:
                results = glob.glob(os.path.join(directory, pattern))
            return [res for res in results[:50] if self._is_safe_path(res, "READ", source_id)]
        except Exception as e:
            return f"Error searching: {e}"

    def get_size(self, path, source_id="UNKNOWN"):
        if not self._is_safe_path(path, "READ", source_id):
            return "Error: Path traversal or authorization blocked."
        try:
            if os.path.isfile(path):
                size = os.path.getsize(path)
            elif os.path.isdir(path):
                size = sum(
                    os.path.getsize(os.path.join(dirpath, f))
                    for dirpath, _, filenames in os.walk(path)
                    for f in filenames
                )
            else:
                return f"Not found: {path}"

            for unit in ['B', 'KB', 'MB', 'GB']:
                if size < 1024:
                    return f"{size:.1f} {unit}"
                size /= 1024
            return f"{size:.1f} TB"
        except Exception as e:
            return f"Error: {e}"

    def list_dir(self, path, source_id="UNKNOWN"):
        if not self._is_safe_path(path, "READ", source_id):
            return [{"error": "Path traversal or authorization blocked"}]
        try:
            items = []
            for entry in os.scandir(path):
                items.append({
                    "name": entry.name,
                    "is_dir": entry.is_dir(),
                    "size": entry.stat().st_size if entry.is_file() else 0,
                })
            return items
        except Exception as e:
            return [{"error": f"Error listing: {e}"}]

    def read_file(self, path, max_chars=5000, source_id="UNKNOWN"):
        if not self._is_safe_path(path, "READ", source_id):
            return "Error: Path traversal or authorization blocked."
        try:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read(max_chars)
            return content
        except Exception as e:
            return f"Error reading file: {e}"
