# ================================================================
# JARVIS AETHER-CORE V2.0 — CORTEX-OFFLINE (LAYER 2 / CORTEX)
# ================================================================
# Codename : CORTEX-OFFLINE
# Role     : Offline AI Agent — Ollama (Gemma4 / Qwen2.5 / Llama3.2)
# Tech     : Ollama Python SDK + requests fallback
# Chain    : Gemma4 (tool-calling) → Qwen2.5 → Llama3.2
# ================================================================

import sys
import os
import json

# প্রজেক্ট রুট পাথ সেটআপ
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

try:
    from CONFIG.constants import (
        PRIMARY_OFFLINE_MODEL,
        SECONDARY_OFFLINE_MODEL,
    )
    from INFERENCE.online import JARVIS_SYSTEM_PROMPT
except ImportError:
    # ডিফল্ট ভ্যালু যদি ইমপোর্ট ব্যর্থ হয়
    PRIMARY_OFFLINE_MODEL = "gemma4:4b"
    SECONDARY_OFFLINE_MODEL = "qwen2.5:7b"
    JARVIS_SYSTEM_PROMPT = """You are JARVIS — Joint Autonomous Responsive Virtual Intelligent System.
You were exclusively created by Aether AI Lab, designed by Adil.
You are an ultra-intelligent AI assistant inspired by Iron Man's JARVIS."""

# Ollama সার্ভার URL (লোকাল)
OLLAMA_URL = "http://localhost:11434"


class CortexOffline:
    """
    JARVIS CORTEX-OFFLINE — অফলাইন AI মস্তিষ্ক।
    ইন্টারনেট ছাড়াই Ollama লোকাল মডেল ব্যবহার করে চিন্তা করে।
    
    ফলব্যাক চেইন:
    [1] Gemma4 (gemma4:4b) — প্রাইমারি, টুল-কলিং সমর্থন
    [2] Qwen2.5:7b — সেকেন্ডারি
    """

    def __init__(self):
        self._ollama_available = False
        self._installed_models = []
        self._gemma4_agent = None
        self._check_ollama()
        self._init_gemma4()
        print("[CORTEX-OFFLINE] Offline intelligence agent initialized.")

    def _check_ollama(self):
        """Ollama সার্ভার চালু আছে কিনা এবং কোন মডেলগুলো ইনস্টল আছে চেক করে।"""
        try:
            import requests
            resp = requests.get(f"{OLLAMA_URL}/api/tags", timeout=3)
            if resp.status_code == 200:
                self._installed_models = [m["name"] for m in resp.json().get("models", [])]
                self._ollama_available = True
                print(f"[CORTEX-OFFLINE] Ollama ONLINE. Models: {self._installed_models}")
            else:
                print("[CORTEX-OFFLINE] Ollama responded but with error.")
        except Exception:
            print("[CORTEX-OFFLINE] Ollama not running. Start with: ollama serve")
            self._ollama_available = False

    def _init_gemma4(self):
        """Gemma 4 এজেন্ট ইনিশিয়ালাইজ করা হচ্ছে (টুল-কলিং সহ)।"""
        if not self._ollama_available:
            return

        try:
            from INFERENCE.gemma4_agent import CortexGemma4
            self._gemma4_agent = CortexGemma4(model=PRIMARY_OFFLINE_MODEL)
            if self._gemma4_agent.is_available():
                print("[CORTEX-OFFLINE] Gemma4 agent with tool-calling READY.")
            else:
                print(f"[CORTEX-OFFLINE] Gemma4 model not installed. Install: ollama pull {PRIMARY_OFFLINE_MODEL}")
                self._gemma4_agent = None
        except Exception as e:
            print(f"[CORTEX-OFFLINE] Gemma4 init error: {e}")
            self._gemma4_agent = None

    def _query_basic_ollama(self, prompt: str, model: str, max_tokens=2048):
        """
        সাধারণ Ollama API কুয়েরি (টুল-কলিং ছাড়া)।
        Qwen2.5 এবং Llama3.2-এর জন্য ব্যবহৃত হয়।
        """
        if not self._ollama_available:
            return None, "ollama_offline"

        full_prompt = f"{JARVIS_SYSTEM_PROMPT}\n\nUser: {prompt}\nJARVIS:"

        try:
            import requests
            response = requests.post(
                f"{OLLAMA_URL}/api/generate",
                json={
                    "model": model,
                    "prompt": full_prompt,
                    "stream": False,
                    "options": {
                        "num_predict": max_tokens,
                        "temperature": 0.7,
                    }
                },
                timeout=120  # অফলাইন মডেলের জন্য ২ মিনিট পর্যন্ত অপেক্ষা
            )

            if response.status_code == 200:
                data = response.json()
                text = data.get("response", "").strip()
                return text, f"ollama:{model}"
            else:
                print(f"[CORTEX-OFFLINE] Ollama error: HTTP {response.status_code}")
                return None, f"ollama_http_{response.status_code}"

        except Exception as e:
            print(f"[CORTEX-OFFLINE] Ollama query failed: {e}")
            return None, f"ollama_error: {e}"

    def think(self, messages: list[dict]):
        """
        মূল কমান্ড — অফলাইনে চিন্তা করে।
        সম্পূর্ণ ফলব্যাক চেইন:
        [1] Gemma4 (টুল-কলিং সহ) → [2] Qwen2.5 → [3] None
        """
        # Convert messages list to simple offline prompt
        offline_prompt = "\n".join([
            m["content"] for m in messages if m.get("role") == "user"
        ])
        
        # === LEVEL 1: Gemma 4 (প্রাইমারি — টুল-কলিং সমর্থন) ===
        if self._gemma4_agent and self._gemma4_agent.is_available():
            print("[CORTEX-OFFLINE] Attempting Gemma4 (primary, tool-calling)...")
            response, provider = self._gemma4_agent.think(offline_prompt)
            if response:
                return response, provider

        # === LEVEL 2: Qwen2.5:7b (সেকেন্ডারি) ===
        print("[CORTEX-OFFLINE] Attempting Qwen2.5 (secondary)...")
        response, provider = self._query_basic_ollama(offline_prompt, SECONDARY_OFFLINE_MODEL)
        if response:
            return response, provider

        # উভয়ই ব্যর্থ
        return None, "all_offline_failed"

    def is_available(self):
        """Ollama সার্ভার চলছে কিনা।"""
        return self._ollama_available

    def has_gemma4(self):
        """Gemma 4 প্রস্তুত কিনা।"""
        return self._gemma4_agent is not None and self._gemma4_agent.is_available()

    def list_models(self):
        """Ollama-তে যেসব মডেল ইনস্টল আছে তার তালিকা।"""
        return self._installed_models

    def get_status(self):
        """অফলাইন সিস্টেমের বিস্তারিত অবস্থা।"""
        return {
            "ollama_online": self._ollama_available,
            "installed_models": self._installed_models,
            "gemma4_ready": self.has_gemma4(),
            "primary_model": PRIMARY_OFFLINE_MODEL,
            "secondary_model": SECONDARY_OFFLINE_MODEL,
        }

    def clear_history(self):
        """Gemma 4-এর কথোপকথনের ইতিহাস মুছে দেয়।"""
        if self._gemma4_agent:
            self._gemma4_agent.clear_history()


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  CORTEX-OFFLINE — Unit Test")
    print("=" * 60)

    cortex = CortexOffline()

    # স্ট্যাটাস রিপোর্ট
    print("\n[TEST 1] Offline system status:")
    status = cortex.get_status()
    for k, v in status.items():
        print(f"  {k}: {v}")

    if cortex.is_available():
        print(f"\n[TEST 2] Available models: {cortex.list_models()}")
        print(f"[TEST 2] Gemma4 ready: {cortex.has_gemma4()}")

        print("\n[TEST 3] Sending test query: 'Explain Python in one sentence.'")
        messages = [{"role": "user", "content": "Explain Python in one sentence."}]
        response, provider = cortex.think(messages)
        if response:
            print(f"  Provider: {provider}")
            print(f"  Response: {response[:300]}")
        else:
            print("  Query failed.")
