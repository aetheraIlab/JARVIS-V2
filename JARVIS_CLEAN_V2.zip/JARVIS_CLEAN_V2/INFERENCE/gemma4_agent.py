# ================================================================
# JARVIS AETHER-CORE V2.0 — CORTEX-GEMMA4 (LAYER 2 / CORTEX)
# ================================================================
# Codename : CORTEX-GEMMA4
# Role     : Primary Offline AI Agent — Gemma 4 via Ollama
# Tech     : Ollama REST API with native tool-calling
# Priority : 3rd in chain (after Groq + Gemini, before Qwen2.5)
# ================================================================

import sys
import os
import json
import time

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from INFERENCE.online import JARVIS_SYSTEM_PROMPT

# Ollama সার্ভার URL (লোকাল)
OLLAMA_URL = "http://localhost:11434"

# Gemma 4 মডেল নাম (Ollama-তে যেভাবে ইনস্টল আছে)
GEMMA4_MODEL = "gemma4:4b"

# ================================================================
# TOOL DEFINITIONS — Gemma 4 যেসব ফাংশন কল করতে পারবে
# ================================================================
JARVIS_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_current_time",
            "description": "Gets the current date and time.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_system_info",
            "description": "Gets system information including CPU, RAM, disk usage.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "open_application",
            "description": "Opens a desktop application by name.",
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Name of the application to open (e.g. 'chrome', 'notepad', 'calculator').",
                    },
                },
                "required": ["app_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "Searches the web for information.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The search query to look up.",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "set_reminder",
            "description": "Sets a reminder for the user.",
            "parameters": {
                "type": "object",
                "properties": {
                    "message": {
                        "type": "string",
                        "description": "Reminder message.",
                    },
                    "time_str": {
                        "type": "string",
                        "description": "When to remind, e.g. '5 PM', 'in 30 minutes', 'tomorrow 9 AM'.",
                    },
                },
                "required": ["message", "time_str"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "take_screenshot",
            "description": "Takes a screenshot of the current screen.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "file_operation",
            "description": "Performs file system operations like create, list, delete files.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "description": "Action to perform: 'create', 'list', 'delete', 'read', 'move'.",
                    },
                    "path": {
                        "type": "string",
                        "description": "File or directory path.",
                    },
                    "content": {
                        "type": "string",
                        "description": "Content for file creation (optional).",
                    },
                },
                "required": ["action", "path"],
            },
        },
    },
]


# ================================================================
# TOOL EXECUTION ENGINE — টুল কল এক্সিকিউট করে
# ================================================================
class ToolExecutor:
    """
    JARVIS TOOL EXECUTOR — Gemma 4 যখন টুল কল করে, এটি সেটি এক্সিকিউট করে।
    """

    @staticmethod
    def execute(tool_name, arguments):
        """
        টুলের নাম এবং আর্গুমেন্ট পেয়ে এক্সিকিউট করে।
        রিটার্ন: (success: bool, result: str)
        """
        try:
            if tool_name == "get_current_time":
                return ToolExecutor._get_current_time()
            elif tool_name == "get_system_info":
                return ToolExecutor._get_system_info()
            elif tool_name == "open_application":
                return ToolExecutor._open_application(arguments.get("app_name", ""))
            elif tool_name == "web_search":
                return ToolExecutor._web_search(arguments.get("query", ""))
            elif tool_name == "set_reminder":
                return ToolExecutor._set_reminder(
                    arguments.get("message", ""),
                    arguments.get("time_str", ""),
                )
            elif tool_name == "take_screenshot":
                return ToolExecutor._take_screenshot()
            elif tool_name == "file_operation":
                return ToolExecutor._file_operation(
                    arguments.get("action", ""),
                    arguments.get("path", ""),
                    arguments.get("content", ""),
                )
            else:
                return False, f"Unknown tool: {tool_name}"
        except Exception as e:
            return False, f"Tool execution error: {e}"

    @staticmethod
    def _get_current_time():
        from datetime import datetime
        now = datetime.now()
        result = f"Current time: {now.strftime('%I:%M %p')}, Date: {now.strftime('%A, %B %d, %Y')}"
        return True, result

    @staticmethod
    def _get_system_info():
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=1)
            ram = psutil.virtual_memory()
            disk = psutil.disk_usage("/")
            result = (
                f"CPU Usage: {cpu}% | "
                f"RAM: {ram.percent}% ({ram.used // (1024**3)}GB / {ram.total // (1024**3)}GB) | "
                f"Disk: {disk.percent}% ({disk.used // (1024**3)}GB / {disk.total // (1024**3)}GB)"
            )
            return True, result
        except ImportError:
            return False, "psutil not installed. Run: pip install psutil"

    @staticmethod
    def _open_application(app_name):
        if not app_name:
            return False, "No application name provided."

        import subprocess
        import shlex
        # উইন্ডোজ অ্যাপ ম্যাপিং
        app_map = {
            "notepad": "notepad.exe",
            "calculator": "calc.exe",
            "paint": "mspaint.exe",
            "cmd": "cmd.exe",
            "terminal": "wt.exe",
            "explorer": "explorer.exe",
            "file explorer": "explorer.exe",
            "chrome": "chrome.exe",
            "brave": "brave.exe",
            "firefox": "firefox.exe",
            "edge": "msedge.exe",
            "spotify": "spotify.exe",
            "vscode": "code.exe",
            "vs code": "code.exe",
            "word": "winword.exe",
            "excel": "excel.exe",
            "powerpoint": "powerpnt.exe",
            "task manager": "taskmgr.exe",
            "settings": "ms-settings:",
        }

        app_lower = app_name.lower().strip()
        exe = app_map.get(app_lower, app_lower)

        # SECURITY: Block shell metacharacters in executable name
        if any(c in exe for c in ['&', '|', ';', '`', '$', '>', '<']):
            return False, f"Blocked: unsafe characters in app name '{app_name}'"

        try:
            if exe.startswith("ms-"):
                # SECURITY FIX: os.startfile instead of os.system("start ...")
                os.startfile(exe)
            else:
                # SECURITY FIX: shell=False, list args instead of shell=True
                subprocess.Popen([exe], shell=False,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
            return True, f"Opened: {app_name}"
        except Exception as e:
            return False, f"Failed to open {app_name}: {e}"

    @staticmethod
    def _web_search(query):
        if not query:
            return False, "No search query provided."
        # DuckDuckGo সার্চ
        try:
            from duckduckgo_search import DDGS
            with DDGS() as ddgs:
                results = list(ddgs.text(query, max_results=3))
            if results:
                output = []
                for r in results:
                    output.append(f"- {r['title']}: {r['body'][:150]}")
                return True, "\n".join(output)
            return True, "No results found."
        except ImportError:
            return False, "duckduckgo-search not installed."
        except Exception as e:
            return False, f"Search error: {e}"

    @staticmethod
    def _set_reminder(message, time_str):
        if not message:
            return False, "No reminder message provided."
        # আপাতত মেমোরিতে সেভ করে (পরে DAEMON_REMINDER-এ পাঠানো হবে)
        return True, f"Reminder set: '{message}' at {time_str}"

    @staticmethod
    def _take_screenshot():
        try:
            import pyautogui
            from datetime import datetime
            from CONFIG.config import VISION_DIR

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = os.path.join(str(VISION_DIR), f"screenshot_{timestamp}.png")
            screenshot = pyautogui.screenshot()
            screenshot.save(filepath)
            return True, f"Screenshot saved: {filepath}"
        except ImportError:
            return False, "pyautogui not installed."
        except Exception as e:
            return False, f"Screenshot error: {e}"

    @staticmethod
    def _is_safe_tool_path(target_path):
        """SECURITY: Validate path is within safe sandbox (project root or user Documents)."""
        try:
            # Resolve symlinks to prevent symlink escape attacks
            real_path = os.path.realpath(target_path)
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            user_docs = os.path.join(os.path.expanduser("~"), "Documents")

            is_in_project = os.path.commonpath([real_path, project_root]) == project_root
            is_in_docs = os.path.commonpath([real_path, user_docs]) == user_docs

            return is_in_project or is_in_docs
        except (ValueError, OSError):
            return False

    @staticmethod
    def _file_operation(action, path, content=""):
        if not action or not path:
            return False, "Action and path are required."

        # SECURITY FIX: Validate path is within sandbox
        if not ToolExecutor._is_safe_tool_path(path):
            return False, f"SECURITY: Path '{path}' is outside the safe workspace."

        action = action.lower().strip()

        if action == "list":
            if os.path.isdir(path):
                items = os.listdir(path)
                return True, f"Contents of {path}:\n" + "\n".join(f"  - {i}" for i in items[:20])
            return False, f"Not a directory: {path}"

        elif action == "read":
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as f:
                    return True, f.read()[:2000]
            return False, f"File not found: {path}"

        elif action == "create":
            with open(path, "w", encoding="utf-8") as f:
                f.write(content or "")
            return True, f"File created: {path}"

        elif action == "delete":
            if os.path.exists(path):
                os.remove(path)
                return True, f"Deleted: {path}"
            return False, f"Not found: {path}"

        return False, f"Unknown action: {action}"


# ================================================================
# GEMMA 4 CORTEX — মূল AI এজেন্ট
# ================================================================
class CortexGemma4:
    """
    JARVIS CORTEX-GEMMA4 — অফলাইন AI মস্তিষ্ক (প্রাইমারি)।

    Gemma 4 Ollama-তে চলে এবং নেটিভ টুল-কলিং সমর্থন করে।
    এটি শুধু উত্তরই দেয় না, সরাসরি অ্যাকশনও নিতে পারে:
    - অ্যাপ ওপেন করা
    - স্ক্রিনশট নেওয়া
    - ওয়েব সার্চ করা
    - ফাইল অপারেশন করা
    - সিস্টেম তথ্য দেওয়া
    """

    def __init__(self, model=None):
        self.model = model or GEMMA4_MODEL
        self._available = False
        self._model_installed = False
        self.tool_executor = ToolExecutor()
        self._check_ollama()
        print(f"[CORTEX-GEMMA4] Gemma4 agent initialized (model: {self.model}).")

    def _check_ollama(self):
        """Ollama সার্ভার এবং Gemma 4 মডেল চেক করা হচ্ছে।"""
        try:
            import requests
            # সার্ভার চেক
            resp = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
            if resp.status_code == 200:
                models = [m["name"] for m in resp.json().get("models", [])]
                self._available = True

                # Gemma 4 মডেল ইনস্টল আছে কিনা চেক
                if any(self.model in m for m in models):
                    self._model_installed = True
                    print(f"[CORTEX-GEMMA4] Ollama ONLINE. Model '{self.model}' READY.")
                else:
                    print(f"[CORTEX-GEMMA4] Ollama ONLINE but '{self.model}' not found.")
                    print(f"[CORTEX-GEMMA4] Available models: {models}")
                    print(f"[CORTEX-GEMMA4] Install with: ollama pull {self.model}")
            else:
                print("[CORTEX-GEMMA4] Ollama responded with error.")
        except Exception:
            print("[CORTEX-GEMMA4] Ollama not running. Start with: ollama serve")
            self._available = False

    def _build_messages(self, user_message, history=None):
        """Ollama Chat API-এর জন্য মেসেজ ফরম্যাট তৈরি করে।"""
        messages = [
            {"role": "system", "content": JARVIS_SYSTEM_PROMPT},
        ]

        # কথোপকথনের ইতিহাস যোগ (শেষ ১০টি)
        if history:
            for entry in history[-10:]:
                messages.append({
                    "role": entry.get("role", "user"),
                    "content": entry.get("content", ""),
                })

        messages.append({"role": "user", "content": user_message})
        return messages

    def query(self, user_message, use_tools=True, max_tokens=2048, history=None):
        """
        Gemma 4-কে একটি প্রশ্ন পাঠায়।
        use_tools=True হলে টুল-কলিং সক্রিয় থাকবে।

        রিটার্ন: (response_text, provider_name)
        """
        if not self._available:
            return None, "gemma4_ollama_offline"

        if not self._model_installed:
            return None, f"gemma4_model_not_installed"

        try:
            import requests

            messages = self._build_messages(user_message, history=history)

            # API রিকোয়েস্ট তৈরি
            payload = {
                "model": self.model,
                "messages": messages,
                "stream": False,
                "options": {
                    "num_predict": max_tokens,
                    "temperature": 0.7,
                },
            }

            # টুল-কলিং সক্রিয় থাকলে টুলস যোগ
            if use_tools and JARVIS_TOOLS:
                payload["tools"] = JARVIS_TOOLS

            # Ollama Chat API কল
            response = requests.post(
                f"{OLLAMA_URL}/api/chat",
                json=payload,
                timeout=120,
            )

            if response.status_code != 200:
                print(f"[CORTEX-GEMMA4] Ollama error: HTTP {response.status_code}")
                return None, f"gemma4_http_{response.status_code}"

            data = response.json()
            message = data.get("message", {})

            # টুল কল চেক
            tool_calls = message.get("tool_calls", [])
            if tool_calls:
                return self._handle_tool_calls(user_message, messages, tool_calls, max_tokens)

            # সাধারণ টেক্সট রেসপন্স
            text = message.get("content", "").strip()
            if text:
                return text, f"gemma4:{self.model}"

            return None, "gemma4_empty_response"

        except Exception as e:
            print(f"[CORTEX-GEMMA4] Query error: {e}")
            return None, f"gemma4_error: {e}"

    def _handle_tool_calls(self, original_query, messages, tool_calls, max_tokens):
        """
        Gemma 4 যদি টুল কল করে, সেটি এক্সিকিউট করে ফলাফল আবার মডেলে পাঠায়।
        এটি agentic loop-এর মূল অংশ।
        """
        import requests

        tool_results = []
        executed_tools = []

        for tc in tool_calls:
            func_info = tc.get("function", {})
            tool_name = func_info.get("name", "")
            arguments = func_info.get("arguments", {})

            print(f"[CORTEX-GEMMA4] Tool Call: {tool_name}({json.dumps(arguments, ensure_ascii=False)})")

            # টুল এক্সিকিউট
            success, result = self.tool_executor.execute(tool_name, arguments)
            status = "success" if success else "error"
            print(f"[CORTEX-GEMMA4] Tool Result [{status}]: {result[:200]}")

            tool_results.append({
                "tool": tool_name,
                "success": success,
                "result": result,
            })
            executed_tools.append(tool_name)

        # টুলের ফলাফল দিয়ে ফলো-আপ রিকোয়েস্ট পাঠানো হচ্ছে
        tool_summary = "\n".join(
            f"[{r['tool']}] {'OK' if r['success'] else 'FAILED'}: {r['result']}"
            for r in tool_results
        )

        # এবার AI-কে টুলের ফলাফল দিয়ে চূড়ান্ত উত্তর তৈরি করতে বলা হচ্ছে
        follow_up_messages = messages.copy()

        # AI-এর টুল কল রেসপন্স যোগ
        follow_up_messages.append({
            "role": "assistant",
            "content": "",
            "tool_calls": tool_calls,
        })

        # টুলের ফলাফল যোগ
        for tc, tr in zip(tool_calls, tool_results):
            follow_up_messages.append({
                "role": "tool",
                "content": tr["result"],
            })

        try:
            response = requests.post(
                f"{OLLAMA_URL}/api/chat",
                json={
                    "model": self.model,
                    "messages": follow_up_messages,
                    "stream": False,
                    "options": {
                        "num_predict": max_tokens,
                        "temperature": 0.7,
                    },
                },
                timeout=120,
            )

            if response.status_code == 200:
                data = response.json()
                text = data.get("message", {}).get("content", "").strip()
                if text:
                    tools_used = ", ".join(executed_tools)
                    return text, f"gemma4:{self.model}[tools:{tools_used}]"

        except Exception as e:
            print(f"[CORTEX-GEMMA4] Follow-up error: {e}")

        # ফলো-আপ ব্যর্থ হলে টুলের ফলাফল সরাসরি রিটার্ন
        fallback_text = f"I executed the following actions:\n{tool_summary}"
        return fallback_text, f"gemma4:{self.model}[tools_raw]"

    def think(self, user_message, history=None):
        """
        সরলীকৃত ইন্টারফেস — শুধু প্রশ্ন দিলেই উত্তর দেয়।
        ARBITER-এর সাথে সামঞ্জস্যপূর্ণ।
        """
        return self.query(user_message, use_tools=True, history=history)

    def think_no_tools(self, user_message, history=None):
        """টুল-কলিং ছাড়া শুধু চ্যাট মোডে উত্তর দেয়।"""
        return self.query(user_message, use_tools=False, history=history)

    def is_available(self):
        """Gemma 4 প্রস্তুত কিনা চেক করে।"""
        return self._available and self._model_installed

    def clear_history(self):
        """কথোপকথনের ইতিহাস মুছে দেয়।"""
        pass

    def get_status(self):
        """এজেন্টের বর্তমান অবস্থা।"""
        return {
            "model": self.model,
            "ollama_online": self._available,
            "model_installed": self._model_installed,
            "history_length": 0,
            "tools_count": len(JARVIS_TOOLS),
        }


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  CORTEX-GEMMA4 — Unit Test")
    print("=" * 60)

    agent = CortexGemma4()

    # === TEST 1: Status ===
    print("\n[TEST 1] Agent Status:")
    status = agent.get_status()
    for k, v in status.items():
        print(f"  {k}: {v}")

    # === TEST 2: Tool Executor (standalone) ===
    print("\n[TEST 2] Tool Executor tests...")

    # সময়
    ok, result = ToolExecutor.execute("get_current_time", {})
    print(f"  get_current_time -> [{ok}] {result}")

    # সিস্টেম ইনফো
    ok, result = ToolExecutor.execute("get_system_info", {})
    print(f"  get_system_info  -> [{ok}] {result}")

    # ফাইল তালিকা
    ok, result = ToolExecutor.execute("file_operation", {"action": "list", "path": "."})
    print(f"  file_operation   -> [{ok}] {result[:200]}")

    # === TEST 3: AI Query (if available) ===
    if agent.is_available():
        print("\n[TEST 3] Sending AI query...")
        response, provider = agent.think("What time is it right now?")
        if response:
            print(f"  Provider: {provider}")
            print(f"  Response: {response[:300]}")
        else:
            print(f"  Failed: {provider}")

        print("\n[TEST 4] Sending tool-requiring query...")
        response, provider = agent.think("Tell me my system's CPU and RAM usage.")
        if response:
            print(f"  Provider: {provider}")
            print(f"  Response: {response[:300]}")
        else:
            print(f"  Failed: {provider}")
    else:
        print("\n[TEST 3] Skipped — Gemma4 not available.")
        print(f"  Install with: ollama pull {GEMMA4_MODEL}")

    print("\n" + "=" * 60)
    print("  [CORTEX-GEMMA4] All unit tests complete.")
    print("=" * 60)
