import logging
import json
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from CONFIG.secure_config import config
except ImportError:
    pass

from INFERENCE.online import CortexOnline
from INFERENCE.offline import CortexOffline

logger = logging.getLogger("PIPELINE")

class Arbiter:
    """সিঙ্গেল ইনফারেন্স পাইপলাইন। (Hardened System)"""

    def __init__(self):
        try:
            self.has_groq = config.has_groq
            self.has_gemini = config.has_gemini
        except NameError:
            self.has_groq = False
            self.has_gemini = False
        self.online_engine = CortexOnline()
        self.offline_engine = CortexOffline()
        logger.info("Inference Pipeline initialized. Fallbacks and Retry limits active.")

    def _execute_with_retry(self, query_func, messages: list[dict], max_retries=1):
        """রেসিলিয়েন্ট এক্সিকিউশন রেট্রাই লিমিট সহ। (PRO LEVEL)"""
        for attempt in range(max_retries + 1):
            try:
                response = query_func(messages)
                if response:
                    # Unpack proper provider tuple
                    text, provider = response
                    if text and isinstance(text, str) and text.strip() != "":
                        return text.strip(), provider
            except Exception as e:
                logger.warning(f"Model call failed (Attempt {attempt + 1}/{max_retries + 1}): {e}")
                
        return None, None

    def think(self, prompt: str, context: list = None):
        """
        ক্লিন ইনফারেন্স ফ্লো:
        1. Groq (Primary) - Fast
        2. Gemini (Secondary) - Reliable
        3. Gemma/Qwen (Offline Fallback) - Always available
        """
        # Ensure context is a valid list of dicts
        messages = context if isinstance(context, list) else []
        messages.append({"role": "user", "content": str(prompt)})

        # 1. Groq
        if self.has_groq:
            text, provider = self._execute_with_retry(self.online_engine.query_groq, messages, max_retries=1)
            if text:
                return text, provider

        # 2. Gemini
        if self.has_gemini:
            text, provider = self._execute_with_retry(self.online_engine.query_gemini, messages, max_retries=1)
            if text:
                return text, provider

        # 3. Offline (Gemma4/Qwen)
        logger.warning("All online engines failed or unavailable. Falling back to Offline Cortex...")
        # No retries for offline to save CPU
        text, provider = self._execute_with_retry(self.offline_engine.think, messages, max_retries=0) 
        if text:
            return text, provider

        # 4. Ultimate Failsafe (System must NEVER crash)
        logger.critical("ALL INFERENCE ENGINES FAILED. Using static fallback.")
        return "I apologize, but all my cognitive engines are currently offline. I cannot process this request.", "static"

    async def think_stream(self, prompt: str, context: list = None):
        """
        স্ট্রিম ভার্সন: টোকেন জেনারেট হওয়ার সাথে সাথে ইল্ড করবে।
        """
        success = False
        
        if self.has_groq or self.has_gemini:
            try:
                # pass context directly, think_stream handles appending
                async for chunk, provider in self.online_engine.think_stream(prompt, context):
                    if chunk:
                        success = True
                        yield chunk, provider
            except Exception as e:
                logger.warning(f"Online stream failed: {e}")
                
        if not success:
            logger.warning("Falling back to offline stream (not implemented yet, returning single string).")
            # Offline does not support streaming yet, yield whole text
            messages = context if isinstance(context, list) else []
            messages.append({"role": "user", "content": str(prompt)})
            
            text, provider = self._execute_with_retry(self.offline_engine.think, messages, max_retries=0)
            if text:
                yield text, provider
            else:
                yield "I apologize, but my cognitive engines are offline.", "static"
