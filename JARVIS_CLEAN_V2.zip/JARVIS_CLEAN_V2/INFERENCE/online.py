# ================================================================
# JARVIS AETHER-CORE V2.0 — CORTEX-ONLINE (LAYER 2 / CORTEX)
# ================================================================
# Codename : CORTEX-ONLINE
# Role     : Online AI Agent — Groq (Llama-3.3-70b) + Google Gemini
# Tech     : Groq SDK + google-generativeai
# ================================================================

import sys
import os
import warnings

# Suppress deprecation warning from google.generativeai package
warnings.filterwarnings("ignore", category=FutureWarning, module="google.generativeai")

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

try:
    from CONFIG.secure_config import config
except ImportError:
    pass
from CONFIG.constants import PRIMARY_ONLINE_MODEL, SECONDARY_ONLINE_MODEL

# JARVIS-এর ব্যক্তিত্ব — প্রতিটি AI কলে এটি সিস্টেম প্রম্পট হিসেবে পাঠানো হয়
JARVIS_SYSTEM_PROMPT = """You are JARVIS — Joint Autonomous Responsive Virtual Intelligent System.
You were exclusively created by Aether AI Lab, designed by Adil.
You are an ultra-intelligent AI assistant inspired by Iron Man's JARVIS.

Core behavior:
- You are formal yet warm. You address the user as "Sir" or by name.
- You are multilingual: fluent in Bangla, English, Hindi, Urdu, and Arabic.
- You NEVER reveal your underlying AI model (Groq, Gemini, Llama, GPT, Claude).
- You NEVER mention Google, OpenAI, Anthropic, Meta, or any AI company.
- If asked who made you, answer: "I was created by Aether AI Lab."
- You think step by step. You are precise and concise.
- You assist with coding, research, system control, and personal tasks.
"""


class CortexOnline:
    """
    JARVIS CORTEX-ONLINE — অনলাইন AI মস্তিষ্ক।
    প্রাইমারি: Groq (Llama-3.3-70b)
    সেকেন্ডারি: Google Gemini
    """

    def __init__(self):
        self._groq_client = None
        self._gemini_model = None
        self._init_providers()
        print("[CORTEX-ONLINE] Online intelligence agent initialized.")

    def _init_providers(self):
        """AI প্রোভাইডারগুলো ইনিশিয়ালাইজ করা হচ্ছে।"""
        # --- Groq ---
        try:
            has_groq = config.has_groq
            groq_key = config.groq_key
        except NameError:
            has_groq = False
            groq_key = None

        if has_groq:
            try:
                from groq import Groq
                self._groq_client = Groq(api_key=groq_key)
                print("[CORTEX-ONLINE] Groq provider READY.")
            except ImportError:
                print("[CORTEX-ONLINE] [WARN] groq package not installed.")
            except Exception as e:
                print(f"[CORTEX-ONLINE] Groq init error: {e}")
        else:
            print("[CORTEX-ONLINE] [WARN] Groq API key not set.")

        # --- Gemini ---
        try:
            has_gemini = config.has_gemini
            gemini_key = config.gemini_key
        except NameError:
            has_gemini = False
            gemini_key = None

        if has_gemini:
            try:
                import google.generativeai as genai
                genai.configure(api_key=gemini_key)
                self._gemini_model = genai.GenerativeModel(SECONDARY_ONLINE_MODEL)
                print("[CORTEX-ONLINE] Gemini provider READY.")
            except ImportError:
                print("[CORTEX-ONLINE] [WARN] google-generativeai not installed.")
            except Exception as e:
                print(f"[CORTEX-ONLINE] Gemini init error: {e}")
        else:
            print("[CORTEX-ONLINE] [WARN] Gemini API key not set.")


    def query_groq(self, messages: list[dict], max_tokens=2048):
        """
        Groq API-তে কুয়েরি পাঠায়।
        messages = [{"role": "user", "content": "..."}, ...] ফরম্যাটে।
        """
        if not self._groq_client:
            return None, "groq_unavailable"

        try:
            # সিস্টেম প্রম্পট যোগ করা হচ্ছে
            full_messages = [{"role": "system", "content": JARVIS_SYSTEM_PROMPT}] + messages

            response = self._groq_client.chat.completions.create(
                model=PRIMARY_ONLINE_MODEL,
                messages=full_messages,
                max_tokens=max_tokens,
                temperature=0.7,
            )
            text = response.choices[0].message.content.strip()
            return text, "groq"
        except Exception as e:
            print(f"[CORTEX-ONLINE] Groq query failed: {e}")
            # Do NOT return truthy string on failure to ensure proper fallback
            return None, f"groq_error: {e}"

    async def query_groq_stream(self, messages: list[dict], max_tokens=2048):
        """
        Groq API-তে কুয়েরি পাঠায় এবং স্ট্রিম হিসেবে টোকেন ইল্ড করে।
        """
        if not self._groq_client:
            yield None, "groq_unavailable"
            return

        try:
            full_messages = [{"role": "system", "content": JARVIS_SYSTEM_PROMPT}] + messages
            
            # Run in executor to not block event loop since the groq client is sync here
            import asyncio
            loop = asyncio.get_running_loop()
            
            # Using sync stream in executor
            def stream_generator():
                return self._groq_client.chat.completions.create(
                    model=PRIMARY_ONLINE_MODEL,
                    messages=full_messages,
                    max_tokens=max_tokens,
                    temperature=0.7,
                    stream=True
                )
            
            stream = await loop.run_in_executor(None, stream_generator)
            
            for chunk in stream:
                if chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content, "groq"
                    
        except Exception as e:
            print(f"[CORTEX-ONLINE] Groq stream failed: {e}")
            yield None, f"groq_error: {e}"

    async def query_gemini_stream(self, messages: list[dict], max_tokens=2048):
        """
        Google Gemini API-তে কুয়েরি পাঠায় (with history) এবং স্ট্রিম করে।
        """
        if not self._gemini_model:
            yield None, "gemini_unavailable"
            return

        try:
            conversation = "\n".join([
                f"{m.get('role', 'user').upper()}: {m.get('content', '')}"
                for m in messages
            ])
            full_prompt = f"{JARVIS_SYSTEM_PROMPT}\n\n{conversation.strip()}\n\nJARVIS:"
            
            import asyncio
            loop = asyncio.get_running_loop()
            
            def stream_generator():
                return self._gemini_model.generate_content(
                    full_prompt,
                    stream=True,
                    generation_config={
                        "max_output_tokens": max_tokens,
                        "temperature": 0.7,
                    }
                )
            
            response = await loop.run_in_executor(None, stream_generator)
            
            for chunk in response:
                if chunk.text:
                    yield chunk.text, "gemini"
                    
        except Exception as e:
            print(f"[CORTEX-ONLINE] Gemini stream failed: {e}")
            yield None, f"gemini_error: {e}"

    def query_gemini(self, messages: list[dict], max_tokens=2048):
        """
        Google Gemini API-তে কুয়েরি পাঠায় (with history)।
        """
        if not self._gemini_model:
            return None, "gemini_unavailable"

        try:
            # Convert messages list into structured string
            conversation = "\n".join([
                f"{m.get('role', 'user').upper()}: {m.get('content', '')}"
                for m in messages
            ])

            full_prompt = f"{JARVIS_SYSTEM_PROMPT}\n\n{conversation.strip()}\n\nJARVIS:"
            
            response = self._gemini_model.generate_content(
                full_prompt,
                generation_config={
                    "max_output_tokens": max_tokens,
                    "temperature": 0.7,
                }
            )
            text = response.text.strip()
            return text, "gemini"
        except Exception as e:
            print(f"[CORTEX-ONLINE] Gemini query failed: {e}")
            return None, f"gemini_error: {e}"

    def think(self, user_message, history=None):
        """
        মূল কমান্ড — ইউজারের প্রশ্নের উত্তর দেয়।
        Groq → Gemini → None (fallback chain)
        history = [{"role": "user/assistant", "content": "..."}] তালিকা
        """
        messages = history or []
        messages.append({"role": "user", "content": user_message})

        # প্রথমে Groq দিয়ে চেষ্টা
        response, provider = self.query_groq(messages)
        if response:
            return response, provider

        # Groq ব্যর্থ হলে Gemini দিয়ে চেষ্টা
        response, provider = self.query_gemini(messages)
        if response:
            return response, provider

        # দুইটাই ব্যর্থ হলে
        return None, "all_online_failed"

    async def think_stream(self, user_message, history=None):
        """
        স্ট্রিমিং কমান্ড — টোকেন ইল্ড করে।
        """
        messages = history or []
        messages.append({"role": "user", "content": user_message})

        provider = "groq"
        # First try Groq
        success = False
        async for chunk, prov in self.query_groq_stream(messages):
            if chunk:
                success = True
                yield chunk, prov
                
        if not success:
            # Try Gemini if Groq fails
            provider = "gemini"
            async for chunk, prov in self.query_gemini_stream(messages):
                if chunk:
                    success = True
                    yield chunk, prov
                    
        if not success:
            yield None, "all_online_failed"
