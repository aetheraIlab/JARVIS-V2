# ================================================================
# JARVIS AETHER-CORE V2.0 — AUDIO-OUT (LAYER 1 / SYNAPSE)
# ================================================================
# Codename : AUDIO-OUT
# Role     : Speaking Agent — High-Quality Edge-TTS with instant interrupt
# Tech     : edge-tts + pygame
# ================================================================

import sys
import os
import asyncio
import threading
import time
import tempfile
import edge_tts

# Ensure parent directory is in path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

class AudioOut:
    """
    JARVIS AUDIO-OUT — Speech Agent.
    Uses edge-tts for natural, low-latency streaming voices.
    Supports instant interruption and sentence-chunked streaming.
    """

    def __init__(self):
        self.voice = "en-GB-ThomasNeural" # Professional British Male
        self.rate = "+0%"
        self.volume = "+0%"
        self._interrupted = False
        self._speaking = False
        
        self._playback_queue = asyncio.Queue()
        self._playback_task = None
        self._is_playback_running = False
        
        # Initialize pygame mixer for playback
        try:
            # Hide pygame prompt
            os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
            import pygame
            pygame.mixer.init()
            self.mixer = pygame.mixer
        except ImportError:
            print("[AUDIO-OUT] [WARN] pygame not installed. Run: pip install pygame")
            self.mixer = None
            
        print(f"[AUDIO-OUT] Speaking agent initialized with voice: {self.voice}")

    def speak(self, text):
        """Synchronous wrapper for speaking."""
        asyncio.run(self.speak_async(text))

    async def speak_async(self, text):
        """
        Generates TTS audio and plays it asynchronously.
        Can be instantly interrupted by calling interrupt().
        """
        if not text or not self.mixer:
            return

        self._interrupted = False
        await self._synthesize_and_queue(text)
        self._ensure_playback_worker()

    def _ensure_playback_worker(self):
        if not self._is_playback_running:
            self._is_playback_running = True
            self._playback_task = asyncio.create_task(self._playback_worker())

    async def _synthesize_and_queue(self, text):
        """Synthesizes text to a temp file and queues it for playback."""
        if not text.strip() or self._interrupted:
            return
            
        try:
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3")
            temp_path = temp_file.name
            temp_file.close()

            communicate = edge_tts.Communicate(text, self.voice, rate=self.rate, volume=self.volume)
            await communicate.save(temp_path)
            
            if self._interrupted:
                self._cleanup(temp_path)
                return
                
            await self._playback_queue.put(temp_path)
        except Exception as e:
            print(f"[AUDIO-OUT] Synthesis error: {e}")
            if temp_path: self._cleanup(temp_path)

    async def speak_stream(self, async_text_generator):
        """
        Receives text tokens, buffers them into sentences, and queues them for playback.
        """
        if not self.mixer:
            return
            
        self._interrupted = False
        self._ensure_playback_worker()
        
        buffer = ""
        punctuations = {'.', '?', '!', '\n'}
        
        try:
            async for chunk in async_text_generator:
                # If provider is attached, extract just the chunk
                if isinstance(chunk, tuple):
                    chunk = chunk[0]
                    
                if self._interrupted:
                    break
                if chunk:
                    buffer += chunk
                    # Check if we should flush
                    if len(buffer.strip()) > 0 and (buffer[-1] in punctuations or len(buffer) > 150):
                        # Flush the sentence to TTS
                        await self._synthesize_and_queue(buffer.strip())
                        buffer = ""
                        
            # Flush remaining
            if buffer.strip() and not self._interrupted:
                await self._synthesize_and_queue(buffer.strip())
                
        except Exception as e:
            print(f"[AUDIO-OUT] Stream generation error: {e}")

    async def _playback_worker(self):
        """Background task that continuously plays queued audio files."""
        while self._is_playback_running:
            try:
                # Wait for next audio file
                temp_path = await self._playback_queue.get()
                
                if self._interrupted:
                    self._cleanup(temp_path)
                    self._playback_queue.task_done()
                    continue
                    
                self._speaking = True
                
                try:
                    self.mixer.music.load(temp_path)
                    self.mixer.music.play()

                    while self.mixer.music.get_busy():
                        if self._interrupted:
                            self.mixer.music.stop()
                            break
                        await asyncio.sleep(0.05)
                finally:
                    self.mixer.music.unload()
                    await asyncio.sleep(0.1)
                    self._cleanup(temp_path)
                    
                self._playback_queue.task_done()
                
                # If queue is empty, we are done speaking
                if self._playback_queue.empty():
                    self._speaking = False
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"[AUDIO-OUT] Playback worker error: {e}")
                self._speaking = False

    def interrupt(self):
        """Instantly stops playback and clears the queue."""
        self._interrupted = True
        
        # Clear the queue
        while not self._playback_queue.empty():
            try:
                path = self._playback_queue.get_nowait()
                self._cleanup(path)
                self._playback_queue.task_done()
            except asyncio.QueueEmpty:
                break
                
        if self.mixer and self.mixer.music.get_busy():
            self.mixer.music.stop()
        self._speaking = False
        print("[AUDIO-OUT] ⛔ Speech interrupted.")

    def _cleanup(self, path):
        """Safely delete temp file."""
        try:
            if os.path.exists(path):
                os.unlink(path)
        except Exception as e:
            pass # Ignore cleanup errors on windows occasionally holding files

    def is_speaking(self):
        return self._speaking

    def stop(self):
        self.interrupt()
        self._is_playback_running = False
        if self._playback_task:
            self._playback_task.cancel()
        if self.mixer:
            self.mixer.quit()
        print("[AUDIO-OUT] Speaking agent offline.")

# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    async def run_test():
        print("=" * 50)
        print("  AUDIO-OUT (EDGE-TTS) — Unit Test")
        print("=" * 50)
        
        agent = AudioOut()
        
        print("\n[TEST] Speaking...")
        await agent.speak_async("Hello Sir. JARVIS audio output system is operational. I will now count to ten. One, two, three, four, five, six, seven, eight, nine, ten.")
        
        print("\n[TEST] Interrupt test...")
        # Start speaking as a task
        speak_task = asyncio.create_task(agent.speak_async("I am going to say a very long sentence that you should interrupt before I finish saying it entirely."))
        
        # Wait 2 seconds then interrupt
        await asyncio.sleep(2)
        print("Interrupting!")
        agent.interrupt()
        
        await speak_task
        print("\n[AUDIO-OUT] Unit test complete. ✓")
        agent.stop()
        
    asyncio.run(run_test())
