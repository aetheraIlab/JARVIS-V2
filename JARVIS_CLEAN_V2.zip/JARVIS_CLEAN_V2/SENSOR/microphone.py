# ================================================================
# JARVIS AETHER-CORE V2.0 — AUDIO-IN (LAYER 1 / SYNAPSE)
# ================================================================
# Codename : AUDIO-IN
# Role     : Hearing Agent — VAD + Speech-to-Text
# Tech     : sounddevice + webrtcvad + faster-whisper
# ================================================================

import sys
import os
import queue
import time
import numpy as np
import tempfile
import wave
import threading

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from CONFIG.constants import WAKE_WORD, STOP_WORDS

class AudioIn:
    """
    JARVIS AUDIO-IN — Hearing Agent.
    Uses WebRTC VAD to detect speech and faster-whisper for near-instant STT.
    Provides streaming-like low latency.
    """

    def __init__(self):
        self.running = False
        self.command_queue = queue.Queue()
        
        self.sample_rate = 16000
        self.frame_duration_ms = 30 # WebRTC supports 10, 20, or 30
        self.frame_size = int(self.sample_rate * (self.frame_duration_ms / 1000.0))
        
        self._init_engine()
        print("[AUDIO-IN] Hearing agent initialized.")

    def _init_engine(self):
        """Loads WebRTC VAD and Faster-Whisper."""
        try:
            import webrtcvad
            self.vad = webrtcvad.Vad()
            self.vad.set_mode(3) # 0 to 3, 3 is most aggressive
            print("[AUDIO-IN] WebRTC VAD loaded.")
        except ImportError:
            print("[AUDIO-IN] [!] webrtcvad not installed.")
            self.vad = None

        try:
            from faster_whisper import WhisperModel
            print("[AUDIO-IN] Loading faster-whisper model (tiny.en)...")
            # compute_type="int8" is good for CPU
            self.model = WhisperModel("tiny.en", device="cpu", compute_type="int8")
            print("[AUDIO-IN] faster-whisper loaded.")
        except ImportError:
            print("[AUDIO-IN] [WARN] faster-whisper not installed.")
            self.model = None

    def listen_once(self, timeout=10, phrase_time_limit=15):
        """
        Synchronously listen for one utterance using VAD and transcribe it.
        """
        if not self.vad or not self.model:
            print("[AUDIO-IN] Missing dependencies for listen_once.")
            return None

        try:
            import sounddevice as sd
        except ImportError:
            print("[AUDIO-IN] [WARN] sounddevice not installed.")
            return None

        print("[AUDIO-IN] 🎙 Listening...")
        
        q = queue.Queue()
        def callback(indata, frames, time, status):
            if status:
                print(status, file=sys.stderr)
            q.put(bytes(indata))

        audio_buffer = []
        speech_started = False
        silence_frames = 0
        max_silence_frames = int(1.5 / (self.frame_duration_ms / 1000.0)) # 1.5 seconds of silence
        
        start_time = time.time()
        
        with sd.RawInputStream(samplerate=self.sample_rate, blocksize=self.frame_size, dtype='int16',
                               channels=1, callback=callback):
            while True:
                # Global timeout
                if time.time() - start_time > timeout and not speech_started:
                    return None
                    
                # Max phrase limit
                if speech_started and time.time() - start_time > phrase_time_limit:
                    break

                try:
                    frame = q.get(timeout=0.1)
                except queue.Empty:
                    continue

                is_speech = self.vad.is_speech(frame, self.sample_rate)

                if is_speech:
                    if not speech_started:
                        speech_started = True
                        # Restart the timeout from when speech started
                        start_time = time.time() 
                    silence_frames = 0
                    audio_buffer.append(frame)
                else:
                    if speech_started:
                        silence_frames += 1
                        audio_buffer.append(frame)
                        if silence_frames > max_silence_frames:
                            break # End of speech detected
                    else:
                        # Keep a small rolling buffer of pre-speech so we don't cut off the first phoneme
                        audio_buffer.append(frame)
                        if len(audio_buffer) > 10:
                            audio_buffer.pop(0)

        if not speech_started or not audio_buffer:
            return None

        # Transcribe
        print("[AUDIO-IN] Processing audio...")
        audio_data = b''.join(audio_buffer)
        
        # Save to temp wav for whisper
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            with wave.open(tmp.name, 'wb') as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2) # 16-bit
                wf.setframerate(self.sample_rate)
                wf.writeframes(audio_data)
            tmp_path = tmp.name

        try:
            segments, _ = self.model.transcribe(tmp_path, beam_size=1)
            text = " ".join([segment.text for segment in segments]).strip()
        finally:
            os.unlink(tmp_path)

        if text:
            print(f"[AUDIO-IN] ✓ Heard: \"{text}\"")
        return text

    def is_wake_word(self, text):
        if not text: return False
        return WAKE_WORD in text.lower().replace(",", "").replace(".", "")

    def is_stop_command(self, text):
        if not text: return False
        return any(word in text.lower() for word in STOP_WORDS)

    def start_continuous_listen(self, on_speech_start=None):
        """
        Starts a background thread that continuously listens for speech.
        If on_speech_start callback is provided, it is called the moment VAD detects speech 
        (useful for instantly interrupting TTS).
        """
        self.running = True
        self.is_muted = False
        thread = threading.Thread(target=self._listen_loop, args=(on_speech_start,), daemon=True)
        thread.start()
        print("[AUDIO-IN] Continuous listening started.")

    def mute(self):
        self.is_muted = True
        
    def unmute(self):
        self.is_muted = False

    def _listen_loop(self, on_speech_start):
        """The core continuous VAD listening loop."""
        if not self.vad or not self.model:
            self.running = False
            return
            
        try:
            import sounddevice as sd
        except ImportError:
            self.running = False
            return

        q = queue.Queue()
        def callback(indata, frames, time, status):
            if status: pass
            q.put(bytes(indata))

        audio_buffer = []
        speech_started = False
        silence_frames = 0
        
        # Snappier silence timeout for real-time conversation (0.8s instead of 1.2s)
        base_silence_sec = 0.8 
        max_silence_frames = int(base_silence_sec / (self.frame_duration_ms / 1000.0))

        # Start stream
        stream = sd.RawInputStream(samplerate=self.sample_rate, blocksize=self.frame_size, dtype='int16',
                               channels=1, callback=callback)
        stream.start()

        while self.running:
            try:
                frame = q.get(timeout=0.1)
            except queue.Empty:
                continue

            if self.is_muted:
                if speech_started:
                    # Cancel current recording if muted mid-speech
                    speech_started = False
                    audio_buffer = []
                continue

            is_speech = self.vad.is_speech(frame, self.sample_rate)

            if is_speech:
                if not speech_started:
                    speech_started = True
                    silence_frames = 0
                    if on_speech_start:
                        on_speech_start() # Trigger interrupt immediately
                else:
                    silence_frames = 0
                audio_buffer.append(frame)
            else:
                if speech_started:
                    silence_frames += 1
                    audio_buffer.append(frame)
                    
                    # Dynamic silence: if utterance is already very long, cut off sooner
                    current_duration = len(audio_buffer) * (self.frame_duration_ms / 1000.0)
                    dynamic_max_silence = max_silence_frames
                    if current_duration > 5.0:
                        dynamic_max_silence = int(0.5 / (self.frame_duration_ms / 1000.0))
                        
                    if silence_frames > dynamic_max_silence:
                        # Process the utterance
                        self._process_utterance(b''.join(audio_buffer))
                        audio_buffer = []
                        speech_started = False
                else:
                    audio_buffer.append(frame)
                    if len(audio_buffer) > 15:
                        audio_buffer.pop(0)

        stream.stop()
        stream.close()

    def _process_utterance(self, audio_data):
        """Helper to transcribe a chunk of audio in the background."""
        if len(audio_data) < self.sample_rate * 2 * 0.5: # Skip if less than 0.5 seconds
            return
            
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            with wave.open(tmp.name, 'wb') as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(self.sample_rate)
                wf.writeframes(audio_data)
            tmp_path = tmp.name

        try:
            segments, _ = self.model.transcribe(tmp_path, beam_size=1)
            text = " ".join([segment.text for segment in segments]).strip()
            if text:
                print(f"[AUDIO-IN] ✓ Heard: \"{text}\"")
                self.command_queue.put(text)
        except Exception as e:
            print(f"[AUDIO-IN] Transcription error: {e}")
        finally:
            os.unlink(tmp_path)

    def get_command(self, block=False, timeout=None):
        try:
            return self.command_queue.get(block=block, timeout=timeout)
        except queue.Empty:
            return None

    def stop(self):
        self.running = False
        print("[AUDIO-IN] Hearing agent offline.")

# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 50)
    print("  AUDIO-IN (VAD + Whisper) — Unit Test")
    print("=" * 50)

    agent = AudioIn()
    
    print("\n[TEST] Single listen test (Say something)...")
    result = agent.listen_once(timeout=10)
    
    if result:
        print(f"[TEST] You said: \"{result}\"")
    else:
        print("[TEST] No speech detected.")
        
    print("\n[AUDIO-IN] Unit test complete. ✓")
