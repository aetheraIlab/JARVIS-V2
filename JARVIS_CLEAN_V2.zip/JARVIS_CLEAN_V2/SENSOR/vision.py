# ================================================================
# JARVIS AETHER-CORE V2.0 — OPTIC (LAYER 1 / SYNAPSE)
# ================================================================
# Codename : OPTIC
# Role     : Multi-Backend Vision Agent — Camera Fallback System
# Tech     : OpenCV (MSMF/DSHOW/FFMPEG), face_recognition
# ================================================================

import sys
import os
import threading
import time
import logging
from typing import Optional, List, Any
import numpy as np

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

try:
    from CONFIG.config import VISION_DIR
except ImportError:
    VISION_DIR = "HEAP/vision"

logger = logging.getLogger("VISION")

class MultiBackendVision:
    """
    JARVIS Multi-Backend Vision System.
    Provides robust camera fallback to handle IPU6/Windows 11 incompatibilities.
    Attempts MSMF -> DSHOW -> FFMPEG -> IP Camera -> Mock Mode sequentially.
    """
    def __init__(self, camera_index=0):
        self.camera_index = camera_index
        self.running = False
        self.cap = None
        self.backend_name = None
        self.is_available = False
        self._cv2 = None
        self._face_rec = None
        self._known_encodings = []
        self._known_names = []
        self._last_frame = None
        self._lock = threading.Lock()
        
        # Performance tracking
        self._frames_read = 0
        self._start_time = 0
        self.fps = 0.0
        self.resolution = (0, 0)

        self._init_vision_modules()

        if self._cv2:
            # Fallback sequence
            self.BACKENDS = [
                (self._cv2.CAP_MSMF, "Windows Media Foundation (MSMF)"),
                (self._cv2.CAP_DSHOW, "DirectShow (DSHOW)"),
                (self._cv2.CAP_FFMPEG, "FFmpeg"),
            ]
        else:
            self.BACKENDS = []

        self.IP_CAMERA_URLS = [
            "http://192.168.1.100:8080/video",  # DroidCam default
            "http://192.168.0.100:4747/video",   # IP Webcam default
            "http://10.0.0.1:8080/video",
        ]

    def _init_vision_modules(self):
        """OpenCV এবং face_recognition লোড করা হচ্ছে।"""
        try:
            import cv2
            self._cv2 = cv2
            logger.info("[OPTIC] OpenCV loaded.")
        except ImportError:
            logger.error("[OPTIC] OpenCV not installed. Run: pip install opencv-python")

        try:
            import face_recognition
            self._face_rec = face_recognition
            logger.info("[OPTIC] face_recognition loaded.")
        except ImportError:
            logger.warning("[OPTIC] face_recognition not installed. Run: pip install face-recognition")

    # ── Fallback Initialization Logic ─────────────────────────────

    def initialize(self) -> bool:
        """Try all backends sequentially. Return True if any works."""
        if not self._cv2:
            logger.error("[OPTIC] Cannot initialize — OpenCV is missing.")
            return False

        logger.info("[OPTIC] Starting Multi-Backend Camera Probe...")

        # 1. Try local camera with different backends
        for backend_id, name in self.BACKENDS:
            if self._try_backend(backend_id, name):
                self._emit_status("connected", f"Local camera via {name}")
                return True

        # 2. Try IP Cameras
        if self._try_ip_camera():
            self._emit_status("connected", "IP Camera")
            return True

        # 3. Try Mock Mode
        if self._try_mock_mode():
            self._emit_status("connected", "Mock Mode")
            return True

        self._emit_status("failed", "All vision backends failed.")
        return False

    def _try_backend(self, backend_id: int, name: str) -> bool:
        """Attempt to open the local camera using a specific OpenCV API backend."""
        logger.info(f"[OPTIC] Trying backend: {name} (Index: {self.camera_index})")
        try:
            cap = self._cv2.VideoCapture(self.camera_index, backend_id)
            if cap is None or not cap.isOpened():
                logger.warning(f"[OPTIC] Backend {name} failed to open.")
                if cap:
                    cap.release()
                return False

            # Test read to ensure it's actually working (some backends open but return empty frames)
            ret, frame = cap.read()
            if not ret or frame is None:
                logger.warning(f"[OPTIC] Backend {name} opened but failed to read a frame.")
                cap.release()
                return False

            self.cap = cap
            self.backend_name = name
            self.is_available = True
            self.resolution = (int(cap.get(self._cv2.CAP_PROP_FRAME_WIDTH)), 
                               int(cap.get(self._cv2.CAP_PROP_FRAME_HEIGHT)))
            logger.info(f"[OPTIC] Success! Using {name} at {self.resolution[0]}x{self.resolution[1]}")
            return True
        except Exception as e:
            logger.error(f"[OPTIC] Exception while trying backend {name}: {e}")
            return False

    def _try_ip_camera(self) -> bool:
        """Attempt to connect to a smartphone IP camera."""
        logger.info("[OPTIC] Trying IP Camera fallbacks...")
        for url in self.IP_CAMERA_URLS:
            try:
                cap = self._cv2.VideoCapture(url)
                if cap and cap.isOpened():
                    ret, frame = cap.read()
                    if ret and frame is not None:
                        self.cap = cap
                        self.backend_name = f"IP Camera ({url})"
                        self.is_available = True
                        self.resolution = (int(cap.get(self._cv2.CAP_PROP_FRAME_WIDTH)), 
                                           int(cap.get(self._cv2.CAP_PROP_FRAME_HEIGHT)))
                        logger.info(f"[OPTIC] Success! Connected to {self.backend_name}")
                        return True
                if cap:
                    cap.release()
            except Exception as e:
                logger.debug(f"[OPTIC] IP Camera {url} failed: {e}")
        return False

    def _try_mock_mode(self) -> bool:
        """Fallback to a static image for testing when no camera is present."""
        logger.info("[OPTIC] Falling back to Mock Mode (static image).")
        # Create a blank black image with text
        img = np.zeros((480, 640, 3), dtype=np.uint8)
        self._cv2.putText(img, "MOCK CAMERA", (200, 240), 
                          self._cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        self.backend_name = "Mock Image"
        self.is_available = True
        self.resolution = (640, 480)
        self._last_frame = img
        return True

    def _emit_status(self, event_type: str, detail: str):
        """Emit a signal via the KERNEL SignalBus if available."""
        try:
            from KERNEL.scheduler import SignalBus
            bus = SignalBus()  # In a real app, this should be the shared instance
            # Since bus is usually passed or global, we just log if we can't emit
            logger.debug(f"[VISION_EVENT] {event_type} - {detail}")
        except Exception:
            pass

    # ── Core Operations ───────────────────────────────────────────

    def capture_frame(self) -> Optional[np.ndarray]:
        """Capture a single frame from the active backend."""
        if not self.is_available:
            if not self.initialize():
                return None

        if self.backend_name == "Mock Image":
            return self._last_frame

        with self._lock:
            ret, frame = self.cap.read()
            if ret:
                self._last_frame = frame
                self._frames_read += 1
                return frame
            else:
                logger.warning("[OPTIC] Failed to capture frame. Camera disconnected?")
                self.cleanup()
                return None

    def detect_faces(self) -> List[dict]:
        """
        Haar Cascade face detection. Returns list of face bounding boxes.
        """
        if not self._cv2:
            return []

        frame = self.capture_frame()
        if frame is None:
            return []

        try:
            gray = self._cv2.cvtColor(frame, self._cv2.COLOR_BGR2GRAY)
            cascade_path = self._cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
            face_cascade = self._cv2.CascadeClassifier(cascade_path)
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
            
            # Format results
            results = []
            for (x, y, w, h) in faces:
                results.append({"x": int(x), "y": int(y), "width": int(w), "height": int(h)})
            return results
        except Exception as e:
            logger.error(f"[OPTIC] detect_faces error: {e}")
            return []

    def get_status(self) -> dict:
        """Return the current status of the vision system."""
        # Calculate rough FPS if running
        if self._start_time > 0 and self._frames_read > 0:
            elapsed = time.time() - self._start_time
            if elapsed > 0:
                self.fps = round(self._frames_read / elapsed, 2)

        return {
            "is_available": self.is_available,
            "backend": self.backend_name,
            "resolution": f"{self.resolution[0]}x{self.resolution[1]}" if self.resolution != (0,0) else "Unknown",
            "fps": self.fps,
            "faces_known": len(self._known_names)
        }

    def cleanup(self):
        """Release resources."""
        self.running = False
        self.is_available = False
        if self.cap and self.cap.isOpened():
            self.cap.release()
        self.cap = None
        self._emit_status("disconnected", "Vision system cleaned up")
        logger.info("[OPTIC] Vision agent offline and resources cleaned up.")

    # ── Legacy Methods (Preserved for compatibility) ──────────────

    def register_owner_face(self, image_path, name="Adil"):
        """মালিকের ফেস এনকোডিং সেভ করে যেন পরে চিনতে পারে।"""
        if not self._face_rec:
            logger.warning("[OPTIC] face_recognition module not available.")
            return False

        if not os.path.exists(image_path):
            logger.warning(f"[OPTIC] Image not found: {image_path}")
            return False

        try:
            image = self._face_rec.load_image_file(image_path)
            encodings = self._face_rec.face_encodings(image)
            if encodings:
                self._known_encodings.append(encodings[0])
                self._known_names.append(name)
                logger.info(f"[OPTIC] ✓ Face registered: {name}")
                return True
            else:
                logger.warning("[OPTIC] No face found in the image.")
                return False
        except Exception as e:
            logger.error(f"[OPTIC] Face registration error: {e}")
            return False

    def identify_face(self, frame):
        """একটি ফ্রেমে থাকা মুখ শনাক্ত করে নাম রিটার্ন করে।"""
        if not self._face_rec or not self._known_encodings or frame is None:
            return []

        try:
            small_frame = self._cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
            rgb_small = small_frame[:, :, ::-1]  # BGR to RGB

            face_locations = self._face_rec.face_locations(rgb_small)
            face_encodings = self._face_rec.face_encodings(rgb_small, face_locations)

            results = []
            for encoding in face_encodings:
                matches = self._face_rec.compare_faces(self._known_encodings, encoding, tolerance=0.5)
                name = "Unknown"
                if True in matches:
                    idx = matches.index(True)
                    name = self._known_names[idx]
                results.append(name)

            return results
        except Exception as e:
            logger.error(f"[OPTIC] Face ID error: {e}")
            return []

    def detect_faces_count(self, frame=None):
        """একটি ফ্রেমে কতগুলো মুখ আছে তা গুনে রিটার্ন করে।"""
        if frame is None:
            frame = self.capture_frame()
        if frame is None:
            return 0
        
        faces = self.detect_faces() # Uses the new method
        return len(faces)

    def get_last_frame(self):
        """সর্বশেষ ক্যাপচার করা ফ্রেম রিটার্ন করে।"""
        return self._last_frame

    def start_feed(self):
        """ব্যাকগ্রাউন্ডে ক্যামেরা ফিড শুরু করে।"""
        if not self.is_available and not self.initialize():
            logger.error("[OPTIC] Cannot start feed — No camera backends available.")
            return

        self.running = True
        self._frames_read = 0
        self._start_time = time.time()
        thread = threading.Thread(target=self._feed_loop, daemon=True)
        thread.start()
        logger.info("[OPTIC] Live camera feed started.")

    def _feed_loop(self):
        """ক্যামেরা থেকে ক্রমাগত ফ্রেম রিড করে।"""
        while self.running:
            self.capture_frame()
            time.sleep(0.05)  # ~20 FPS

    def stop(self):
        """Legacy alias for cleanup."""
        self.cleanup()


# Global Singleton for system-wide use
vision_system = MultiBackendVision()

# Alias for backwards compatibility
Optic = MultiBackendVision


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("=" * 50)
    print("  OPTIC — Multi-Backend Vision Test")
    print("=" * 50)

    agent = vision_system
    success = agent.initialize()
    
    print(f"\n[TEST] Initialization Success: {success}")
    print(f"[TEST] Status: {agent.get_status()}")

    if success:
        print("\n[TEST] Attempting single frame capture...")
        frame = agent.capture_frame()
        if frame is not None:
            print(f"[TEST] ✓ Frame captured: {frame.shape}")
            faces = agent.detect_faces()
            print(f"[TEST] Faces detected: {len(faces)} -> {faces}")
        else:
            print("[TEST] [WARN] Failed to capture frame despite successful initialization.")

    agent.cleanup()
    print("\n[OPTIC] Unit test complete. ✓")
