# ================================================================
# JARVIS AETHER-CORE V2.0 — HEAP-NODE (LAYER 1 / SYNAPSE)
# ================================================================
# Codename : HEAP-NODE
# Role     : Real-time Memory Agent — Live read/write of all events
# Tech     : SQLite3 (via ATLAS) + CACHE-NODE
# ================================================================

import sys
import os
import threading
import time
from datetime import datetime

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from HEAP.database import Atlas
from HEAP.cache import CacheNode


class HeapNode:
    """
    JARVIS HEAP-NODE — রিয়েল-টাইম মেমোরি এজেন্ট।
    সব কথোপকথন, ইভেন্ট, এবং সিস্টেম লগ তাৎক্ষণিকভাবে সেভ করে।
    দ্রুত অ্যাক্সেসের জন্য CACHE-NODE ব্যবহার করে,
    স্থায়ী সঞ্চয়ের জন্য ATLAS ব্যবহার করে।
    """

    def __init__(self, atlas: Atlas = None, cache: CacheNode = None):
        self.atlas = atlas or Atlas()
        self.cache = cache or CacheNode()
        self._write_lock = threading.Lock()
        print("[HEAP-NODE] Real-time memory agent online.")

    def record_conversation(self, speaker, message, agent="APEX"):
        """কথোপকথন সেভ করে (ক্যাশ + ডাটাবেস উভয়ে)।"""
        with self._write_lock:
            # ক্যাশে সর্বশেষ কথোপকথন আপডেট করা হচ্ছে
            self.cache.set("last_speaker", speaker)
            self.cache.set("last_message", message)
            self.cache.set("last_agent", agent)

            # ATLAS-এ স্থায়ীভাবে সেভ করা হচ্ছে
            self.atlas.commit_signal(speaker, agent, "CONVERSATION", message)

    def record_event(self, agent_codename, event_type, detail=""):
        """যেকোনো সিস্টেম ইভেন্ট লগ করে।"""
        with self._write_lock:
            self.atlas.commit_signal(
                agent_codename, "SYSTEM", event_type, detail
            )

    def remember(self, fragment, importance=1, tags=""):
        """দীর্ঘমেয়াদী মেমোরি হিসেবে কিছু সেভ করে।"""
        with self._write_lock:
            self.atlas.add_memory(fragment, importance, tags)

    def recall_recent(self, limit=10):
        """সাম্প্রতিক কথোপকথন ফিরে আনে।"""
        rows = self.atlas.query(
            "SELECT * FROM signals WHERE signal_type='CONVERSATION' ORDER BY id DESC LIMIT ?",
            (limit,)
        )
        return [dict(r) for r in rows]

    def recall_memories(self, limit=5):
        """সবচেয়ে গুরুত্বপূর্ণ মেমোরিগুলো ফিরে আনে।"""
        rows = self.atlas.query(
            "SELECT * FROM memories ORDER BY importance_score DESC, id DESC LIMIT ?",
            (limit,)
        )
        return [dict(r) for r in rows]

    def get_last_context(self):
        """সর্বশেষ কথোপকথনের কনটেক্সট ক্যাশ থেকে ফিরে আনে।"""
        return {
            "speaker": self.cache.get("last_speaker", "Unknown"),
            "message": self.cache.get("last_message", ""),
            "agent": self.cache.get("last_agent", "APEX"),
        }

    def set_identity(self, key, value):
        """ইউজারের তথ্য আপডেট করে।"""
        self.atlas.update_identity(key, value)

    def get_identity(self, key):
        """ইউজারের তথ্য ফিরে আনে।"""
        rows = self.atlas.query(
            "SELECT value FROM identity WHERE attribute=?", (key,)
        )
        if rows:
            return rows[0]["value"]
        return None

    def get_conversation_count(self):
        """মোট কতগুলো কথোপকথন হয়েছে তা জানায়।"""
        rows = self.atlas.query(
            "SELECT COUNT(*) as cnt FROM signals WHERE signal_type='CONVERSATION'"
        )
        return rows[0]["cnt"] if rows else 0


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 50)
    print("  HEAP-NODE — Unit Test")
    print("=" * 50)

    heap = HeapNode()

    # কথোপকথন সেভ
    heap.record_conversation("Adil", "Hello JARVIS, how are you?", "APEX")
    heap.record_conversation("JARVIS", "I am operational, Sir.", "CORTEX-ONLINE")

    # মেমোরি সেভ
    heap.remember("Owner prefers Bengali responses", importance=5, tags="language,preference")
    heap.remember("JARVIS boot time is 2.3 seconds", importance=2, tags="system,performance")

    # আইডেন্টিটি
    heap.set_identity("owner_name", "Adil")
    heap.set_identity("location", "Bangladesh")

    # রিকল
    print("\n[TEST] Recent conversations:")
    for c in heap.recall_recent(3):
        print(f"  {c['sender']}: {c['data']}")

    print("\n[TEST] Important memories:")
    for m in heap.recall_memories(3):
        print(f"  [{m['importance_score']}★] {m['memory_fragment']}")

    print(f"\n[TEST] Owner: {heap.get_identity('owner_name')}")
    print(f"[TEST] Total conversations: {heap.get_conversation_count()}")
    print(f"[TEST] Last context: {heap.get_last_context()}")

    print("\n[HEAP-NODE] Unit test complete. ✓")
