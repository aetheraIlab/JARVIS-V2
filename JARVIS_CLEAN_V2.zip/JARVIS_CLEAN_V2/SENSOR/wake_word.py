# ================================================================
# JARVIS AETHER-CORE V2.0 — WAKE WORD DETECTOR (SENSOR LAYER)
# ================================================================
# Codename : SENTINEL-WAKEWORD
# Role     : Continuous listening + Wake word detection
# Tech     : SpeechRecognition (Google STT fallback) — CPU-only
# Platform : Windows 11 / Aether Core OS
# ================================================================

import sys
import logging
import threading
import queue
import time
from pathlib import Path
from collections import deque

import numpy as np

# ── Project root path ──────────────────────────────────────────
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

try:
    from SENSOR.microphone import AudioIn
    from CONFIG.constants import WAKE_WORD
except ImportError:
    AudioIn = None
    WAKE_WORD = "jarvis"

# ── Module logger ──────────────────────────────────────────────
logger = logging.getLogger("SENTINEL-WAKEWORD")
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(
        logging.Formatter("[%(name)s] %(levelname)s  %(message)s")
    )
    logger.addHandler(_handler)
    logger.setLevel(logging.INFO)


class WakeWordDetector:
    """
    JARVIS SENTINEL-WAKEWORD — Wake-word detection engine.

    Continuously listens to the default microphone via the
    ``SpeechRecognition`` library, transcribes short audio windows
    with *Google Speech-to-Text* (online) as the primary recogniser,
    and checks whether the configured wake word (default: ``"jarvis"``)
    appears in the transcript.

    Once the wake word is detected the detector enters *awake* mode,
    records a follow-up command, and pushes it into a thread-safe
    ``detected_command_queue`` for downstream consumers
    (e.g. ``VoicePipeline``).

    Design decisions
    ----------------
    * **No PocketSphinx** — removed because the previous placeholder
      path (``/path/to/dict``) was never valid on Windows and the
      library is difficult to maintain cross-platform.
    * **No ``fp16=True``** — that flag requires a CUDA-capable GPU
      and crashes on CPU-only hosts.
    * **SpeechRecognition + Google STT** — lightweight, zero-model-
      download, works on CPU & Windows 11 out of the box.
    * Public API exposes ``start_listening()`` / ``stop_listening()``
      to match the contract expected by ``KERNEL.voice_pipeline``.
    """

    # ────────────────────────────────────────────────────────────
    # Initialisation
    # ────────────────────────────────────────────────────────────

    def __init__(
        self,
        wake_word: str = WAKE_WORD,
        sensitivity: float = 0.5,
        timeout: int = 10,
    ):
        """
        Initialise the wake-word detector.

        Args:
            wake_word:   The keyword to listen for (case-insensitive).
            sensitivity: 0.0–1.0 — higher values require a stronger
                         match before the detector triggers.
            timeout:     Maximum seconds to wait for a follow-up
                         command after a wake-word detection.
        """
        self.wake_word: str = wake_word.lower().strip()
        self.sensitivity: float = max(0.0, min(1.0, sensitivity))
        self.timeout: int = timeout

        # ── Audio engine ───────────────────────────────────────
        self._audio_in: AudioIn | None = AudioIn() if AudioIn else None
        self._sr = None          # speech_recognition module ref
        self._recognizer = None  # sr.Recognizer instance

        # ── State flags ────────────────────────────────────────
        self.running: bool = False
        self.awake: bool = False
        self._detection_thread: threading.Thread | None = None

        # ── Output queue (detected commands) ───────────────────
        self.detected_command_queue: queue.Queue = queue.Queue()

        # ── Audio buffer (captures audio around the wake word) ─
        self.audio_buffer: deque = deque(maxlen=16000 * 2)  # ~2 s

        # ── Statistics ─────────────────────────────────────────
        self.detections_count: int = 0
        self.false_positives: int = 0
        self.command_captures: int = 0

        # ── Bootstrap ──────────────────────────────────────────
        self._init_engine()
        logger.info("Wake-word detector initialised.")
        logger.info("Listening for: '%s'", self.wake_word)

    # ────────────────────────────────────────────────────────────
    # Engine bootstrap
    # ────────────────────────────────────────────────────────────

    def _init_engine(self) -> None:
        """Load the SpeechRecognition engine (Google STT backend)."""
        try:
            import speech_recognition as sr

            self._sr = sr
            self._recognizer = sr.Recognizer()
            # Tune for ambient noise on Windows desktop environments
            self._recognizer.energy_threshold = 300
            self._recognizer.dynamic_energy_threshold = True
            self._recognizer.pause_threshold = 0.8
            logger.info("SpeechRecognition engine loaded (Google STT).")
        except ImportError:
            logger.warning(
                "SpeechRecognition not installed. "
                "Install: pip install SpeechRecognition"
            )
            self._recognizer = None

    # ────────────────────────────────────────────────────────────
    # Public API — matches VoicePipeline contract
    # ────────────────────────────────────────────────────────────

    def start_listening(self) -> None:
        """Start the continuous wake-word listening loop (threaded)."""
        if self.running:
            logger.info("Already listening — ignoring duplicate start.")
            return

        self.running = True
        self._detection_thread = threading.Thread(
            target=self._listening_loop,
            name="SENTINEL-WAKEWORD-Listener",
            daemon=True,
        )
        self._detection_thread.start()
        logger.info("Continuous listening started.")

    def stop_listening(self) -> None:
        """Stop the listening loop gracefully."""
        self.running = False
        if self._detection_thread and self._detection_thread.is_alive():
            self._detection_thread.join(timeout=5)
        self._detection_thread = None
        logger.info("Listening stopped.")

    # Legacy aliases — kept so old callers don't break immediately
    start = start_listening
    stop = stop_listening

    # ────────────────────────────────────────────────────────────
    # Core listening loop
    # ────────────────────────────────────────────────────────────

    def _listening_loop(self) -> None:
        """
        Main listening loop (runs on a daemon thread).

        1. Captures a short audio window via SpeechRecognition.
        2. Transcribes with Google STT.
        3. Checks for the wake word.
        4. On match → records a follow-up command and enqueues it.
        """
        if not self._sr or not self._recognizer:
            logger.error(
                "Cannot listen — SpeechRecognition is not available."
            )
            self.running = False
            return

        logger.info("Listening loop active. Waiting for wake word…")

        while self.running:
            try:
                # ── Step 1: Listen for a short phrase ──────────
                transcript = self._listen_short_phrase(
                    timeout=3, phrase_time_limit=3
                )
                if transcript is None:
                    continue

                # ── Step 2: Buffer raw bytes for diagnostics ───
                raw_bytes = transcript.encode("utf-8", errors="replace")
                audio_data = np.frombuffer(
                    raw_bytes.ljust(2, b"\x00"), dtype=np.uint8
                )
                self.audio_buffer.extend(audio_data)

                # ── Step 3: Check for wake word ────────────────
                if self.wake_word in transcript.lower():
                    logger.info("🎤 Wake word detected in: '%s'", transcript)
                    self.detections_count += 1
                    self.awake = True

                    # ── Step 4: Record follow-up command ───────
                    command_text = self._wait_for_command()
                    self.awake = False

                    if command_text:
                        self.command_captures += 1
                        self.detected_command_queue.put(
                            {
                                "text": command_text,
                                "timestamp": time.time(),
                                "confidence": "high",
                            }
                        )
                        logger.info(
                            "✓ Command captured: '%s'", command_text
                        )
                    else:
                        self.false_positives += 1
                        logger.info(
                            "✗ Wake word heard but no follow-up command."
                        )

            except KeyboardInterrupt:
                logger.info("Interrupted by user.")
                break
            except Exception:
                logger.exception("Listening error")
                time.sleep(0.5)

    # ────────────────────────────────────────────────────────────
    # STT helpers
    # ────────────────────────────────────────────────────────────

    def _listen_short_phrase(
        self,
        timeout: int = 3,
        phrase_time_limit: int = 3,
    ) -> str | None:
        """
        Capture a short audio window and transcribe it via Google STT.

        Returns the transcribed text (lowercase, stripped) or ``None``
        if nothing intelligible was captured.
        """
        if not self._sr or not self._recognizer:
            return None

        try:
            mic = self._sr.Microphone()
            with mic as source:
                self._recognizer.adjust_for_ambient_noise(
                    source, duration=0.3
                )
                audio = self._recognizer.listen(
                    source,
                    timeout=timeout,
                    phrase_time_limit=phrase_time_limit,
                )

            # Primary: Google Speech-to-Text (free tier, no API key)
            text = self._transcribe_google(audio)
            return text

        except self._sr.WaitTimeoutError:
            # No speech in the window — perfectly normal
            return None
        except Exception:
            logger.exception("Short-phrase listen error")
            return None

    def _transcribe_google(self, audio_data) -> str | None:
        """
        Transcribe audio using Google's free Speech-to-Text API.

        Args:
            audio_data: ``speech_recognition.AudioData`` instance.

        Returns:
            Transcribed text (stripped, lowercase) or ``None``.
        """
        if not self._recognizer or not self._sr:
            return None

        try:
            text = self._recognizer.recognize_google(audio_data)
            return text.strip().lower() if text else None
        except self._sr.UnknownValueError:
            return None
        except self._sr.RequestError as exc:
            logger.warning("Google STT request error: %s", exc)
            return None

    # ────────────────────────────────────────────────────────────
    # Follow-up command capture
    # ────────────────────────────────────────────────────────────

    def _wait_for_command(self, duration: int | None = None) -> str | None:
        """
        After the wake word is detected, listen for the user's
        actual command within *duration* seconds.

        Returns:
            The transcribed command text, or ``None`` on timeout /
            silence.
        """
        duration = duration or self.timeout
        logger.info(
            "Listening for command (%ds timeout)…", duration
        )

        try:
            transcript = self._listen_short_phrase(
                timeout=duration, phrase_time_limit=duration
            )
            if transcript:
                # Strip the wake word itself from the command if present
                clean = transcript.replace(self.wake_word, "").strip()
                return clean if clean else None
            return None

        except Exception:
            logger.exception("Command capture error")
            return None

    # ────────────────────────────────────────────────────────────
    # Queue reader (for external consumers)
    # ────────────────────────────────────────────────────────────

    def get_detected_command(self, timeout: float = 1.0) -> dict | None:
        """
        Blocking read from the detected-command queue.

        Returns:
            A dict ``{"text": str, "timestamp": float,
            "confidence": str}`` or ``None`` on timeout.
        """
        try:
            return self.detected_command_queue.get(timeout=timeout)
        except queue.Empty:
            return None

    # ────────────────────────────────────────────────────────────
    # Statistics
    # ────────────────────────────────────────────────────────────

    def get_stats(self) -> dict:
        """Return detection statistics as a JSON-serialisable dict."""
        return {
            "running": self.running,
            "awake": self.awake,
            "total_detections": self.detections_count,
            "false_positives": self.false_positives,
            "successful_commands": self.command_captures,
            "accuracy": (
                self.command_captures / self.detections_count
                if self.detections_count > 0
                else 0.0
            ),
            "wake_word": self.wake_word,
            "sensitivity": self.sensitivity,
        }


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  SENTINEL-WAKEWORD — Unit Test")
    print("=" * 60)

    detector = WakeWordDetector(wake_word="jarvis", sensitivity=0.7)

    # Status report
    print(f"\n[TEST] Initial configuration:")
    stats = detector.get_stats()
    for k, v in stats.items():
        print(f"  {k}: {v}")

    # Start listening
    print(f"\n[TEST] Starting continuous listening...")
    detector.start_listening()

    print("\n⏳ Listening for 10 seconds… (say 'JARVIS' to test)")
    print("Note: Requires microphone + internet for Google STT")

    try:
        for i in range(10):
            cmd = detector.get_detected_command(timeout=1)
            if cmd:
                print(f"\n✓ DETECTED COMMAND: '{cmd['text']}'")
                print(f"  Confidence: {cmd['confidence']}")
                print(f"  Timestamp: {cmd['timestamp']}")
                break

            sys.stdout.write(f"\r[{i + 1}/10] Waiting...")
            sys.stdout.flush()

        else:
            print("\n⏱ Timeout reached (no command detected)")

    except KeyboardInterrupt:
        print("\n\n[TEST] Interrupted by user")

    finally:
        print("\n[TEST] Stopping listener...")
        detector.stop_listening()

        print("\n[TEST] Final statistics:")
        stats = detector.get_stats()
        for k, v in stats.items():
            if isinstance(v, float):
                print(f"  {k}: {v:.2f}")
            else:
                print(f"  {k}: {v}")

    print("\n" + "=" * 60)
    print("  SENTINEL-WAKEWORD test complete. ✓")
    print("=" * 60)
