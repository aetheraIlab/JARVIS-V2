# ================================================================
# JARVIS AETHER-CORE V2.0 — PRIORITY SCHEDULER
# ================================================================
# Role     : DAG-aware task scheduling with parallel execution
# ================================================================

import asyncio
import logging
import time

from SWARM.task_graph import TaskGraph, TaskNode, TaskStatus
from SWARM.event_stream import EventStream, SwarmEvent, SwarmTelemetry

logger = logging.getLogger("SWARM-SCHEDULER")


class Scheduler:
    """
    Priority-aware, DAG-respecting scheduler.
    Dispatches ready tasks in parallel, enforces timeouts,
    propagates cancellations, and prevents starvation.
    """

    def __init__(self, max_parallel: int = 5):
        self.max_parallel = max_parallel
        self.events = EventStream()
        self.telemetry = SwarmTelemetry()
        self._active_tasks: dict[str, asyncio.Task] = {}
        self._semaphore = asyncio.Semaphore(max_parallel)

    async def execute_graph(self, graph: TaskGraph, execute_fn) -> TaskGraph:
        """
        Executes a full TaskGraph.

        execute_fn: async callable(task_node: TaskNode) -> result
                    Must raise on failure.
        """
        self.events.emit(SwarmEvent.DAG_STARTED, {
            "dag_id": graph.id, "dag_name": graph.name,
            "total_tasks": len(graph.nodes)
        })

        logger.info(f"[SCHEDULER] Executing DAG '{graph.name}' with {len(graph.nodes)} tasks")

        while not graph.is_complete:
            ready = graph.get_ready_tasks()

            if not ready and not self._active_tasks:
                # Deadlock: nothing ready, nothing running
                logger.error("[SCHEDULER] Deadlock detected — no runnable tasks remain.")
                break

            # Launch all ready tasks in parallel (up to semaphore limit)
            launch_tasks = []
            for task_node in ready:
                graph.mark_running(task_node.id)
                coro = self._run_task(graph, task_node, execute_fn)
                t = asyncio.create_task(coro)
                self._active_tasks[task_node.id] = t
                launch_tasks.append(t)

            if launch_tasks:
                # Wait for at least one task to finish before re-checking ready queue
                done, _ = await asyncio.wait(
                    self._active_tasks.values(),
                    return_when=asyncio.FIRST_COMPLETED
                )
                # Clean up completed
                finished_ids = [
                    tid for tid, t in self._active_tasks.items() if t.done()
                ]
                for tid in finished_ids:
                    self._active_tasks.pop(tid, None)
            else:
                # Nothing to launch, but tasks still running — wait briefly
                await asyncio.sleep(0.1)

        # DAG complete
        graph.completed_at = time.time()
        total_ms = (graph.completed_at - graph.created_at) * 1000

        if graph.is_success:
            self.events.emit(SwarmEvent.DAG_COMPLETED, {
                "dag_id": graph.id, "dag_name": graph.name,
                "total_ms": round(total_ms, 1)
            })
            logger.info(f"[SCHEDULER] DAG '{graph.name}' completed in {total_ms:.0f}ms")
        else:
            self.events.emit(SwarmEvent.DAG_FAILED, {
                "dag_id": graph.id, "dag_name": graph.name,
                "trace": graph.get_trace()
            })
            logger.error(f"[SCHEDULER] DAG '{graph.name}' FAILED.")

        return graph

    async def _run_task(self, graph: TaskGraph, task_node: TaskNode, execute_fn):
        """Execute a single task with semaphore gating and timeout."""
        async with self._semaphore:
            self.telemetry.record_delegation()
            try:
                result = await asyncio.wait_for(
                    execute_fn(task_node),
                    timeout=task_node.timeout
                )
                graph.mark_completed(task_node.id, result)
                self.telemetry.record_task_complete(task_node.latency_ms)

            except asyncio.TimeoutError:
                error_msg = f"Task '{task_node.name}' timed out after {task_node.timeout}s"
                logger.error(f"[SCHEDULER] {error_msg}")

                # Retry logic
                if task_node.retry_count < task_node.max_retries:
                    task_node.retry_count += 1
                    task_node.status = TaskStatus.PENDING
                    task_node.started_at = None
                    logger.info(f"[SCHEDULER] Retrying '{task_node.name}' ({task_node.retry_count}/{task_node.max_retries})")
                else:
                    graph.mark_failed(task_node.id, error_msg)
                    self.telemetry.record_task_fail()

            except Exception as e:
                error_msg = str(e)
                if task_node.retry_count < task_node.max_retries:
                    task_node.retry_count += 1
                    task_node.status = TaskStatus.PENDING
                    task_node.started_at = None
                    logger.info(f"[SCHEDULER] Retrying '{task_node.name}' after error ({task_node.retry_count}/{task_node.max_retries})")
                else:
                    graph.mark_failed(task_node.id, error_msg)
                    self.telemetry.record_task_fail()
