# ================================================================
# JARVIS AETHER-CORE V2.0 — BROKER ABSTRACTION LAYER
# ================================================================
# Codename : NEXUS-BROKER
# Role     : Transport-agnostic message broker interface
# Design   : Strategy Pattern — swap InMemory ↔ Redis ↔ NATS
# ================================================================

import asyncio
import logging
import time
import uuid
from abc import ABC, abstractmethod
from collections import defaultdict
from enum import IntEnum

logger = logging.getLogger("SWARM-BROKER")


# ================================================================
# MESSAGE PRIORITY
# ================================================================
class Priority(IntEnum):
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    BACKGROUND = 3


# ================================================================
# MESSAGE ENVELOPE
# ================================================================
class Envelope:
    """Immutable message container travelling through the broker."""

    __slots__ = (
        "id", "topic", "sender", "payload", "priority",
        "timestamp", "reply_to", "correlation_id", "ttl"
    )

    def __init__(self, topic: str, sender: str, payload: dict,
                 priority: Priority = Priority.NORMAL,
                 reply_to: str = None, correlation_id: str = None,
                 ttl: float = 30.0):
        self.id = uuid.uuid4().hex[:12]
        self.topic = topic
        self.sender = sender
        self.payload = payload
        self.priority = priority
        self.timestamp = time.time()
        self.reply_to = reply_to
        self.correlation_id = correlation_id or self.id
        self.ttl = ttl

    @property
    def expired(self) -> bool:
        return (time.time() - self.timestamp) > self.ttl

    def __repr__(self):
        return f"<Envelope {self.id} topic={self.topic} from={self.sender} pri={self.priority.name}>"


# ================================================================
# ABSTRACT BROKER INTERFACE
# ================================================================
class BaseBroker(ABC):
    """
    Transport abstraction. All broker backends implement this.
    Future implementations: RedisBroker, NATSBroker, DistributedBroker.
    """

    @abstractmethod
    async def publish(self, envelope: Envelope):
        """Push a message onto a topic."""

    @abstractmethod
    async def subscribe(self, topic: str, handler):
        """Register a coroutine handler for a topic."""

    @abstractmethod
    async def unsubscribe(self, topic: str, handler):
        """Remove a handler from a topic."""

    @abstractmethod
    async def request(self, envelope: Envelope, timeout: float = 10.0) -> Envelope:
        """Publish a message and wait for a correlated reply (RPC pattern)."""

    @abstractmethod
    async def shutdown(self):
        """Gracefully tear down the broker."""


# ================================================================
# IN-MEMORY BROKER (asyncio-native, zero dependencies)
# ================================================================
class InMemoryBroker(BaseBroker):
    """
    Production-grade in-memory async message broker.
    Uses asyncio.PriorityQueue for ordered delivery and
    asyncio.Event for request/response correlation.
    """

    def __init__(self):
        self._subscribers: dict[str, list] = defaultdict(list)
        self._pending_replies: dict[str, asyncio.Future] = {}
        self._queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._running = False
        self._dispatch_task = None
        self._stats = {"published": 0, "delivered": 0, "expired": 0, "errors": 0}
        logger.info("[BROKER] InMemoryBroker initialized.")

    async def start(self):
        """Starts the background dispatch loop."""
        self._running = True
        self._dispatch_task = asyncio.create_task(self._dispatch_loop())
        logger.info("[BROKER] Dispatch loop started.")

    async def _dispatch_loop(self):
        """Continuously drains the priority queue and fans out to subscribers."""
        while self._running:
            try:
                # Blocks until a message is available
                priority_val, envelope = await asyncio.wait_for(
                    self._queue.get(), timeout=1.0
                )
            except asyncio.TimeoutError:
                continue
            except Exception:
                continue

            if envelope.expired:
                self._stats["expired"] += 1
                continue

            # Check if this is a reply to a pending request
            if envelope.topic.startswith("_reply_") and envelope.correlation_id in self._pending_replies:
                fut = self._pending_replies.pop(envelope.correlation_id)
                if not fut.done():
                    fut.set_result(envelope)
                continue

            # Fan out to subscribers
            handlers = self._subscribers.get(envelope.topic, [])
            for handler in handlers:
                try:
                    await handler(envelope)
                    self._stats["delivered"] += 1
                except Exception as e:
                    self._stats["errors"] += 1
                    logger.error(f"[BROKER] Handler error on topic '{envelope.topic}': {e}")

    async def publish(self, envelope: Envelope):
        await self._queue.put((envelope.priority, envelope))
        self._stats["published"] += 1

    async def subscribe(self, topic: str, handler):
        if handler not in self._subscribers[topic]:
            self._subscribers[topic].append(handler)

    async def unsubscribe(self, topic: str, handler):
        if handler in self._subscribers[topic]:
            self._subscribers[topic].remove(handler)

    async def request(self, envelope: Envelope, timeout: float = 10.0) -> Envelope:
        """Publishes a message and waits for a correlated reply."""
        reply_topic = f"_reply_{envelope.correlation_id}"
        envelope.reply_to = reply_topic

        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        self._pending_replies[envelope.correlation_id] = fut

        await self.publish(envelope)

        try:
            result = await asyncio.wait_for(fut, timeout=timeout)
            return result
        except asyncio.TimeoutError:
            self._pending_replies.pop(envelope.correlation_id, None)
            logger.warning(f"[BROKER] Request timeout for {envelope.id} on topic {envelope.topic}")
            return None

    async def shutdown(self):
        self._running = False
        if self._dispatch_task:
            self._dispatch_task.cancel()
        logger.info(f"[BROKER] Shutdown. Stats: {self._stats}")

    def get_stats(self) -> dict:
        return dict(self._stats)
