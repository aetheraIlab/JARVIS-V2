# ================================================================
# JARVIS AETHER-CORE V2.0 — TASK GRAPH (DAG ENGINE)
# ================================================================
# Role     : Directed Acyclic Graph for multi-step task decomposition
# ================================================================

import uuid
import time
import logging
from enum import Enum
from collections import defaultdict

logger = logging.getLogger("SWARM-DAG")


class TaskStatus(Enum):
    PENDING = "PENDING"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    SKIPPED = "SKIPPED"


class TaskNode:
    """A single node in the task DAG."""

    __slots__ = (
        "id", "name", "agent_type", "payload",
        "priority", "status", "result", "error",
        "dependencies", "dependents",
        "created_at", "started_at", "completed_at",
        "retry_count", "max_retries", "timeout"
    )

    def __init__(self, name: str, agent_type: str, payload: dict,
                 priority: int = 2, timeout: float = 30.0, max_retries: int = 1):
        self.id = uuid.uuid4().hex[:10]
        self.name = name
        self.agent_type = agent_type
        self.payload = payload
        self.priority = priority
        self.status = TaskStatus.PENDING
        self.result = None
        self.error = None
        self.dependencies: list[str] = []   # IDs of tasks this depends on
        self.dependents: list[str] = []     # IDs of tasks that depend on this
        self.created_at = time.time()
        self.started_at = None
        self.completed_at = None
        self.retry_count = 0
        self.max_retries = max_retries
        self.timeout = timeout

    @property
    def latency_ms(self) -> float:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at) * 1000
        return 0.0

    def __repr__(self):
        return f"<TaskNode {self.id} '{self.name}' [{self.status.value}] agent={self.agent_type}>"


class TaskGraph:
    """
    Directed Acyclic Graph for task orchestration.
    Supports dependency-aware scheduling, parallel fan-out, and execution tracing.
    """

    def __init__(self, name: str = "unnamed_dag"):
        self.id = uuid.uuid4().hex[:10]
        self.name = name
        self.nodes: dict[str, TaskNode] = {}
        self.created_at = time.time()
        self.completed_at = None

    def add_task(self, task: TaskNode) -> str:
        """Add a task node to the graph."""
        self.nodes[task.id] = task
        return task.id

    def add_dependency(self, task_id: str, depends_on_id: str):
        """Declare that task_id depends on depends_on_id completing first."""
        if task_id not in self.nodes or depends_on_id not in self.nodes:
            raise ValueError("Both task IDs must exist in the graph.")
        self.nodes[task_id].dependencies.append(depends_on_id)
        self.nodes[depends_on_id].dependents.append(task_id)

    def get_ready_tasks(self) -> list[TaskNode]:
        """Returns all tasks whose dependencies are fully completed."""
        ready = []
        for node in self.nodes.values():
            if node.status != TaskStatus.PENDING:
                continue
            all_deps_done = all(
                self.nodes[dep_id].status == TaskStatus.COMPLETED
                for dep_id in node.dependencies
            )
            if all_deps_done:
                ready.append(node)
        # Sort by priority (lower = higher priority)
        ready.sort(key=lambda t: t.priority)
        return ready

    def mark_running(self, task_id: str):
        node = self.nodes[task_id]
        node.status = TaskStatus.RUNNING
        node.started_at = time.time()

    def mark_completed(self, task_id: str, result=None):
        node = self.nodes[task_id]
        node.status = TaskStatus.COMPLETED
        node.result = result
        node.completed_at = time.time()
        logger.info(f"[DAG] Task '{node.name}' completed in {node.latency_ms:.0f}ms")

    def mark_failed(self, task_id: str, error: str = ""):
        node = self.nodes[task_id]
        node.status = TaskStatus.FAILED
        node.error = error
        node.completed_at = time.time()
        logger.error(f"[DAG] Task '{node.name}' FAILED: {error}")

        # Cancel all downstream dependents
        self._cancel_dependents(task_id)

    def _cancel_dependents(self, task_id: str):
        """Recursively cancel all tasks that depended on a failed task."""
        for dep_id in self.nodes[task_id].dependents:
            dep_node = self.nodes[dep_id]
            if dep_node.status == TaskStatus.PENDING:
                dep_node.status = TaskStatus.SKIPPED
                dep_node.error = f"Upstream dependency '{task_id}' failed."
                self._cancel_dependents(dep_id)

    @property
    def is_complete(self) -> bool:
        return all(
            n.status in (TaskStatus.COMPLETED, TaskStatus.FAILED,
                         TaskStatus.CANCELLED, TaskStatus.SKIPPED)
            for n in self.nodes.values()
        )

    @property
    def is_success(self) -> bool:
        return all(
            n.status == TaskStatus.COMPLETED for n in self.nodes.values()
        )

    def get_trace(self) -> list[dict]:
        """Returns a full execution trace for observability."""
        trace = []
        for node in sorted(self.nodes.values(), key=lambda n: n.created_at):
            trace.append({
                "id": node.id,
                "name": node.name,
                "agent": node.agent_type,
                "status": node.status.value,
                "latency_ms": round(node.latency_ms, 1),
                "error": node.error,
                "deps": node.dependencies,
            })
        return trace

    def __repr__(self):
        total = len(self.nodes)
        done = sum(1 for n in self.nodes.values() if n.status == TaskStatus.COMPLETED)
        return f"<TaskGraph '{self.name}' {done}/{total} tasks complete>"
