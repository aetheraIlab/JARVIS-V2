# ================================================================
# JARVIS AETHER-CORE V2.0 — CONSENSUS ENGINE
# ================================================================
# Role     : Hybrid quorum/veto consensus for multi-agent decisions
# ================================================================

import asyncio
import logging
import time

from SWARM.event_stream import EventStream, SwarmEvent

logger = logging.getLogger("SWARM-CONSENSUS")


class Vote:
    """A single agent's vote on a proposal."""
    __slots__ = ("agent_id", "decision", "confidence", "weight", "reason")

    def __init__(self, agent_id: str, decision: bool, confidence: float = 1.0,
                 weight: float = 1.0, reason: str = ""):
        self.agent_id = agent_id
        self.decision = decision
        self.confidence = confidence  # 0.0 - 1.0
        self.weight = weight
        self.reason = reason

    @property
    def weighted_score(self) -> float:
        return self.confidence * self.weight * (1.0 if self.decision else -1.0)


class ConsensusEngine:
    """
    Hybrid Consensus Engine.
    - Normal tasks: quorum-based weighted voting.
    - Critical tasks: PresidentAgent retains FINAL VETO POWER.
    - Tie-break: falls back to PresidentAgent.
    """

    def __init__(self, quorum_ratio: float = 0.5):
        self.quorum_ratio = quorum_ratio  # fraction of votes needed
        self.events = EventStream()

    async def propose(self, proposal_id: str, proposal: dict,
                      voters: list[dict], is_critical: bool = False,
                      timeout: float = 10.0) -> dict:
        """
        Runs a consensus round.

        voters: list of dicts with keys:
            - agent_id: str
            - vote_fn: async callable(proposal) -> Vote
            - is_president: bool (optional)

        Returns: { "approved": bool, "votes": [...], "method": str }
        """
        self.events.emit(SwarmEvent.CONSENSUS_STARTED, {
            "proposal_id": proposal_id,
            "voters": [v["agent_id"] for v in voters],
            "critical": is_critical
        })

        collected_votes: list[Vote] = []
        president_vote: Vote = None

        # Gather votes with timeout
        tasks = []
        for voter in voters:
            tasks.append(self._collect_vote(voter, proposal, timeout))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, Exception):
                logger.error(f"[CONSENSUS] Vote collection error: {result}")
                continue
            if result is None:
                continue
            collected_votes.append(result)

            # Track president's vote separately
            voter_info = next((v for v in voters if v["agent_id"] == result.agent_id), None)
            if voter_info and voter_info.get("is_president"):
                president_vote = result

        if not collected_votes:
            self.events.emit(SwarmEvent.CONSENSUS_FAILED, {"proposal_id": proposal_id, "reason": "No votes"})
            return {"approved": False, "votes": [], "method": "NO_VOTES"}

        # ── CRITICAL PATH: President Veto ─────────────────────
        if is_critical and president_vote:
            if not president_vote.decision:
                logger.warning(f"[CONSENSUS] PRESIDENT VETO on proposal {proposal_id}")
                self.events.emit(SwarmEvent.CONSENSUS_REACHED, {
                    "proposal_id": proposal_id, "approved": False, "method": "VETO"
                })
                return {"approved": False, "votes": collected_votes, "method": "PRESIDENT_VETO"}

        # ── NORMAL PATH: Weighted Quorum ──────────────────────
        total_weight = sum(abs(v.weighted_score) for v in collected_votes)
        approve_weight = sum(v.weighted_score for v in collected_votes if v.decision)

        quorum_met = len(collected_votes) >= max(1, int(len(voters) * self.quorum_ratio))

        if total_weight == 0:
            approved = False
        else:
            approval_ratio = approve_weight / total_weight
            approved = approval_ratio > 0.5 and quorum_met

        # ── TIE-BREAK: President Decides ──────────────────────
        if total_weight > 0 and abs(approve_weight / total_weight - 0.5) < 0.05:
            if president_vote:
                approved = president_vote.decision
                method = "TIE_BREAK_PRESIDENT"
            else:
                approved = False
                method = "TIE_BREAK_DENY"
        else:
            method = "QUORUM"

        self.events.emit(SwarmEvent.CONSENSUS_REACHED, {
            "proposal_id": proposal_id,
            "approved": approved,
            "method": method,
            "approval_ratio": round(approve_weight / max(total_weight, 0.001), 3)
        })

        logger.info(f"[CONSENSUS] Proposal '{proposal_id}': approved={approved} method={method}")

        return {
            "approved": approved,
            "votes": collected_votes,
            "method": method
        }

    async def _collect_vote(self, voter: dict, proposal: dict,
                            timeout: float) -> Vote:
        try:
            vote = await asyncio.wait_for(
                voter["vote_fn"](proposal), timeout=timeout
            )
            return vote
        except asyncio.TimeoutError:
            logger.warning(f"[CONSENSUS] Vote timeout from {voter['agent_id']}")
            return None
        except Exception as e:
            logger.error(f"[CONSENSUS] Vote error from {voter['agent_id']}: {e}")
            return None
