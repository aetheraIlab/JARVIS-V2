# ================================================================
# JARVIS AETHER-CORE V2.0 — COORDINATION MEMORY
# ================================================================
# Role     : Shared swarm memory for multi-agent collaboration
# ================================================================

import threading
import time
import logging

logger = logging.getLogger("SWARM-COORD-MEM")


class CoordinationMemory:
    """
    Global shared memory bus for the entire swarm.
    Unlike ExecutionContext (scoped to one DAG), this persists
    across DAG executions for session-level swarm state.
    """

    def __init__(self):
        self._global_store: dict = {}
        self._agent_stores: dict[str, dict] = {}
        self._lock = threading.RLock()
        logger.info("[COORD-MEM] Coordination Memory initialized.")

    # ── Global Memory ─────────────────────────────────────────
    def write(self, key: str, value, ttl: float = None):
        """Write to global swarm memory."""
        with self._lock:
            self._global_store[key] = {
                "value": value,
                "written_at": time.time(),
                "ttl": ttl
            }

    def read(self, key: str, default=None):
        """Read from global swarm memory. Respects TTL expiry."""
        with self._lock:
            entry = self._global_store.get(key)
            if entry is None:
                return default
            if entry["ttl"] and (time.time() - entry["written_at"]) > entry["ttl"]:
                del self._global_store[key]
                return default
            return entry["value"]

    # ── Agent-Scoped Memory ───────────────────────────────────
    def agent_write(self, agent_id: str, key: str, value):
        """Private scratchpad for a specific agent."""
        with self._lock:
            if agent_id not in self._agent_stores:
                self._agent_stores[agent_id] = {}
            self._agent_stores[agent_id][key] = value

    def agent_read(self, agent_id: str, key: str, default=None):
        with self._lock:
            return self._agent_stores.get(agent_id, {}).get(key, default)

    def agent_snapshot(self, agent_id: str) -> dict:
        with self._lock:
            return dict(self._agent_stores.get(agent_id, {}))

    # ── Diagnostics ───────────────────────────────────────────
    def global_keys(self) -> list:
        with self._lock:
            return list(self._global_store.keys())

    def registered_agents(self) -> list:
        with self._lock:
            return list(self._agent_stores.keys())

    def clear_all(self):
        with self._lock:
            self._global_store.clear()
            self._agent_stores.clear()
