# ================================================================
# JARVIS AETHER-CORE V2.0 — ROUTING ENGINE
# ================================================================
# Role     : Topic-based and capability-based message routing
# ================================================================

import logging

logger = logging.getLogger("SWARM-ROUTER")


class RoutingEngine:
    """
    Routes tasks/messages to the best-matching agent based on
    capability, current load, and specialization score.
    """

    def __init__(self, distributed_bus):
        self.bus = distributed_bus

    def find_best_agent(self, required_capability: str, exclude: list = None) -> str:
        """
        Returns the agent_id best suited for the requested capability.
        Selection criteria: capability match → IDLE state → highest weight.
        """
        exclude = exclude or []
        candidates = self.bus.get_agents_for_capability(required_capability)
        candidates = [c for c in candidates if c not in exclude]

        if not candidates:
            logger.warning(f"[ROUTER] No agent found for capability '{required_capability}'")
            return None

        # Score candidates
        scored = []
        for agent_id in candidates:
            info = self.bus.get_agent_info(agent_id)
            score = info.get("weight", 1.0)

            state = info.get("state", "OFFLINE")
            if state == "IDLE":
                score += 5.0
            elif state == "EXECUTING":
                score += 1.0
            elif state == "DEGRADED":
                score -= 3.0
            elif state in ("FAILED", "OFFLINE"):
                score -= 10.0

            scored.append((agent_id, score))

        scored.sort(key=lambda x: x[1], reverse=True)

        best = scored[0]
        if best[1] <= 0:
            logger.warning(f"[ROUTER] All agents for '{required_capability}' are unhealthy.")
            return None

        logger.info(f"[ROUTER] Routed '{required_capability}' → {best[0]} (score={best[1]:.1f})")
        return best[0]

    def find_all_agents(self, required_capability: str) -> list[str]:
        """Returns all agents capable of handling a capability, sorted by score."""
        candidates = self.bus.get_agents_for_capability(required_capability)
        if not candidates:
            return []

        scored = []
        for agent_id in candidates:
            info = self.bus.get_agent_info(agent_id)
            score = info.get("weight", 1.0)
            state = info.get("state", "OFFLINE")
            if state == "IDLE":
                score += 5.0
            elif state == "DEGRADED":
                score -= 3.0
            scored.append((agent_id, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return [s[0] for s in scored if s[1] > 0]
