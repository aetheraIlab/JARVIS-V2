# ================================================================
# JARVIS AETHER-CORE V2.0 — RECOVERY MANAGER
# ================================================================
# Role     : Failed-agent reassignment, deadlock recovery, retry
# ================================================================

import asyncio
import logging
import time

from SWARM.task_graph import TaskGraph, TaskNode, TaskStatus
from SWARM.event_stream import EventStream, SwarmEvent, AgentState

logger = logging.getLogger("SWARM-RECOVERY")


class RecoveryManager:
    """
    Autonomous recovery system for the swarm.
    Handles agent failures, task reassignment, deadlock detection,
    and cascading failure prevention.
    """

    def __init__(self, worker_pool, delegation_engine):
        self.pool = worker_pool
        self.delegation = delegation_engine
        self.events = EventStream()

        # Anti-cascade: track recent recovery attempts
        self._recovery_history: dict[str, list[float]] = {}
        self._max_recoveries_per_minute = 5

    async def handle_agent_failure(self, agent_id: str, error: str = ""):
        """Called when an agent is detected as failed."""
        logger.error(f"[RECOVERY] Agent '{agent_id}' failed: {error}")

        # Anti-cascade check
        if self._is_cascade(agent_id):
            logger.critical(f"[RECOVERY] CASCADE DETECTED for '{agent_id}'. Halting recovery.")
            self.pool.set_state(agent_id, AgentState.OFFLINE)
            return

        self.pool.set_state(agent_id, AgentState.FAILED)
        self.events.emit(SwarmEvent.AGENT_FAILED, {
            "agent_id": agent_id, "error": error
        })

        # Attempt recovery
        self.pool.set_state(agent_id, AgentState.RECOVERING)

        # Simple recovery: mark idle and let scheduler retry
        await asyncio.sleep(2.0)  # Brief cooldown
        self.pool.set_state(agent_id, AgentState.IDLE)
        self.events.emit(SwarmEvent.AGENT_RECOVERED, {"agent_id": agent_id})
        self.events.emit(SwarmEvent.SWARM_RECOVERY, {"agent_id": agent_id, "action": "reset_to_idle"})
        logger.info(f"[RECOVERY] Agent '{agent_id}' recovered and marked IDLE.")

    async def reassign_task(self, task_node: TaskNode, failed_agent: str,
                            graph: TaskGraph) -> str:
        """Reassign a failed task to a different agent."""
        new_agent = self.delegation.delegate(
            task_node.agent_type, exclude=[failed_agent]
        )

        if new_agent:
            # Reset task to pending so scheduler picks it up again
            task_node.status = TaskStatus.PENDING
            task_node.started_at = None
            task_node.error = None
            self.events.emit(SwarmEvent.TASK_REASSIGNED, {
                "task_id": task_node.id,
                "task_name": task_node.name,
                "from": failed_agent,
                "to": new_agent
            })
            logger.info(f"[RECOVERY] Task '{task_node.name}' reassigned: {failed_agent} → {new_agent}")
            return new_agent
        else:
            logger.error(f"[RECOVERY] Cannot reassign '{task_node.name}' — no alternatives available.")
            return None

    def _is_cascade(self, agent_id: str) -> bool:
        """Detects cascading failure loops."""
        now = time.time()
        if agent_id not in self._recovery_history:
            self._recovery_history[agent_id] = []

        # Trim old entries
        self._recovery_history[agent_id] = [
            t for t in self._recovery_history[agent_id]
            if now - t < 60.0
        ]

        self._recovery_history[agent_id].append(now)
        return len(self._recovery_history[agent_id]) > self._max_recoveries_per_minute

    def detect_deadlock(self, graph: TaskGraph) -> bool:
        """Check if a DAG is deadlocked."""
        running = [n for n in graph.nodes.values() if n.status == TaskStatus.RUNNING]
        pending = [n for n in graph.nodes.values() if n.status == TaskStatus.PENDING]

        if not running and pending:
            # Nothing running but tasks remain — possible deadlock
            for p in pending:
                deps_ok = all(
                    graph.nodes[d].status == TaskStatus.COMPLETED
                    for d in p.dependencies
                )
                if deps_ok:
                    return False  # At least one task is actually ready
            return True  # True deadlock
        return False
