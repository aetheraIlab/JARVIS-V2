# ================================================================
# JARVIS AETHER-CORE V2.0 — SWARM ORCHESTRATOR
# ================================================================
# Codename : HIVEMIND
# Role     : Supreme multi-agent orchestration controller
# Design   : DAG planner + priority scheduler + consensus arbiter
# ================================================================

import asyncio
import logging
import sys
import os
import time

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from SWARM.broker import InMemoryBroker, Priority
from SWARM.distributed_bus import DistributedBus
from SWARM.planner import Planner
from SWARM.scheduler import Scheduler
from SWARM.task_graph import TaskGraph, TaskNode, TaskStatus
from SWARM.execution_context import ExecutionContext
from SWARM.coordination_memory import CoordinationMemory
from SWARM.consensus_engine import ConsensusEngine
from SWARM.delegation_engine import DelegationEngine
from SWARM.recovery_manager import RecoveryManager
from SWARM.worker_pool import WorkerPool
from SWARM.event_stream import EventStream, SwarmEvent, AgentState
from SWARM.telemetry import TelemetryCollector

logger = logging.getLogger("SWARM-ORCHESTRATOR")


class SwarmOrchestrator:
    """
    JARVIS HIVEMIND — Supreme Swarm Orchestrator.

    This is the brain of the multi-agent collaborative system.
    It receives user intent from the PresidentAgent, decomposes it
    into a DAG of sub-tasks, delegates them to specialized agents,
    runs them in parallel with dependency awareness, handles failures,
    and returns the consolidated result.

    Integration Points:
    - PresidentAgent calls orchestrator.execute(intent, data)
    - Each agent registers with the WorkerPool on startup
    - The DistributedBus carries all inter-agent messages
    """

    def __init__(self, signal_bus=None):
        # Core Infrastructure
        self.signal_bus = signal_bus
        self.broker = InMemoryBroker()

        self.bus = DistributedBus(self.broker)
        self.pool = WorkerPool()
        self.planner = Planner()
        self.scheduler = Scheduler(max_parallel=5)
        self.consensus = ConsensusEngine(quorum_ratio=0.5)
        self.delegation = DelegationEngine(self.bus)
        self.recovery = RecoveryManager(self.pool, self.delegation)
        self.coord_memory = CoordinationMemory()
        self.events = EventStream()
        self.telemetry = TelemetryCollector()

        # Active execution contexts (one per running DAG)
        self._active_contexts: dict[str, ExecutionContext] = {}

        # Security: recursion depth limit
        self._max_dag_depth = 10
        self._active_dags = 0

        logger.info("[HIVEMIND] Swarm Orchestrator initialized.")

    async def start(self):
        """Boot the swarm infrastructure."""
        await self.bus.start()
        logger.info("[HIVEMIND] Swarm Orchestrator ONLINE.")

    async def shutdown(self):
        """Gracefully shut down the swarm."""
        await self.bus.shutdown()
        self.coord_memory.clear_all()
        logger.info("[HIVEMIND] Swarm Orchestrator OFFLINE.")

    # ================================================================
    # AGENT REGISTRATION (called during system boot)
    # ================================================================
    def register_agent(self, agent_id: str, agent_ref, capabilities: list,
                       weight: float = 1.0):
        """Register an agent with both the worker pool and the bus."""
        self.pool.register(agent_id, agent_ref, capabilities, weight)
        self.bus.register_agent(agent_id, capabilities, weight)

    # ================================================================
    # PRIMARY EXECUTION ENTRY POINT
    # ================================================================
    async def execute(self, intent: str, data: dict,
                      user_text: str = "") -> dict:
        """
        Main entry point called by PresidentAgent.

        1. Plans a DAG from the intent.
        2. Creates an ExecutionContext for shared state.
        3. Schedules and runs the DAG.
        4. Returns consolidated results.
        """
        # Anti-recursion guard
        if self._active_dags >= self._max_dag_depth:
            logger.error("[HIVEMIND] Max DAG depth reached. Rejecting task.")
            return {"success": False, "error": "Recursion depth limit reached."}

        self._active_dags += 1
        start_time = time.time()

        if self.signal_bus:
            asyncio.create_task(self.signal_bus.emit("SWARM", "DAG_STARTED", {"intent": intent, "user_text": user_text}))


        try:
            # 1. Plan
            graph = self.planner.plan(intent, data, user_text)
            logger.info(f"[HIVEMIND] DAG planned: '{graph.name}' with {len(graph.nodes)} tasks")

            # 2. Create shared execution context
            ctx = ExecutionContext(graph.id)
            ctx.set("user_text", user_text)
            ctx.set("intent", intent)
            ctx.set("data", data)
            self._active_contexts[graph.id] = ctx

            # 3. Execute DAG via Scheduler
            completed_graph = await self.scheduler.execute_graph(
                graph, self._make_task_executor(ctx)
            )

            # 4. Collect results
            elapsed_ms = (time.time() - start_time) * 1000
            success = completed_graph.is_success
            self.telemetry.record_dag_complete(elapsed_ms, success)

            results = {}
            for node in completed_graph.nodes.values():
                results[node.name] = {
                    "status": node.status.value,
                    "result": node.result,
                    "error": node.error,
                    "latency_ms": round(node.latency_ms, 1)
                }

            # 5. Cleanup
            self._active_contexts.pop(graph.id, None)

            return {
                "success": success,
                "dag_name": graph.name,
                "dag_id": graph.id,
                "elapsed_ms": round(elapsed_ms, 1),
                "tasks": results,
                "trace": completed_graph.get_trace(),
                "context_snapshot": ctx.snapshot()
            }

            if self.signal_bus:
                asyncio.create_task(self.signal_bus.emit("SWARM", "DAG_COMPLETED", {"dag_id": graph.id, "success": success, "elapsed_ms": elapsed_ms}))


        except Exception as e:
            logger.error(f"[HIVEMIND] Orchestration error: {e}")
            return {"success": False, "error": str(e)}

        finally:
            self._active_dags -= 1

    # ================================================================
    # TASK EXECUTOR FACTORY
    # ================================================================
    def _make_task_executor(self, ctx: ExecutionContext):
        """
        Returns an async function that the Scheduler calls for each TaskNode.
        This function delegates the task to the appropriate agent.
        """
        async def execute_task(task_node: TaskNode):
            agent_type = task_node.agent_type

            # Special case: AI_THINK is handled directly by PresidentAgent
            if agent_type == "AI_THINK":
                # Store for President to pick up
                ctx.set(f"result_{task_node.id}", task_node.payload.get("user_text", ""))
                return task_node.payload.get("user_text", "")

            # Find the best agent for this task type
            agent_id = self.delegation.delegate(agent_type)

            if not agent_id:
                raise RuntimeError(f"No agent available for type '{agent_type}'")

            # Mark agent as executing
            self.pool.set_state(agent_id, AgentState.EXECUTING)
            self.bus.set_agent_state(agent_id, AgentState.EXECUTING)

            try:
                # Get the agent reference and call its execute method
                worker = self.pool.get_worker(agent_id)
                if worker and worker.agent_ref and hasattr(worker.agent_ref, "execute"):
                    # Check if it's a coroutine
                    if asyncio.iscoroutinefunction(worker.agent_ref.execute):
                        result = await worker.agent_ref.execute(
                            task_node.payload.get("action", task_node.name),
                            task_node.payload.get("data", {})
                        )
                    else:
                        result = worker.agent_ref.execute(
                            task_node.payload.get("data", {}),
                            source_id="SYSTEM"
                        )
                else:
                    # Fallback: publish task to the bus and let the agent handle it
                    result = f"Task '{task_node.name}' delegated to {agent_id}"

                # Store result in shared context for downstream tasks
                ctx.set(f"result_{task_node.id}", result)
                self.pool.record_success(agent_id)
                self.telemetry.record_task(success=True)

                return result

            except Exception as e:
                self.pool.record_failure(agent_id)
                self.pool.set_state(agent_id, AgentState.FAILED)
                self.telemetry.record_task(success=False)

                # Attempt recovery & reassignment
                if self.signal_bus:
                    asyncio.create_task(self.signal_bus.emit("SWARM", "AGENT_FAILED", {"agent_id": agent_id, "error": str(e)}))
                
                await self.recovery.handle_agent_failure(agent_id, str(e))
                raise


            finally:
                # Reset agent state
                if self.pool.get_worker(agent_id):
                    self.pool.set_state(agent_id, AgentState.IDLE)
                    self.bus.set_agent_state(agent_id, AgentState.IDLE)

        return execute_task

    # ================================================================
    # DIAGNOSTICS
    # ================================================================
    def get_status(self) -> dict:
        return {
            "active_dags": self._active_dags,
            "registered_agents": len(self.pool.get_all()),
            "healthy_agents": len(self.pool.get_healthy()),
            "degraded_agents": len(self.pool.get_degraded()),
            "telemetry": self.telemetry.get_dashboard(),
            "worker_report": self.pool.get_status_report(),
            "broker_stats": self.broker.get_stats() if hasattr(self.broker, "get_stats") else {},
            "coord_memory_keys": self.coord_memory.global_keys(),
        }


# ================================================================
# STANDALONE TEST
# ================================================================
if __name__ == "__main__":
    async def test_orchestrator():
        print("=" * 60)
        print("  SWARM ORCHESTRATOR — Unit Test")
        print("=" * 60)

        orch = SwarmOrchestrator()
        await orch.start()

        # Register mock agents
        class MockAgent:
            def execute(self, data, source_id="SYSTEM"):
                return f"MockAgent executed with data: {data}"

        orch.register_agent("research_01", MockAgent(), ["web_research"], weight=2.0)
        orch.register_agent("browser_01", MockAgent(), ["web_browse"], weight=1.5)
        orch.register_agent("fs_01", MockAgent(), ["file_ops"], weight=1.0)
        orch.register_agent("term_01", MockAgent(), ["shell_exec"], weight=1.0)

        # Execute a simple single-task DAG
        print("\n--- Test 1: Single Task ---")
        result = await orch.execute("web_search", {"query": "NVIDIA GPU prices"}, "Find NVIDIA GPU prices")
        print(f"Success: {result['success']}")
        print(f"Elapsed: {result['elapsed_ms']}ms")
        for name, info in result.get("tasks", {}).items():
            print(f"  Task '{name}': {info['status']}")

        # Execute a multi-step DAG
        print("\n--- Test 2: Multi-Step DAG ---")
        result2 = await orch.execute("research_and_save", {"query": "AI trends 2026"}, "Research AI trends and save")
        print(f"Success: {result2['success']}")
        print(f"Elapsed: {result2['elapsed_ms']}ms")
        for name, info in result2.get("tasks", {}).items():
            print(f"  Task '{name}': {info['status']} | {info.get('latency_ms', 0)}ms")

        # Status report
        print("\n--- Swarm Status ---")
        status = orch.get_status()
        print(f"Active DAGs: {status['active_dags']}")
        print(f"Registered Agents: {status['registered_agents']}")
        print(f"Healthy: {status['healthy_agents']}")
        print(f"Telemetry: {status['telemetry']}")

        await orch.shutdown()
        print("\n[HIVEMIND] Test complete. ✓")

    asyncio.run(test_orchestrator())
