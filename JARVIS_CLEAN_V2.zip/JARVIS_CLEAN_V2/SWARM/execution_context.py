# ================================================================
# JARVIS AETHER-CORE V2.0 — EXECUTION CONTEXT
# ================================================================
# Role     : Shared state container for a single DAG execution
# ================================================================

import threading
import time
import uuid


class ExecutionContext:
    """
    Provides a shared, thread-safe key-value store for agents
    collaborating on the same TaskGraph (DAG).
    
    Agents read/write intermediate results here so downstream
    nodes can consume upstream outputs without direct coupling.
    """

    def __init__(self, dag_id: str):
        self.id = uuid.uuid4().hex[:10]
        self.dag_id = dag_id
        self._store: dict = {}
        self._lock = threading.RLock()
        self.created_at = time.time()

    def set(self, key: str, value):
        with self._lock:
            self._store[key] = value

    def get(self, key: str, default=None):
        with self._lock:
            return self._store.get(key, default)

    def has(self, key: str) -> bool:
        with self._lock:
            return key in self._store

    def keys(self) -> list:
        with self._lock:
            return list(self._store.keys())

    def snapshot(self) -> dict:
        """Returns a frozen copy of the current state."""
        with self._lock:
            return dict(self._store)

    def __repr__(self):
        return f"<ExecutionContext dag={self.dag_id} keys={len(self._store)}>"
