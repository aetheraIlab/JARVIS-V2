# ================================================================
# JARVIS AETHER-CORE V2.0 — WORKER POOL
# ================================================================
# Role     : Agent lifecycle management and worker registration
# ================================================================

import logging
import time

from SWARM.event_stream import EventStream, SwarmEvent, AgentState

logger = logging.getLogger("SWARM-WORKERS")


class WorkerEntry:
    """Tracks a single agent's registration and lifecycle."""

    __slots__ = (
        "agent_id", "agent_ref", "capabilities", "weight",
        "state", "registered_at", "last_heartbeat",
        "tasks_completed", "tasks_failed"
    )

    def __init__(self, agent_id: str, agent_ref, capabilities: list,
                 weight: float = 1.0):
        self.agent_id = agent_id
        self.agent_ref = agent_ref  # Reference to actual agent object
        self.capabilities = capabilities
        self.weight = weight
        self.state = AgentState.IDLE
        self.registered_at = time.time()
        self.last_heartbeat = time.time()
        self.tasks_completed = 0
        self.tasks_failed = 0

    @property
    def success_rate(self) -> float:
        total = self.tasks_completed + self.tasks_failed
        if total == 0:
            return 1.0
        return self.tasks_completed / total


class WorkerPool:
    """
    Manages the lifecycle of all registered swarm agents.
    Provides the registry that DistributedBus and DelegationEngine query.
    """

    def __init__(self):
        self._workers: dict[str, WorkerEntry] = {}
        self.events = EventStream()
        logger.info("[WORKER-POOL] Initialized.")

    def register(self, agent_id: str, agent_ref, capabilities: list,
                 weight: float = 1.0):
        """Register a new agent worker."""
        entry = WorkerEntry(agent_id, agent_ref, capabilities, weight)
        self._workers[agent_id] = entry
        self.events.emit(SwarmEvent.AGENT_REGISTERED, {
            "agent_id": agent_id,
            "capabilities": capabilities,
            "weight": weight
        })
        logger.info(f"[WORKER-POOL] Registered: {agent_id} caps={capabilities}")

    def deregister(self, agent_id: str):
        self._workers.pop(agent_id, None)
        logger.info(f"[WORKER-POOL] Deregistered: {agent_id}")

    def get_worker(self, agent_id: str) -> WorkerEntry:
        return self._workers.get(agent_id)

    def get_agent_ref(self, agent_id: str):
        """Returns the actual agent object for direct method calls."""
        entry = self._workers.get(agent_id)
        return entry.agent_ref if entry else None

    def set_state(self, agent_id: str, state: str):
        entry = self._workers.get(agent_id)
        if entry:
            old_state = entry.state
            entry.state = state
            if old_state != state:
                self.events.emit(SwarmEvent.AGENT_STATE_CHANGED, {
                    "agent_id": agent_id,
                    "from": old_state,
                    "to": state
                })

    def heartbeat(self, agent_id: str):
        entry = self._workers.get(agent_id)
        if entry:
            entry.last_heartbeat = time.time()

    def record_success(self, agent_id: str):
        entry = self._workers.get(agent_id)
        if entry:
            entry.tasks_completed += 1

    def record_failure(self, agent_id: str):
        entry = self._workers.get(agent_id)
        if entry:
            entry.tasks_failed += 1

    def get_all(self) -> dict[str, WorkerEntry]:
        return dict(self._workers)

    def get_healthy(self) -> list[str]:
        return [
            aid for aid, w in self._workers.items()
            if w.state in (AgentState.IDLE, AgentState.EXECUTING, AgentState.WAITING)
        ]

    def get_degraded(self) -> list[str]:
        return [
            aid for aid, w in self._workers.items()
            if w.state in (AgentState.DEGRADED, AgentState.FAILED)
        ]

    def get_status_report(self) -> dict:
        report = {}
        for aid, w in self._workers.items():
            report[aid] = {
                "state": w.state,
                "caps": w.capabilities,
                "weight": w.weight,
                "success_rate": round(w.success_rate, 2),
                "completed": w.tasks_completed,
                "failed": w.tasks_failed
            }
        return report
