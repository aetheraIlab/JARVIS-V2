# ================================================================
# JARVIS AETHER-CORE V2.0 — EVENT STREAM & TELEMETRY
# ================================================================
# Role     : Real-time swarm telemetry, lifecycle events, tracing
# ================================================================

import logging
import json
import os
import time
from datetime import datetime
from threading import Lock

logger = logging.getLogger("SWARM-EVENTS")


# ================================================================
# EVENT TYPES
# ================================================================
class SwarmEvent:
    TASK_DELEGATED = "TASK_DELEGATED"
    TASK_COMPLETED = "TASK_COMPLETED"
    TASK_FAILED = "TASK_FAILED"
    TASK_REASSIGNED = "TASK_REASSIGNED"
    CONSENSUS_STARTED = "CONSENSUS_STARTED"
    CONSENSUS_REACHED = "CONSENSUS_REACHED"
    CONSENSUS_FAILED = "CONSENSUS_FAILED"
    AGENT_REGISTERED = "AGENT_REGISTERED"
    AGENT_FAILED = "AGENT_FAILED"
    AGENT_RECOVERED = "AGENT_RECOVERED"
    AGENT_STATE_CHANGED = "AGENT_STATE_CHANGED"
    SWARM_RECOVERY = "SWARM_RECOVERY"
    DAG_STARTED = "DAG_STARTED"
    DAG_COMPLETED = "DAG_COMPLETED"
    DAG_FAILED = "DAG_FAILED"


# ================================================================
# AGENT LIFECYCLE STATES
# ================================================================
class AgentState:
    IDLE = "IDLE"
    PLANNING = "PLANNING"
    EXECUTING = "EXECUTING"
    WAITING = "WAITING"
    DEGRADED = "DEGRADED"
    FAILED = "FAILED"
    RECOVERING = "RECOVERING"
    OFFLINE = "OFFLINE"


# ================================================================
# EVENT STREAM (Singleton)
# ================================================================
class EventStream:
    """Centralized event stream for the entire swarm."""

    _instance = None
    _lock = Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True

        self._listeners = {}  # event_type -> [callable]
        self._history = []    # last N events for debugging
        self._max_history = 500

        log_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "HEAP", "logs"
        )
        os.makedirs(log_dir, exist_ok=True)
        self._log_file = os.path.join(log_dir, "swarm_events.jsonl")
        logger.info("[EVENT-STREAM] Initialized.")

    def on(self, event_type: str, callback):
        """Register a listener for a specific event type."""
        if event_type not in self._listeners:
            self._listeners[event_type] = []
        if callback not in self._listeners[event_type]:
            self._listeners[event_type].append(callback)

    def off(self, event_type: str, callback):
        """Remove a listener."""
        if event_type in self._listeners and callback in self._listeners[event_type]:
            self._listeners[event_type].remove(callback)

    def emit(self, event_type: str, data: dict = None):
        """Emit an event synchronously to all registered listeners."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "event": event_type,
            "data": data or {}
        }

        # Persist
        self._history.append(entry)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

        # Write to disk
        try:
            with open(self._log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass

        # Dispatch to listeners
        for cb in self._listeners.get(event_type, []):
            try:
                cb(entry)
            except Exception as e:
                logger.error(f"[EVENT-STREAM] Listener error on {event_type}: {e}")

        logger.debug(f"[EVENT] {event_type}: {data}")

    def get_recent(self, count: int = 20) -> list:
        return self._history[-count:]


# ================================================================
# TELEMETRY COLLECTOR
# ================================================================
class SwarmTelemetry:
    """Collects aggregated swarm performance metrics."""

    def __init__(self):
        self._counters = {
            "tasks_delegated": 0,
            "tasks_completed": 0,
            "tasks_failed": 0,
            "consensus_rounds": 0,
            "recoveries": 0,
            "avg_task_latency_ms": 0.0,
        }
        self._latencies = []

    def record_task_complete(self, latency_ms: float):
        self._counters["tasks_completed"] += 1
        self._latencies.append(latency_ms)
        if len(self._latencies) > 100:
            self._latencies = self._latencies[-100:]
        self._counters["avg_task_latency_ms"] = sum(self._latencies) / len(self._latencies)

    def record_task_fail(self):
        self._counters["tasks_failed"] += 1

    def record_delegation(self):
        self._counters["tasks_delegated"] += 1

    def record_consensus(self):
        self._counters["consensus_rounds"] += 1

    def record_recovery(self):
        self._counters["recoveries"] += 1

    def get_metrics(self) -> dict:
        return dict(self._counters)
