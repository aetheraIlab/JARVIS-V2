# ================================================================
# JARVIS AETHER-CORE V2.0 — DISTRIBUTED BUS
# ================================================================
# Role     : High-level async pub/sub with agent discovery
# ================================================================

import asyncio
import logging
import time

from SWARM.broker import InMemoryBroker, Envelope, Priority

logger = logging.getLogger("SWARM-DBUS")


class DistributedBus:
    """
    High-level messaging layer built on top of the Broker abstraction.
    Provides agent discovery, heartbeat propagation, topic routing,
    broadcast, and request/response messaging.
    """

    def __init__(self, broker=None):
        self.broker = broker or InMemoryBroker()
        self._registered_agents: dict[str, dict] = {}
        self._heartbeats: dict[str, float] = {}
        self._running = False

    async def start(self):
        await self.broker.start()
        self._running = True
        asyncio.create_task(self._heartbeat_monitor())
        logger.info("[DBUS] Distributed Bus online.")

    # ── Agent Discovery ───────────────────────────────────────
    def register_agent(self, agent_id: str, capabilities: list[str], weight: float = 1.0):
        """Register an agent and its capabilities with the bus."""
        self._registered_agents[agent_id] = {
            "capabilities": capabilities,
            "weight": weight,
            "registered_at": time.time(),
            "state": "IDLE"
        }
        self._heartbeats[agent_id] = time.time()
        logger.info(f"[DBUS] Agent registered: {agent_id} caps={capabilities}")

    def deregister_agent(self, agent_id: str):
        self._registered_agents.pop(agent_id, None)
        self._heartbeats.pop(agent_id, None)

    def get_agents_for_capability(self, capability: str) -> list[str]:
        """Find all agents that can handle a given capability."""
        return [
            aid for aid, info in self._registered_agents.items()
            if capability in info["capabilities"]
        ]

    def get_agent_info(self, agent_id: str) -> dict:
        return self._registered_agents.get(agent_id, {})

    def set_agent_state(self, agent_id: str, state: str):
        if agent_id in self._registered_agents:
            self._registered_agents[agent_id]["state"] = state

    def get_all_agents(self) -> dict:
        return dict(self._registered_agents)

    # ── Heartbeat ─────────────────────────────────────────────
    def heartbeat(self, agent_id: str):
        """Call periodically from each agent to signal liveness."""
        self._heartbeats[agent_id] = time.time()

    async def _heartbeat_monitor(self):
        """Background task detecting dead agents.

        Also checks the UAF HeartbeatMonitor for recent beats so that
        agents sending heartbeats through the UAF pipeline are not
        falsely marked DEGRADED by the DBUS.
        """
        # Lazy-import to avoid circular dependency at module load
        uaf_monitor = None
        try:
            from AGENT.heartbeat import heartbeat_monitor as _hb
            uaf_monitor = _hb
        except ImportError:
            pass

        while self._running:
            await asyncio.sleep(60)
            now = time.time()
            for agent_id, last_beat in list(self._heartbeats.items()):
                # Bridge: if the UAF HeartbeatMonitor has a recent beat
                # for this agent (possibly under a different ID scheme),
                # refresh the DBUS timestamp so we don't false-alarm.
                if uaf_monitor is not None:
                    self._sync_uaf_heartbeat(uaf_monitor, agent_id)
                    last_beat = self._heartbeats.get(agent_id, last_beat)

                if now - last_beat > 300.0:  # 300s timeout
                    if self._registered_agents.get(agent_id, {}).get("state") != "OFFLINE":
                        logger.warning(f"[DBUS] Agent '{agent_id}' missed heartbeat. Marking DEGRADED.")
                        self.set_agent_state(agent_id, "DEGRADED")

    def _sync_uaf_heartbeat(self, uaf_monitor, agent_id: str):
        """Check if the UAF HeartbeatMonitor has a recent beat for this agent
        and, if so, update our local timestamp to stay in sync."""
        # UAF agents register with IDs like "BROWSER_AGENT", "CODE_AGENT", etc.
        # The DBUS uses short IDs like "BROWSER", "CODE".
        candidate_ids = [agent_id, f"{agent_id}_AGENT"]
        for uid in candidate_ids:
            summary = uaf_monitor.get_agent_summary(uid)
            if summary and summary.get("beat_count", 0) > 0:
                age = summary.get("last_beat_age_seconds", 999)
                if age < 300.0:
                    self._heartbeats[agent_id] = time.time() - age
                    return

    # ── Messaging ─────────────────────────────────────────────
    async def publish(self, sender: str, topic: str, payload: dict,
                      priority: Priority = Priority.NORMAL):
        env = Envelope(topic=topic, sender=sender, payload=payload, priority=priority)
        await self.broker.publish(env)

    async def subscribe(self, topic: str, handler):
        await self.broker.subscribe(topic, handler)

    async def unsubscribe(self, topic: str, handler):
        await self.broker.unsubscribe(topic, handler)

    async def request(self, sender: str, topic: str, payload: dict,
                      timeout: float = 10.0) -> Envelope:
        """Send a message and wait for a correlated reply (RPC)."""
        env = Envelope(topic=topic, sender=sender, payload=payload)
        return await self.broker.request(env, timeout=timeout)

    async def broadcast(self, sender: str, payload: dict):
        """Send a message to ALL registered agents."""
        env = Envelope(topic="_broadcast", sender=sender, payload=payload,
                       priority=Priority.HIGH)
        await self.broker.publish(env)

    # ── Lifecycle ─────────────────────────────────────────────
    async def shutdown(self):
        self._running = False
        await self.broker.shutdown()
        logger.info("[DBUS] Distributed Bus offline.")
