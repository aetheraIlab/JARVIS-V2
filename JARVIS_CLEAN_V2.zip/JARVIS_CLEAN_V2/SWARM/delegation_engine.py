# ================================================================
# JARVIS AETHER-CORE V2.0 — DELEGATION ENGINE
# ================================================================
# Role     : Capability-aware task delegation with fallback chains
# ================================================================

import logging
from SWARM.routing_engine import RoutingEngine
from SWARM.event_stream import EventStream, SwarmEvent

logger = logging.getLogger("SWARM-DELEGATION")


class DelegationEngine:
    """
    Matches tasks to the best available agent using capability routing,
    workload balancing, and fallback delegation chains.
    """

    def __init__(self, distributed_bus):
        self.bus = distributed_bus
        self.router = RoutingEngine(distributed_bus)
        self.events = EventStream()

        # Agent type → required capability mapping
        self.capability_map = {
            "RESEARCH": "web_research",
            "BROWSER": "web_browse",
            "FILESYSTEM": "file_ops",
            "TERMINAL": "shell_exec",
            "CODE": "code_gen",
            "MONITOR": "sys_monitor",
            "EMAIL": "email_ops",
            "REMINDER": "scheduling",
        }

        # Fallback chains: if primary fails, try next
        self.fallback_chains = {
            "web_research": ["web_browse"],
            "web_browse": [],
            "file_ops": [],
            "shell_exec": [],
            "code_gen": ["web_research"],
        }

    def delegate(self, agent_type: str, exclude: list = None) -> str:
        """
        Find the best agent for a given agent_type.
        Returns agent_id or None.
        """
        capability = self.capability_map.get(agent_type)
        if not capability:
            logger.warning(f"[DELEGATE] Unknown agent type: {agent_type}")
            return None

        # Try primary capability
        agent_id = self.router.find_best_agent(capability, exclude=exclude)

        if agent_id:
            self.events.emit(SwarmEvent.TASK_DELEGATED, {
                "agent_type": agent_type,
                "agent_id": agent_id,
                "capability": capability
            })
            return agent_id

        # Try fallback chain
        fallbacks = self.fallback_chains.get(capability, [])
        for fb_cap in fallbacks:
            agent_id = self.router.find_best_agent(fb_cap, exclude=exclude)
            if agent_id:
                logger.info(f"[DELEGATE] Fallback: {agent_type} → {fb_cap} → {agent_id}")
                self.events.emit(SwarmEvent.TASK_DELEGATED, {
                    "agent_type": agent_type,
                    "agent_id": agent_id,
                    "capability": fb_cap,
                    "fallback": True
                })
                return agent_id

        logger.error(f"[DELEGATE] No agent available for {agent_type} (all fallbacks exhausted)")
        return None

    def delegate_all(self, agent_type: str) -> list[str]:
        """Find ALL agents capable of handling a type (for consensus voting)."""
        capability = self.capability_map.get(agent_type, agent_type)
        return self.router.find_all_agents(capability)
