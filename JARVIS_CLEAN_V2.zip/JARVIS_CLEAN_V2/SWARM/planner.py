# ================================================================
# JARVIS AETHER-CORE V2.0 — AUTONOMOUS PLANNER
# ================================================================
# Role     : Decomposes user intent into a DAG of sub-tasks
# ================================================================

import logging

from SWARM.task_graph import TaskGraph, TaskNode
from SWARM.broker import Priority

logger = logging.getLogger("SWARM-PLANNER")


# ================================================================
# INTENT → AGENT TYPE MAPPING
# ================================================================
INTENT_AGENT_MAP = {
    "web_search": "RESEARCH",
    "browse_url": "BROWSER",
    "file_create": "FILESYSTEM",
    "file_read": "FILESYSTEM",
    "file_delete": "FILESYSTEM",
    "run_command": "TERMINAL",
    "write_code": "CODE",
    "sys_stats": "MONITOR",
    "send_email": "EMAIL",
    "set_reminder": "REMINDER",
    "general_ai": "AI_THINK",
}


class Planner:
    """
    Autonomous Task Planner.
    Takes a user's high-level intent and decomposes it into a
    Directed Acyclic Graph (DAG) of executable sub-tasks.
    """

    def __init__(self):
        pass

    def plan(self, intent: str, data: dict, user_text: str = "") -> TaskGraph:
        """
        Creates a TaskGraph from a classified intent.
        For simple single-agent tasks, creates a single-node DAG.
        For complex multi-step tasks, creates a multi-node DAG with dependencies.
        """
        graph = TaskGraph(name=f"plan_{intent}")

        # Check for complex multi-step intents
        if intent == "research_and_save":
            return self._plan_research_and_save(graph, data, user_text)

        if intent == "research_and_code":
            return self._plan_research_and_code(graph, data, user_text)

        # Default: single-node DAG
        agent_type = INTENT_AGENT_MAP.get(intent, "AI_THINK")
        task = TaskNode(
            name=f"{intent}_task",
            agent_type=agent_type,
            payload={"intent": intent, "data": data, "user_text": user_text},
            priority=Priority.NORMAL,
            timeout=30.0
        )
        graph.add_task(task)
        logger.info(f"[PLANNER] Single-task plan: {intent} → {agent_type}")
        return graph

    # ── Complex Plan Templates ────────────────────────────────

    def _plan_research_and_save(self, graph: TaskGraph, data: dict,
                                user_text: str) -> TaskGraph:
        """Research a topic, then save the results to a file."""
        t1 = TaskNode(
            name="research_topic",
            agent_type="RESEARCH",
            payload={"intent": "web_search", "data": data, "user_text": user_text},
            priority=Priority.HIGH,
            timeout=45.0
        )
        t2 = TaskNode(
            name="save_results",
            agent_type="FILESYSTEM",
            payload={"intent": "file_create", "data": data, "user_text": user_text},
            priority=Priority.NORMAL,
            timeout=15.0
        )

        id1 = graph.add_task(t1)
        id2 = graph.add_task(t2)
        graph.add_dependency(id2, id1)  # save depends on research

        logger.info("[PLANNER] Multi-task plan: research → save")
        return graph

    def _plan_research_and_code(self, graph: TaskGraph, data: dict,
                                user_text: str) -> TaskGraph:
        """Research a topic, write code based on findings, then validate."""
        t1 = TaskNode(
            name="research_topic",
            agent_type="RESEARCH",
            payload={"intent": "web_search", "data": data, "user_text": user_text},
            priority=Priority.HIGH,
            timeout=45.0
        )
        t2 = TaskNode(
            name="generate_code",
            agent_type="CODE",
            payload={"intent": "write_code", "data": data, "user_text": user_text},
            priority=Priority.NORMAL,
            timeout=30.0
        )
        t3 = TaskNode(
            name="save_code",
            agent_type="FILESYSTEM",
            payload={"intent": "file_create", "data": data, "user_text": user_text},
            priority=Priority.NORMAL,
            timeout=15.0
        )

        id1 = graph.add_task(t1)
        id2 = graph.add_task(t2)
        id3 = graph.add_task(t3)
        graph.add_dependency(id2, id1)  # code depends on research
        graph.add_dependency(id3, id2)  # save depends on code

        logger.info("[PLANNER] Multi-task plan: research → code → save")
        return graph
