# ================================================================
# JARVIS AETHER-CORE V2.0 — SWARM TELEMETRY
# ================================================================
# Role     : Aggregated metrics dashboard hook for swarm observability
# ================================================================

import logging
import time

logger = logging.getLogger("SWARM-TELEMETRY")


class TelemetryCollector:
    """Collects real-time performance metrics from all swarm subsystems."""

    def __init__(self):
        self._metrics = {
            "dags_executed": 0,
            "dags_succeeded": 0,
            "dags_failed": 0,
            "tasks_total": 0,
            "tasks_completed": 0,
            "tasks_failed": 0,
            "consensus_rounds": 0,
            "recoveries": 0,
            "messages_published": 0,
            "avg_dag_latency_ms": 0.0,
        }
        self._dag_latencies = []
        self._start_time = time.time()

    def record_dag_complete(self, latency_ms: float, success: bool):
        self._metrics["dags_executed"] += 1
        if success:
            self._metrics["dags_succeeded"] += 1
        else:
            self._metrics["dags_failed"] += 1
        self._dag_latencies.append(latency_ms)
        if len(self._dag_latencies) > 200:
            self._dag_latencies = self._dag_latencies[-200:]
        self._metrics["avg_dag_latency_ms"] = round(
            sum(self._dag_latencies) / len(self._dag_latencies), 1
        )

    def record_task(self, success: bool):
        self._metrics["tasks_total"] += 1
        if success:
            self._metrics["tasks_completed"] += 1
        else:
            self._metrics["tasks_failed"] += 1

    def record_consensus(self):
        self._metrics["consensus_rounds"] += 1

    def record_recovery(self):
        self._metrics["recoveries"] += 1

    def record_message(self):
        self._metrics["messages_published"] += 1

    @property
    def uptime_seconds(self) -> float:
        return round(time.time() - self._start_time, 1)

    def get_dashboard(self) -> dict:
        return {
            "uptime_s": self.uptime_seconds,
            **self._metrics
        }
