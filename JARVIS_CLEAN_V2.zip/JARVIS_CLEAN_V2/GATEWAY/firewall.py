# ================================================================
# JARVIS AETHER-CORE V2.0 — FIREWALL (LAYER 1 / GATEWAY)
# ================================================================
# Codename : FIREWALL
# Role     : Internal Node-to-Node RPC Communication Firewall
# Tech     : SQLite (Atlas) + pathlib
# ================================================================

import sys
import os
import logging
from pathlib import Path

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from HEAP.database import Atlas

class JARVISFirewall:
    """
    JARVIS FIREWALL — Internal Node Communication Security.
    Manages whitelists, blacklists, and port restrictions for all internal network nodes.
    """
    def __init__(self, atlas=None):
        self.logger = logging.getLogger("FIREWALL")
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
            
        self.atlas = atlas or Atlas()
        self.allowed_ports = {5000, 5001, 5002, 8080}
        self._ensure_tables()
        self.logger.info("Firewall initialized. Guarding internal RPC traffic.")

    def _ensure_tables(self):
        """ডাটাবেস টেবিল তৈরি করে।"""
        try:
            cursor = self.atlas.conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS firewall_rules (
                    node_name TEXT PRIMARY KEY,
                    ip_address TEXT,
                    port INTEGER,
                    status TEXT NOT NULL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS firewall_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    node_name TEXT,
                    ip_address TEXT,
                    allowed INTEGER
                )
            ''')
            self.atlas.conn.commit()
        except Exception as e:
            self.logger.error(f"Database error during firewall initialization: {e}")

    def allow_node(self, node_name: str, ip: str, port: int) -> bool:
        """একটি নোডকে হোয়াইটলিস্ট করে।"""
        if not self.check_port(port):
            self.logger.warning(f"Blocked attempt to whitelist {node_name} on unauthorized port {port}.")
            return False
            
        try:
            cursor = self.atlas.conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO firewall_rules (node_name, ip_address, port, status)
                VALUES (?, ?, ?, 'ALLOWED')
            ''', (node_name, ip, port))
            self.atlas.conn.commit()
            self.logger.info(f"Node '{node_name}' ({ip}:{port}) added to whitelist.")
            return True
        except Exception as e:
            self.logger.error(f"Failed to whitelist node '{node_name}': {e}")
            return False

    def deny_node(self, node_name: str) -> bool:
        """একটি নোডকে ব্ল্যাকলিস্ট করে।"""
        try:
            cursor = self.atlas.conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO firewall_rules (node_name, ip_address, port, status)
                VALUES (?, NULL, NULL, 'DENIED')
            ''', (node_name,))
            self.atlas.conn.commit()
            self.logger.warning(f"Node '{node_name}' added to blacklist.")
            return True
        except Exception as e:
            self.logger.error(f"Failed to blacklist node '{node_name}': {e}")
            return False

    def is_allowed(self, node_name: str, ip: str) -> bool:
        """চেক করে যে নোডটি কমিউনিকেট করার অনুমতি রাখে কিনা।"""
        try:
            cursor = self.atlas.conn.cursor()
            cursor.execute('SELECT status, ip_address FROM firewall_rules WHERE node_name = ?', (node_name,))
            row = cursor.fetchone()
            
            allowed = False
            if row:
                status, stored_ip = row
                if status == 'ALLOWED' and stored_ip == ip:
                    allowed = True
                    
            self.log_attempt(node_name, ip, allowed)
            return allowed
        except Exception as e:
            self.logger.error(f"Error checking node authorization: {e}")
            return False

    def check_port(self, port: int) -> bool:
        """শুধুমাত্র নির্দিষ্ট পোর্টগুলো অ্যালাউ করে।"""
        return port in self.allowed_ports

    def log_attempt(self, node_name: str, ip: str, allowed: bool):
        """কানেকশন এটেম্পট লগ করে।"""
        try:
            cursor = self.atlas.conn.cursor()
            cursor.execute('''
                INSERT INTO firewall_logs (node_name, ip_address, allowed)
                VALUES (?, ?, ?)
            ''', (node_name, ip, 1 if allowed else 0))
            self.atlas.conn.commit()
        except Exception as e:
            self.logger.error(f"Failed to log attempt from '{node_name}': {e}")

if __name__ == "__main__":
    print("="*50)
    print("  FIREWALL — Unit Test")
    print("="*50)
    
    fw = JARVISFirewall()
    
    # Test valid addition
    print("\n[TEST] Whitelist node...")
    fw.allow_node("SENTINEL_1", "192.168.1.100", 5001)
    
    # Test invalid port
    print("\n[TEST] Whitelist node on invalid port...")
    fw.allow_node("ROGUE_NODE", "192.168.1.101", 9999)
    
    # Test allow check
    print(f"\n[TEST] Check allowed node: {fw.is_allowed('SENTINEL_1', '192.168.1.100')}")
    print(f"[TEST] Check rogue node: {fw.is_allowed('ROGUE_NODE', '192.168.1.101')}")
    print(f"[TEST] Check wrong IP: {fw.is_allowed('SENTINEL_1', '10.0.0.5')}")
    
    # Test deny node
    print("\n[TEST] Blacklist node...")
    fw.deny_node("SENTINEL_1")
    print(f"[TEST] Check node after blacklist: {fw.is_allowed('SENTINEL_1', '192.168.1.100')}")
    
    print("\n[FIREWALL] Unit test complete. ✓")
