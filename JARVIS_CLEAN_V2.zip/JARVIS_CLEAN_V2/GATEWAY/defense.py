import sys
import os
import re
import time
import logging
from pathlib import Path
from threading import RLock

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from HEAP.database import Atlas

logger = logging.getLogger("DEFENSE-LAYER")
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

class DefenseLayer:
    """
    JARVIS সিস্টেমের সিকিউরিটি গেটওয়ে।
    ইনপুট স্যানিটাইজেশন, রেট লিমিটিং এবং কমান্ড চেকিং পরিচালনা করে।
    """

    def __init__(self):
        self.atlas = Atlas()
        self._rate_limits = {}  # Format: {source_id: [timestamps]}
        self._lock = RLock()
        
        # Dangerous patterns to strip or block
        self.dangerous_commands = [
            r"\brm\s+-rf\b", r"\bdel\s+/f\b", r"\bformat\b", 
            r"\bshutdown\b", r"\bmkfs\b", r"\bdrop\s+table\b",
            r"os\.system", r"subprocess\.Popen", r"exec\(", r"eval\("
        ]
        
        logger.info("DefenseLayer initialized successfully.")

    def sanitize_input(self, text: str) -> str:
        """ইনজেকশন এটেম্পট এবং ক্ষতিকর ক্যারেক্টার রিমুভ করে।"""
        if not text:
            return ""
        
        # Strip null bytes and non-printable characters (except standard newlines/tabs)
        sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', str(text))
        
        # We don't blindly strip && here because it might be valid user chat like "I am fine && you?"
        # Command scanner will handle malicious execution patterns.
        
        return sanitized.strip()

    def rate_limit(self, source_id: str) -> bool:
        """প্রতি মিনিটে সর্বোচ্চ ৩০টি রিকোয়েস্ট অ্যালাউ করে।"""
        with self._lock:
            current_time = time.time()
            if source_id not in self._rate_limits:
                self._rate_limits[source_id] = []
                
            # Filter timestamps from the last 60 seconds
            self._rate_limits[source_id] = [t for t in self._rate_limits[source_id] if current_time - t <= 60]
            
            if len(self._rate_limits[source_id]) >= 30:
                self.log_threat("RATE_LIMIT", f"Source {source_id} exceeded 30 req/min limit.")
                return False
                
            self._rate_limits[source_id].append(current_time)
            return True

    def scan_command(self, text: str) -> bool:
        """ক্ষতিকর কমান্ড ডিটেক্ট করে।"""
        text_lower = text.lower()
        for pattern in self.dangerous_commands:
            if re.search(pattern, text_lower):
                return False
        return True

    def log_threat(self, threat_type: str, detail: str):
        """ডাটাবেসে থ্রেট লগ করে।"""
        try:
            logger.warning(f"THREAT DETECTED [{threat_type}]: {detail}")
            # Atlas commit_signal accepts: source, signal_type, intent, payload
            self.atlas.commit_signal("DEFENSE_LAYER", "SECURITY_ALERT", threat_type, detail)
        except Exception as e:
            logger.error(f"Failed to log threat to database: {e}")

    def is_safe(self, text: str, source_id: str = "default_user") -> dict:
        """সমস্ত সিকিউরিটি চেক একসাথে রান করে।"""
        # ১. রেট লিমিট চেক
        if not self.rate_limit(source_id):
            return {"safe": False, "reason": "Rate limit exceeded. Please wait 60 seconds."}
            
        # ২. স্যানিটাইজেশন
        sanitized_text = self.sanitize_input(text)
        
        # ৩. কমান্ড স্ক্যান
        if not self.scan_command(sanitized_text):
            self.log_threat("DANGEROUS_COMMAND", f"Blocked execution attempt: {text}")
            return {"safe": False, "reason": "Input contains blocked or dangerous commands."}
            
        return {"safe": True, "reason": "Input is safe.", "sanitized_text": sanitized_text}
