import os
import sys
import sqlite3
import logging
import bcrypt
import jwt
from datetime import datetime, timedelta
from pathlib import Path

# .env ফোল্ডার লোড করার চেষ্টা করা হচ্ছে
try:
    from dotenv import load_dotenv
    _has_dotenv = True
except ImportError:
    _has_dotenv = False

# লগার সেটআপ
logger = logging.getLogger("AUTH-GATEWAY")
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

class AuthGateway:
    """
    নিরাপদ অথেনটিকেশন সিস্টেম (JWT + Bcrypt)।
    ইউজার লগইন, টোকেন ভেরিফিকেশন এবং রেট লিমিটিং ম্যানেজ করে (No Pickle Usage)।
    """

    def __init__(self):
        # প্রজেক্ট ডিরেক্টরি সেটআপ (Cross-platform)
        self.base_dir = Path(__file__).resolve().parent.parent
        
        if _has_dotenv:
            load_dotenv(dotenv_path=self.base_dir / ".env")
            
        self.db_path = Path(__file__).resolve().parent / "auth.db"
        self._jwt_secret = os.environ.get("JWT_SECRET", "jarvis_super_secure_jwt_secret_key_123")
        self._jwt_algo = "HS256"
        self._init_db()
        logger.info("Auth Gateway initialized successfully. JWT & Bcrypt Active.")

    def _init_db(self):
        """SQLite ডাটাবেস এবং টেবিল তৈরি করে।"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                # ইউজার টেবিল
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS users (
                        username TEXT PRIMARY KEY,
                        password_hash TEXT NOT NULL
                    )
                ''')
                # রেট লিমিট টেবিল
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS rate_limits (
                        username TEXT PRIMARY KEY,
                        failed_attempts INTEGER DEFAULT 0,
                        lockout_until TEXT
                    )
                ''')
                conn.commit()
        except Exception as e:
            logger.error(f"Failed to initialize auth database: {e}")

    def register(self, username, password):
        """নতুন ইউজার রেজিস্টার করে (Bcrypt হ্যাশ সহ)।"""
        try:
            salt = bcrypt.gensalt()
            pwd_hash = bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO users (username, password_hash)
                    VALUES (?, ?)
                ''', (username, pwd_hash))
                
                cursor.execute('''
                    INSERT OR IGNORE INTO rate_limits (username, failed_attempts)
                    VALUES (?, 0)
                ''', (username,))
                conn.commit()
            logger.info(f"User '{username}' registered successfully.")
            return True
        except Exception as e:
            logger.error(f"Registration failed for '{username}': {e}")
            return False

    def _check_rate_limit(self, cursor, username):
        """রেট লিমিট চেক করে (Max 5 attempts -> 60s lockout)।"""
        cursor.execute('SELECT failed_attempts, lockout_until FROM rate_limits WHERE username = ?', (username,))
        row = cursor.fetchone()
        
        if not row:
            return True, None  # No limit record found, safe
            
        attempts, lockout_until = row
        
        if lockout_until:
            lock_time = datetime.fromisoformat(lockout_until)
            if datetime.now() < lock_time:
                remaining = (lock_time - datetime.now()).seconds
                return False, f"Account locked. Try again in {remaining} seconds."
            else:
                # Lock expired, reset
                cursor.execute('UPDATE rate_limits SET failed_attempts = 0, lockout_until = NULL WHERE username = ?', (username,))
                return True, None
                
        return True, None

    def _increment_failed_attempt(self, cursor, username):
        """ব্যর্থ চেষ্টার কাউন্ট বাড়ায় এবং প্রয়োজনে লক করে।"""
        cursor.execute('SELECT failed_attempts FROM rate_limits WHERE username = ?', (username,))
        row = cursor.fetchone()
        
        if not row:
            cursor.execute('INSERT INTO rate_limits (username, failed_attempts) VALUES (?, 1)', (username,))
            return
            
        attempts = row[0] + 1
        
        if attempts >= 5:
            lock_time = (datetime.now() + timedelta(seconds=60)).isoformat()
            cursor.execute('UPDATE rate_limits SET failed_attempts = ?, lockout_until = ? WHERE username = ?', (attempts, lock_time, username))
            logger.warning(f"User '{username}' locked out for 60 seconds due to 5 failed attempts.")
        else:
            cursor.execute('UPDATE rate_limits SET failed_attempts = ? WHERE username = ?', (attempts, username))

    def _reset_attempts(self, cursor, username):
        """সফল লগইনের পর ফেইল কাউন্ট রিসেট করে।"""
        cursor.execute('UPDATE rate_limits SET failed_attempts = 0, lockout_until = NULL WHERE username = ?', (username,))

    def login(self, username, password):
        """ইউজার ভেরিফাই করে এবং সফল হলে JWT টোকেন রিটার্ন করে।"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # ১. রেট লিমিট চেক
                is_allowed, reason = self._check_rate_limit(cursor, username)
                if not is_allowed:
                    logger.warning(f"Login denied for '{username}': {reason}")
                    return None
                    
                # ২. ইউজার ফেচ করা
                cursor.execute('SELECT password_hash FROM users WHERE username = ?', (username,))
                row = cursor.fetchone()
                
                if not row:
                    logger.warning(f"Login failed: User '{username}' not found.")
                    return None
                    
                pwd_hash = row[0].encode('utf-8')
                
                # ৩. পাসওয়ার্ড ভেরিফাই করা (Bcrypt)
                if bcrypt.checkpw(password.encode('utf-8'), pwd_hash):
                    self._reset_attempts(cursor, username)
                    conn.commit()
                    
                    # JWT টোকেন জেনারেট করা (Expiration: 2 hours)
                    payload = {
                        "sub": username,
                        "exp": datetime.now() + timedelta(hours=2),
                        "iat": datetime.now()
                    }
                    token = jwt.encode(payload, self._jwt_secret, algorithm=self._jwt_algo)
                    logger.info(f"User '{username}' logged in successfully.")
                    return token
                else:
                    self._increment_failed_attempt(cursor, username)
                    conn.commit()
                    logger.warning(f"Login failed: Invalid password for '{username}'.")
                    return None
                    
        except Exception as e:
            logger.error(f"Login process failed: {e}")
            return None

    def verify_token(self, token):
        """JWT টোকেন ভ্যালিডেট করে।"""
        if not token:
            return False
            
        try:
            # ডিকোড এবং ভেরিফাই (Expiration is automatically checked by PyJWT)
            decoded = jwt.decode(token, self._jwt_secret, algorithms=[self._jwt_algo])
            logger.info(f"Token verified successfully for user: {decoded.get('sub')}")
            return True
        except jwt.ExpiredSignatureError:
            logger.warning("Token verification failed: Token has expired.")
            return False
        except jwt.InvalidTokenError:
            logger.warning("Token verification failed: Invalid token.")
            return False
        except Exception as e:
            logger.error(f"Token verification encountered an error: {e}")
            return False

if __name__ == "__main__":
    print("="*50)
    print(" AUTH GATEWAY UNIT TEST ")
    print("="*50)
    
    auth = AuthGateway()
    test_user = "admin"
    test_pass = "secure_password_123"
    
    print(f"\n[1] Registering user '{test_user}'...")
    auth.register(test_user, test_pass)
    
    print("\n[2] Testing Rate Limiting (5 wrong attempts)...")
    for i in range(6):
        print(f"    Attempt {i+1}...")
        token = auth.login(test_user, "wrong_pass")
        if not token:
            print("    -> Login blocked/failed as expected.")
            
    print("\n[3] Testing Valid Login (Should fail if locked out)...")
    valid_token = auth.login(test_user, test_pass)
    if valid_token:
        print("    -> Login successful! Token generated.")
    else:
        print("    -> Login blocked! (Expected behavior due to 60s lockout)")
        
    print("\n[AUTH] Test Complete. Rate limiting and bcrypt integration verified.")
