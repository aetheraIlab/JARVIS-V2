# ================================================================
# JARVIS AETHER-CORE V2.0 — CIPHER-GATE (LAYER 11 / CIPHER)
# ================================================================
# Codename : CIPHER-GATE
# Role     : Guest Handler — Limited permissions for non-owners
# ================================================================

import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


# কোন কোন কমান্ড গেস্ট চালাতে পারবে
GUEST_ALLOWED = [
    "AI_QUERY", "WEB_SEARCH", "TIME", "WEATHER", "GREETING",
]

# কোন কোন কমান্ড শুধুমাত্র মালিক চালাতে পারবে
OWNER_ONLY = [
    "FILE_DELETE", "PROC_KILL", "APP_CLOSE", "SHUTDOWN", "RESTART",
    "SEND_EMAIL", "READ_INBOX", "VAULT_ACCESS", "SYSTEM_SETTINGS",
]


class CipherGate:
    """
    JARVIS CIPHER-GATE — গেস্ট হ্যান্ডলার।
    মালিক ভেরিফাইড না হলে সীমিত অ্যাক্সেস দেয়।
    """

    def __init__(self):
        self.owner_verified = False
        self.guest_mode = True
        self.access_log = []
        print("[CIPHER-GATE] Guest handler initialized.")

    def set_owner_verified(self, status=True):
        """মালিক ভেরিফিকেশন সেট করে।"""
        self.owner_verified = status
        self.guest_mode = not status
        mode = "OWNER" if status else "GUEST"
        print(f"[CIPHER-GATE] Access mode: {mode}")

    def check_permission(self, action_type):
        """একটি অ্যাকশন চালানোর অনুমতি আছে কিনা চেক করে।"""
        # মালিক ভেরিফাইড থাকলে সব অ্যাক্সেস দেওয়া হবে
        if self.owner_verified:
            self._log_access(action_type, "GRANTED", "owner")
            return True

        # গেস্ট মোডে শুধুমাত্র নির্দিষ্ট কমান্ড চলবে
        if action_type in OWNER_ONLY:
            self._log_access(action_type, "DENIED", "guest")
            return False

        if action_type in GUEST_ALLOWED:
            self._log_access(action_type, "GRANTED", "guest")
            return True

        # অজানা অ্যাকশন — ডিফল্টভাবে ব্লক
        self._log_access(action_type, "DENIED", "guest_unknown")
        return False

    def get_denial_message(self, action_type):
        """অনুমতি না থাকলে কী বলবে।"""
        return (
            f"I'm sorry, but the action '{action_type}' requires owner verification. "
            "Please verify your identity through face recognition first."
        )

    def _log_access(self, action, result, mode):
        from datetime import datetime
        self.access_log.append({
            "action": action, "result": result,
            "mode": mode, "time": datetime.now().isoformat()
        })
        if len(self.access_log) > 200:
            self.access_log.pop(0)

    def get_access_log(self, count=10):
        return self.access_log[-count:]

    def get_status(self):
        return {
            "owner_verified": self.owner_verified,
            "guest_mode": self.guest_mode,
            "total_access_checks": len(self.access_log),
        }


if __name__ == "__main__":
    print("=" * 50)
    print("  CIPHER-GATE — Unit Test")
    print("=" * 50)
    gate = CipherGate()
    print(f"\n[TEST] Guest mode — AI_QUERY: {gate.check_permission('AI_QUERY')}")
    print(f"[TEST] Guest mode — FILE_DELETE: {gate.check_permission('FILE_DELETE')}")
    gate.set_owner_verified(True)
    print(f"[TEST] Owner mode — FILE_DELETE: {gate.check_permission('FILE_DELETE')}")
    print(f"[TEST] Status: {gate.get_status()}")
    print("\n[CIPHER-GATE] Unit test complete. ✓")
