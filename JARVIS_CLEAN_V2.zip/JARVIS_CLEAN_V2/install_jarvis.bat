@echo off
title JARVIS AETHER-CORE V2.0 - System Setup ^& Update
color 0B

echo ================================================================
echo   J.A.R.V.I.S  V2.0 -- AETHER-CORE
echo   SYSTEM INSTALLER ^& UPDATER (Windows 11 CPU-Only)
echo ================================================================
echo.

echo [1/4] Checking Python verification...
python --version
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Python is not installed or not in PATH!
    echo Please install Python 3.11+ and try again.
    pause
    exit /b
)

echo.
echo [2/4] Upgrading 'pip' to the latest version...
python -m pip install --upgrade pip

echo.
echo [3/4] Installing / Updating JARVIS Core Dependencies...
python -m pip install -r requirements.txt

echo.
echo [4/4] Installing / Updating Dynamic Agents ^& OS Level Libraries...
:: System, Window Management & OS Controls
python -m pip install pyautogui pygetwindow win10toast plyer psutil schedule

:: AI, Speech & Vision
python -m pip install openai-whisper SpeechRecognition pyttsx3 httpx
python -m pip install opencv-python mediapipe face_recognition cmake dlib

:: Web, UI & APIs
python -m pip install eel duckduckgo-search requests beautifulsoup4
python -m pip install google-auth google-auth-oauthlib google-api-python-client

echo.
echo ================================================================
echo   [SUCCESS] ALL SYSTEMS DOWNLOADING/UPDATING COMPLETE!
echo ================================================================
echo.
echo 1. To start JARVIS AETHER-CORE, run:  python main.py
echo 2. To start PRISM HUD Interface, run: python PRISM_HUD\hud_launcher.py
echo.
pause
