# ================================================================
# JARVIS AETHER-CORE V2.0 — HEARTBEAT MONITOR
# ================================================================
# Role     : Dedicated liveness monitor for all UAF agents
# Layer    : AGENT (Universal Agent Framework)
# Design   : Singleton — import heartbeat_monitor from this module
# ================================================================

import asyncio
import time
import logging
import threading
from typing import Dict, Optional, Callable, List, Any
from datetime import datetime, timezone

from AGENT.state_machine import AgentStateMachine, AgentState

logger = logging.getLogger("HEARTBEAT")


class _AgentRecord:
    """Internal tracking record for a single registered agent."""

    __slots__ = (
        "agent_id", "state_machine", "last_beat_time",
        "metadata", "registered_at", "beat_count",
    )

    def __init__(self, agent_id: str, metadata: Optional[dict] = None):
        self.agent_id = agent_id
        self.state_machine = AgentStateMachine(agent_id)
        self.last_beat_time: float = time.monotonic()
        self.metadata: dict = metadata or {}
        self.registered_at: str = datetime.now(timezone.utc).isoformat()
        self.beat_count: int = 0


class HeartbeatMonitor:
    """
    Production-grade heartbeat monitor for the JARVIS UAF.

    Maintains a registry of agent state machines. Agents call
    ``heartbeat(agent_id)`` periodically; the monitor runs a
    background async loop that marks agents DEGRADED or OFFLINE
    when beats are missed.

    Usage::

        from AGENT.heartbeat import heartbeat_monitor

        heartbeat_monitor.register_agent("BROWSER")
        heartbeat_monitor.heartbeat("BROWSER")
        status = heartbeat_monitor.get_health_status()
    """

    # ── Configuration ─────────────────────────────────────────
    CHECK_INTERVAL_SECONDS: float = 60.0
    DEGRADED_TIMEOUT_SECONDS: float = 300.0
    OFFLINE_TIMEOUT_SECONDS: float = 600.0

    def __init__(self):
        self._agents: Dict[str, _AgentRecord] = {}
        self._lock = threading.RLock()
        self._running = False
        self._monitor_task: Optional[asyncio.Task] = None
        self._offline_callbacks: List[Callable[[str], Any]] = []

    # ── Registration ──────────────────────────────────────────
    def register_agent(self, agent_id: str, metadata: Optional[dict] = None) -> None:
        """
        Register a new agent with the heartbeat monitor.

        Creates a fresh ``AgentStateMachine`` for the agent, transitions
        it through INITIALIZING → IDLE, and records the initial beat.

        Args:
            agent_id:  Unique identifier for the agent.
            metadata:  Optional dict of static agent info (version, caps).
        """
        with self._lock:
            if agent_id in self._agents:
                logger.warning(f"[HEARTBEAT] Agent '{agent_id}' already registered. Skipping.")
                return

            record = _AgentRecord(agent_id, metadata)
            # Walk through the startup lifecycle
            record.state_machine.transition(AgentState.INITIALIZING, reason="Registered with HeartbeatMonitor")
            record.state_machine.transition(AgentState.IDLE, reason="Initial boot complete")
            record.last_beat_time = time.monotonic()

            self._agents[agent_id] = record
            logger.info(f"[HEARTBEAT] Agent registered: {agent_id}")

    def deregister_agent(self, agent_id: str) -> None:
        """Remove an agent from monitoring."""
        with self._lock:
            record = self._agents.pop(agent_id, None)
            if record:
                record.state_machine.transition(AgentState.OFFLINE, reason="Deregistered")
                logger.info(f"[HEARTBEAT] Agent deregistered: {agent_id}")

    # ── Heartbeat Reception ───────────────────────────────────
    def heartbeat(self, agent_id: str, metadata: Optional[dict] = None) -> None:
        """
        Receive a heartbeat pulse from an agent.

        Updates the last-beat timestamp. If the agent was previously
        DEGRADED, promotes it back to IDLE.

        Args:
            agent_id:  The beating agent's identifier.
            metadata:  Optional per-beat telemetry (CPU, queue depth, etc.).
        """
        with self._lock:
            record = self._agents.get(agent_id)
            if not record:
                logger.warning(f"[HEARTBEAT] Beat from unregistered agent '{agent_id}'. Auto-registering.")
                self.register_agent(agent_id, metadata)
                record = self._agents[agent_id]

            record.last_beat_time = time.monotonic()
            record.beat_count += 1
            if metadata:
                record.metadata.update(metadata)

            # Recover from DEGRADED → IDLE
            current = record.state_machine.current_state
            if current == AgentState.DEGRADED:
                record.state_machine.transition(AgentState.IDLE, reason="Heartbeat recovered")
            # Recover from ERROR → INITIALIZING → IDLE (full restart cycle)
            elif current == AgentState.ERROR:
                record.state_machine.transition(AgentState.INITIALIZING, reason="Heartbeat after error")
                record.state_machine.transition(AgentState.IDLE, reason="Recovered from error")
            # Recover from OFFLINE → INITIALIZING → IDLE
            elif current == AgentState.OFFLINE:
                record.state_machine.transition(AgentState.INITIALIZING, reason="Heartbeat after offline")
                record.state_machine.transition(AgentState.IDLE, reason="Came back online")

    # ── Background Monitor Loop ───────────────────────────────
    async def monitor_loop(self) -> None:
        """
        Async background loop that checks agent liveness every
        ``CHECK_INTERVAL_SECONDS``. Call this via ``asyncio.create_task``.
        """
        self._running = True
        logger.info("[HEARTBEAT] Monitor loop started.")
        try:
            while self._running:
                self._check_timeouts()
                await asyncio.sleep(self.CHECK_INTERVAL_SECONDS)
        except asyncio.CancelledError:
            logger.info("[HEARTBEAT] Monitor loop cancelled.")
        finally:
            self._running = False
            logger.info("[HEARTBEAT] Monitor loop stopped.")

    async def start(self) -> None:
        """Start the monitor loop as an asyncio task."""
        if self._running:
            return
        self._monitor_task = asyncio.create_task(self.monitor_loop())
        logger.info("[HEARTBEAT] Monitor started.")

    def stop(self) -> None:
        """Gracefully stop the monitor loop."""
        self._running = False
        if self._monitor_task and not self._monitor_task.done():
            self._monitor_task.cancel()
        logger.info("[HEARTBEAT] Monitor stop requested.")

    # ── Timeout Detection ─────────────────────────────────────
    def _check_timeouts(self) -> None:
        """
        Scan all agents and transition any that have missed their
        heartbeat window to DEGRADED or OFFLINE.
        """
        now = time.monotonic()
        with self._lock:
            for agent_id, record in self._agents.items():
                elapsed = now - record.last_beat_time
                current = record.state_machine.current_state

                # Already offline — nothing to do
                if current == AgentState.OFFLINE:
                    continue

                if elapsed >= self.OFFLINE_TIMEOUT_SECONDS:
                    if current != AgentState.OFFLINE:
                        record.state_machine.transition(
                            AgentState.OFFLINE,
                            reason=f"No heartbeat for {elapsed:.1f}s (limit: {self.OFFLINE_TIMEOUT_SECONDS}s)"
                        )
                        logger.warning(f"[HEARTBEAT] Agent '{agent_id}' marked OFFLINE (no beat for {elapsed:.1f}s)")
                        self._fire_offline_callbacks(agent_id)

                elif elapsed >= self.DEGRADED_TIMEOUT_SECONDS:
                    if current not in (AgentState.DEGRADED, AgentState.ERROR, AgentState.SHUTTING_DOWN):
                        record.state_machine.transition(
                            AgentState.DEGRADED,
                            reason=f"No heartbeat for {elapsed:.1f}s (limit: {self.DEGRADED_TIMEOUT_SECONDS}s)"
                        )
                        logger.warning(f"[HEARTBEAT] Agent '{agent_id}' marked DEGRADED (no beat for {elapsed:.1f}s)")

    # ── Offline Callbacks ─────────────────────────────────────
    def on_agent_offline(self, callback: Callable[[str], Any]) -> None:
        """
        Register a callback to be invoked when any agent goes OFFLINE.

        The callback receives the ``agent_id`` as its sole argument.
        """
        self._offline_callbacks.append(callback)

    def _fire_offline_callbacks(self, agent_id: str) -> None:
        for cb in self._offline_callbacks:
            try:
                cb(agent_id)
            except Exception as e:
                logger.error(f"[HEARTBEAT] Offline callback error for '{agent_id}': {e}")

    # ── Query Interface ───────────────────────────────────────
    def get_agent_state(self, agent_id: str) -> Optional[AgentState]:
        """Return the current state of a single agent, or None if unknown."""
        with self._lock:
            record = self._agents.get(agent_id)
            return record.state_machine.current_state if record else None

    def get_agent_summary(self, agent_id: str) -> Optional[dict]:
        """Return the full state-machine summary for one agent."""
        with self._lock:
            record = self._agents.get(agent_id)
            if not record:
                return None
            summary = record.state_machine.get_summary()
            summary["beat_count"] = record.beat_count
            summary["last_beat_age_seconds"] = round(time.monotonic() - record.last_beat_time, 2)
            summary["metadata"] = record.metadata
            return summary

    def get_health_status(self) -> dict:
        """
        Return a full health dashboard for all registered agents.

        Returns a dict with per-agent summaries and aggregate counts::

            {
                "total_agents": 10,
                "healthy": 8,
                "degraded": 1,
                "offline": 1,
                "agents": { "BROWSER": {...}, ... }
            }
        """
        with self._lock:
            agents_summary = {}
            healthy = degraded = offline = errored = 0

            for agent_id, record in self._agents.items():
                state = record.state_machine.current_state
                agents_summary[agent_id] = self.get_agent_summary(agent_id)

                if state in (AgentState.IDLE, AgentState.BUSY):
                    healthy += 1
                elif state == AgentState.DEGRADED:
                    degraded += 1
                elif state == AgentState.OFFLINE:
                    offline += 1
                elif state == AgentState.ERROR:
                    errored += 1

            return {
                "total_agents": len(self._agents),
                "healthy": healthy,
                "degraded": degraded,
                "errored": errored,
                "offline": offline,
                "monitor_running": self._running,
                "agents": agents_summary,
            }

    def get_all_agent_ids(self) -> list:
        """Return a list of all registered agent IDs."""
        with self._lock:
            return list(self._agents.keys())

    def __repr__(self) -> str:
        with self._lock:
            return (
                f"<HeartbeatMonitor agents={len(self._agents)} "
                f"running={self._running}>"
            )


# ── Global Singleton ──────────────────────────────────────────
heartbeat_monitor = HeartbeatMonitor()
