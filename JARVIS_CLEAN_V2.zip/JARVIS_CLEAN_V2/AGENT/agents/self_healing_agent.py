import sys
import os
import asyncio

# Ensure project root is in path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from SELF_HEAL.crash_monitor import CrashMonitor
from MONITOR.tracer import TraceManager

class SelfHealingAgent(BaseAgent):
    """
    JARVIS UAF Self-Healing Agent.
    Wrapper for SELF_HEAL/crash_monitor.py.
    """
    AGENT_ID = "HEAL_AGENT"
    AGENT_NAME = "Self-Healing Engine Agent"
    VERSION = "2.0.0"
    CATEGORY = "resilience"
    CAPABILITIES = [
        {"name": "crash_monitoring", "description": "Listen for system exceptions and trigger repair"},
        {"name": "autonomous_repair", "description": "Generate patches and apply them in sandbox"}
    ]

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.monitor = CrashMonitor(bus)

    async def initialize(self) -> None:
        await super().initialize()
        self.monitor.start()

    async def execute(self, action: str, params: dict) -> AgentResponse:
        self.logger.info(f"Executing action: {action}")
        
        if action == "manual_repair":
            traceback = params.get("traceback")
            exception = params.get("exception", "Unknown")
            # Trigger the repair protocol manually
            import threading
            threading.Thread(target=self.monitor._initiate_repair_protocol, args=(traceback, exception), daemon=True).start()
            trace_id = TraceManager.get_current_trace_id() or TraceManager.generate_trace_id()
            return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result="Manual repair protocol initiated", trace_id=trace_id)
            
        trace_id = TraceManager.get_current_trace_id() or TraceManager.generate_trace_id()
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}", trace_id=trace_id)
