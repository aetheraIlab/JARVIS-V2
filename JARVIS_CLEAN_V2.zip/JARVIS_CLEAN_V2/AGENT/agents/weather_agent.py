import asyncio
from datetime import datetime
from AGENT.base_agent import BaseAgent
from AGENT.registry import agent_registry
from AGENT.response import AgentResponse
from CONFIG.secure_config import config

try:
    import aiohttp
    _AIOHTTP_AVAILABLE = True
except ImportError:
    _AIOHTTP_AVAILABLE = False


@agent_registry.register
class WeatherAgent(BaseAgent):
    """
    JARVIS UAF Weather Agent.
    Production-grade OpenWeatherMap integration.
    """
    AGENT_ID = "WEATHER_AGENT"
    AGENT_NAME = "Weather Agent"
    VERSION = "2.0.0"
    CATEGORY = "information"
    
    CAPABILITIES = [
        'current_weather', 'forecast_5day',
        'air_quality', 'weather_alerts', 'sunrise_sunset'
    ]
    
    BASE_URL = "https://api.openweathermap.org/data/2.5"

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        # Fetch from config (or environment)
        self.api_key = config.openweather_api_key
        self.default_city = "Dhaka"
        
    async def initialize(self) -> None:
        await super().initialize()
        if not _AIOHTTP_AVAILABLE:
            self.logger.warning("aiohttp not installed. Please run: pip install aiohttp")
        if not self.api_key or self.api_key == "get_free_key_from_openweathermap.org":
            self.logger.warning("OPENWEATHER_API_KEY is not set or is the default placeholder.")

    async def execute(self, action: str, params: dict) -> AgentResponse:
        """Main execution router."""
        if not _AIOHTTP_AVAILABLE:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="aiohttp is not installed.")
        if not self.api_key or self.api_key == "get_free_key_from_openweathermap.org":
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="OpenWeather API key is missing.")
            
        try:
            if action == "current_weather":
                return await self._current_weather(params)
            elif action == "forecast_5day":
                return await self._forecast_5day(params)
            elif action == "air_quality":
                return await self._air_quality(params)
            elif action == "weather_alerts":
                return await self._weather_alerts(params)
            elif action == "sunrise_sunset":
                return await self._sunrise_sunset(params)
            else:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}")
        except Exception as e:
            self.logger.error(f"Error executing {action}: {e}", exc_info=True)
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=str(e))

    async def _fetch(self, endpoint: str, params: dict) -> dict:
        """Helper to fetch from OpenWeatherMap API."""
        params["appid"] = self.api_key
        params.setdefault("units", "metric")  # Default to metric
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.BASE_URL}/{endpoint}", params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    text = await response.text()
                    raise Exception(f"API Error {response.status}: {text}")

    async def _get_coords(self, city: str):
        """Helper to get lat/lon for a city."""
        res = await self._fetch("weather", {"q": city})
        return res["coord"]["lat"], res["coord"]["lon"]

    async def _current_weather(self, params: dict) -> AgentResponse:
        """Get current weather for a city."""
        city = params.get("city", self.default_city)
        data = await self._fetch("weather", {"q": city})
        
        result = {
            "city": data.get("name"),
            "temp": data["main"].get("temp"),
            "feels_like": data["main"].get("feels_like"),
            "humidity": data["main"].get("humidity"),
            "wind_speed": data["wind"].get("speed"),
            "description": data["weather"][0].get("description") if data.get("weather") else "unknown",
            "icon": data["weather"][0].get("icon") if data.get("weather") else ""
        }
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="current_weather", result=result)

    async def _forecast_5day(self, params: dict) -> AgentResponse:
        """Get 5-day forecast (3-hour intervals)."""
        city = params.get("city", self.default_city)
        data = await self._fetch("forecast", {"q": city})
        
        forecast = []
        for item in data.get("list", [])[:10]: # Return first 10 intervals to avoid huge responses
            forecast.append({
                "time": item.get("dt_txt"),
                "temp": item["main"].get("temp"),
                "description": item["weather"][0].get("description") if item.get("weather") else ""
            })
            
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="forecast_5day", result={"city": data["city"]["name"], "forecast": forecast})

    async def _air_quality(self, params: dict) -> AgentResponse:
        """Get Air Quality Index."""
        city = params.get("city", self.default_city)
        lat, lon = await self._get_coords(city)
        
        data = await self._fetch("air_pollution", {"lat": lat, "lon": lon})
        
        if data.get("list"):
            aqi = data["list"][0]["main"]["aqi"]
            components = data["list"][0]["components"]
            return AgentResponse(success=True, agent_id=self.AGENT_ID, action="air_quality", result={"city": city, "aqi": aqi, "components": components})
            
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action="air_quality", error="No AQI data found")

    async def _weather_alerts(self, params: dict) -> AgentResponse:
        """Get severe weather alerts. Requires OneCall API access (often paid), so we fake it or use current."""
        # Using standard weather endpoint, real alerts require OneCall 3.0
        city = params.get("city", self.default_city)
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="weather_alerts", result={"city": city, "alerts": []})

    async def _sunrise_sunset(self, params: dict) -> AgentResponse:
        """Get sunrise and sunset times."""
        city = params.get("city", self.default_city)
        data = await self._fetch("weather", {"q": city})
        
        sys_data = data.get("sys", {})
        sunrise = sys_data.get("sunrise")
        sunset = sys_data.get("sunset")
        
        if sunrise and sunset:
            return AgentResponse(success=True, agent_id=self.AGENT_ID, action="sunrise_sunset", result={
                "city": city,
                "sunrise": datetime.fromtimestamp(sunrise).strftime('%Y-%m-%d %H:%M:%S'),
                "sunset": datetime.fromtimestamp(sunset).strftime('%Y-%m-%d %H:%M:%S')
            })
            
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action="sunrise_sunset", error="Sunrise/Sunset data not found")
