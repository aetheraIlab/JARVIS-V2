import sys
import os
import asyncio

# Ensure project root is in path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from EXECUTOR.terminal_agent import TerminalAgent as BaseTerminalAgent
from MONITOR.tracer import TraceManager

class TerminalAgent(BaseAgent):
    """
    JARVIS UAF Terminal Agent.
    Wrapper for EXECUTOR/terminal_agent.py.
    """
    AGENT_ID = "TERMINAL_AGENT"
    AGENT_NAME = "Terminal Execution Agent"
    VERSION = "2.0.0"
    CATEGORY = "execution"
    CAPABILITIES = [
        {"name": "shell_exec", "description": "Execute whitelisted shell commands securely"}
    ]

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.executor = BaseTerminalAgent()

    async def execute(self, action: str, params: dict) -> AgentResponse:
        self.logger.info(f"Executing action: {action}")
        source_id = params.get("source_id", "UNKNOWN")
        
        if action == "run_command":
            command = params.get("command")
            if not command:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="No command provided")
            
            
            result = self.executor.execute(command, source_id)
            trace_id = TraceManager.get_current_trace_id() or TraceManager.generate_trace_id()
            return AgentResponse(success="Error" not in result, agent_id=self.AGENT_ID, action=action, result=result, trace_id=trace_id)
            
        trace_id = TraceManager.get_current_trace_id() or TraceManager.generate_trace_id()
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}", trace_id=trace_id)
