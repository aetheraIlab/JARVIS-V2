# ================================================================
# JARVIS AETHER-CORE V2.0 — PLANNER AGENT (DAG Task Orchestrator)
# ================================================================
# Role     : LLM-driven task decomposition, DAG planning, and
#            multi-agent execution orchestration
# Layer    : AGENT (Universal Agent Framework)
# Design   : Uses INFERENCE/pipeline.py for real LLM-driven planning
#            — NO hardcoded templates
# ================================================================

import os
import sys
import json
import asyncio
import uuid
import logging
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.registry import agent_registry
from AGENT.response import AgentResponse
from MONITOR.tracer import Tracer

logger = logging.getLogger("PLANNER_AGENT")


# ── DAG Data Structures ──────────────────────────────────────

@dataclass
class TaskNode:
    """
    A single node in the execution DAG.

    Each node represents one atomic action to be dispatched to
    a specific agent. Nodes can declare dependencies on other
    nodes, forming a directed acyclic graph.
    """
    id: str
    action: str
    agent: str
    params: dict
    depends_on: List[str] = field(default_factory=list)
    status: str = "pending"       # pending | running | done | failed | skipped
    result: Any = None
    error: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "action": self.action,
            "agent": self.agent,
            "params": self.params,
            "depends_on": self.depends_on,
            "status": self.status,
            "result": self.result,
            "error": self.error,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }


@dataclass
class ExecutionPlan:
    """
    A full execution plan consisting of a DAG of TaskNodes.
    """
    plan_id: str
    goal: str
    nodes: Dict[str, TaskNode] = field(default_factory=dict)
    status: str = "created"      # created | running | completed | failed | adapted
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    completed_at: Optional[str] = None

    def add_node(self, node: TaskNode):
        self.nodes[node.id] = node

    def get_ready_nodes(self) -> List[TaskNode]:
        """Return nodes whose dependencies are all 'done'."""
        ready = []
        for node in self.nodes.values():
            if node.status != "pending":
                continue
            deps_met = all(
                self.nodes[dep].status == "done"
                for dep in node.depends_on
                if dep in self.nodes
            )
            if deps_met:
                ready.append(node)
        return ready

    def is_complete(self) -> bool:
        return all(n.status in ("done", "skipped") for n in self.nodes.values())

    def is_failed(self) -> bool:
        return any(n.status == "failed" for n in self.nodes.values())

    def progress(self) -> dict:
        total = len(self.nodes)
        done = sum(1 for n in self.nodes.values() if n.status == "done")
        failed = sum(1 for n in self.nodes.values() if n.status == "failed")
        running = sum(1 for n in self.nodes.values() if n.status == "running")
        pending = sum(1 for n in self.nodes.values() if n.status == "pending")
        return {
            "total": total, "done": done, "failed": failed,
            "running": running, "pending": pending,
            "percent": round(done / total * 100, 1) if total else 0,
        }

    def to_dict(self) -> dict:
        return {
            "plan_id": self.plan_id,
            "goal": self.goal,
            "status": self.status,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "progress": self.progress(),
            "nodes": {k: v.to_dict() for k, v in self.nodes.items()},
        }


# ── LLM Prompt Templates ─────────────────────────────────────

DECOMPOSE_SYSTEM_PROMPT = """You are JARVIS, an advanced AI task planner.
Your job is to decompose a user's complex request into a list of concrete, 
executable sub-tasks. Each sub-task must be assigned to one of the available 
JARVIS agents.

Available agents and their capabilities:
{capabilities}

RULES:
1. Each task must have a unique ID (task_1, task_2, etc.).
2. Each task must specify which agent handles it and which action to call.
3. Tasks may depend on other tasks (list dependency IDs).
4. Tasks with no dependencies can run in parallel.
5. Keep the plan minimal — avoid redundant steps.
6. Respond ONLY with valid JSON. No markdown, no explanation.

Respond with this exact JSON structure:
{{
  "tasks": [
    {{
      "id": "task_1",
      "action": "<action_name>",
      "agent": "<AGENT_ID>",
      "params": {{}},
      "depends_on": []
    }}
  ]
}}"""


ADAPT_SYSTEM_PROMPT = """You are JARVIS, an advanced AI task planner.
A step in the current execution plan has FAILED. You need to adapt the plan.

Current plan state:
{plan_state}

Failed task:
{failed_task}

Error message:
{error}

Available agents and their capabilities:
{capabilities}

RULES:
1. Suggest replacement tasks or skip the failed step.
2. Preserve existing task IDs for completed tasks.
3. New task IDs should continue the sequence.
4. Respond ONLY with valid JSON.

Respond with this exact JSON structure:
{{
  "replacement_tasks": [
    {{
      "id": "task_N",
      "action": "<action_name>",
      "agent": "<AGENT_ID>",
      "params": {{}},
      "depends_on": []
    }}
  ],
  "skip_failed": true
}}"""


# ── Planner Agent ─────────────────────────────────────────────

@agent_registry.register
class PlannerAgent(BaseAgent):
    """
    JARVIS UAF Planner Agent — LLM-driven DAG Task Orchestrator.

    Uses the inference pipeline to dynamically decompose complex
    user requests into directed acyclic graphs of sub-tasks,
    then orchestrates their execution across the registered
    agent fleet.

    This is NOT template-based. Every plan is generated by the LLM
    in real-time based on the actual user request and the currently
    available agent capabilities.
    """

    AGENT_ID = "PLANNER_AGENT"
    AGENT_NAME = "Dynamic Planner Agent"
    VERSION = "2.0.0"
    CATEGORY = "orchestration"

    CAPABILITIES = [
        {"name": "create_plan", "description": "Generate an execution plan (DAG) from a goal"},
        {"name": "execute_plan", "description": "Execute a previously created plan"},
        {"name": "decompose_task", "description": "Decompose a complex task into sub-tasks via LLM"},
        {"name": "schedule_tasks", "description": "Schedule tasks onto the SignalBus"},
        {"name": "monitor_plan", "description": "Get the current status of a plan"},
        {"name": "adapt_plan", "description": "Adapt a plan when a step fails"},
    ]

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)

        # Lazy-load the inference engine to avoid circular imports
        self._arbiter = None

        # Active plans keyed by plan_id
        self._plans: Dict[str, ExecutionPlan] = {}

    def _get_arbiter(self):
        """Lazy-load the Arbiter inference engine."""
        if self._arbiter is None:
            from INFERENCE.pipeline import Arbiter
            self._arbiter = Arbiter()
        return self._arbiter

    def _get_capabilities_text(self) -> str:
        """Build a human-readable capability list for the LLM prompt."""
        caps = agent_registry.get_capabilities()
        lines = []
        for agent_id, cap_list in sorted(caps.items()):
            if cap_list:
                lines.append(f"  {agent_id}: {', '.join(cap_list)}")
        return "\n".join(lines) if lines else "  (no agents registered)"

    # ── Execution Router ──────────────────────────────────────

    async def execute(self, action: str, params: dict) -> AgentResponse:
        dispatch = {
            "create_plan": self._create_plan,
            "execute_plan": self._execute_plan,
            "decompose_task": self._decompose_task,
            "schedule_tasks": self._schedule_tasks,
            "monitor_plan": self._monitor_plan,
            "adapt_plan": self._adapt_plan,
        }

        handler = dispatch.get(action)
        if not handler:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action=action,
                error=f"Unknown action: {action}"
            )

        try:
            return await handler(params)
        except Exception as e:
            self.logger.error(f"PlannerAgent error on '{action}': {e}", exc_info=True)
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action=action,
                error=str(e)
            )

    # ── Core: Decompose Task ──────────────────────────────────

    async def _decompose_task(self, params: dict) -> AgentResponse:
        """
        Use the LLM to decompose a complex goal into sub-tasks.

        params:
            goal: str  — the user's high-level request
        """
        goal = params.get("goal")
        if not goal:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="decompose_task",
                error="'goal' is required."
            )

        capabilities_text = self._get_capabilities_text()
        system_prompt = DECOMPOSE_SYSTEM_PROMPT.format(capabilities=capabilities_text)

        arbiter = self._get_arbiter()

        # Run the synchronous arbiter.think in a thread pool
        loop = asyncio.get_running_loop()
        response_text, provider = await loop.run_in_executor(
            None,
            arbiter.think,
            goal,
            [{"role": "system", "content": system_prompt}],
        )

        # Parse the LLM's JSON response
        tasks = self._parse_llm_json(response_text)
        if tasks is None:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="decompose_task",
                error="LLM did not return valid JSON.",
                metadata={"raw_response": response_text[:500], "provider": provider},
            )

        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action="decompose_task",
            result={"tasks": tasks, "provider": provider},
        )

    # ── Core: Create Plan ─────────────────────────────────────

    async def _create_plan(self, params: dict) -> AgentResponse:
        """
        Decompose a goal and wrap the result as an ExecutionPlan.

        params:
            goal: str
        """
        goal = params.get("goal")
        if not goal:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="create_plan",
                error="'goal' is required."
            )

        # Decompose via LLM
        decompose_result = await self._decompose_task({"goal": goal})
        if not decompose_result.success:
            return decompose_result  # Forward the error

        tasks_data = decompose_result.result.get("tasks", [])
        self.logger.info(f"Decomposed result: {decompose_result.result}")
        
        # Sometimes the LLM nests the 'tasks' array inside another 'tasks' key
        if isinstance(tasks_data, dict) and "tasks" in tasks_data:
            tasks_data = tasks_data["tasks"]


        # Build DAG
        plan_id = f"plan_{uuid.uuid4().hex[:8]}"
        plan = ExecutionPlan(plan_id=plan_id, goal=goal)

        for t in tasks_data:
            if not isinstance(t, dict):
                self.logger.warning(f"Skipping invalid task item: {t}")
                continue
                
            node = TaskNode(
                id=t.get("id", f"task_{uuid.uuid4().hex[:6]}"),
                action=t.get("action", "unknown"),
                agent=t.get("agent", "UNKNOWN"),
                params=t.get("params", {}),
                depends_on=t.get("depends_on", []),
            )
            plan.add_node(node)

        self._plans[plan_id] = plan

        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action="create_plan",
            result=plan.to_dict(),
        )

    # ── Core: Execute Plan ────────────────────────────────────

    async def _execute_plan(self, params: dict) -> AgentResponse:
        """
        Execute a plan by its ID, walking the DAG layer by layer.

        params:
            plan_id: str
            auto_adapt: bool  — if True, attempt LLM re-planning on failure
        """
        plan_id = params.get("plan_id")
        auto_adapt = params.get("auto_adapt", False)

        if not plan_id or plan_id not in self._plans:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="execute_plan",
                error=f"Plan '{plan_id}' not found."
            )

        plan = self._plans[plan_id]
        plan.status = "running"

        max_iterations = len(plan.nodes) + 5  # safety limit
        iteration = 0

        while not plan.is_complete() and iteration < max_iterations:
            iteration += 1
            ready = plan.get_ready_nodes()

            if not ready:
                # Deadlock or all remaining tasks depend on failed ones
                if plan.is_failed():
                    if auto_adapt:
                        adapted = await self._try_adapt(plan)
                        if adapted:
                            continue
                    break
                else:
                    break  # Nothing ready but not failed — should not happen

            # Execute all ready nodes
            tasks_coros = [self._execute_node(node) for node in ready]
            if params.get("sequential", False):
                for coro in tasks_coros:
                    await coro
            else:
                await asyncio.gather(*tasks_coros)

        plan.status = "completed" if plan.is_complete() else "failed"
        plan.completed_at = datetime.now(timezone.utc).isoformat()

        return AgentResponse(
            success=plan.is_complete(),
            agent_id=self.AGENT_ID,
            action="execute_plan",
            result=plan.to_dict(),
        )

    async def _execute_node(self, node: TaskNode):
        """Execute a single TaskNode by dispatching to the target agent."""
        node.status = "running"
        node.started_at = datetime.now(timezone.utc).isoformat()
        
        span = Tracer.start_span("PLANNER_EXECUTE_NODE", metadata={"node_id": node.id, "agent": node.agent, "action": node.action})

        agent_instance = agent_registry.get_instance(node.agent)
        if not agent_instance:
            # Try to instantiate it
            agent_instance = agent_registry.instantiate(node.agent)

        if not agent_instance:
            node.status = "failed"
            node.error = f"Agent '{node.agent}' not found in registry."
            node.completed_at = datetime.now(timezone.utc).isoformat()
            logger.error(f"[PLANNER] Node {node.id}: Agent '{node.agent}' not found.")
            span.end(status="failed", error=node.error)
            return

        try:
            # Use execute_with_state if available for auto state management
            if hasattr(agent_instance, "execute_with_state"):
                response = await agent_instance.execute_with_state(node.action, node.params)
            else:
                response = await agent_instance.execute(node.action, node.params)

            if response.success:
                node.status = "done"
                node.result = response.result
                span.end(status="success", result=node.result)
            else:
                node.status = "failed"
                node.error = response.error
                node.result = response.result
                span.end(status="failed", error=node.error, result=node.result)
        except Exception as e:
            node.status = "failed"
            node.error = str(e)
            logger.error(f"[PLANNER] Node {node.id} execution error: {e}")
            span.end(status="failed", error=str(e))
        finally:
            node.completed_at = datetime.now(timezone.utc).isoformat()

    async def _try_adapt(self, plan: ExecutionPlan) -> bool:
        """Attempt to adapt the plan using LLM when a node fails."""
        failed_nodes = [n for n in plan.nodes.values() if n.status == "failed"]
        if not failed_nodes:
            return False

        failed = failed_nodes[0]
        adapt_result = await self._adapt_plan({
            "plan_id": plan.plan_id,
            "failed_task_id": failed.id,
        })

        return adapt_result.success

    # ── Schedule Tasks ────────────────────────────────────────

    async def _schedule_tasks(self, params: dict) -> AgentResponse:
        """
        Emit plan tasks onto the SignalBus for decoupled execution.

        params:
            plan_id: str
        """
        plan_id = params.get("plan_id")
        if not plan_id or plan_id not in self._plans:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="schedule_tasks",
                error=f"Plan '{plan_id}' not found."
            )

        plan = self._plans[plan_id]

        if not self.bus:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="schedule_tasks",
                error="SignalBus not available."
            )

        scheduled = 0
        for node in plan.nodes.values():
            if node.status == "pending":
                await self.bus.emit(
                    sender=self.AGENT_ID,
                    signal_type="TASK_SCHEDULED",
                    data={
                        "plan_id": plan_id,
                        "task": node.to_dict(),
                    },
                )
                scheduled += 1

        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action="schedule_tasks",
            result={"scheduled": scheduled, "plan_id": plan_id},
        )

    # ── Monitor Plan ──────────────────────────────────────────

    async def _monitor_plan(self, params: dict) -> AgentResponse:
        """
        Return the current status of a plan.

        params:
            plan_id: str  — if omitted, lists all plans
        """
        plan_id = params.get("plan_id")

        if plan_id:
            plan = self._plans.get(plan_id)
            if not plan:
                return AgentResponse(
                    success=False, agent_id=self.AGENT_ID, action="monitor_plan",
                    error=f"Plan '{plan_id}' not found."
                )
            return AgentResponse(
                success=True, agent_id=self.AGENT_ID, action="monitor_plan",
                result=plan.to_dict(),
            )
        else:
            summaries = {}
            for pid, p in self._plans.items():
                summaries[pid] = {
                    "goal": p.goal,
                    "status": p.status,
                    "progress": p.progress(),
                    "created_at": p.created_at,
                }
            return AgentResponse(
                success=True, agent_id=self.AGENT_ID, action="monitor_plan",
                result={"plans": summaries, "total": len(summaries)},
            )

    # ── Adapt Plan ────────────────────────────────────────────

    async def _adapt_plan(self, params: dict) -> AgentResponse:
        """
        Adapt a plan when a task fails, using the LLM to suggest
        replacement tasks or skip the failed step.

        params:
            plan_id: str
            failed_task_id: str
        """
        plan_id = params.get("plan_id")
        failed_task_id = params.get("failed_task_id")

        plan = self._plans.get(plan_id)
        if not plan:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="adapt_plan",
                error=f"Plan '{plan_id}' not found."
            )

        failed_node = plan.nodes.get(failed_task_id)
        if not failed_node:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="adapt_plan",
                error=f"Task '{failed_task_id}' not found in plan."
            )

        capabilities_text = self._get_capabilities_text()
        prompt = ADAPT_SYSTEM_PROMPT.format(
            plan_state=json.dumps(plan.progress(), indent=2),
            failed_task=json.dumps(failed_node.to_dict(), indent=2),
            error=failed_node.error or "Unknown error",
            capabilities=capabilities_text,
        )

        arbiter = self._get_arbiter()
        loop = asyncio.get_running_loop()
        response_text, provider = await loop.run_in_executor(
            None,
            arbiter.think,
            f"Adapt this plan because task '{failed_task_id}' failed.",
            [{"role": "system", "content": prompt}],
        )

        adaptation = self._parse_llm_json(response_text)
        if adaptation is None:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="adapt_plan",
                error="LLM did not return valid adaptation JSON.",
                metadata={"raw_response": response_text[:500]},
            )

        # Apply adaptations
        skip = adaptation.get("skip_failed", False)
        if skip:
            failed_node.status = "skipped"

        replacements = adaptation.get("replacement_tasks", [])
        for t in replacements:
            new_node = TaskNode(
                id=t.get("id", f"adapted_{uuid.uuid4().hex[:6]}"),
                action=t.get("action", "unknown"),
                agent=t.get("agent", "UNKNOWN"),
                params=t.get("params", {}),
                depends_on=t.get("depends_on", []),
            )
            plan.add_node(new_node)

        plan.status = "adapted"

        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action="adapt_plan",
            result={
                "skipped": skip,
                "new_tasks": len(replacements),
                "plan": plan.to_dict(),
            },
        )

    # ── JSON Parser ───────────────────────────────────────────

    @staticmethod
    def _parse_llm_json(text: str) -> Optional[dict]:
        """
        Robustly parse JSON from LLM output.
        Handles markdown code blocks and leading/trailing garbage.
        """
        if not text:
            return None

        # Strip markdown fences
        cleaned = text.strip()
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            # Remove first line (```json) and last line (```)
            lines = [l for l in lines if not l.strip().startswith("```")]
            cleaned = "\n".join(lines)

        # Try direct parse
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            pass

        # Try to find JSON object in the text
        brace_start = cleaned.find("{")
        brace_end = cleaned.rfind("}")
        if brace_start != -1 and brace_end != -1 and brace_end > brace_start:
            try:
                return json.loads(cleaned[brace_start:brace_end + 1])
            except json.JSONDecodeError:
                pass

        return None
