import os
import datetime
import pickle
from pathlib import Path

from AGENT.base_agent import BaseAgent
from AGENT.registry import agent_registry
from AGENT.response import AgentResponse

# Google API imports
try:
    from googleapiclient.discovery import build
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    _GOOGLE_CALENDAR_AVAILABLE = True
except ImportError:
    _GOOGLE_CALENDAR_AVAILABLE = False


@agent_registry.register
class CalendarAgent(BaseAgent):
    """
    JARVIS UAF Calendar Agent.
    Production-grade Google Calendar integration.
    """
    AGENT_ID = "CALENDAR_AGENT"
    AGENT_NAME = "Calendar Agent"
    VERSION = "2.0.0"
    CATEGORY = "productivity"
    
    CAPABILITIES = [
        'create_event', 'list_events', 'update_event',
        'delete_event', 'search_events', 'get_availability',
        'set_reminder', 'get_today_schedule'
    ]

    # If modifying these scopes, delete the file token.pickle.
    SCOPES = ['https://www.googleapis.com/auth/calendar']
    
    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        
        # Paths for Google Auth
        project_root = Path(__file__).resolve().parent.parent.parent
        self.creds_dir = project_root / "INTEGRATIONS"
        self.creds_dir.mkdir(exist_ok=True)
        
        self.creds_file = self.creds_dir / "google_credentials.json"
        self.token_file = self.creds_dir / "google_calendar_token.pickle"
        
        self.creds = None
        self.service = None
        
    async def initialize(self) -> None:
        """Authenticate with Google Calendar."""
        await super().initialize()
        
        if not _GOOGLE_CALENDAR_AVAILABLE:
            self.logger.warning("Google Calendar API packages not installed. Please run: pip install google-api-python-client google-auth-oauthlib google-auth-httplib2")
            return

        try:
            self._authenticate()
        except Exception as e:
            self.logger.error(f"Failed to authenticate with Google Calendar: {e}")

    def _authenticate(self):
        """Handle Google Calendar OAuth2 authentication."""
        if self.token_file.exists():
            with open(self.token_file, 'rb') as token:
                self.creds = pickle.load(token)
                
        # If there are no (valid) credentials available, let the user log in.
        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                self.creds.refresh(Request())
            else:
                if not self.creds_file.exists():
                    self.logger.warning(f"Credentials file missing: {self.creds_file}")
                    return
                flow = InstalledAppFlow.from_client_secrets_file(
                    str(self.creds_file), self.SCOPES)
                self.creds = flow.run_local_server(port=0)
                
            # Save the credentials for the next run
            with open(self.token_file, 'wb') as token:
                pickle.dump(self.creds, token)
                
        if self.creds:
            self.service = build('calendar', 'v3', credentials=self.creds)
            self.logger.info("Google Calendar authentication successful.")

    async def execute(self, action: str, params: dict) -> AgentResponse:
        """Main execution router."""
        if not self.service:
            return AgentResponse(
                success=False,
                agent_id=self.AGENT_ID,
                action=action,
                error="Google Calendar is not authenticated or unavailable."
            )
            
        try:
            if action == "create_event":
                return await self._create_event(params)
            elif action == "list_events":
                return await self._list_events(params)
            elif action == "update_event":
                return await self._update_event(params)
            elif action == "delete_event":
                return await self._delete_event(params)
            elif action == "search_events":
                return await self._search_events(params)
            elif action == "get_availability":
                return await self._get_availability(params)
            elif action == "set_reminder":
                return await self._set_reminder(params)
            elif action == "get_today_schedule":
                return await self._get_today_schedule(params)
            else:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}")
        except Exception as e:
            self.logger.error(f"Error executing {action}: {e}", exc_info=True)
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=str(e))

    async def _create_event(self, params: dict) -> AgentResponse:
        """Create a new calendar event."""
        summary = params.get("title", "New Event")
        description = params.get("description", "")
        start_time_str = params.get("start_time")  # ISO format string expected
        end_time_str = params.get("end_time")      # ISO format string expected
        timezone = params.get("timezone", "Asia/Dhaka")

        if not start_time_str or not end_time_str:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="create_event", error="start_time and end_time are required")

        event = {
            'summary': summary,
            'description': description,
            'start': {
                'dateTime': start_time_str,
                'timeZone': timezone,
            },
            'end': {
                'dateTime': end_time_str,
                'timeZone': timezone,
            },
        }

        created_event = self.service.events().insert(calendarId='primary', body=event).execute()
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="create_event", result=created_event)

    async def _list_events(self, params: dict) -> AgentResponse:
        """List upcoming events."""
        days = params.get("days", 7)
        max_results = params.get("max_results", 10)
        
        now = datetime.datetime.utcnow().isoformat() + 'Z'  # 'Z' indicates UTC time
        time_max = (datetime.datetime.utcnow() + datetime.timedelta(days=days)).isoformat() + 'Z'
        
        events_result = self.service.events().list(
            calendarId='primary', 
            timeMin=now,
            timeMax=time_max,
            maxResults=max_results, 
            singleEvents=True,
            orderBy='startTime'
        ).execute()
        
        events = events_result.get('items', [])
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="list_events", result=events)

    async def _update_event(self, params: dict) -> AgentResponse:
        """Update an existing event."""
        event_id = params.get("event_id")
        if not event_id:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="update_event", error="event_id is required")

        # Get existing event
        event = self.service.events().get(calendarId='primary', eventId=event_id).execute()
        
        # Update fields
        if "title" in params:
            event['summary'] = params["title"]
        if "description" in params:
            event['description'] = params["description"]
            
        updated_event = self.service.events().update(calendarId='primary', eventId=event_id, body=event).execute()
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="update_event", result=updated_event)

    async def _delete_event(self, params: dict) -> AgentResponse:
        """Delete an event."""
        event_id = params.get("event_id")
        if not event_id:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="delete_event", error="event_id is required")

        self.service.events().delete(calendarId='primary', eventId=event_id).execute()
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="delete_event", result={"deleted_id": event_id})

    async def _search_events(self, params: dict) -> AgentResponse:
        """Search events by keyword."""
        keyword = params.get("keyword")
        if not keyword:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="search_events", error="keyword is required")

        events_result = self.service.events().list(
            calendarId='primary',
            q=keyword,
            maxResults=10,
            singleEvents=True,
            orderBy='startTime'
        ).execute()
        
        events = events_result.get('items', [])
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="search_events", result=events)

    async def _get_availability(self, params: dict) -> AgentResponse:
        """Check availability (free/busy)."""
        start_time_str = params.get("start_time")
        end_time_str = params.get("end_time")
        
        if not start_time_str or not end_time_str:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="get_availability", error="start_time and end_time are required")

        body = {
            "timeMin": start_time_str,
            "timeMax": end_time_str,
            "items": [{"id": 'primary'}]
        }
        
        eventsResult = self.service.freebusy().query(body=body).execute()
        calendars = eventsResult.get('calendars', {})
        primary = calendars.get('primary', {})
        busy = primary.get('busy', [])
        
        is_free = len(busy) == 0
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="get_availability", result={"is_free": is_free, "busy_slots": busy})

    async def _set_reminder(self, params: dict) -> AgentResponse:
        """Add a reminder to an existing event."""
        event_id = params.get("event_id")
        minutes = params.get("minutes", 10)
        
        if not event_id:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="set_reminder", error="event_id is required")

        event = self.service.events().get(calendarId='primary', eventId=event_id).execute()
        
        reminders = event.get('reminders', {})
        reminders['useDefault'] = False
        overrides = reminders.get('overrides', [])
        overrides.append({'method': 'popup', 'minutes': minutes})
        reminders['overrides'] = overrides
        event['reminders'] = reminders
        
        updated_event = self.service.events().update(calendarId='primary', eventId=event_id, body=event).execute()
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="set_reminder", result=updated_event)

    async def _get_today_schedule(self, params: dict) -> AgentResponse:
        """Get today's agenda."""
        now = datetime.datetime.utcnow()
        start_of_day = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat() + 'Z'
        end_of_day = now.replace(hour=23, minute=59, second=59, microsecond=999999).isoformat() + 'Z'
        
        events_result = self.service.events().list(
            calendarId='primary', 
            timeMin=start_of_day,
            timeMax=end_of_day,
            singleEvents=True,
            orderBy='startTime'
        ).execute()
        
        events = events_result.get('items', [])
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="get_today_schedule", result=events)
