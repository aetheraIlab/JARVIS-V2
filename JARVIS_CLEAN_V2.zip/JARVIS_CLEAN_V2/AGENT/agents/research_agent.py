import sys
import os
import asyncio
import json

# Ensure parent directory is in path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from INFERENCE.pipeline import Arbiter
from AGENT.agents.browser_agent import BrowserAgent

class ResearchAgent(BaseAgent):
    """
    JARVIS UAF Research Agent.
    Capable of autonomous multi-step web research, fact comparison, and report generation.
    """
    AGENT_ID = "RESEARCH_AGENT"
    AGENT_NAME = "Research Agent"
    VERSION = "1.0.0"
    CATEGORY = "intelligence"

    CAPABILITIES = [
        {"name": "deep_research", "description": "Conduct deep internet research on a topic"},
        {"name": "fact_checking", "description": "Verify facts across multiple sources"}
    ]

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.arbiter = Arbiter()
        # Initialize internal Browser Agent in headless mode for scraping
        self.browser = BrowserAgent(bus=bus, atlas=atlas, cache=cache, headless=True)
        self.memory = None

    async def initialize(self) -> None:
        """Initialize the Research Agent and its dependencies."""
        await super().initialize()
        await self.browser.initialize()
        
        # PHASE 1 FIX: Use modular memory system directly
        try:
            from MANAGER.memory import MemoryManager
            self.memory = MemoryManager(atlas=self.atlas)
        except Exception as e:
            self.logger.warning(f"Could not load MemoryManager: {e}")
            
        self.logger.info("Research Agent initialized.")

    async def shutdown(self) -> None:
        """Shutdown the Research Agent and clean up."""
        await self.browser.shutdown()
        await super().shutdown()
        self.logger.info("Research Agent shut down.")

    async def execute(self, action: str, params: dict) -> AgentResponse:
        """Execute action for Research Agent."""
        self.logger.info(f"Executing action: {action}")
        if action in ("start_research", "deep_research"):
            return await self._action_start_research(params)
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}")

    async def _action_start_research(self, params: dict) -> AgentResponse:
        """Main entry point for starting a research task."""
        query = params.get("query", "")
        max_depth = params.get("max_depth", 3)
        
        # If the input was raw text (e.g. from KERNEL dispatch)
        if not query and "text" in params:
            query = params["text"]
            
        if not query:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="start_research", error="Empty query")

        try:
            report = await self._run_research_workflow(query, max_depth)
            return AgentResponse(
                success=True, 
                agent_id=self.AGENT_ID, 
                action="start_research", 
                result={"report": report}
            )
        except Exception as e:
            self.logger.error(f"Research failed: {e}", exc_info=True)
            return AgentResponse(
                success=False, 
                agent_id=self.AGENT_ID, 
                action="start_research", 
                error=str(e)
            )

    async def _run_research_workflow(self, query: str, max_depth: int) -> str:
        """Orchestrates the research process: plan -> search -> extract -> summarize -> save."""
        self.logger.info(f"Starting research workflow for: {query}")

        # Step 1: Decompose Query (Search Plan)
        self.logger.info("Decomposing query...")
        plan_prompt = (
            f"I need to research the following topic: '{query}'.\n"
            f"Break this down into up to {max_depth} highly specific Google search terms.\n"
            "Return ONLY a JSON array of strings. Do not include markdown formatting or extra text.\n"
            "Example: [\"search term 1\", \"search term 2\"]"
        )
        plan_json, _ = self.arbiter.think(plan_prompt)
        
        try:
            # Clean response to parse JSON safely
            start_idx = plan_json.find('[')
            end_idx = plan_json.rfind(']') + 1
            if start_idx != -1 and end_idx != -1:
                search_terms = json.loads(plan_json[start_idx:end_idx])
            else:
                search_terms = [query]
        except Exception as e:
            self.logger.warning(f"Failed to parse search plan, defaulting to main query. Error: {e}")
            search_terms = [query]
            
        self.logger.info(f"Generated Search Plan: {search_terms}")
        
        all_extracted_facts = []
        visited_urls = []

        # Step 2: Execute Searches & Extract Facts
        for term in search_terms[:max_depth]:
            self.logger.info(f"Executing search for: {term}")
            
            # Use BrowserAgent to search Google
            search_res = await self.browser.execute("search_google", {"query": term})
            if not search_res.success:
                self.logger.warning(f"Search failed for '{term}': {search_res.error}")
                continue
                
            tab_id = search_res.result.get("tab_id")
            url = search_res.result.get("url")
            visited_urls.append(url)
            
            # Give the page a moment to load
            await asyncio.sleep(2)
            
            # Extract readable content
            read_res = await self.browser.execute("read_page", {"tab_id": tab_id})
            
            if read_res.success:
                # Limit tokens to prevent overwhelming the LLM
                page_text = read_res.result.get("text", "")[:6000] 
                
                # Use Arbiter to extract facts
                fact_prompt = (
                    f"Extract the most important, verifiable facts from the following text "
                    f"related to the research topic: '{query}'.\n\n"
                    f"Source Text:\n{page_text}\n\n"
                    f"If there is no relevant information, state 'No relevant facts found.'"
                )
                facts, _ = self.arbiter.think(fact_prompt)
                all_extracted_facts.append({
                    "term": term, 
                    "url": url, 
                    "facts": facts
                })
            else:
                self.logger.warning(f"Failed to read page for '{term}'")
            
            # Close the tab to save memory
            await self.browser.execute("close_tab", {"tab_id": tab_id})

        # Step 3: Fact Comparison & Report Generation
        self.logger.info("Generating comprehensive report...")
        report_prompt = (
            f"Write a comprehensive, professional markdown report for the query: '{query}'.\n"
            "Use ONLY the following gathered facts. Ensure you cite the URLs provided using markdown links.\n"
            "If sources conflict, compare the facts and highlight the discrepancies.\n"
            "If you do not have enough information based on the facts below, state exactly what is missing.\n\n"
            f"Gathered Facts Data:\n{json.dumps(all_extracted_facts, indent=2)}"
        )
        report, _ = self.arbiter.think(report_prompt)

        # Step 4: Persistent Memory Consolidation (PHASE 1 FIX: modular memory API)
        if self.memory:
            self.logger.info("Consolidating key facts into long-term memory...")
            memory_prompt = (
                f"Extract a 1-2 sentence core takeaway or summary from the following research report "
                f"that should be remembered permanently. Report:\n{report[:2000]}"
            )
            takeaway, _ = self.arbiter.think(memory_prompt)
            
            try:
                # Store as episodic memory with high importance
                await self.memory.episodic.add_episode(
                    content=f"Research Summary for '{query}': {takeaway}",
                    importance=0.9,
                    metadata={"category": "research", "source": "RESEARCH_AGENT", "tags": "research,autonomous_study"}
                )
                self.logger.info("Memory consolidation successful.")
            except Exception as mem_err:
                self.logger.error(f"Failed to save to memory: {mem_err}")

        return report

# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    async def run_test():
        print("=" * 60)
        print("  UAF RESEARCH AGENT — Unit Test")
        print("=" * 60)
        
        agent = ResearchAgent()
        await agent.initialize()
        
        query = "What is the primary difference between Playwright and Selenium?"
        print(f"\n[Test] Starting research on: '{query}'")
        
        res = await agent.execute("start_research", {"query": query, "max_depth": 2})
        
        if res.success:
            print("\n" + "=" * 60)
            print("  RESEARCH REPORT")
            print("=" * 60)
            print(res.result["report"])
        else:
            print(f"\n[ERROR] Research failed: {res.error}")
            
        await agent.shutdown()
        print("\n[RESEARCH AGENT] Test Complete.")

    asyncio.run(run_test())
