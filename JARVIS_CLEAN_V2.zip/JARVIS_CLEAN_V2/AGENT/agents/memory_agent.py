import sys
import os
import asyncio

# Ensure project root is in path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from MANAGER.memory import MemoryManager


class MemoryAgent(BaseAgent):
    """
    JARVIS UAF Memory Agent.
    Direct integration with MANAGER/memory/ (Modular Cognitive System).
    
    PHASE 1 FIX: Replaced legacy MemoryManager import with modular system.
    """
    AGENT_ID = "MEMORY_AGENT"
    AGENT_NAME = "Cognitive Memory Agent"
    VERSION = "4.0.0"
    CATEGORY = "intelligence"
    CAPABILITIES = [
        {"name": "semantic_recall", "description": "Retrieve relevant memories based on query"},
        {"name": "memory_ingestion", "description": "Store new interactions in long-term memory"},
        {"name": "learn_fact", "description": "Learn a structural fact about the user"},
        {"name": "end_session", "description": "End and consolidate the current session"}
    ]

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.memory = MemoryManager(atlas=atlas)

    async def execute(self, action: str, params: dict) -> AgentResponse:
        self.logger.info(f"Executing action: {action}")
        
        if action == "semantic_recall":
            query = params.get("query", params.get("text", ""))
            top_k = params.get("top_k", 5)
            try:
                results = await self.memory.retrieval.search_all(query, top_k=top_k)
                formatted = [
                    {"content": r.record.content, "score": round(r.score, 3), "type": r.record.type}
                    for r in results
                ]
                return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result=formatted)
            except Exception as e:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=str(e))
        
        elif action == "memory_ingestion":
            user_text = params.get("user", "")
            jarvis_text = params.get("jarvis", "")
            trace_id = params.get("trace_id", "")
            try:
                content = f"User: {user_text}\nJARVIS: {jarvis_text}"
                mem_id = await self.memory.episodic.add_episode(
                    content=content,
                    importance=0.5,
                    trace_id=trace_id
                )
                return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result={"memory_id": mem_id})
            except Exception as e:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=str(e))
        
        elif action == "learn_fact":
            key = params.get("key", "")
            value = params.get("value", "")
            confidence = params.get("confidence", 1.0)
            source = params.get("source", "user")
            try:
                await self.memory.learn_fact(key, value, confidence, source)
                return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result=f"Learned: {key}={value}")
            except Exception as e:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=str(e))
        
        elif action == "end_session":
            try:
                self.memory.end_session()
                return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result="Session ended and consolidated")
            except Exception as e:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=str(e))

        # Legacy compatibility aliases
        elif action == "retrieve":
            return await self.execute("semantic_recall", params)
        elif action == "store":
            return await self.execute("memory_ingestion", params)
            
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}")
