import os
import asyncio
from AGENT.base_agent import BaseAgent
from AGENT.registry import agent_registry
from AGENT.response import AgentResponse
from CONFIG.secure_config import config

try:
    import aiohttp
    _AIOHTTP_AVAILABLE = True
except ImportError:
    _AIOHTTP_AVAILABLE = False


@agent_registry.register
class NewsAgent(BaseAgent):
    """
    JARVIS UAF News Agent.
    Production-grade NewsAPI integration.
    """
    AGENT_ID = "NEWS_AGENT"
    AGENT_NAME = "News Agent"
    VERSION = "2.0.0"
    CATEGORY = "information"
    
    CAPABILITIES = [
        'top_headlines', 'search_news',
        'category_news', 'tech_news', 'trending'
    ]
    
    BASE_URL = "https://newsapi.org/v2"

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.api_key = config.news_api_key
        
    async def initialize(self) -> None:
        await super().initialize()
        if not _AIOHTTP_AVAILABLE:
            self.logger.warning("aiohttp not installed. Please run: pip install aiohttp")
        if not self.api_key or self.api_key == "get_free_key_from_newsapi.org":
            self.logger.warning("NEWS_API_KEY is not set or is the default placeholder.")

    async def execute(self, action: str, params: dict) -> AgentResponse:
        """Main execution router."""
        if not _AIOHTTP_AVAILABLE:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="aiohttp is not installed.")
        if not self.api_key or self.api_key == "get_free_key_from_newsapi.org":
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="News API key is missing.")
            
        try:
            if action == "top_headlines":
                return await self._top_headlines(params)
            elif action == "search_news":
                return await self._search_news(params)
            elif action == "category_news":
                return await self._category_news(params)
            elif action == "tech_news":
                return await self._tech_news(params)
            elif action == "trending":
                return await self._trending(params)
            else:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}")
        except Exception as e:
            self.logger.error(f"Error executing {action}: {e}", exc_info=True)
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=str(e))

    async def _fetch(self, endpoint: str, params: dict) -> dict:
        """Helper to fetch from NewsAPI."""
        params["apiKey"] = self.api_key
        params.setdefault("pageSize", 10)  # Max 10 articles as requested
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.BASE_URL}/{endpoint}", params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    text = await response.text()
                    raise Exception(f"API Error {response.status}: {text}")

    def _format_articles(self, data: dict) -> list:
        """Extract requested fields from response."""
        articles = data.get("articles", [])
        formatted = []
        for a in articles:
            formatted.append({
                "title": a.get("title"),
                "description": a.get("description"),
                "url": a.get("url"),
                "source": a.get("source", {}).get("name"),
                "published": a.get("publishedAt")
            })
        return formatted

    async def _top_headlines(self, params: dict) -> AgentResponse:
        """Get top headlines."""
        country = params.get("country", "bd")
        data = await self._fetch("top-headlines", {"country": country})
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="top_headlines", result=self._format_articles(data))

    async def _search_news(self, params: dict) -> AgentResponse:
        """Search news by keyword."""
        keyword = params.get("keyword")
        if not keyword:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="search_news", error="keyword is required")
            
        data = await self._fetch("everything", {"q": keyword, "sortBy": "publishedAt"})
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="search_news", result=self._format_articles(data))

    async def _category_news(self, params: dict) -> AgentResponse:
        """Get news by category."""
        category = params.get("category", "general")
        country = params.get("country", "bd")
        data = await self._fetch("top-headlines", {"country": country, "category": category})
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="category_news", result=self._format_articles(data))

    async def _tech_news(self, params: dict) -> AgentResponse:
        """Shortcut for tech category."""
        params["category"] = "technology"
        # We can use global for tech news to get more variety, or default to US
        params.setdefault("country", "us")
        data = await self._fetch("top-headlines", {"country": params["country"], "category": params["category"]})
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="tech_news", result=self._format_articles(data))

    async def _trending(self, params: dict) -> AgentResponse:
        """Get most popular news today."""
        # 'everything' endpoint sorted by popularity gives trending
        # Provide a broad query like 'world' or 'news' if nothing specific
        query = params.get("q", "world")
        data = await self._fetch("everything", {"q": query, "sortBy": "popularity"})
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action="trending", result=self._format_articles(data))
