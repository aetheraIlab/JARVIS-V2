import sys
import os
import asyncio

# Ensure project root is in path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from SENSOR.tts import AudioOut

class VoiceAgent(BaseAgent):
    """
    JARVIS UAF Voice Agent.
    Wrapper for SENSOR/tts.py.
    """
    AGENT_ID = "VOICE_AGENT"
    AGENT_NAME = "Voice Output Agent"
    VERSION = "2.0.0"
    CATEGORY = "sensory"
    CAPABILITIES = [
        {"name": "tts_output", "description": "Convert text to high-quality speech"}
    ]

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.tts = AudioOut()

    async def execute(self, action: str, params: dict) -> AgentResponse:
        self.logger.info(f"Executing action: {action}")
        
        if action == "speak":
            text = params.get("text")
            if not text:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="No text provided")
            
            await self.tts.speak_async(text)
            return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result="Speech completed")
            
        elif action == "interrupt":
            self.tts.interrupt()
            return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result="Speech interrupted")
            
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}")
