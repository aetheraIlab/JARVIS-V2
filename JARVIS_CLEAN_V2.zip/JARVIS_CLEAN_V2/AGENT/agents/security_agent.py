import sys
import os
import asyncio

# Ensure project root is in path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from KERNEL.defense_layer import DefenseLayer

class SecurityAgent(BaseAgent):
    """
    JARVIS UAF Security Agent.
    Wrapper for KERNEL/defense_layer.py.
    """
    AGENT_ID = "SECURITY_AGENT"
    AGENT_NAME = "System Security Agent"
    VERSION = "2.0.0"
    CATEGORY = "security"
    CAPABILITIES = [
        {"name": "threat_analysis", "description": "Detect prompt injection and malicious intent"},
        {"name": "authorization", "description": "Gatekeep sensitive system actions"}
    ]

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.defense = DefenseLayer()

    async def execute(self, action: str, params: dict) -> AgentResponse:
        self.logger.info(f"Executing action: {action}")
        
        if action == "validate_prompt":
            text = params.get("text")
            source = params.get("source", "UNKNOWN")
            result = self.defense.is_safe(text, source)
            return AgentResponse(success=result["safe"], agent_id=self.AGENT_ID, action=action, result=result)
            
        elif action == "authorize_action":
            source = params.get("source")
            action_type = params.get("action_type")
            target = params.get("target")
            allowed = self.defense.authorize(source, action_type, target)
            return AgentResponse(success=allowed, agent_id=self.AGENT_ID, action=action, result={"authorized": allowed})
            
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}")
