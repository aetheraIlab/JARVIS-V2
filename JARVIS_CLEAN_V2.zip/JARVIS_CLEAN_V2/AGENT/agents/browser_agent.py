import sys
import os
import asyncio
from urllib.parse import quote_plus

# Ensure parent directory is in path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from AGENT.safe_executor import SafeExecutor

# Import BROWSER modules
from BROWSER.session_manager import SessionManager
from BROWSER.dom_analyzer import DOMAnalyzer
from BROWSER.extraction_engine import ExtractionEngine
from BROWSER.safe_browsing import SafeBrowsing
from BROWSER.automation_engine import AutomationEngine
from BROWSER.download_manager import DownloadManager
from BROWSER.browser_memory import BrowserMemory

class BrowserAgent(BaseAgent):
    """
    JARVIS UAF Browser Agent.
    Production-grade, highly modular, fully async Playwright-based browser agent.
    """
    AGENT_ID = "BROWSER_AGENT"
    AGENT_NAME = "Browser Agent"
    VERSION = "2.0.0"
    CATEGORY = "connectivity"
    
    CAPABILITIES = [
        {"name": "web_search", "description": "Search the internet via browser"},
        {"name": "webpage_reading", "description": "Extract readable content from URLs"},
        {"name": "browser_automation", "description": "Click, fill forms, scroll"},
        {"name": "screenshot_capture", "description": "Take screenshots of webpages"}
    ]

    def __init__(self, bus=None, atlas=None, cache=None, headless=True):
        super().__init__(bus, atlas, cache)
        self.headless = headless
        
        # Initialize BROWSER micro-modules
        self.session_manager = SessionManager(headless=self.headless)
        self.dom_analyzer = DOMAnalyzer()
        self.extractor = ExtractionEngine()
        self.safe_browsing = SafeBrowsing()
        self.automation = AutomationEngine()
        self.download_manager = DownloadManager()
        self.memory = BrowserMemory()

    async def initialize(self) -> None:
        """Start the browser session."""
        await super().initialize()
        await self.session_manager.initialize()
        self.logger.info("Browser session initialized.")

    async def shutdown(self) -> None:
        """Gracefully close the browser."""
        await self.session_manager.shutdown()
        await super().shutdown()
        self.logger.info("Browser session shut down.")

    async def execute(self, action: str, params: dict) -> AgentResponse:
        """
        The Universal Execution Router.
        Uses SafeExecutor to isolate errors.
        """
        self.logger.info(f"Executing action: {action}")
        
        # Mapping actions to internal methods
        action_map = {
            "open_url": self._action_open_url,
            "search_google": self._action_search_google,
            "search_youtube": self._action_search_youtube,
            "read_page": self._action_read_page,
            "extract_text": self._action_extract_text,
            "click_element": self._action_click_element,
            "fill_form": self._action_fill_form,
            "scroll_page": self._action_scroll_page,
            "screenshot": self._action_screenshot,
            "manage_tabs": self._action_manage_tabs,
            "get_page_metadata": self._action_get_page_metadata,
            "close_tab": self._action_close_tab,
            "close_browser": self._action_close_browser,
        }

        if action not in action_map:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="Unknown action")

        # Execute securely
        handler = action_map[action]
        return await SafeExecutor.run(handler, params, agent_id=self.AGENT_ID, action=action)

    # ---------------------------------------------------------
    # ACTION HANDLERS
    # ---------------------------------------------------------

    async def _action_open_url(self, params: dict):
        url = params.get("url")
        if not url:
            raise ValueError("Missing 'url' parameter")

        # Security Check
        safety = self.safe_browsing.check_url(url)
        if not safety["safe"]:
            self.logger.warning(f"Blocked URL: {url} - {safety['reason']}")
            raise PermissionError(f"SafeBrowsing blocked URL: {safety['reason']}")

        page, tab_id = await self.session_manager.new_page()
        if not page:
            raise RuntimeError("Failed to create new page context")

        # Setup download interception
        page.on("download", lambda d: asyncio.create_task(self.download_manager.handle_download(d)))

        await page.goto(safety["url"], wait_until="domcontentloaded")
        title = await page.title()
        
        self.memory.record_visit(page.url, title)
        
        return {
            "url": page.url,
            "title": title,
            "tab_id": tab_id
        }

    async def _action_search_google(self, params: dict):
        query = params.get("query")
        if not query:
            raise ValueError("Missing 'query' parameter")

        # Sanitize prompt injection
        query = self.safe_browsing.sanitize_input(query)
        search_url = f"https://www.google.com/search?q={quote_plus(query)}"
        
        return await self._action_open_url({"url": search_url})

    async def _action_search_youtube(self, params: dict):
        query = params.get("query")
        if not query:
            raise ValueError("Missing 'query' parameter")
            
        query = self.safe_browsing.sanitize_input(query)
        search_url = f"https://www.youtube.com/results?search_query={quote_plus(query)}"
        
        return await self._action_open_url({"url": search_url})

    async def _action_read_page(self, params: dict):
        # Could read an already open tab or open a new one
        tab_id = params.get("tab_id")
        url = params.get("url")

        if url:
            res = await self._action_open_url({"url": url})
            tab_id = res["tab_id"]

        page = self.session_manager.tab_manager.get_tab(tab_id)
        if not page:
            raise ValueError("Invalid tab_id or failed to open URL")

        # Extract HTML
        html_content = await page.content()
        
        # Use ExtractionEngine to clean the text
        extracted = await self.extractor.extract_article(html_content, url=page.url)
        if not extracted["success"]:
            # Fallback to simple dom text
            text = await page.evaluate("() => document.body.innerText")
            return {"text": text, "fallback": True}
            
        return {"text": extracted["content"], "method": extracted["method"]}

    async def _action_extract_text(self, params: dict):
        # Similar to read_page but might target specific selectors
        tab_id = params.get("tab_id") or self.session_manager.tab_manager.active_tab_id
        selector = params.get("selector", "body")
        
        page = self.session_manager.tab_manager.get_tab(tab_id)
        if not page:
             raise ValueError("No active tab")
             
        elements = await page.query_selector_all(selector)
        texts = [await el.inner_text() for el in elements[:50]]
        return {"texts": texts}

    async def _action_click_element(self, params: dict):
        tab_id = params.get("tab_id") or self.session_manager.tab_manager.active_tab_id
        selector = params.get("selector")
        target_text = params.get("target_text")
        
        page = self.session_manager.tab_manager.get_tab(tab_id)
        if not page:
             raise ValueError("No active tab")

        # If selector is missing, use DOM analyzer to find it by text
        if not selector and target_text:
            res = await self.dom_analyzer.find_best_selector(page, target_text)
            if res["success"]:
                selector = res["selector"]
            else:
                raise ValueError(f"Could not find element with text: {target_text}")

        res = await self.automation.click_element(page, selector)
        if res["success"]:
            self.memory.record_action("click", {"selector": selector})
        return res

    async def _action_fill_form(self, params: dict):
        tab_id = params.get("tab_id") or self.session_manager.tab_manager.active_tab_id
        fields = params.get("fields")  # dict of selector: value
        
        page = self.session_manager.tab_manager.get_tab(tab_id)
        if not page or not fields:
             raise ValueError("No active tab or missing fields")

        res = await self.automation.fill_form(page, fields)
        if res["success"]:
            self.memory.record_action("fill_form", {"fields_count": len(fields)})
        return res

    async def _action_scroll_page(self, params: dict):
        tab_id = params.get("tab_id") or self.session_manager.tab_manager.active_tab_id
        direction = params.get("direction", "down")
        amount = params.get("amount", 800)
        
        page = self.session_manager.tab_manager.get_tab(tab_id)
        if not page:
             raise ValueError("No active tab")

        return await self.automation.scroll_page(page, direction, amount)

    async def _action_screenshot(self, params: dict):
        tab_id = params.get("tab_id") or self.session_manager.tab_manager.active_tab_id
        path = params.get("path", "logs/screenshots/browser_capture.png")
        full_page = params.get("full_page", True)
        
        page = self.session_manager.tab_manager.get_tab(tab_id)
        if not page:
             raise ValueError("No active tab")

        os.makedirs(os.path.dirname(path), exist_ok=True)
        await page.screenshot(path=path, full_page=full_page)
        return {"path": path}

    async def _action_manage_tabs(self, params: dict):
        # Switch to tab, list tabs
        sub_action = params.get("sub_action", "list")
        if sub_action == "list":
            return {"tabs": list(self.session_manager.tab_manager.tabs.keys()), "active": self.session_manager.tab_manager.active_tab_id}
        elif sub_action == "switch":
            tab_id = params.get("tab_id")
            success = self.session_manager.tab_manager.switch_tab(tab_id)
            return {"success": success}
        raise ValueError("Unknown sub_action")

    async def _action_get_page_metadata(self, params: dict):
        tab_id = params.get("tab_id") or self.session_manager.tab_manager.active_tab_id
        page = self.session_manager.tab_manager.get_tab(tab_id)
        if not page:
             raise ValueError("No active tab")
             
        html_content = await page.content()
        return self.extractor.get_metadata(html_content)

    async def _action_close_tab(self, params: dict):
        tab_id = params.get("tab_id")
        return {"success": await self.session_manager.tab_manager.close_tab(tab_id)}

    async def _action_close_browser(self, params: dict):
        await self.shutdown()
        return {"success": True}

# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    async def run_tests():
        print("=" * 60)
        print("  UAF BROWSER AGENT — Unit Test")
        print("=" * 60)
        
        agent = BrowserAgent(headless=True)
        
        # Test Initialize
        await agent.initialize()
        
        # Test Search & Open
        res = await agent.execute("search_google", {"query": "OpenAI"})
        print(f"Search Result: {res.to_dict()}")
        
        if res.success:
            tab_id = res.result["tab_id"]
            
            # Test Read Page
            read_res = await agent.execute("read_page", {"tab_id": tab_id})
            print(f"Read Success: {read_res.success}")
            if read_res.success:
                print(f"Content Length: {len(read_res.result['text'])}")
                
            # Test Extract Metadata
            meta_res = await agent.execute("get_page_metadata", {"tab_id": tab_id})
            print(f"Metadata: {meta_res.result}")
            
            # Test Screenshot
            shot_res = await agent.execute("screenshot", {"tab_id": tab_id, "path": "logs/screenshots/test.png"})
            print(f"Screenshot saved to: {shot_res.result}")
            
        # Test Shutdown
        await agent.shutdown()
        print("\n[BROWSER AGENT] Tests Complete.")

    asyncio.run(run_tests())
