import sys
import os
import json

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from INFERENCE.pipeline import Arbiter
from DRIVER.gmail import Postmaster

class EmailAgent(BaseAgent):
    """
    JARVIS UAF Secure Email Agent.
    Capable of reading, categorizing, drafting, and sending emails securely.
    """
    AGENT_ID = "EMAIL_AGENT"
    AGENT_NAME = "Email Agent"
    VERSION = "1.0.0"
    CATEGORY = "connectivity"

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.arbiter = Arbiter()
        self.postmaster = Postmaster()

    async def initialize(self) -> None:
        """Authenticate with Gmail."""
        await super().initialize()
        # Non-blocking auth attempt
        self.postmaster.authenticate()
        if self.postmaster.is_configured():
            self.logger.info("Email Agent initialized and authenticated.")
        else:
            self.logger.warning("Email Agent initialized but NOT authenticated. Missing credentials.json?")

    async def shutdown(self) -> None:
        await super().shutdown()
        self.logger.info("Email Agent shut down.")

    async def execute(self, action: str, params: dict) -> AgentResponse:
        self.logger.info(f"Executing action: {action}")
        
        if not self.postmaster.is_configured():
             if not self.postmaster.authenticate():
                 return AgentResponse(
                     success=False, 
                     agent_id=self.AGENT_ID, 
                     action=action, 
                     error="Email Agent is not authenticated. Please place credentials.json in CONFIG directory."
                 )
        
        # Generic routing from President
        if action == "EMAIL_COMMAND":
            text = params.get("text", "").lower()
            if "check" in text or "read" in text or "inbox" in text:
                return await self._action_check_emails(params)
            elif "draft" in text or "compose" in text:
                return await self._action_draft_email(params)
            else:
                return await self._action_send_email(params)

        # Direct actions
        if action == "check_emails":
            return await self._action_check_emails(params)
        elif action == "draft_email":
            return await self._action_draft_email(params)
        elif action == "send_email":
            return await self._action_send_email(params)
            
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}")

    async def _action_check_emails(self, params: dict) -> AgentResponse:
        count = params.get("count", 5)
        summarize = params.get("summarize", True)
        
        try:
            emails = self.postmaster.read_inbox(max_results=count)
            if not emails:
                return AgentResponse(success=True, agent_id=self.AGENT_ID, action="check_emails", result={"message": "Inbox is empty or no recent emails."})
                
            if "error" in emails[0]:
                 return AgentResponse(success=False, agent_id=self.AGENT_ID, action="check_emails", error=emails[0]["error"])

            if not summarize:
                return AgentResponse(success=True, agent_id=self.AGENT_ID, action="check_emails", result={"emails": emails})
                
            # Smart Summarization & Categorization
            self.logger.info("Summarizing emails...")
            email_data_str = json.dumps(emails, indent=2)
            
            prompt = (
                "You are an intelligent email assistant. Below is a JSON list of recent emails.\n"
                "For each email, provide a 1-sentence summary, categorize it (Primary, Updates, Promotions, Spam), "
                "and flag it as HIGH or NORMAL priority.\n"
                "Format as a clean markdown list.\n\n"
                f"Emails:\n{email_data_str}"
            )
            
            summary_report, _ = self.arbiter.think(prompt)
            
            return AgentResponse(success=True, agent_id=self.AGENT_ID, action="check_emails", result={"report": summary_report, "raw_emails": emails})
            
        except Exception as e:
            self.logger.error(f"Failed to check emails: {e}", exc_info=True)
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="check_emails", error=str(e))

    async def _action_draft_email(self, params: dict) -> AgentResponse:
        recipient = params.get("to")
        subject_hint = params.get("subject", "No Subject")
        context = params.get("context", "")
        
        if not recipient:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="draft_email", error="Recipient email address is required.")
            
        try:
            # Generate email body
            prompt = (
                f"Draft a professional email to '{recipient}' about '{subject_hint}'.\n"
                f"Context/Instructions: {context}\n\n"
                "Return ONLY the body of the email. Do not include the subject line or headers."
            )
            body, _ = self.arbiter.think(prompt)
            
            # Create draft via API
            res = self.postmaster.create_draft(to_email=recipient, subject=subject_hint, body=body)
            
            return AgentResponse(success=True, agent_id=self.AGENT_ID, action="draft_email", result={"message": res, "draft_body": body})
            
        except Exception as e:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="draft_email", error=str(e))

    async def _action_send_email(self, params: dict) -> AgentResponse:
        recipient = params.get("to")
        subject = params.get("subject", "No Subject")
        body = params.get("body", "")
        approved = params.get("approved", False)
        
        if not recipient or not body:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="send_email", error="Recipient and body are required.")
            
        # Security: Require explicit approval flag
        if not approved:
            return AgentResponse(
                success=False, 
                agent_id=self.AGENT_ID, 
                action="send_email", 
                error="Email dispatch blocked. Explicit user approval is required before sending."
            )
            
        try:
            res = self.postmaster.send_email(to_email=recipient, subject=subject, body=body)
            return AgentResponse(success=True, agent_id=self.AGENT_ID, action="send_email", result={"message": res})
        except Exception as e:
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action="send_email", error=str(e))
