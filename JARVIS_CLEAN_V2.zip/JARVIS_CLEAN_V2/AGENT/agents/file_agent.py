import sys
import os
import asyncio

# Ensure project root is in path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from EXECUTOR.filesystem import ForgeFile

class FileAgent(BaseAgent):
    """
    JARVIS UAF File Agent.
    Wrapper for EXECUTOR/filesystem.py.
    """
    AGENT_ID = "FILE_AGENT"
    AGENT_NAME = "Filesystem Management Agent"
    VERSION = "2.0.0"
    CATEGORY = "execution"
    CAPABILITIES = [
        {"name": "file_ops", "description": "Manage files and directories (create, delete, search)"}
    ]

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.executor = ForgeFile()

    async def execute(self, action: str, params: dict) -> AgentResponse:
        self.logger.info(f"Executing action: {action}")
        source_id = params.get("source_id", "UNKNOWN")
        
        if action == "create_file":
            path = params.get("path")
            content = params.get("content", "")
            result = self.executor.create_file(path, content, source_id)
            return AgentResponse(success="Error" not in result, agent_id=self.AGENT_ID, action=action, result=result)
            
        elif action == "delete_file":
            path = params.get("path")
            result = self.executor.delete_file(path, source_id)
            return AgentResponse(success="Error" not in result, agent_id=self.AGENT_ID, action=action, result=result)
            
        elif action == "search_files":
            pattern = params.get("pattern", "*")
            root = params.get("root", ".")
            result = self.executor.search_files(pattern, root, source_id)
            return AgentResponse(success=isinstance(result, list), agent_id=self.AGENT_ID, action=action, result=result)
            
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}")
