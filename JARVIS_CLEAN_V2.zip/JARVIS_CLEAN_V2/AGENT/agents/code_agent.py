import sys
import os
import asyncio

# Ensure project root is in path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from EXECUTOR.code_agent import ExecutorCode
from MONITOR.tracer import TraceManager

class CodeAgent(BaseAgent):
    """
    JARVIS UAF Code Agent.
    Wrapper for EXECUTOR/code_agent.py to provide UAF compliance.
    """
    AGENT_ID = "CODE_AGENT"
    AGENT_NAME = "Code Execution Agent"
    VERSION = "2.0.0"
    CATEGORY = "execution"
    CAPABILITIES = [
        {"name": "code_gen", "description": "Execute and analyze Python code in a sandbox"}
    ]

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.executor = ExecutorCode()

    async def execute(self, action: str, params: dict) -> AgentResponse:
        self.logger.info(f"Executing action: {action}")
        
        if action == "execute_python":
            code = params.get("code")
            if not code:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="No code provided")
            
            result = self.executor.execute(code)
            trace_id = TraceManager.get_current_trace_id() or TraceManager.generate_trace_id()
            if result["success"]:
                return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result=result, trace_id=trace_id)
            else:
                return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=result["error"], result=result, trace_id=trace_id)
        
        elif action == "evaluate_expression":
            expr = params.get("expression")
            result = self.executor.evaluate_expression(expr)
            trace_id = TraceManager.get_current_trace_id() or TraceManager.generate_trace_id()
            return AgentResponse(success=result["success"], agent_id=self.AGENT_ID, action=action, result=result, error=result["error"], trace_id=trace_id)
            
        trace_id = TraceManager.get_current_trace_id() or TraceManager.generate_trace_id()
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error=f"Unknown action: {action}", trace_id=trace_id)
