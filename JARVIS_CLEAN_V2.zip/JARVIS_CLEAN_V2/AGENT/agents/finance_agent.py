# ================================================================
# JARVIS AETHER-CORE V2.0 — FINANCE AGENT
# ================================================================
# Role     : Real-time financial data, crypto, stocks, FX, portfolio
# Layer    : AGENT (Universal Agent Framework)
# APIs     : CoinGecko (free), Alpha Vantage (free), ExchangeRate
# ================================================================

import os
import sys
import json
import asyncio
import sqlite3
import logging
from datetime import datetime, timezone
from pathlib import Path

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from AGENT.base_agent import BaseAgent
from AGENT.registry import agent_registry
from AGENT.response import AgentResponse
from CONFIG.secure_config import config

try:
    import aiohttp
    _AIOHTTP_AVAILABLE = True
except ImportError:
    _AIOHTTP_AVAILABLE = False

logger = logging.getLogger("FINANCE_AGENT")


@agent_registry.register
class FinanceAgent(BaseAgent):
    """
    JARVIS UAF Finance Agent.

    Provides real-time financial intelligence:
    - Cryptocurrency prices via CoinGecko (no API key required)
    - Stock prices via Alpha Vantage (free key)
    - Currency conversion with BDT focus
    - Local SQLite portfolio tracking
    - Configurable price alerts
    """

    AGENT_ID = "FINANCE_AGENT"
    AGENT_NAME = "Finance Agent"
    VERSION = "2.0.0"
    CATEGORY = "finance"

    CAPABILITIES = [
        {"name": "crypto_price", "description": "Get cryptocurrency prices (BTC, ETH, etc.)"},
        {"name": "stock_price", "description": "Get stock prices via Alpha Vantage"},
        {"name": "currency_convert", "description": "Convert between currencies (BDT focus)"},
        {"name": "bdt_rates", "description": "Get Bangladesh Taka exchange rates"},
        {"name": "portfolio_track", "description": "Track holdings in a local portfolio"},
        {"name": "price_alert", "description": "Set price threshold alerts"},
    ]

    # ── API Endpoints (all free tier) ─────────────────────────
    COINGECKO_URL = "https://api.coingecko.com/api/v3"
    ALPHA_VANTAGE_URL = "https://www.alphavantage.co/query"
    EXCHANGE_RATE_URL = "https://api.exchangerate-api.com/v4/latest"

    def __init__(self, bus=None, atlas=None, cache=None):
        super().__init__(bus, atlas, cache)
        self.alpha_vantage_key = config.alpha_vantage_api_key

        # Portfolio DB
        project_root = Path(__file__).resolve().parent.parent.parent
        self._db_path = project_root / "HEAP" / "portfolio.db"
        self._init_db()

        # In-memory price alerts
        self._alerts: list[dict] = []

    # ── Database ──────────────────────────────────────────────

    def _init_db(self):
        """Create the portfolio table if it doesn't exist."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        conn.execute("""
            CREATE TABLE IF NOT EXISTS portfolio (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_type TEXT NOT NULL,
                symbol TEXT NOT NULL,
                quantity REAL NOT NULL,
                purchase_price REAL,
                purchase_date TEXT,
                notes TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS price_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                target_price REAL NOT NULL,
                direction TEXT NOT NULL,
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        conn.close()

    # ── Execution Router ──────────────────────────────────────

    async def execute(self, action: str, params: dict) -> AgentResponse:
        if not _AIOHTTP_AVAILABLE:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action=action,
                error="aiohttp is not installed. Run: pip install aiohttp"
            )

        dispatch = {
            "crypto_price": self._crypto_price,
            "stock_price": self._stock_price,
            "currency_convert": self._currency_convert,
            "bdt_rates": self._bdt_rates,
            "portfolio_track": self._portfolio_track,
            "price_alert": self._price_alert,
        }

        handler = dispatch.get(action)
        if not handler:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action=action,
                error=f"Unknown action: {action}"
            )

        try:
            return await handler(params)
        except Exception as e:
            self.logger.error(f"Error executing {action}: {e}", exc_info=True)
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action=action,
                error=str(e)
            )

    # ── HTTP Helper ───────────────────────────────────────────

    async def _get_json(self, url: str, params: dict = None) -> dict:
        """Fetch JSON from a URL with aiohttp."""
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    raise Exception(f"HTTP {resp.status}: {text[:200]}")
                return await resp.json()

    # ── Crypto ────────────────────────────────────────────────

    async def _crypto_price(self, params: dict) -> AgentResponse:
        """
        Get crypto prices from CoinGecko (no key required).

        params:
            coins: str or list  — e.g. "bitcoin" or ["bitcoin","ethereum"]
            vs_currency: str    — default "usd"
        """
        coins_input = params.get("coins", "bitcoin")
        vs = params.get("vs_currency", "usd")

        if isinstance(coins_input, list):
            coins_str = ",".join(coins_input)
        else:
            coins_str = str(coins_input)

        data = await self._get_json(
            f"{self.COINGECKO_URL}/simple/price",
            {
                "ids": coins_str,
                "vs_currencies": vs,
                "include_24hr_change": "true",
                "include_market_cap": "true",
            },
        )

        return AgentResponse(
            success=True, agent_id=self.AGENT_ID,
            action="crypto_price", result=data
        )

    # ── Stocks ────────────────────────────────────────────────

    async def _stock_price(self, params: dict) -> AgentResponse:
        """
        Get stock quote from Alpha Vantage.

        params:
            symbol: str  — e.g. "AAPL"
        """
        symbol = params.get("symbol", "AAPL")

        if not self.alpha_vantage_key:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="stock_price",
                error="ALPHA_VANTAGE_API_KEY not set in .env"
            )

        data = await self._get_json(
            self.ALPHA_VANTAGE_URL,
            {
                "function": "GLOBAL_QUOTE",
                "symbol": symbol,
                "apikey": self.alpha_vantage_key,
            },
        )

        quote = data.get("Global Quote", {})
        if not quote:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="stock_price",
                error=f"No data returned for symbol '{symbol}'. Check if the symbol is valid."
            )

        result = {
            "symbol": quote.get("01. symbol"),
            "price": float(quote.get("05. price", 0)),
            "change": float(quote.get("09. change", 0)),
            "change_percent": quote.get("10. change percent", "0%"),
            "volume": int(quote.get("06. volume", 0)),
            "latest_trading_day": quote.get("07. latest trading day"),
        }

        return AgentResponse(
            success=True, agent_id=self.AGENT_ID,
            action="stock_price", result=result
        )

    # ── Currency ──────────────────────────────────────────────

    async def _currency_convert(self, params: dict) -> AgentResponse:
        """
        Convert between currencies.

        params:
            amount: float   — default 1.0
            from_cur: str   — default "USD"
            to_cur: str     — default "BDT"
        """
        amount = float(params.get("amount", 1.0))
        from_cur = params.get("from_cur", "USD").upper()
        to_cur = params.get("to_cur", "BDT").upper()

        data = await self._get_json(f"{self.EXCHANGE_RATE_URL}/{from_cur}")
        rates = data.get("rates", {})

        if to_cur not in rates:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action="currency_convert",
                error=f"Currency '{to_cur}' not found in exchange data."
            )

        rate = rates[to_cur]
        converted = round(amount * rate, 2)

        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action="currency_convert",
            result={
                "from": from_cur,
                "to": to_cur,
                "amount": amount,
                "rate": rate,
                "converted": converted,
            }
        )

    async def _bdt_rates(self, params: dict) -> AgentResponse:
        """
        Get key exchange rates against BDT.

        params:
            currencies: list  — default ["USD","EUR","GBP","INR","SAR"]
        """
        target_currencies = params.get("currencies", ["USD", "EUR", "GBP", "INR", "SAR"])

        data = await self._get_json(f"{self.EXCHANGE_RATE_URL}/BDT")
        all_rates = data.get("rates", {})

        # Invert: the API gives BDT→X, we want X→BDT
        bdt_rates = {}
        for cur in target_currencies:
            cur = cur.upper()
            if cur in all_rates and all_rates[cur] != 0:
                bdt_rates[cur] = round(1.0 / all_rates[cur], 2)

        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action="bdt_rates",
            result={"base": "BDT", "rates_per_unit": bdt_rates}
        )

    # ── Portfolio ─────────────────────────────────────────────

    async def _portfolio_track(self, params: dict) -> AgentResponse:
        """
        Manage the local portfolio.

        params:
            operation: str   — "add" | "remove" | "list" | "summary"
            asset_type: str  — "crypto" | "stock"
            symbol: str
            quantity: float
            purchase_price: float
            notes: str
        """
        op = params.get("operation", "list")
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row

        try:
            if op == "add":
                conn.execute(
                    "INSERT INTO portfolio (asset_type, symbol, quantity, purchase_price, purchase_date, notes) VALUES (?,?,?,?,?,?)",
                    (
                        params.get("asset_type", "crypto"),
                        params.get("symbol", "BTC").upper(),
                        float(params.get("quantity", 0)),
                        float(params.get("purchase_price", 0)),
                        datetime.now(timezone.utc).isoformat(),
                        params.get("notes", ""),
                    ),
                )
                conn.commit()
                return AgentResponse(
                    success=True, agent_id=self.AGENT_ID, action="portfolio_track",
                    result={"message": "Asset added to portfolio."}
                )

            elif op == "remove":
                asset_id = params.get("id")
                if not asset_id:
                    return AgentResponse(
                        success=False, agent_id=self.AGENT_ID, action="portfolio_track",
                        error="'id' is required for remove."
                    )
                conn.execute("DELETE FROM portfolio WHERE id = ?", (asset_id,))
                conn.commit()
                return AgentResponse(
                    success=True, agent_id=self.AGENT_ID, action="portfolio_track",
                    result={"message": f"Asset #{asset_id} removed."}
                )

            elif op == "list":
                rows = conn.execute("SELECT * FROM portfolio ORDER BY created_at DESC").fetchall()
                holdings = [dict(r) for r in rows]
                return AgentResponse(
                    success=True, agent_id=self.AGENT_ID, action="portfolio_track",
                    result={"holdings": holdings, "count": len(holdings)}
                )

            elif op == "summary":
                rows = conn.execute(
                    "SELECT asset_type, symbol, SUM(quantity) as total_qty, AVG(purchase_price) as avg_price "
                    "FROM portfolio GROUP BY asset_type, symbol"
                ).fetchall()
                summary = [dict(r) for r in rows]
                return AgentResponse(
                    success=True, agent_id=self.AGENT_ID, action="portfolio_track",
                    result={"summary": summary}
                )

            else:
                return AgentResponse(
                    success=False, agent_id=self.AGENT_ID, action="portfolio_track",
                    error=f"Unknown operation: {op}. Use add/remove/list/summary."
                )
        finally:
            conn.close()

    # ── Price Alerts ──────────────────────────────────────────

    async def _price_alert(self, params: dict) -> AgentResponse:
        """
        Manage price alerts.

        params:
            operation: str      — "set" | "list" | "clear"
            symbol: str         — e.g. "bitcoin"
            target_price: float
            direction: str      — "above" | "below"
        """
        op = params.get("operation", "list")
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row

        try:
            if op == "set":
                symbol = params.get("symbol")
                target = params.get("target_price")
                direction = params.get("direction", "above")

                if not symbol or target is None:
                    return AgentResponse(
                        success=False, agent_id=self.AGENT_ID, action="price_alert",
                        error="'symbol' and 'target_price' are required."
                    )

                conn.execute(
                    "INSERT INTO price_alerts (symbol, target_price, direction) VALUES (?,?,?)",
                    (symbol.lower(), float(target), direction),
                )
                conn.commit()
                return AgentResponse(
                    success=True, agent_id=self.AGENT_ID, action="price_alert",
                    result={"message": f"Alert set: {symbol} {direction} {target}"}
                )

            elif op == "list":
                rows = conn.execute(
                    "SELECT * FROM price_alerts WHERE active = 1 ORDER BY created_at DESC"
                ).fetchall()
                alerts = [dict(r) for r in rows]
                return AgentResponse(
                    success=True, agent_id=self.AGENT_ID, action="price_alert",
                    result={"alerts": alerts, "count": len(alerts)}
                )

            elif op == "clear":
                conn.execute("UPDATE price_alerts SET active = 0")
                conn.commit()
                return AgentResponse(
                    success=True, agent_id=self.AGENT_ID, action="price_alert",
                    result={"message": "All alerts cleared."}
                )

            else:
                return AgentResponse(
                    success=False, agent_id=self.AGENT_ID, action="price_alert",
                    error=f"Unknown operation: {op}. Use set/list/clear."
                )
        finally:
            conn.close()
