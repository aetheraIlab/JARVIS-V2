from enum import Enum
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import threading
import logging

logger = logging.getLogger("STATE_MACHINE")

class AgentState(Enum):
    CREATED = "created"
    INITIALIZING = "initializing"
    IDLE = "idle"
    BUSY = "busy"
    DEGRADED = "degraded"
    ERROR = "error"
    SHUTTING_DOWN = "shutting_down"
    OFFLINE = "offline"

# Valid state transitions map
VALID_TRANSITIONS = {
    AgentState.CREATED: [AgentState.INITIALIZING, AgentState.OFFLINE],
    AgentState.INITIALIZING: [AgentState.IDLE, AgentState.ERROR, AgentState.OFFLINE],
    AgentState.IDLE: [AgentState.BUSY, AgentState.SHUTTING_DOWN, AgentState.DEGRADED, AgentState.OFFLINE],
    AgentState.BUSY: [AgentState.IDLE, AgentState.ERROR, AgentState.DEGRADED, AgentState.OFFLINE],
    AgentState.DEGRADED: [AgentState.IDLE, AgentState.ERROR, AgentState.OFFLINE],
    AgentState.ERROR: [AgentState.INITIALIZING, AgentState.OFFLINE],
    AgentState.SHUTTING_DOWN: [AgentState.OFFLINE],
    AgentState.OFFLINE: [AgentState.INITIALIZING],
}

@dataclass
class StateTransition:
    from_state: AgentState
    to_state: AgentState
    timestamp: datetime
    reason: str
    metadata: Dict[str, Any] = field(default_factory=dict)

class AgentStateMachine:
    """
    Thread-safe State Machine for Universal Agent Framework (UAF).
    Tracks agent lifecycle, uptime, and maintains a history of transitions.
    """
    
    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        self._state = AgentState.CREATED
        self._history: List[StateTransition] = []
        self._max_history = 100
        
        # Uptime tracking
        self._creation_time = datetime.now(timezone.utc)
        self._last_active_time: Optional[datetime] = None
        self._total_active_seconds = 0.0
        
        self._lock = threading.RLock()
        
    @property
    def current_state(self) -> AgentState:
        with self._lock:
            return self._state
            
    def transition(self, new_state: AgentState, reason: str = "", metadata: dict = None) -> bool:
        """
        Transition the agent to a new state if valid.
        Records the transition in history and updates uptime metrics.
        """
        with self._lock:
            if not self.can_transition(new_state):
                logger.warning(f"[STATE] Invalid transition for {self.agent_id}: {self._state.name} -> {new_state.name}")
                return False
                
            now = datetime.now(timezone.utc)
            
            # Record transition
            transition = StateTransition(
                from_state=self._state,
                to_state=new_state,
                timestamp=now,
                reason=reason,
                metadata=metadata or {}
            )
            self._history.append(transition)
            if len(self._history) > self._max_history:
                self._history.pop(0)
                
            # Update uptime metrics
            if self._state in (AgentState.IDLE, AgentState.BUSY) and self._last_active_time:
                self._total_active_seconds += (now - self._last_active_time).total_seconds()
                
            if new_state in (AgentState.IDLE, AgentState.BUSY):
                self._last_active_time = now
            else:
                self._last_active_time = None
                
            # Perform transition
            old_state = self._state
            self._state = new_state
            
            logger.debug(f"[STATE] {self.agent_id} transitioned: {old_state.name} -> {new_state.name} ({reason})")
            return True

    def can_transition(self, new_state: AgentState) -> bool:
        """Check if a transition to new_state is allowed from the current state."""
        with self._lock:
            if self._state == new_state:
                return True # Idempotent
            allowed = VALID_TRANSITIONS.get(self._state, [])
            return new_state in allowed

    def is_healthy(self) -> bool:
        """Check if the agent is in a healthy, operational state (IDLE or BUSY)."""
        with self._lock:
            return self._state in (AgentState.IDLE, AgentState.BUSY)

    def is_operational(self) -> bool:
        """Check if the agent is theoretically capable of operating (Not ERROR or OFFLINE)."""
        with self._lock:
            return self._state not in (AgentState.ERROR, AgentState.OFFLINE)

    def get_history(self) -> List[StateTransition]:
        """Return a copy of the state transition history."""
        with self._lock:
            return list(self._history)

    def get_uptime_seconds(self) -> float:
        """Calculate total active uptime in seconds."""
        with self._lock:
            uptime = self._total_active_seconds
            if self._state in (AgentState.IDLE, AgentState.BUSY) and self._last_active_time:
                now = datetime.now(timezone.utc)
                uptime += (now - self._last_active_time).total_seconds()
            return uptime

    def get_summary(self) -> dict:
        """Return a summary dictionary of the agent's current state and health."""
        with self._lock:
            return {
                "agent_id": self.agent_id,
                "current_state": self._state.value,
                "is_healthy": self.is_healthy(),
                "is_operational": self.is_operational(),
                "uptime_seconds": round(self.get_uptime_seconds(), 2),
                "total_transitions": len(self._history),
                "created_at": self._creation_time.isoformat(),
                "last_transition": self._history[-1].timestamp.isoformat() if self._history else None
            }

    def reset(self) -> bool:
        """Reset the agent to INITIALIZING state if allowed from the current state."""
        with self._lock:
            if self.can_transition(AgentState.INITIALIZING):
                return self.transition(AgentState.INITIALIZING, reason="Manual reset triggered")
            return False

    def __repr__(self) -> str:
        with self._lock:
            return f"<AgentStateMachine id='{self.agent_id}' state={self._state.name}>"

    def __str__(self) -> str:
        with self._lock:
            health = "HEALTHY" if self.is_healthy() else "DEGRADED/ERROR"
            return f"Agent {self.agent_id} is {self._state.name} ({health}) - Uptime: {self.get_uptime_seconds():.1f}s"
