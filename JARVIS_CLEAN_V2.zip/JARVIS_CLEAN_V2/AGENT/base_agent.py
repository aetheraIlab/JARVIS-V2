# ================================================================
# JARVIS AETHER-CORE V2.0 — BASE AGENT (UAF)
# ================================================================
# Role     : Abstract base class for all Universal Agent Framework agents
# Layer    : AGENT
# Design   : All modular JARVIS agents MUST inherit from this class
# ================================================================

import asyncio
import time
import logging
from abc import ABC, abstractmethod
from typing import Any, Optional

from .response import AgentResponse
from .agent_logger import AgentLogger
from .state_machine import AgentStateMachine, AgentState
from MONITOR.tracer import Tracer
from MONITOR.metrics import metrics_manager

logger = logging.getLogger("BASE_AGENT")


class BaseAgent(ABC):
    """
    The Universal Agent Framework (UAF) base class.

    All modular JARVIS agents must inherit from this. Provides:
    - Lifecycle management (start / stop / initialize / shutdown)
    - State machine integration (CREATED → IDLE → BUSY → etc.)
    - Heartbeat loop (auto-registers with HeartbeatMonitor)
    - Capability declaration and task-type matching
    - Standardized status reporting
    """

    # ── Class-level declarations (override in subclasses) ─────
    AGENT_ID: str = "BASE_AGENT"
    AGENT_NAME: str = "Base Agent"
    VERSION: str = "1.0.0"
    CATEGORY: str = "generic"
    CAPABILITIES: list = []

    # ── Heartbeat Configuration ───────────────────────────────
    HEARTBEAT_INTERVAL_SECONDS: float = 15.0

    def __init__(self, bus=None, atlas=None, cache=None):
        self.bus = bus
        self.atlas = atlas
        self.cache = cache
        self.logger = AgentLogger(self.AGENT_ID)

        # State machine
        self.state_machine = AgentStateMachine(self.AGENT_ID)

        # Runtime state
        self._running: bool = False
        self._heartbeat_task: Optional[asyncio.Task] = None
        self.tasks_completed: int = 0
        self.current_task: Optional[str] = None
        self._start_time: Optional[float] = None

        # Register with the global HeartbeatMonitor (lazy import to
        # avoid circular imports at module load time)
        try:
            from .heartbeat import heartbeat_monitor
            heartbeat_monitor.register_agent(
                self.AGENT_ID,
                metadata={
                    "name": self.AGENT_NAME,
                    "version": self.VERSION,
                    "category": self.CATEGORY,
                    "capabilities": [
                        c["name"] if isinstance(c, dict) else str(c)
                        for c in self.CAPABILITIES
                    ],
                },
            )
        except Exception as e:
            logger.warning(f"[{self.AGENT_ID}] HeartbeatMonitor registration skipped: {e}")

    # ── Lifecycle ─────────────────────────────────────────────

    async def initialize(self) -> None:
        """Setup connections, state, and any resources the agent needs."""
        self.state_machine.transition(AgentState.INITIALIZING, reason="initialize() called")
        self.logger.info(f"{self.AGENT_NAME} initialized.")
        self.state_machine.transition(AgentState.IDLE, reason="Initialization complete")

    async def start(self) -> None:
        """
        Start the agent's runtime loop.

        Transitions the state machine to IDLE and launches the
        background heartbeat coroutine.
        """
        if self._running:
            return

        self._running = True
        self._start_time = time.monotonic()

        # Ensure we're in IDLE before accepting work
        current = self.state_machine.current_state
        if current == AgentState.CREATED:
            self.state_machine.transition(AgentState.INITIALIZING, reason="start() called")
            self.state_machine.transition(AgentState.IDLE, reason="Agent started")
        elif current in (AgentState.ERROR, AgentState.OFFLINE):
            self.state_machine.transition(AgentState.INITIALIZING, reason="Restarting from error/offline")
            self.state_machine.transition(AgentState.IDLE, reason="Agent restarted")

        # Launch heartbeat background task
        try:
            loop = asyncio.get_running_loop()
            self._heartbeat_task = loop.create_task(self._heartbeat_loop())
        except RuntimeError:
            # No running loop — heartbeat will not auto-send
            logger.warning(f"[{self.AGENT_ID}] No event loop; heartbeat loop not started.")

        self.logger.info(f"{self.AGENT_NAME} started.")

    async def stop(self) -> None:
        """
        Gracefully stop the agent.

        Cancels the heartbeat task, transitions to SHUTTING_DOWN → OFFLINE,
        and deregisters from the HeartbeatMonitor.
        """
        self._running = False

        # Cancel heartbeat
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass

        # State transition
        self.state_machine.transition(AgentState.SHUTTING_DOWN, reason="stop() called")
        self.state_machine.transition(AgentState.OFFLINE, reason="Agent stopped")

        self.logger.info(f"{self.AGENT_NAME} stopped.")

    async def shutdown(self) -> None:
        """Graceful teardown (alias for stop for backward compatibility)."""
        await self.stop()
        self.logger.info(f"{self.AGENT_NAME} shut down.")

    # ── Heartbeat ─────────────────────────────────────────────

    async def _heartbeat_loop(self) -> None:
        """
        Background coroutine that sends a heartbeat pulse to the
        global HeartbeatMonitor every ``HEARTBEAT_INTERVAL_SECONDS``.
        """
        try:
            from .heartbeat import heartbeat_monitor
        except ImportError:
            logger.warning(f"[{self.AGENT_ID}] heartbeat module unavailable.")
            return

        try:
            while self._running:
                heartbeat_monitor.heartbeat(
                    self.AGENT_ID,
                    metadata={
                        "state": self.state_machine.current_state.value,
                        "tasks_completed": self.tasks_completed,
                        "current_task": self.current_task,
                        "uptime_seconds": round(time.monotonic() - (self._start_time or time.monotonic()), 2),
                    },
                )
                await asyncio.sleep(self.HEARTBEAT_INTERVAL_SECONDS)
        except asyncio.CancelledError:
            pass  # Normal shutdown path

    async def heartbeat(self) -> dict:
        """
        Status pulse for legacy callers and the Swarm DistributedBus.

        Returns a dict with the agent's current health snapshot.
        """
        return {
            "agent_id": self.AGENT_ID,
            "status": self.state_machine.current_state.value,
            "version": self.VERSION,
            "tasks_completed": self.tasks_completed,
            "current_task": self.current_task,
        }

    # ── Execution ─────────────────────────────────────────────

    @abstractmethod
    async def execute(self, action: str, params: dict) -> AgentResponse:
        """
        Main execution entrypoint.

        Subclasses MUST implement this. The state machine is automatically
        transitioned to BUSY before execution and back to IDLE after.
        Override ``_execute_impl`` if you want auto-state management.
        """
        pass

    async def execute_with_state(self, action: str, params: dict) -> AgentResponse:
        """
        Wrapper that manages state transitions around ``execute()``.

        Transitions IDLE → BUSY before the call and BUSY → IDLE after.
        On error, transitions to ERROR.
        """
        self.state_machine.transition(AgentState.BUSY, reason=f"Executing: {action}")
        self.current_task = action
        
        span = Tracer.start_span(f"AGENT_EXECUTE_{self.AGENT_ID}", metadata={"action": action, "params": params})

        try:
            result = await self.execute(action, params)
            self.tasks_completed += 1
            self.state_machine.transition(AgentState.IDLE, reason=f"Completed: {action}")
            span.end(status="success" if result.success else "failed", error=result.error, result=result.result)
            return result
        except Exception as e:
            self.state_machine.transition(AgentState.ERROR, reason=f"Failed: {action} — {e}")
            self.logger.error(f"Execution failed: {e}", exc_info=True)
            span.end(status="failed", error=str(e))
            return AgentResponse(
                success=False,
                agent_id=self.AGENT_ID,
                action=action,
                error=str(e),
            )
        finally:
            self.current_task = None

    async def execute_with_validation(self, action: str, params: dict, max_retries: int = 2, fallback_action: str = None) -> AgentResponse:
        """
        Execution Validation Layer wrapper.
        
        Attempts `execute_with_state` with exponential backoff retries.
        If it continuously fails, it falls back to `fallback_action` if provided,
        and degrades the confidence score in the AgentResponse.
        """
        retries = 0
        base_delay = 1.0
        last_error = None
        
        span = Tracer.start_span(f"VALIDATION_{self.AGENT_ID}", metadata={"action": action, "max_retries": max_retries, "fallback": fallback_action})
        
        while retries <= max_retries:
            response = await self.execute_with_state(action, params)
            if response.success:
                response.retries = retries
                duration = (time.time() - span.start_time) * 1000
                span.end(status="success", result=response.result, metadata={"retries": retries, "used_fallback": False})
                metrics_manager.record(self.AGENT_ID, action, True, duration, retries=retries)
                return response
            
            last_error = response.error
            self.logger.warning(f"Validation failed for '{action}' (Attempt {retries+1}/{max_retries+1}): {last_error}")
            
            if retries < max_retries:
                # Exponential backoff
                await asyncio.sleep(base_delay * (2 ** retries))
            retries += 1
            
        # All retries failed
        self.logger.error(f"Execution validation completely failed for '{action}' after {max_retries+1} attempts.")
        
        # Attempt fallback
        if fallback_action:
            self.logger.warning(f"Attempting fallback action: '{fallback_action}'")
            fallback_response = await self.execute_with_state(fallback_action, params)
            
            fallback_response.retries = retries
            fallback_response.used_fallback = True
            
            if fallback_response.success:
                # Fallback succeeded, but confidence is degraded
                fallback_response.confidence = 0.5
                duration = (time.time() - span.start_time) * 1000
                span.end(status="success_fallback", result=fallback_response.result, metadata={"retries": retries, "used_fallback": True, "confidence": 0.5})
                metrics_manager.record(self.AGENT_ID, action, True, duration, retries=retries, used_fallback=True)
                return fallback_response
            else:
                # Both primary and fallback failed
                fallback_response.confidence = 0.0
                duration = (time.time() - span.start_time) * 1000
                span.end(status="failed", error="Both primary and fallback failed", metadata={"retries": retries, "used_fallback": True, "confidence": 0.0})
                metrics_manager.record(self.AGENT_ID, action, False, duration, retries=retries, used_fallback=True, error="Both primary and fallback failed")
                return fallback_response
                
        # No fallback provided
        duration = (time.time() - span.start_time) * 1000
        span.end(status="failed", error=f"Max retries exceeded: {last_error}", metadata={"retries": retries, "used_fallback": False})
        metrics_manager.record(self.AGENT_ID, action, False, duration, retries=retries, error=f"Max retries exceeded: {last_error}")
        return AgentResponse(
            success=False,
            agent_id=self.AGENT_ID,
            action=action,
            error=f"Max retries exceeded: {last_error}",
            retries=retries,
            confidence=0.0
        )

    # ── Capability Matching ───────────────────────────────────

    def can_handle(self, task_type: str) -> bool:
        """
        Check if this agent declares the given task type in its
        CAPABILITIES list.

        Supports both ``str`` entries and ``dict`` entries with a
        ``"name"`` key.
        """
        for cap in self.CAPABILITIES:
            if isinstance(cap, dict):
                if cap.get("name") == task_type:
                    return True
            elif isinstance(cap, str):
                if cap == task_type:
                    return True
        return False

    # ── Status Reporting ──────────────────────────────────────

    def get_status(self) -> dict:
        """
        Return a comprehensive status snapshot of this agent.

        Includes state machine summary, runtime metrics, and capabilities.
        """
        sm_summary = self.state_machine.get_summary()
        return {
            "agent_id": self.AGENT_ID,
            "agent_name": self.AGENT_NAME,
            "version": self.VERSION,
            "category": self.CATEGORY,
            "running": self._running,
            "current_state": sm_summary["current_state"],
            "is_healthy": sm_summary["is_healthy"],
            "is_operational": sm_summary["is_operational"],
            "uptime_seconds": sm_summary["uptime_seconds"],
            "tasks_completed": self.tasks_completed,
            "current_task": self.current_task,
            "total_transitions": sm_summary["total_transitions"],
            "capabilities": [
                c["name"] if isinstance(c, dict) else str(c)
                for c in self.CAPABILITIES
            ],
        }

    # ── Dunder Methods ────────────────────────────────────────

    def __repr__(self) -> str:
        state = self.state_machine.current_state.value
        return f"<{self.AGENT_NAME} id='{self.AGENT_ID}' state={state}>"

    def __str__(self) -> str:
        state = self.state_machine.current_state.value
        health = "HEALTHY" if self.state_machine.is_healthy() else "NOT HEALTHY"
        return f"{self.AGENT_NAME} [{self.AGENT_ID}] — {state} ({health})"
