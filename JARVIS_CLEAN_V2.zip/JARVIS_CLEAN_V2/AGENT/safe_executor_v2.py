# ================================================================
# JARVIS AETHER-CORE V2.0 — SafeExecutorV2
# ================================================================
# Role     : HARD-SAFE subprocess-isolated execution engine
# Security : Zero-trust, sandboxed, resource-limited, network-blocked
# Replaces : AGENT/safe_executor.py (in-process asyncio.wait_for)
# Usage    : from AGENT.safe_executor_v2 import SafeExecutorV2
# ================================================================

import os
import sys
import time
import json
import shutil
import logging
import tempfile
import subprocess
import platform
from pathlib import Path
from typing import Optional

from MONITOR.tracer import TraceManager

logger = logging.getLogger("SAFE-EXECUTOR-V2")


# ── Dangerous Command Blocklist ──────────────────────────────────
BLOCKED_COMMANDS = frozenset({
    # Destructive
    "rm", "rmdir", "del", "erase", "format", "mkfs",
    "shred", "wipe", "fdisk", "diskpart",
    # System control
    "shutdown", "reboot", "halt", "poweroff", "init",
    "taskkill", "kill", "pkill", "killall",
    # Fork bombs / resource abuse
    ":(){ :|:& };:", "yes", "cat /dev/urandom",
    # Privilege escalation
    "sudo", "su", "runas", "chmod", "chown", "icacls",
    "net user", "net localgroup",
    # Network exfiltration
    "curl", "wget", "nc", "ncat", "netcat", "ssh", "scp",
    "ftp", "sftp", "telnet", "nmap",
    # Registry / system modification
    "reg", "regedit", "bcdedit", "schtasks",
})

BLOCKED_PATTERNS = [
    "rm -rf", "rm -r", "del /f", "del /s",
    "format c:", "format d:",
    ":(){ :|:", "fork()", "while true",
    "> /dev/sda", "dd if=",
    "mkfs.", "shred -",
    "net user", "net localgroup",
]

BLOCKED_PYTHON_IMPORTS = frozenset({
    "os", "sys", "subprocess", "socket", "requests",
    "urllib", "http", "ftplib", "pickle", "ctypes",
    "shutil", "glob", "tempfile", "pathlib",
    "signal", "multiprocessing", "threading",
    "webbrowser", "smtplib", "imaplib",
})


class ExecutionResult:
    """Structured result from a sandboxed execution."""

    __slots__ = (
        "success", "exit_code", "stdout", "stderr",
        "duration", "timed_out", "killed", "sandbox_path",
        "error_summary", "trace_id", "risk_score"
    )

    def __init__(self, **kwargs):
        for slot in self.__slots__:
            setattr(self, slot, kwargs.get(slot, None))

    def to_dict(self) -> dict:
        return {s: getattr(self, s) for s in self.__slots__}

    def __repr__(self):
        status = "OK" if self.success else "FAIL"
        return f"<ExecutionResult {status} exit={self.exit_code} {self.duration:.2f}s>"


class SafeExecutorV2:
    """
    JARVIS HARD-SAFE Execution Engine.

    All code and commands are executed in an isolated subprocess with:
    - Hard timeout (kill after N seconds)
    - Memory limit (via Windows Job Object / ulimit)
    - CPU limit (via process priority + timeout)
    - Sandboxed working directory (temp, auto-cleaned)
    - stdout/stderr capture with truncation
    - Blocked dangerous commands and imports
    - No network access unless explicitly allowed
    """

    # ── Configuration ─────────────────────────────────────────────
    DEFAULT_TIMEOUT = 30          # seconds
    MAX_MEMORY_MB = 256           # MB per subprocess
    MAX_OUTPUT_BYTES = 50_000     # 50KB output cap
    MAX_CODE_LENGTH = 100_000     # 100KB code cap
    SANDBOX_BASE = None           # Set at init

    def __init__(self, project_root: Optional[str] = None):
        self.project_root = project_root or str(
            Path(__file__).resolve().parent.parent
        )
        # Create persistent sandbox base inside HEAP
        self.SANDBOX_BASE = os.path.join(
            self.project_root, "HEAP", "sandbox_v2"
        )
        os.makedirs(self.SANDBOX_BASE, exist_ok=True)
        logger.info(
            f"[SAFE-EXECUTOR-V2] Initialized. "
            f"Sandbox: {self.SANDBOX_BASE} | "
            f"Timeout: {self.DEFAULT_TIMEOUT}s | "
            f"Memory: {self.MAX_MEMORY_MB}MB"
        )

    # ══════════════════════════════════════════════════════════════
    # PUBLIC API
    # ══════════════════════════════════════════════════════════════

    def execute_python(
        self,
        code: str,
        timeout: int = None,
        allow_network: bool = False,
        context: dict = None,
    ) -> ExecutionResult:
        """
        Execute Python code in a fully isolated subprocess.

        Args:
            code: Python source code string
            timeout: Hard kill timeout in seconds
            allow_network: If False, blocks all network imports
            context: Dict of variables to inject (JSON-serializable only)

        Returns:
            ExecutionResult with stdout, stderr, timing, etc.
        """
        timeout = timeout or self.DEFAULT_TIMEOUT
        trace_id = TraceManager.get_current_trace_id() or TraceManager.generate_trace_id()
        risk_score = self._score_risk(code, "python")
        
        span = TraceManager.start_span(
            name="execute_python",
            metadata={"timeout": timeout, "risk_score": risk_score}
        )

        # ── Pre-flight validation ─────────────────────────────────
        if not code or not code.strip():
            res = ExecutionResult(
                success=False, exit_code=-1, stdout="", stderr="",
                duration=0.0, timed_out=False, killed=False,
                error_summary="Empty code provided.",
                trace_id=trace_id, risk_score=risk_score
            )
            span.end("FAILED", error=res.error_summary, result=res.to_dict())
            return res

        if len(code) > self.MAX_CODE_LENGTH:
            res = ExecutionResult(
                success=False, exit_code=-1, stdout="", stderr="",
                duration=0.0, timed_out=False, killed=False,
                error_summary=f"Code exceeds {self.MAX_CODE_LENGTH} char limit.",
                trace_id=trace_id, risk_score=risk_score
            )
            span.end("FAILED", error=res.error_summary, result=res.to_dict())
            return res

        # ── Static security scan ──────────────────────────────────
        violation = self._scan_python_code(code, allow_network)
        if violation:
            res = ExecutionResult(
                success=False, exit_code=-1, stdout="", stderr="",
                duration=0.0, timed_out=False, killed=False,
                error_summary=f"SECURITY BLOCKED: {violation}",
                trace_id=trace_id, risk_score=risk_score
            )
            span.end("FAILED", error=res.error_summary, result=res.to_dict())
            return res

        # ── Build sandboxed execution ─────────────────────────────
        sandbox_dir = self._create_sandbox()
        try:
            # Inject context variables
            prefix = ""
            if context:
                safe_ctx = {
                    k: v for k, v in context.items()
                    if isinstance(v, (int, float, str, bool, list, dict, type(None)))
                }
                prefix = f"import json\n_ctx = json.loads({json.dumps(json.dumps(safe_ctx))})\nlocals().update(_ctx)\n"

            full_code = prefix + code

            # Write to sandbox temp file
            script_path = os.path.join(sandbox_dir, "_exec.py")
            with open(script_path, "w", encoding="utf-8") as f:
                f.write(full_code)

            # ── Execute in isolated subprocess ────────────────────
            result = self._run_subprocess(
                cmd=[sys.executable, "-I", "-S", "-u", script_path],
                cwd=sandbox_dir,
                timeout=timeout,
                sandbox_path=sandbox_dir,
            )
            result.trace_id = trace_id
            result.risk_score = risk_score
            
            span.end(
                status="SUCCESS" if result.success else "FAILED",
                error=result.error_summary,
                result=result.to_dict()
            )
            return result
        finally:
            self._cleanup_sandbox(sandbox_dir)

    def execute_shell(
        self,
        command: str,
        timeout: int = None,
        source_id: str = "UNKNOWN",
    ) -> ExecutionResult:
        """
        Execute a shell command in a sandboxed subprocess.

        Args:
            command: Shell command string
            timeout: Hard kill timeout in seconds
            source_id: Trust level identifier

        Returns:
            ExecutionResult with stdout, stderr, timing, etc.
        """
        timeout = timeout or self.DEFAULT_TIMEOUT
        trace_id = TraceManager.get_current_trace_id() or TraceManager.generate_trace_id()
        risk_score = self._score_risk(command, "shell")
        
        span = TraceManager.start_span(
            name="execute_shell",
            metadata={"timeout": timeout, "source_id": source_id, "risk_score": risk_score}
        )

        # ── Pre-flight validation ─────────────────────────────────
        if not command or not command.strip():
            res = ExecutionResult(
                success=False, exit_code=-1, stdout="", stderr="",
                duration=0.0, timed_out=False, killed=False,
                error_summary="Empty command.",
                trace_id=trace_id, risk_score=risk_score
            )
            span.end("FAILED", error=res.error_summary, result=res.to_dict())
            return res

        if len(command) > 500:
            res = ExecutionResult(
                success=False, exit_code=-1, stdout="", stderr="",
                duration=0.0, timed_out=False, killed=False,
                error_summary="Command exceeds 500 char limit.",
                trace_id=trace_id, risk_score=risk_score
            )
            span.end("FAILED", error=res.error_summary, result=res.to_dict())
            return res

        # ── Dangerous command scan ────────────────────────────────
        violation = self._scan_shell_command(command)
        if violation:
            logger.warning(
                f"[SECURITY] Blocked command from {source_id}: "
                f"{command[:80]}... ({violation})"
            )
            res = ExecutionResult(
                success=False, exit_code=-1, stdout="", stderr="",
                duration=0.0, timed_out=False, killed=False,
                error_summary=f"SECURITY BLOCKED: {violation}",
                trace_id=trace_id, risk_score=risk_score
            )
            span.end("FAILED", error=res.error_summary, result=res.to_dict())
            return res

        # ── Execute in sandbox ────────────────────────────────────
        sandbox_dir = self._create_sandbox()
        try:
            if platform.system() == "Windows":
                cmd = ["cmd.exe", "/c", command]
            else:
                cmd = ["/bin/sh", "-c", command]

            result = self._run_subprocess(
                cmd=cmd,
                cwd=sandbox_dir,
                timeout=timeout,
                sandbox_path=sandbox_dir,
            )
            result.trace_id = trace_id
            result.risk_score = risk_score
            
            span.end(
                status="SUCCESS" if result.success else "FAILED",
                error=result.error_summary,
                result=result.to_dict()
            )
            return result
        finally:
            self._cleanup_sandbox(sandbox_dir)

    def test_patch(
        self,
        target_file: str,
        new_content: str,
        timeout: int = 15,
    ) -> ExecutionResult:
        """
        Test a self-healing patch in complete isolation.

        1. Writes new_content to a sandbox copy
        2. Runs py_compile for syntax validation
        3. Attempts to import the module in a subprocess
        4. Returns structured result

        Args:
            target_file: Original file path (for naming only)
            new_content: The patched source code
            timeout: Hard kill timeout

        Returns:
            ExecutionResult with validation details
        """
        trace_id = TraceManager.get_current_trace_id() or TraceManager.generate_trace_id()
        span = TraceManager.start_span(
            name="test_patch",
            metadata={"timeout": timeout, "target_file": target_file}
        )

        if not new_content or not new_content.strip():
            res = ExecutionResult(
                success=False, exit_code=-1, stdout="", stderr="",
                duration=0.0, timed_out=False, killed=False,
                error_summary="Empty patch content.",
                trace_id=trace_id, risk_score="LOW"
            )
            span.end("FAILED", error=res.error_summary, result=res.to_dict())
            return res

        sandbox_dir = self._create_sandbox()
        try:
            filename = os.path.basename(target_file)
            sandbox_path = os.path.join(sandbox_dir, filename)

            with open(sandbox_path, "w", encoding="utf-8") as f:
                f.write(new_content)

            # Build a test script that validates syntax + imports
            test_script = f'''
import py_compile
import sys
import os

target = {json.dumps(sandbox_path)}
filename = {json.dumps(filename)}

# Step 1: Syntax validation
try:
    py_compile.compile(target, doraise=True)
    print("[PASS] Syntax validation OK")
except py_compile.PyCompileError as e:
    print(f"[FAIL] Syntax error: {{e}}")
    sys.exit(1)

# Step 2: Import validation (isolated)
try:
    import importlib.util
    spec = importlib.util.spec_from_file_location("_patch_test", target)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    print("[PASS] Import validation OK")
except Exception as e:
    print(f"[WARN] Import error (non-fatal): {{e}}")

print("[DONE] Patch validation complete")
'''
            test_path = os.path.join(sandbox_dir, "_test_patch.py")
            with open(test_path, "w", encoding="utf-8") as f:
                f.write(test_script)

            result = self._run_subprocess(
                cmd=[sys.executable, "-I", test_path],
                cwd=sandbox_dir,
                timeout=timeout,
                sandbox_path=sandbox_dir,
            )
            result.trace_id = trace_id
            result.risk_score = "LOW"
            
            span.end(
                status="SUCCESS" if result.success else "FAILED",
                error=result.error_summary,
                result=result.to_dict()
            )
            return result
        finally:
            self._cleanup_sandbox(sandbox_dir)

    # ══════════════════════════════════════════════════════════════
    # SUBPROCESS ENGINE
    # ══════════════════════════════════════════════════════════════

    def _run_subprocess(
        self,
        cmd: list,
        cwd: str,
        timeout: int,
        sandbox_path: str,
    ) -> ExecutionResult:
        """
        Core subprocess execution with hard timeout + resource limits.
        """
        start = time.time()
        timed_out = False
        killed = False
        proc = None

        try:
            # Build environment: strip dangerous vars, block network hints
            env = self._build_safe_env()

            # Build creation flags for Windows resource limits
            creation_flags = 0
            if platform.system() == "Windows":
                # BELOW_NORMAL_PRIORITY_CLASS = 0x00004000
                # CREATE_NEW_PROCESS_GROUP to allow clean kill
                creation_flags = 0x00004000 | subprocess.CREATE_NEW_PROCESS_GROUP

            proc = subprocess.Popen(
                cmd,
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.DEVNULL,
                env=env,
                creationflags=creation_flags if platform.system() == "Windows" else 0,
                start_new_session=(platform.system() != "Windows"),
            )

            try:
                stdout_bytes, stderr_bytes = proc.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                killed = True
                self._force_kill(proc)
                stdout_bytes, stderr_bytes = proc.communicate(timeout=5)

            duration = time.time() - start

            # Decode and truncate
            stdout = self._safe_decode(stdout_bytes)
            stderr = self._safe_decode(stderr_bytes)

            if len(stdout) > self.MAX_OUTPUT_BYTES:
                stdout = stdout[:self.MAX_OUTPUT_BYTES] + \
                    f"\n...[TRUNCATED: {len(stdout) - self.MAX_OUTPUT_BYTES} bytes omitted]"
            if len(stderr) > self.MAX_OUTPUT_BYTES:
                stderr = stderr[:self.MAX_OUTPUT_BYTES] + \
                    f"\n...[TRUNCATED: {len(stderr) - self.MAX_OUTPUT_BYTES} bytes omitted]"

            error_summary = None
            if timed_out:
                error_summary = f"Process killed after {timeout}s timeout."
            elif proc.returncode != 0:
                # Extract last line of stderr as summary
                lines = stderr.strip().split("\n")
                error_summary = lines[-1] if lines else "Unknown error"

            return ExecutionResult(
                success=(proc.returncode == 0 and not timed_out),
                exit_code=proc.returncode,
                stdout=stdout.strip(),
                stderr=stderr.strip(),
                duration=round(duration, 3),
                timed_out=timed_out,
                killed=killed,
                sandbox_path=sandbox_path,
                error_summary=error_summary,
            )

        except Exception as e:
            duration = time.time() - start
            if proc and proc.poll() is None:
                self._force_kill(proc)
                killed = True
            return ExecutionResult(
                success=False,
                exit_code=-1,
                stdout="",
                stderr=str(e),
                duration=round(duration, 3),
                timed_out=timed_out,
                killed=killed,
                sandbox_path=sandbox_path,
                error_summary=f"Subprocess launch failed: {e}",
            )

    # ══════════════════════════════════════════════════════════════
    # SECURITY SCANNERS
    # ══════════════════════════════════════════════════════════════

    def _score_risk(self, content: str, mode: str) -> str:
        """Assigns a risk score to execution content."""
        content_lower = content.lower()
        if mode == "python":
            if "os." in content_lower or "subprocess." in content_lower or "eval(" in content_lower or "exec(" in content_lower:
                return "HIGH"
            if "import " in content_lower or "open(" in content_lower:
                return "MEDIUM"
            return "LOW"
        else:
            if "rm " in content_lower or "del " in content_lower or "format " in content_lower:
                return "CRITICAL"
            if "curl " in content_lower or "wget " in content_lower or ">" in content_lower or "|" in content_lower:
                return "HIGH"
            if "python " in content_lower or "pip " in content_lower:
                return "MEDIUM"
            return "LOW"

    def _scan_python_code(self, code: str, allow_network: bool = False) -> Optional[str]:
        """Static analysis of Python code for dangerous patterns."""
        import ast

        # AST parse
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return f"Syntax error: {e}"

        for node in ast.walk(tree):
            # Block dangerous imports
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                names = []
                if isinstance(node, ast.Import):
                    names = [a.name for a in node.names]
                elif isinstance(node, ast.ImportFrom) and node.module:
                    names = [node.module]

                for name in names:
                    if not name:
                        continue
                    root_mod = name.split(".")[0]
                    if root_mod in BLOCKED_PYTHON_IMPORTS:
                        if allow_network and root_mod in {"requests", "urllib", "http", "socket"}:
                            continue
                        return f"Blocked import: '{name}'"

            # Block dunder attribute access (__subclasses__, __globals__, etc.)
            if isinstance(node, ast.Attribute) and node.attr.startswith("__") and node.attr.endswith("__"):
                return f"Blocked dunder access: '{node.attr}'"

            # Block dangerous builtins
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                if node.func.id in {
                    "exec", "eval", "compile", "open", "__import__",
                    "globals", "locals", "getattr", "setattr", "delattr",
                    "breakpoint", "exit", "quit", "input",
                }:
                    return f"Blocked builtin: '{node.func.id}()'"

            # Block dangerous method calls
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                if node.func.attr in {
                    "system", "exec", "eval", "compile", "open",
                    "remove", "popen", "unlink", "rmdir", "rmtree",
                    "kill", "terminate",
                }:
                    return f"Blocked method: '.{node.func.attr}()'"

        return None  # Clean

    def _scan_shell_command(self, command: str) -> Optional[str]:
        """Static analysis of shell command for dangerous patterns."""
        cmd_lower = command.lower().strip()

        # Check blocked patterns (multi-word)
        for pattern in BLOCKED_PATTERNS:
            if pattern in cmd_lower:
                return f"Blocked pattern: '{pattern}'"

        # Check individual command words
        import shlex
        try:
            tokens = shlex.split(command)
        except ValueError:
            return "Malformed command (shlex parse failure)"

        if not tokens:
            return "Empty command"

        base_cmd = tokens[0].lower()
        # Strip path prefix (e.g., /usr/bin/rm -> rm)
        base_cmd = os.path.basename(base_cmd)

        if base_cmd in BLOCKED_COMMANDS:
            return f"Blocked command: '{base_cmd}'"

        # Check for shell injection characters
        dangerous_chars = {"&", "|", ";", ">", "<", "$", "`", "(", ")"}
        for char in dangerous_chars:
            if char in command:
                return f"Blocked shell metacharacter: '{char}'"

        # Check for path traversal
        if ".." in command:
            return "Path traversal (..) detected"

        return None  # Clean

    # ══════════════════════════════════════════════════════════════
    # SANDBOX MANAGEMENT
    # ══════════════════════════════════════════════════════════════

    def _create_sandbox(self) -> str:
        """Create an isolated temporary directory for execution."""
        sandbox = tempfile.mkdtemp(
            prefix="jarvis_sandbox_",
            dir=self.SANDBOX_BASE,
        )
        logger.debug(f"[SANDBOX] Created: {sandbox}")
        return sandbox

    def _cleanup_sandbox(self, sandbox_dir: str):
        """Remove sandbox directory and all contents."""
        try:
            if sandbox_dir and os.path.exists(sandbox_dir):
                shutil.rmtree(sandbox_dir, ignore_errors=True)
                logger.debug(f"[SANDBOX] Cleaned: {sandbox_dir}")
        except Exception as e:
            logger.warning(f"[SANDBOX] Cleanup failed: {e}")

    def _build_safe_env(self) -> dict:
        """Build a minimal, safe environment for the subprocess."""
        # Start with a minimal set of required env vars
        safe_env = {}

        # Inherit only essential system variables
        passthrough = [
            "PATH", "SYSTEMROOT", "TEMP", "TMP", "HOME", "USERPROFILE",
            "COMSPEC", "WINDIR", "PROGRAMFILES",  # Windows essentials
            "LANG", "LC_ALL", "TERM",              # Unix essentials
        ]
        for key in passthrough:
            val = os.environ.get(key)
            if val:
                safe_env[key] = val

        # Force Python to be non-interactive and safe
        safe_env["PYTHONDONTWRITEBYTECODE"] = "1"
        safe_env["PYTHONIOENCODING"] = "utf-8"
        safe_env["PYTHONNOUSERSITE"] = "1"

        # Explicitly do NOT pass API keys, tokens, secrets
        # (they are not in the passthrough list above)

        return safe_env

    # ══════════════════════════════════════════════════════════════
    # UTILITIES
    # ══════════════════════════════════════════════════════════════

    @staticmethod
    def _force_kill(proc):
        """Force-kill a subprocess and all its children."""
        try:
            if platform.system() == "Windows":
                # taskkill /T kills the entire process tree
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=5,
                )
            else:
                import signal
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    @staticmethod
    def _safe_decode(data: bytes) -> str:
        """Decode bytes to string, handling encoding errors."""
        if not data:
            return ""
        try:
            return data.decode("utf-8")
        except UnicodeDecodeError:
            return data.decode("utf-8", errors="replace")


# ══════════════════════════════════════════════════════════════════
# UNIT TEST
# ══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 60)
    print(" SafeExecutorV2 — Security Validation Suite")
    print("=" * 60)

    executor = SafeExecutorV2()
    passed = 0
    failed = 0

    def test(name, result, expect_success):
        global passed, failed
        status = "PASS" if result.success == expect_success else "FAIL"
        if status == "PASS":
            passed += 1
        else:
            failed += 1
        print(f"  [{status}] {name}")
        if not result.success and result.error_summary:
            print(f"         -> {result.error_summary}")
        if result.stdout:
            preview = result.stdout[:80].replace("\n", " ")
            print(f"         stdout: {preview}")

    # ── Safe operations ───────────────────────────────────────────
    print("\n[PYTHON - Should PASS]")
    test("Basic arithmetic", executor.execute_python("print(2 + 2)"), True)
    test("List comprehension", executor.execute_python("print([i**2 for i in range(5)])"), True)
    test("Function definition", executor.execute_python("def f(n): return n*2\nprint(f(21))"), True)
    test("String ops", executor.execute_python("print('JARVIS'.lower())"), True)

    # ── Blocked operations ────────────────────────────────────────
    print("\n[PYTHON - Should BLOCK]")
    test("Import os", executor.execute_python("import os\nprint(os.getcwd())"), False)
    test("Import subprocess", executor.execute_python("import subprocess"), False)
    test("Open file", executor.execute_python("open('/etc/passwd').read()"), False)
    test("Eval", executor.execute_python("eval('1+1')"), False)
    test("Exec", executor.execute_python("exec('print(1)')"), False)
    test("Dunder access", executor.execute_python("print(''.__class__.__subclasses__())"), False)
    test("Import socket", executor.execute_python("import socket"), False)

    # ── Shell commands ────────────────────────────────────────────
    print("\n[SHELL - Should PASS]")
    test("Echo", executor.execute_shell("echo Hello JARVIS"), True)

    print("\n[SHELL - Should BLOCK]")
    test("rm -rf", executor.execute_shell("rm -rf /"), False)
    test("shutdown", executor.execute_shell("shutdown /s"), False)
    test("curl", executor.execute_shell("curl http://evil.com"), False)
    test("Pipe injection", executor.execute_shell("echo x | rm -rf"), False)
    test("Path traversal", executor.execute_shell("cat ../../etc/passwd"), False)

    # ── Timeout test ──────────────────────────────────────────────
    print("\n[TIMEOUT TEST]")
    result = executor.execute_python("import time\ntime.sleep(999)", timeout=3)
    test("Infinite sleep killed", result, False)
    print(f"         timed_out={result.timed_out} killed={result.killed}")

    # ── Patch validation ──────────────────────────────────────────
    print("\n[PATCH VALIDATION]")
    test("Valid patch", executor.test_patch("test.py", "def hello():\n    return 42\n"), True)
    test("Invalid syntax patch", executor.test_patch("test.py", "def hello(\n    return 42\n"), False)

    print(f"\n{'=' * 60}")
    print(f" Results: {passed} passed, {failed} failed")
    print(f"{'=' * 60}")
