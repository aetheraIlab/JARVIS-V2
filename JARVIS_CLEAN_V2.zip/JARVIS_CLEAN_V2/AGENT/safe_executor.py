import asyncio
import traceback
from .response import AgentResponse

class SafeExecutor:
    """Error-isolated execution wrapper for UAF Agents."""
    
    @staticmethod
    async def run(func, *args, timeout: float = 60.0, agent_id: str = "UNKNOWN", action: str = "unknown") -> AgentResponse:
        """Executes an async function with timeout and error capture."""
        try:
            result = await asyncio.wait_for(func(*args), timeout=timeout)
            return AgentResponse(
                success=True,
                agent_id=agent_id,
                action=action,
                result=result
            )
        except asyncio.TimeoutError:
            return AgentResponse(
                success=False,
                agent_id=agent_id,
                action=action,
                error=f"Execution timed out after {timeout} seconds"
            )
        except Exception as e:
            tb = traceback.format_exc()
            return AgentResponse(
                success=False,
                agent_id=agent_id,
                action=action,
                error=f"Execution failed: {str(e)}",
                metadata={"traceback": tb}
            )
