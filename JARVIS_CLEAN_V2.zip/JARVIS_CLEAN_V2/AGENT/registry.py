# ================================================================
# JARVIS AETHER-CORE V2.0 — DYNAMIC AGENT REGISTRY
# ================================================================
# Role     : Auto-discovery, registration, and lifecycle management
#            for all UAF agents in the JARVIS ecosystem
# Layer    : AGENT (Universal Agent Framework)
# Design   : Singleton — import agent_registry from this module
# ================================================================

import os
import sys
import inspect
import importlib
import importlib.util
import logging
import threading
from pathlib import Path
from typing import Dict, List, Optional, Type, Any

from AGENT.base_agent import BaseAgent

logger = logging.getLogger("AGENT_REGISTRY")


class AgentRegistry:
    """
    Dynamic agent registry for the JARVIS Universal Agent Framework.

    Provides:
    - **Decorator registration**: ``@agent_registry.register`` on a class
    - **Auto-discovery**: scan directories for ``*_agent.py`` files and
      import any ``BaseAgent`` subclasses found inside them
    - **Instance management**: create, cache, and retrieve live agent
      instances by their ``AGENT_ID``
    - **Capability aggregation**: query all registered capabilities
      across the fleet for delegation routing

    Usage::

        from AGENT.registry import agent_registry

        # Auto-discover
        agent_registry.discover_agents(Path("AGENT/agents"))

        # Manual registration
        @agent_registry.register
        class MyAgent(BaseAgent): ...

        # Get a live instance
        agent = agent_registry.get_instance("MY_AGENT")
    """

    def __init__(self):
        self._lock = threading.RLock()

        # agent_id → class reference
        self._classes: Dict[str, Type[BaseAgent]] = {}

        # agent_id → live instance
        self._instances: Dict[str, BaseAgent] = {}

    # ── Decorator-style Registration ──────────────────────────

    def register(self, agent_class: Type[BaseAgent]) -> Type[BaseAgent]:
        """
        Register an agent class. Can be used as a decorator::

            @agent_registry.register
            class FooAgent(BaseAgent):
                AGENT_ID = "FOO_AGENT"
                ...

        Args:
            agent_class: A concrete subclass of BaseAgent.

        Returns:
            The same class, unmodified (pass-through decorator).
        """
        if not (inspect.isclass(agent_class) and issubclass(agent_class, BaseAgent)):
            logger.warning(f"[REGISTRY] Skipping {agent_class}: not a BaseAgent subclass.")
            return agent_class

        agent_id = getattr(agent_class, "AGENT_ID", None)
        if not agent_id or agent_id == "BASE_AGENT":
            logger.warning(f"[REGISTRY] Skipping {agent_class.__name__}: no valid AGENT_ID.")
            return agent_class

        with self._lock:
            if agent_id in self._classes:
                logger.debug(f"[REGISTRY] Agent '{agent_id}' already registered. Updating.")
            self._classes[agent_id] = agent_class
            logger.info(f"[REGISTRY] Registered: {agent_id} ({agent_class.__name__})")

        return agent_class

    # ── Auto-Discovery ────────────────────────────────────────

    def discover_agents(self, path: Path) -> List[str]:
        """
        Scan a directory for ``*_agent.py`` files and register any
        ``BaseAgent`` subclasses found inside them.

        Args:
            path: Directory to scan (relative to project root or absolute).

        Returns:
            List of newly discovered agent IDs.
        """
        discovered: List[str] = []

        # Resolve relative paths against the project root
        if not path.is_absolute():
            project_root = Path(__file__).resolve().parent.parent
            path = project_root / path

        if not path.is_dir():
            logger.warning(f"[REGISTRY] Discovery path does not exist: {path}")
            return discovered

        for py_file in sorted(path.glob("*_agent.py")):
            if py_file.name.startswith("_"):
                continue

            try:
                module = self._import_file(py_file)
                if module is None:
                    continue

                # Inspect all members for BaseAgent subclasses
                for name, obj in inspect.getmembers(module, inspect.isclass):
                    if (
                        issubclass(obj, BaseAgent)
                        and obj is not BaseAgent
                        and getattr(obj, "AGENT_ID", "BASE_AGENT") != "BASE_AGENT"
                    ):
                        agent_id = obj.AGENT_ID
                        with self._lock:
                            if agent_id not in self._classes:
                                self._classes[agent_id] = obj
                                discovered.append(agent_id)
                                logger.info(
                                    f"[REGISTRY] Discovered: {agent_id} "
                                    f"({obj.__name__}) from {py_file.name}"
                                )
                            else:
                                logger.debug(
                                    f"[REGISTRY] Already registered: {agent_id}"
                                )
            except Exception as e:
                logger.error(
                    f"[REGISTRY] Failed to import {py_file.name}: {e}",
                    exc_info=False,
                )

        return discovered

    @staticmethod
    def _import_file(file_path: Path):
        """
        Dynamically import a Python file by its filesystem path.

        Uses ``importlib.util`` to load the module without needing
        it to be on ``sys.path`` or in a package.
        """
        module_name = f"_jarvis_agent_discovery_.{file_path.stem}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, str(file_path))
            if spec is None or spec.loader is None:
                return None
            module = importlib.util.module_from_spec(spec)
            # Temporarily add to sys.modules so relative imports inside the
            # file don't break
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
            return module
        except Exception as e:
            logger.debug(f"[REGISTRY] Import error for {file_path.name}: {e}")
            return None

    # ── Instance Management ───────────────────────────────────

    def instantiate(
        self,
        agent_id: str,
        *args: Any,
        **kwargs: Any,
    ) -> Optional[BaseAgent]:
        """
        Create and cache a live instance of a registered agent.

        Args:
            agent_id: The AGENT_ID of the agent class to instantiate.
            *args, **kwargs: Forwarded to the agent's ``__init__``.

        Returns:
            The agent instance, or None if the class is not registered.
        """
        with self._lock:
            # Return cached instance if it exists
            if agent_id in self._instances:
                return self._instances[agent_id]

            agent_class = self._classes.get(agent_id)
            if agent_class is None:
                logger.warning(f"[REGISTRY] Cannot instantiate unknown agent: {agent_id}")
                return None

            try:
                instance = agent_class(*args, **kwargs)
                self._instances[agent_id] = instance
                logger.info(f"[REGISTRY] Instantiated: {agent_id}")
                return instance
            except Exception as e:
                logger.error(f"[REGISTRY] Failed to instantiate {agent_id}: {e}")
                return None

    def instantiate_all(self, *args: Any, **kwargs: Any) -> Dict[str, BaseAgent]:
        """
        Instantiate all registered agent classes that don't already
        have a live instance.

        Returns:
            Dict of agent_id → instance for all successfully created agents.
        """
        results = {}
        with self._lock:
            for agent_id in list(self._classes.keys()):
                instance = self.instantiate(agent_id, *args, **kwargs)
                if instance:
                    results[agent_id] = instance
        return results

    def get_instance(self, agent_id: str) -> Optional[BaseAgent]:
        """Return the cached live instance for an agent, or None."""
        with self._lock:
            return self._instances.get(agent_id)

    def set_instance(self, agent_id: str, instance: BaseAgent) -> None:
        """
        Manually register a pre-created instance (e.g., agents created
        by the PresidentAgent before the registry existed).
        """
        with self._lock:
            cls = type(instance)
            if agent_id not in self._classes:
                self._classes[agent_id] = cls
            self._instances[agent_id] = instance
            logger.info(f"[REGISTRY] External instance registered: {agent_id}")

    # ── Query Interface ───────────────────────────────────────

    def list_agents(self) -> List[str]:
        """Return a sorted list of all registered agent IDs."""
        with self._lock:
            return sorted(self._classes.keys())

    def list_active(self) -> List[str]:
        """Return a sorted list of all instantiated (active) agent IDs."""
        with self._lock:
            return sorted(self._instances.keys())

    def get_capabilities(self) -> Dict[str, list]:
        """
        Return a map of agent_id → capabilities for every registered
        agent class.

        Capabilities are normalised to a list of strings.
        """
        with self._lock:
            result = {}
            for agent_id, cls in self._classes.items():
                caps = getattr(cls, "CAPABILITIES", [])
                result[agent_id] = [
                    c["name"] if isinstance(c, dict) else str(c)
                    for c in caps
                ]
            return result

    def find_agent_for_capability(self, capability: str) -> Optional[str]:
        """
        Find the first registered agent that declares a given capability.

        Returns:
            The agent_id, or None if no agent has the capability.
        """
        caps = self.get_capabilities()
        for agent_id, cap_list in caps.items():
            if capability in cap_list:
                return agent_id
        return None

    @property
    def agent_count(self) -> int:
        with self._lock:
            return len(self._classes)

    @property
    def instance_count(self) -> int:
        with self._lock:
            return len(self._instances)

    def __repr__(self) -> str:
        return (
            f"<AgentRegistry classes={self.agent_count} "
            f"instances={self.instance_count}>"
        )


# ── Global Singleton ──────────────────────────────────────────
agent_registry = AgentRegistry()
