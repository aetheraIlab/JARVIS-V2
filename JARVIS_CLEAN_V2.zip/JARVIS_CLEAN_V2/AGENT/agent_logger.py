import logging
import os
from datetime import datetime

class AgentLogger:
    """Standardized logging for UAF Agents."""
    def __init__(self, agent_id: str, log_dir: str = "logs/agents"):
        self.agent_id = agent_id
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger(f"AGENT_{agent_id}")
        self.logger.setLevel(logging.INFO)
        
        if not self.logger.handlers:
            # File handler
            fh = logging.FileHandler(os.path.join(log_dir, f"{agent_id.lower()}.log"))
            fh.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
            self.logger.addHandler(fh)
            
            # Console handler
            ch = logging.StreamHandler()
            ch.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
            self.logger.addHandler(ch)

    def info(self, msg: str):
        self.logger.info(msg)

    def warning(self, msg: str):
        self.logger.warning(msg)

    def error(self, msg: str, exc_info=False):
        self.logger.error(msg, exc_info=exc_info)

    def critical(self, msg: str):
        self.logger.critical(msg)

    def audit(self, action: str, detail: str):
        """Security audit trail."""
        self.logger.info(f"[AUDIT] Action: {action} | Detail: {detail}")
