from dataclasses import dataclass, field
from typing import Any
from datetime import datetime

@dataclass
class AgentResponse:
    """Standardized response schema for all UAF Agents."""
    success: bool
    agent_id: str
    action: str
    result: Any = None
    error: str = None
    metadata: dict = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    trace_id: str = "trace_0"
    
    # Execution Validation Fields
    confidence: float = 1.0
    retries: int = 0
    used_fallback: bool = False

    def to_dict(self):
        return {
            "success": self.success,
            "agent_id": self.agent_id,
            "action": self.action,
            "result": self.result,
            "error": self.error,
            "metadata": self.metadata,
            "timestamp": self.timestamp,
            "trace_id": self.trace_id,
            "confidence": self.confidence,
            "retries": self.retries,
            "used_fallback": self.used_fallback
        }
