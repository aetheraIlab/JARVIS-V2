import os
from datetime import datetime

class DownloadManager:
    """
    Intercepts and sandboxes file downloads from the browser.
    """
    def __init__(self, download_dir: str = "logs/browser_downloads"):
        self.download_dir = download_dir
        os.makedirs(self.download_dir, exist_ok=True)
        self.blocked_mimes = ['application/x-msdownload', 'application/x-executable', 'application/x-sh']

    async def handle_download(self, download):
        """Sandboxes and validates a download."""
        suggested_filename = download.suggested_filename
        path = os.path.join(self.download_dir, suggested_filename)
        
        # Security: basic extension check to block executables
        ext = os.path.splitext(suggested_filename)[1].lower()
        if ext in ['.exe', '.bat', '.sh', '.vbs', '.msi', '.scr']:
            await download.cancel()
            return {"success": False, "error": "Download blocked: Dangerous file extension."}
            
        await download.save_as(path)
        return {
            "success": True, 
            "path": path, 
            "url": download.url, 
            "filename": suggested_filename
        }
