import json

class CookiesManager:
    """
    Manages cookie extraction and injection for Playwright contexts.
    """
    def __init__(self):
        pass

    async def get_cookies(self, context, url: str = None):
        """Extracts cookies from the current context."""
        if url:
            return await context.cookies(urls=[url])
        return await context.cookies()

    async def set_cookies(self, context, cookies: list):
        """Injects cookies into the current context."""
        await context.add_cookies(cookies)

    async def clear_cookies(self, context):
        """Clears all cookies from the current context."""
        await context.clear_cookies()
