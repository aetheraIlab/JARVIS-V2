class TabManager:
    """
    Wraps Playwright Page objects. Handles multi-tab routing, 
    tracking active tabs, and closing tabs cleanly.
    """
    def __init__(self):
        self.tabs = {}  # tab_id -> page
        self.active_tab_id = None
        self._tab_counter = 0

    def add_tab(self, page, tab_id: str = None) -> str:
        """Registers a new page as a tab."""
        if not tab_id:
            self._tab_counter += 1
            tab_id = f"tab_{self._tab_counter}"
        
        self.tabs[tab_id] = page
        self.active_tab_id = tab_id
        return tab_id

    def get_active_tab(self):
        """Returns the currently active page/tab."""
        if self.active_tab_id and self.active_tab_id in self.tabs:
            return self.tabs[self.active_tab_id]
        return None

    def get_tab(self, tab_id: str):
        """Returns a specific tab by ID."""
        return self.tabs.get(tab_id)

    def switch_tab(self, tab_id: str):
        """Switches the active tab."""
        if tab_id in self.tabs:
            self.active_tab_id = tab_id
            # page.bring_to_front() could be called here if needed
            return True
        return False

    async def close_tab(self, tab_id: str = None):
        """Closes a specific tab or the active one if none specified."""
        tid = tab_id or self.active_tab_id
        if tid in self.tabs:
            page = self.tabs[tid]
            try:
                await page.close()
            except Exception:
                pass
            del self.tabs[tid]
            if self.active_tab_id == tid:
                self.active_tab_id = list(self.tabs.keys())[0] if self.tabs else None
            return True
        return False

    async def close_all(self):
        """Closes all tracked tabs."""
        for tid, page in list(self.tabs.items()):
            try:
                await page.close()
            except Exception:
                pass
        self.tabs.clear()
        self.active_tab_id = None
