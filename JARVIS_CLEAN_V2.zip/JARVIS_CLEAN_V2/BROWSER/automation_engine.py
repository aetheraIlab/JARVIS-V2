class AutomationEngine:
    """
    Executes mechanical tasks: click_element, fill_form, scroll_page.
    """
    def __init__(self):
        pass

    async def click_element(self, page, selector: str):
        """Clicks an element matching the selector."""
        try:
            # Playwright handles auto-waiting
            await page.click(selector, timeout=5000)
            return {"success": True, "action": "click", "selector": selector}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def fill_form(self, page, fields: dict):
        """Fills out multiple fields in a form."""
        results = {}
        for selector, value in fields.items():
            try:
                await page.fill(selector, str(value), timeout=3000)
                results[selector] = "success"
            except Exception as e:
                results[selector] = f"failed: {str(e)}"
        
        success = all(v == "success" for v in results.values())
        return {"success": success, "results": results}

    async def scroll_page(self, page, direction="down", amount=800):
        """Scrolls the page up or down."""
        try:
            if direction == "down":
                await page.evaluate(f"window.scrollBy(0, {amount});")
            else:
                await page.evaluate(f"window.scrollBy(0, -{amount});")
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}
