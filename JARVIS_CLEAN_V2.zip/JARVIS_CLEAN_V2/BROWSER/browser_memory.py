from collections import deque
from datetime import datetime

class BrowserMemory:
    """
    Short-term memory for the browser session. Tracks visited URLs, 
    frequent domains, and recent actions.
    """
    def __init__(self, max_history=100):
        self.max_history = max_history
        self.history = deque(maxlen=self.max_history)
        self.actions = deque(maxlen=self.max_history)

    def record_visit(self, url: str, title: str):
        """Records a visited URL."""
        self.history.append({
            "url": url,
            "title": title,
            "timestamp": datetime.now().isoformat()
        })

    def record_action(self, action_type: str, details: dict):
        """Records a browser action (e.g., click, fill)."""
        self.actions.append({
            "action": action_type,
            "details": details,
            "timestamp": datetime.now().isoformat()
        })

    def get_recent_history(self, limit=10):
        """Returns the most recently visited pages."""
        return list(self.history)[-limit:]

    def get_recent_actions(self, limit=10):
        """Returns the most recent actions."""
        return list(self.actions)[-limit:]
