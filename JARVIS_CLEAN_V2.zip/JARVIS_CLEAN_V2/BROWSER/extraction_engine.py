try:
    import trafilatura
    from bs4 import BeautifulSoup
except ImportError:
    trafilatura = None
    BeautifulSoup = None

class ExtractionEngine:
    """
    Uses trafilatura and BeautifulSoup to strip noise/ads, convert HTML to clean Markdown.
    """
    def __init__(self):
        self.available = trafilatura is not None and BeautifulSoup is not None

    async def extract_article(self, html_content: str, url: str = None):
        """Extracts the main article content, removing ads and navigation."""
        if not self.available:
            return {"success": False, "error": "Dependencies missing. Run: pip install trafilatura beautifulsoup4 readability-lxml"}

        try:
            # Trafilatura is excellent for main text extraction
            extracted = trafilatura.extract(
                html_content, 
                url=url, 
                include_links=True, 
                include_images=False,
                output_format="markdown"
            )
            
            if extracted:
                return {"success": True, "content": extracted, "method": "trafilatura"}
            
            # Fallback to simple BS4 extraction
            soup = BeautifulSoup(html_content, 'html.parser')
            for script in soup(["script", "style", "nav", "footer", "iframe"]):
                script.extract()
            text = soup.get_text(separator='\n\n', strip=True)
            return {"success": True, "content": text, "method": "bs4_fallback"}
            
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_metadata(self, html_content: str):
        """Extracts title, description, and keywords."""
        if not self.available:
             return {"success": False, "error": "Dependencies missing."}
             
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            title = soup.title.string if soup.title else ""
            
            desc_tag = soup.find('meta', attrs={'name': 'description'})
            description = desc_tag['content'] if desc_tag else ""
            
            return {
                "success": True, 
                "metadata": {
                    "title": title,
                    "description": description
                }
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
