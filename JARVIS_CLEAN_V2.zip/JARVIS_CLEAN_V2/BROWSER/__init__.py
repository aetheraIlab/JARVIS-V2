# BROWSER subsystem init
