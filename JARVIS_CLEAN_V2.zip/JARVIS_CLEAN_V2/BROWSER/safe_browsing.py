from urllib.parse import urlparse
import re

class SafeBrowsing:
    """
    Security gatekeeper. Implements URL trust scoring and blocks malicious domains.
    """
    BLOCKED_TLDS = ['.onion', '.tk', '.ml', '.ga', '.cf', '.gq']
    BLOCKED_KEYWORDS = ['malware', 'phishing', 'hack', 'exploit', 'darkweb']

    def __init__(self):
        pass

    def check_url(self, url: str) -> dict:
        """Validates if a URL is safe to browse."""
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url

        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()

            # Check TLDs
            for tld in self.BLOCKED_TLDS:
                if domain.endswith(tld):
                    return {"safe": False, "reason": f"Blocked TLD: {tld}", "url": url}

            # Check Keywords
            for keyword in self.BLOCKED_KEYWORDS:
                if keyword in domain or keyword in parsed.path.lower():
                    return {"safe": False, "reason": f"Blocked keyword found: {keyword}", "url": url}

            return {"safe": True, "reason": "URL validated", "url": url}
        except Exception as e:
            return {"safe": False, "reason": f"Invalid URL structure: {e}", "url": url}

    def sanitize_input(self, text: str) -> str:
        """Sanitizes text to prevent prompt injection or script execution."""
        # Simple sanitization: remove <script> tags
        sanitized = re.sub(r'<script.*?>.*?</script>', '', text, flags=re.IGNORECASE|re.DOTALL)
        return sanitized
