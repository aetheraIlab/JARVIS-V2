from .tab_manager import TabManager
from .cookies import CookiesManager
from .auth_store import AuthStore

class SessionManager:
    """
    Manages Playwright Browser and BrowserContext lifecycles.
    Handles persistent sessions and auto-restoration.
    """
    def __init__(self, headless=True):
        self.headless = headless
        self.playwright = None
        self.browser = None
        self.context = None
        
        # Sub-modules
        self.tab_manager = TabManager()
        self.cookies_manager = CookiesManager()
        self.auth_store = AuthStore()
        
        self.is_initialized = False

    async def initialize(self):
        """Starts Playwright and the browser instance."""
        if self.is_initialized:
            return True
            
        try:
            from playwright.async_api import async_playwright
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(
                headless=self.headless,
                args=['--disable-dev-shm-usage', '--no-sandbox']
            )
            # Default context
            self.context = await self.browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            self.is_initialized = True
            return True
        except ImportError:
            print("[BROWSER] Playwright not installed. Run: pip install playwright && playwright install chromium")
            return False
        except Exception as e:
            print(f"[BROWSER] Init failed: {e}")
            return False

    async def new_page(self):
        """Creates a new page in the current context and adds it to TabManager."""
        if not self.is_initialized:
            await self.initialize()
            
        if self.context:
            page = await self.context.new_page()
            tab_id = self.tab_manager.add_tab(page)
            return page, tab_id
        return None, None

    async def shutdown(self):
        """Gracefully shuts down all tabs, contexts, and the browser."""
        await self.tab_manager.close_all()
        
        if self.context:
            try:
                await self.context.close()
            except Exception:
                pass
            self.context = None
            
        if self.browser:
            try:
                await self.browser.close()
            except Exception:
                pass
            self.browser = None
            
        if self.playwright:
            try:
                await self.playwright.stop()
            except Exception:
                pass
            self.playwright = None
            
        self.is_initialized = False
