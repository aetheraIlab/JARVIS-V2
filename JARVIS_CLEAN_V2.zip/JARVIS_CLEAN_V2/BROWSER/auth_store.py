import os
import json
from datetime import datetime

class AuthStore:
    """
    Manages persistent authentication states across JARVIS reboots.
    """
    def __init__(self, store_dir: str = "logs/browser_auth"):
        self.store_dir = store_dir
        os.makedirs(self.store_dir, exist_ok=True)

    async def save_state(self, context, domain: str):
        """Saves the context storage state (cookies, local storage) for a domain."""
        path = os.path.join(self.store_dir, f"{domain}_state.json")
        await context.storage_state(path=path)

    async def load_state(self, browser, domain: str):
        """Creates a new context loaded with the saved state for a domain."""
        path = os.path.join(self.store_dir, f"{domain}_state.json")
        if os.path.exists(path):
            return await browser.new_context(storage_state=path)
        return await browser.new_context()

    def clear_state(self, domain: str):
        """Clears the stored authentication state for a domain."""
        path = os.path.join(self.store_dir, f"{domain}_state.json")
        if os.path.exists(path):
            os.remove(path)
            return True
        return False
