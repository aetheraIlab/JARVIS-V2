class DOMAnalyzer:
    """
    Analyzes the DOM dynamically. Extracts interactive elements and 
    smartly matches selectors.
    """
    def __init__(self):
        pass

    async def get_interactive_elements(self, page):
        """Extracts visible interactive elements (buttons, links, inputs)."""
        script = """
        () => {
            const elements = Array.from(document.querySelectorAll('a, button, input, textarea, select, [role="button"]'));
            return elements.map(el => {
                const rect = el.getBoundingClientRect();
                return {
                    tagName: el.tagName.toLowerCase(),
                    text: el.innerText || el.value || el.placeholder || el.getAttribute('aria-label') || '',
                    type: el.type || '',
                    id: el.id,
                    className: el.className,
                    href: el.href || '',
                    visible: rect.width > 0 && rect.height > 0
                };
            }).filter(e => e.visible);
        }
        """
        try:
            elements = await page.evaluate(script)
            return {"success": True, "elements": elements}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def find_best_selector(self, page, target_text: str):
        """Attempts to find a CSS selector that matches the target text."""
        # This is a simplified version. A real one might use NLP or fuzzy matching.
        script = f"""
        () => {{
            const elements = Array.from(document.querySelectorAll('*'));
            for (let el of elements) {{
                if (el.innerText && el.innerText.trim() === '{target_text}') {{
                    if (el.id) return '#' + el.id;
                    if (el.className) return '.' + el.className.split(' ').join('.');
                    return el.tagName.toLowerCase();
                }}
            }}
            return null;
        }}
        """
        try:
            selector = await page.evaluate(script)
            if selector:
                return {"success": True, "selector": selector}
            return {"success": False, "error": "Selector not found"}
        except Exception as e:
            return {"success": False, "error": str(e)}
