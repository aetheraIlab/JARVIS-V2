# ================================================================
# JARVIS AETHER-CORE V2.0 — NEXUS-FETCH (LAYER 4 / NEXUS)
# ================================================================
# Codename : NEXUS-FETCH
# Role     : Web Fetch & Summarize Agent
# Tech     : requests + BeautifulSoup4
# ================================================================

import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class NexusFetch:
    """
    JARVIS NEXUS-FETCH — ওয়েব পেজ ফেচ ও সারসংক্ষেপ এজেন্ট।
    যেকোনো URL থেকে টেক্সট বের করে সারসংক্ষেপ তৈরি করে।
    """

    def __init__(self):
        self._requests = None
        self._bs4 = None
        self._init_tools()
        print("[NEXUS-FETCH] Web fetch agent initialized.")

    def _init_tools(self):
        """requests ও BeautifulSoup লোড করে।"""
        try:
            import requests
            self._requests = requests
        except ImportError:
            print("[NEXUS-FETCH] [WARN] requests not installed.")

        try:
            from bs4 import BeautifulSoup
            self._bs4 = BeautifulSoup
        except ImportError:
            print("[NEXUS-FETCH] [WARN] beautifulsoup4 not installed.")

    def fetch_text(self, url, max_chars=5000):
        """URL থেকে পেজের মূল টেক্সট বের করে।"""
        if not self._requests or not self._bs4:
            return "Fetch tools unavailable."

        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            response = self._requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()

            # ৫ MB এর বেশি পেলোড ব্লক করা হচ্ছে
            if len(response.content) > 5 * 1024 * 1024:
                return "Page too large (>5MB)."

            soup = self._bs4(response.text, 'html.parser')

            # স্ক্রিপ্ট, স্টাইল, নেভিগেশন ইত্যাদি সরিয়ে ফেলা হচ্ছে
            for tag in soup(['script', 'style', 'nav', 'footer', 'header', 'aside']):
                tag.decompose()

            text = soup.get_text(separator='\n', strip=True)

            # খালি লাইন এবং বাড়তি স্পেস পরিষ্কার করা হচ্ছে
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            clean_text = '\n'.join(lines)

            return clean_text[:max_chars]
        except Exception as e:
            return f"Fetch error: {e}"

    def fetch_title(self, url):
        """URL থেকে পেজের টাইটেল বের করে।"""
        if not self._requests or not self._bs4:
            return "Unavailable"
        try:
            headers = {"User-Agent": "Mozilla/5.0"}
            response = self._requests.get(url, headers=headers, timeout=10)
            soup = self._bs4(response.text, 'html.parser')
            title = soup.find('title')
            return title.string.strip() if title and title.string else "No title"
        except Exception as e:
            return f"Error: {e}"

    def fetch_links(self, url, max_links=20):
        """URL থেকে সব লিংক বের করে।"""
        if not self._requests or not self._bs4:
            return []
        try:
            headers = {"User-Agent": "Mozilla/5.0"}
            response = self._requests.get(url, headers=headers, timeout=10)
            soup = self._bs4(response.text, 'html.parser')
            links = []
            for a in soup.find_all('a', href=True):
                href = a['href']
                text = a.get_text(strip=True)
                if href.startswith('http'):
                    links.append({"text": text[:80], "url": href})
                if len(links) >= max_links:
                    break
            return links
        except Exception as e:
            return [{"error": str(e)}]

    def fetch_meta(self, url):
        """URL থেকে মেটা ইনফরমেশন বের করে।"""
        if not self._requests or not self._bs4:
            return {}
        try:
            headers = {"User-Agent": "Mozilla/5.0"}
            response = self._requests.get(url, headers=headers, timeout=10)
            soup = self._bs4(response.text, 'html.parser')
            meta = {}
            title_tag = soup.find('title')
            meta['title'] = title_tag.string.strip() if title_tag and title_tag.string else ""
            desc = soup.find('meta', attrs={'name': 'description'})
            meta['description'] = desc['content'] if desc and desc.get('content') else ""
            return meta
        except Exception as e:
            return {"error": str(e)}


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 50)
    print("  NEXUS-FETCH — Unit Test")
    print("=" * 50)

    nf = NexusFetch()

    url = "https://en.wikipedia.org/wiki/Python_(programming_language)"
    print(f"\n[TEST] Fetching title: {nf.fetch_title(url)}")
    print(f"[TEST] Meta: {nf.fetch_meta(url)}")
    print(f"[TEST] Text (first 300 chars):\n{nf.fetch_text(url, 300)}")

    print("\n[NEXUS-FETCH] Unit test complete. ✓")
