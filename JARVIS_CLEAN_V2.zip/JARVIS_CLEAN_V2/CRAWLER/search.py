# ================================================================
# JARVIS AETHER-CORE V2.0 — NEXUS-SEARCH (LAYER 4 / NEXUS)
# ================================================================
# Codename : NEXUS-SEARCH
# Role     : Web Search Agent — DuckDuckGo
# Tech     : duckduckgo-search
# ================================================================

import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class NexusSearch:
    """
    JARVIS NEXUS-SEARCH — ওয়েব সার্চ এজেন্ট।
    DuckDuckGo ব্যবহার করে ইন্টারনেটে তথ্য খোঁজে।
    """

    def __init__(self):
        self._ddgs = None
        self._init_search()
        print("[NEXUS-SEARCH] Web search agent initialized.")

    def _init_search(self):
        """DuckDuckGo সার্চ ইঞ্জিন লোড করে।"""
        try:
            from duckduckgo_search import DDGS
            self._ddgs = DDGS
            print("[NEXUS-SEARCH] DuckDuckGo engine ready.")
        except ImportError:
            print("[NEXUS-SEARCH] [WARN] duckduckgo-search not installed.")

    def search(self, query, max_results=5):
        """টেক্সট সার্চ করে ফলাফল রিটার্ন করে।"""
        if not self._ddgs:
            return [{"error": "Search engine unavailable."}]
        try:
            with self._ddgs() as ddgs:
                results = list(ddgs.text(query, max_results=max_results))
            return results
        except Exception as e:
            print(f"[NEXUS-SEARCH] Search error: {e}")
            return [{"error": str(e)}]

    def search_news(self, query, max_results=5):
        """নিউজ সার্চ করে।"""
        if not self._ddgs:
            return [{"error": "Search engine unavailable."}]
        try:
            with self._ddgs() as ddgs:
                results = list(ddgs.news(query, max_results=max_results))
            return results
        except Exception as e:
            print(f"[NEXUS-SEARCH] News search error: {e}")
            return [{"error": str(e)}]

    def quick_answer(self, query):
        """সার্চ করে প্রথম ফলাফলের সারসংক্ষেপ দেয়।"""
        results = self.search(query, max_results=3)
        if results and "error" not in results[0]:
            summaries = []
            for r in results:
                title = r.get("title", "")
                body = r.get("body", "")
                summaries.append(f"{title}: {body}")
            return "\n\n".join(summaries)
        return "No results found."


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 50)
    print("  NEXUS-SEARCH — Unit Test")
    print("=" * 50)

    ns = NexusSearch()
    print("\n[TEST] Searching: 'Python programming'")
    results = ns.search("Python programming", max_results=3)
    for r in results:
        print(f"  • {r.get('title', 'N/A')}")
        print(f"    {r.get('body', '')[:100]}...")

    print("\n[NEXUS-SEARCH] Unit test complete. ✓")
