import os
import sys
import time
import logging
import threading
import requests
import shutil
import base64
from flask import Flask, request, jsonify, send_file
from pathlib import Path

try:
    from dotenv import load_dotenv
    _has_dotenv = True
except ImportError:
    _has_dotenv = False

logger = logging.getLogger("NAS-AGENT")
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

class NASAgent:
    """
    JARVIS NAS Node (Storage/Backup).
    NAS ডিভাইসে রান করবে (Windows/Linux) এবং হাবের জন্য স্টোরেজ সার্ভ করবে।
    Capabilities: file storage, backup, media serving.
    """

    def __init__(self, node_name="NAS-Omega", hub_url="http://192.168.1.100:5001"):
        self.node_name = node_name
        self.hub_url = hub_url
        self.capabilities = ["storage", "backup", "media"]
        self.app = Flask(__name__)
        self.running = False
        
        # Load environment settings
        self.base_dir = Path(__file__).resolve().parent.parent
        if _has_dotenv:
            load_dotenv(dotenv_path=self.base_dir / ".env")
            
        # Get NAS Storage Path (default to a local 'nas_data' folder if not set)
        storage_str = os.environ.get("NAS_STORAGE_PATH", str(self.base_dir / "nas_data"))
        self.storage_path = Path(storage_str)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self._setup_routes()
        logger.info(f"NAS Agent initialized. Storage Path: {self.storage_path}")

    def _setup_routes(self):
        @self.app.route('/info', methods=['GET'])
        def api_info():
            return jsonify({
                "name": self.node_name,
                "capabilities": self.capabilities,
                "storage_path": str(self.storage_path),
                "status": "ONLINE"
            })

        @self.app.route('/ping', methods=['GET'])
        def api_ping():
            return jsonify({"status": "OK"})

        @self.app.route('/task', methods=['POST'])
        def api_task():
            data = request.json
            if not data or 'task_type' not in data:
                return jsonify({"error": "Missing task_type"}), 400
                
            task_type = data['task_type']
            payload = data.get('payload', {})
            
            # Execute synchronously
            try:
                if task_type == "store_file":
                    res = self.store_file(payload.get("filename"), payload.get("data", ""))
                    return jsonify(res)
                elif task_type == "retrieve_file":
                    res = self.retrieve_file(payload.get("filename"))
                    return jsonify(res)
                elif task_type == "list_files":
                    res = self.list_files(payload.get("folder", ""))
                    return jsonify(res)
                elif task_type == "backup_jarvis_data":
                    res = self.backup_jarvis_data(payload.get("source_paths", []))
                    return jsonify(res)
                else:
                    return jsonify({"error": f"Unknown task_type: {task_type}"}), 400
            except Exception as e:
                logger.error(f"Task {task_type} failed: {e}")
                return jsonify({"error": str(e)}), 500

    def store_file(self, filename: str, b64_data: str) -> dict:
        """NAS স্টোরেজে একটি ফাইল সেভ করে।"""
        if not filename or not b64_data:
            return {"success": False, "error": "Invalid filename or missing data"}
            
        try:
            # Prevent directory traversal
            safe_filename = Path(filename).name
            target_path = self.storage_path / safe_filename
            
            raw_data = base64.b64decode(b64_data)
            with open(target_path, "wb") as f:
                f.write(raw_data)
                
            logger.info(f"File stored successfully: {safe_filename}")
            return {"success": True, "path": str(target_path)}
        except Exception as e:
            logger.error(f"Store file failed: {e}")
            return {"success": False, "error": str(e)}

    def retrieve_file(self, filename: str) -> dict:
        """NAS স্টোরেজ থেকে ফাইলের ডাটা রিটার্ন করে।"""
        try:
            safe_filename = Path(filename).name
            target_path = self.storage_path / safe_filename
            
            if not target_path.exists():
                return {"success": False, "error": "File not found"}
                
            with open(target_path, "rb") as f:
                raw_data = f.read()
                
            b64_data = base64.b64encode(raw_data).decode('utf-8')
            logger.info(f"File retrieved: {safe_filename}")
            return {"success": True, "filename": safe_filename, "data": b64_data}
        except Exception as e:
            logger.error(f"Retrieve file failed: {e}")
            return {"success": False, "error": str(e)}

    def list_files(self, folder: str = "") -> dict:
        """NAS ডিরেক্টরির ফাইল লিস্ট করে।"""
        try:
            # Basic sanitization to stay within storage path
            target_dir = self.storage_path
            if folder:
                safe_folder = Path(folder).name
                target_dir = self.storage_path / safe_folder
                
            if not target_dir.exists() or not target_dir.is_dir():
                return {"success": False, "error": "Directory not found"}
                
            files = []
            for item in target_dir.iterdir():
                files.append({
                    "name": item.name,
                    "is_dir": item.is_dir(),
                    "size": item.stat().st_size if item.is_file() else 0
                })
                
            return {"success": True, "files": files, "path": str(target_dir)}
        except Exception as e:
            logger.error(f"List files failed: {e}")
            return {"success": False, "error": str(e)}

    def backup_jarvis_data(self, source_paths: list = None) -> dict:
        """সেন্ট্রাল ডাটাবেস (Atlas) এবং ভল্ট (Vault) এর ব্যাকআপ নেয়।"""
        try:
            backup_dir = self.storage_path / "jarvis_backups" / time.strftime("%Y%m%d_%H%M%S")
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            # Default paths if not provided
            if not source_paths:
                # JARVIS/HEAP directory
                heap_dir = self.base_dir / "HEAP"
                if heap_dir.exists():
                    source_paths = [str(heap_dir / "atlas.db"), str(heap_dir / "vault.db")]
            
            backed_up = []
            for sp in source_paths:
                source = Path(sp)
                if source.exists() and source.is_file():
                    shutil.copy2(source, backup_dir / source.name)
                    backed_up.append(source.name)
                    
            logger.info(f"Backup completed to {backup_dir}")
            return {"success": True, "backed_up_files": backed_up, "backup_path": str(backup_dir)}
        except Exception as e:
            logger.error(f"Backup failed: {e}")
            return {"success": False, "error": str(e)}

    def _heartbeat_loop(self):
        """হাব-কে নিজের অস্তিত্ব জানায় (প্রতি ১৫ সেকেন্ডে)।"""
        while self.running:
            try:
                endpoint = f"{self.hub_url}/api/register"
                data = {
                    "name": self.node_name,
                    "ip": self._get_local_ip(),
                    "port": 5002,
                    "capabilities": ",".join(self.capabilities)
                }
                requests.post(endpoint, json=data, timeout=3)
                logger.debug("Heartbeat sent to Hub.")
            except Exception as e:
                logger.warning(f"Heartbeat failed. Hub unreachable: {e}")
            time.sleep(15)

    def _get_local_ip(self) -> str:
        """লোকাল IP বের করে।"""
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('10.255.255.255', 1))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return '127.0.0.1'

    def start_server(self, port=5002):
        """NAS সার্ভার চালু করে।"""
        self.running = True
        threading.Thread(target=self._heartbeat_loop, daemon=True).start()
        
        logger.info(f"Starting NAS Agent on port {port}...")
        self.app.run(host='0.0.0.0', port=port, debug=False, threaded=True, use_reloader=False)

    def stop(self):
        self.running = False

if __name__ == "__main__":
    # Modify hub_url to match your JARVIS Master Node IP
    agent = NASAgent(node_name="NAS-Omega", hub_url="http://192.168.1.100:5001")
    try:
        agent.start_server(port=5002)
    except KeyboardInterrupt:
        agent.stop()
