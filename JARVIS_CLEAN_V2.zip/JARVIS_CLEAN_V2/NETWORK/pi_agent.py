import os
import sys
import time
import logging
import threading
import requests
import platform
from flask import Flask, request, jsonify
from pathlib import Path

# RPi.GPIO (Simulation on Windows)
try:
    if platform.system() == "Linux":
        import RPi.GPIO as GPIO
        _HAS_GPIO = True
    else:
        _HAS_GPIO = False
except ImportError:
    _HAS_GPIO = False

logger = logging.getLogger("PI-AGENT")
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

class PiAgent:
    """
    JARVIS Pi Node (Sensor & Alerts).
    Raspberry Pi (Linux ARM) এ রান করবে, Windows এ সিমুলেশন মোডে চলবে।
    """

    def __init__(self, node_name="Pi-Sensor", hub_url="http://192.168.1.100:5001"):
        self.node_name = node_name
        self.hub_url = hub_url
        self.capabilities = ["gpio_sensors", "alerts", "lightweight_monitoring"]
        self.app = Flask(__name__)
        self.running = False
        
        if _HAS_GPIO:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            logger.info("GPIO Hardware mode ACTIVE.")
        else:
            logger.warning("GPIO module not found or running on Windows. Running in SIMULATION MODE.")

        self._setup_routes()

    def _setup_routes(self):
        @self.app.route('/info', methods=['GET'])
        def api_info():
            return jsonify({
                "name": self.node_name,
                "capabilities": self.capabilities,
                "hardware_mode": _HAS_GPIO,
                "status": "ONLINE"
            })

        @self.app.route('/ping', methods=['GET'])
        def api_ping():
            return jsonify({"status": "OK"})

        @self.app.route('/task', methods=['POST'])
        def api_task():
            data = request.json
            if not data or 'task_type' not in data:
                return jsonify({"error": "Missing task_type"}), 400
                
            task_type = data['task_type']
            payload = data.get('payload', {})
            
            try:
                if task_type == "send_alert":
                    res = self.send_alert(payload.get("message", ""), payload.get("priority", "low"))
                    return jsonify(res)
                elif task_type == "get_sensor_data":
                    res = self.get_sensor_data()
                    return jsonify(res)
                elif task_type == "play_alert_sound":
                    res = self.play_alert_sound()
                    return jsonify(res)
                else:
                    return jsonify({"error": f"Unknown task_type: {task_type}"}), 400
            except Exception as e:
                logger.error(f"Task {task_type} failed: {e}")
                return jsonify({"error": str(e)}), 500

    def send_alert(self, message: str, priority: str = "low") -> dict:
        """ফিজিক্যাল বা সফটওয়্যার এলার্ট জেনারেট করে।"""
        logger.info(f"ALERT [{priority.upper()}]: {message}")
        if priority.lower() in ["high", "critical"]:
            self.play_alert_sound()
        return {"success": True, "alert_logged": True}

    def get_sensor_data(self) -> dict:
        """GPIO সেন্সর থেকে ডাটা ফেচ করে (বা সিমুলেট করে)।"""
        if _HAS_GPIO:
            # Here you would read from actual sensors, e.g., DHT11/DHT22
            temp, humidity = 24.5, 60.0
            logger.info("Reading physical sensor data...")
        else:
            import random
            temp = round(random.uniform(20.0, 35.0), 1)
            humidity = round(random.uniform(40.0, 80.0), 1)
            logger.info("Generated simulated sensor data.")
            
        return {
            "success": True, 
            "temperature_c": temp, 
            "humidity_percent": humidity,
            "simulated": not _HAS_GPIO
        }

    def play_alert_sound(self) -> dict:
        """Buzzer বা স্পিকার ট্রিগার করে।"""
        if _HAS_GPIO:
            # Example GPIO buzzer code
            # BUZZER_PIN = 18
            # GPIO.setup(BUZZER_PIN, GPIO.OUT)
            # GPIO.output(BUZZER_PIN, GPIO.HIGH)
            # time.sleep(1)
            # GPIO.output(BUZZER_PIN, GPIO.LOW)
            logger.info("Hardware Buzzer ACTIVATED!")
        else:
            # Windows Console Beep as simulation
            if platform.system() == "Windows":
                import winsound
                winsound.Beep(1000, 1000)
            logger.info("Simulated Buzzer ACTIVATED!")
            
        return {"success": True, "buzzer_played": True}

    def monitor_network(self):
        """ইন্টারনেট কানেক্টিভিটি চেক করে এবং হাব-কে রিপোর্ট করে।"""
        while self.running:
            try:
                requests.get("https://8.8.8.8", timeout=2)
                net_status = "ONLINE"
            except:
                net_status = "OFFLINE"
                
            try:
                endpoint = f"{self.hub_url}/api/register"
                data = {
                    "name": self.node_name,
                    "ip": self._get_local_ip(),
                    "port": 5002,
                    "capabilities": ",".join(self.capabilities) + f",net={net_status}"
                }
                requests.post(endpoint, json=data, timeout=3)
                logger.debug("Heartbeat & network status sent to Hub.")
            except Exception as e:
                logger.warning(f"Heartbeat failed. Hub unreachable: {e}")
                
            time.sleep(15)

    def _get_local_ip(self) -> str:
        """লোকাল IP বের করে।"""
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('10.255.255.255', 1))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return '127.0.0.1'

    def start_server(self, port=5002):
        """Pi Agent সার্ভার চালু করে।"""
        self.running = True
        threading.Thread(target=self.monitor_network, daemon=True).start()
        
        logger.info(f"Starting Pi Agent on port {port}...")
        self.app.run(host='0.0.0.0', port=port, debug=False, threaded=True, use_reloader=False)

    def stop(self):
        self.running = False
        if _HAS_GPIO:
            GPIO.cleanup()

if __name__ == "__main__":
    agent = PiAgent(node_name="Pi-Sensor", hub_url="http://192.168.1.100:5001")
    try:
        agent.start_server(port=5002)
    except KeyboardInterrupt:
        agent.stop()
