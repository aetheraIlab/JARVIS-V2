import os
import sys
import time
import logging
import threading
import requests
import sqlite3
from flask import Flask, request, jsonify
from flask_cors import CORS
from pathlib import Path

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from HEAP.database import Atlas

logger = logging.getLogger("NETWORK-HUB")
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

class JARVISHub:
    """
    JARVIS ডিস্ট্রিবিউটেড নেটওয়ার্ক হাব (Master Node)।
    রিমোট নোডগুলো ম্যানেজ করে এবং Flask API এর মাধ্যমে টাস্ক ডিস্ট্রিবিউট করে।
    """

    def __init__(self):
        self.atlas = Atlas()
        self.app = Flask(__name__)
        CORS(self.app)
        
        # Flask routes সেটআপ
        self._setup_routes()
        
        self.running = False
        self._heartbeat_thread = None
        
        # নোড রেজিস্ট্রি টেবিল তৈরি (যদি না থাকে)
        self._init_registry()
        logger.info("JARVIS Hub initialized.")

    def _init_registry(self):
        """SQLite ডাটাবেসে (Atlas) নোড রেজিস্ট্রি টেবিল নিশ্চিত করে।"""
        try:
            with sqlite3.connect(self.atlas.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS network_nodes (
                        name TEXT PRIMARY KEY,
                        ip TEXT NOT NULL,
                        port INTEGER NOT NULL,
                        capabilities TEXT,
                        status TEXT DEFAULT 'ONLINE',
                        last_seen REAL
                    )
                ''')
                conn.commit()
        except Exception as e:
            logger.error(f"Failed to init node registry: {e}")

    def _setup_routes(self):
        """Flask API এন্ডপয়েন্টগুলো কনফিগার করে।"""
        @self.app.route('/api/register', methods=['POST'])
        def api_register_node():
            data = request.json
            if not data or 'name' not in data or 'ip' not in data or 'port' not in data:
                return jsonify({"error": "Missing required fields"}), 400
            
            self.register_node(data['name'], data['ip'], data['port'], data.get('capabilities', ''))
            return jsonify({"status": "success", "message": f"Node {data['name']} registered."})

        @self.app.route('/api/nodes', methods=['GET'])
        def api_get_nodes():
            nodes = self._get_all_nodes()
            return jsonify({"nodes": nodes})

        @self.app.route('/api/task', methods=['POST'])
        def api_send_task():
            data = request.json
            if not data or 'node_name' not in data or 'task_type' not in data:
                return jsonify({"error": "Missing node_name or task_type"}), 400
                
            res = self.send_task(data['node_name'], data['task_type'], data.get('payload', {}))
            return jsonify(res)

    def register_node(self, name: str, ip: str, port: int, capabilities: str):
        """নতুন নোড রেজিস্ট্রি ডাটাবেসে যুক্ত করে।"""
        try:
            current_time = time.time()
            with sqlite3.connect(self.atlas.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO network_nodes (name, ip, port, capabilities, status, last_seen)
                    VALUES (?, ?, ?, ?, 'ONLINE', ?)
                ''', (name, ip, port, str(capabilities), current_time))
                conn.commit()
            logger.info(f"Node Registered: {name} at {ip}:{port}")
        except Exception as e:
            logger.error(f"Failed to register node {name}: {e}")

    def _get_node_info(self, name: str):
        try:
            with sqlite3.connect(self.atlas.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT name, ip, port, status, last_seen FROM network_nodes WHERE name = ?', (name,))
                return cursor.fetchone()
        except Exception:
            return None

    def _get_all_nodes(self):
        try:
            with sqlite3.connect(self.atlas.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT name, ip, port, capabilities, status, last_seen FROM network_nodes')
                rows = cursor.fetchall()
                return [{"name": r[0], "ip": r[1], "port": r[2], "capabilities": r[3], "status": r[4], "last_seen": r[5]} for r in rows]
        except Exception:
            return []

    def get_node_status(self, node_name: str) -> dict:
        """রিমোট নোডের স্ট্যাটাস চেক করে (Ping)।"""
        node = self._get_node_info(node_name)
        if not node:
            return {"status": "error", "message": "Node not found"}
            
        ip, port = node[1], node[2]
        try:
            url = f"http://{ip}:{port}/ping"
            response = requests.get(url, timeout=2)
            if response.status_code == 200:
                self._update_node_status(node_name, "ONLINE", time.time())
                return {"status": "ONLINE", "ping_ms": response.elapsed.total_seconds() * 1000}
        except requests.exceptions.RequestException:
            pass
            
        self._update_node_status(node_name, "OFFLINE", node[4])
        return {"status": "OFFLINE"}

    def _update_node_status(self, name: str, status: str, last_seen: float):
        try:
            with sqlite3.connect(self.atlas.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('UPDATE network_nodes SET status = ?, last_seen = ? WHERE name = ?', (status, last_seen, name))
                conn.commit()
        except Exception as e:
            logger.error(f"Failed to update status for {name}: {e}")

    def send_task(self, node_name: str, task_type: str, payload: dict) -> dict:
        """রিমোট নোডে টাস্ক পাঠায়।"""
        node = self._get_node_info(node_name)
        if not node:
            return {"error": f"Node {node_name} not found in registry"}
            
        if node[3] != "ONLINE":
            return {"error": f"Node {node_name} is currently offline"}
            
        ip, port = node[1], node[2]
        url = f"http://{ip}:{port}/task"
        try:
            logger.info(f"Sending task '{task_type}' to node {node_name}")
            response = requests.post(url, json={"task_type": task_type, "payload": payload}, timeout=5)
            response.raise_for_status()
            return {"success": True, "response": response.json()}
        except Exception as e:
            logger.error(f"Task dispatch failed for {node_name}: {e}")
            self._update_node_status(node_name, "OFFLINE", node[4])
            return {"error": str(e)}

    def broadcast(self, message: dict):
        """সব অ্যাক্টিভ নোডে মেসেজ ব্রডকাস্ট করে।"""
        nodes = self._get_all_nodes()
        results = {}
        for node in nodes:
            if node['status'] == 'ONLINE':
                res = self.send_task(node['name'], "broadcast", message)
                results[node['name']] = res
        return results

    def _heartbeat_loop(self):
        """প্রতি ৩০ সেকেন্ডে ডেড নোড চেক করে।"""
        while self.running:
            nodes = self._get_all_nodes()
            current_time = time.time()
            for node in nodes:
                if node['status'] == 'ONLINE' and current_time - node['last_seen'] > 45:
                    # Double check via ping before marking offline
                    self.get_node_status(node['name'])
            time.sleep(30)

    def start_server(self, port=5001):
        """হাব সার্ভার এবং ব্যাকগ্রাউন্ড মনিটরিং চালু করে।"""
        self.running = True
        self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self._heartbeat_thread.start()
        
        logger.info(f"Starting JARVIS Hub on port {port}...")
        # debug=False in production, use threaded=True for handling multiple connections
        self.app.run(host='0.0.0.0', port=port, debug=False, threaded=True, use_reloader=False)

    def stop(self):
        self.running = False

if __name__ == "__main__":
    hub = JARVISHub()
    try:
        hub.start_server()
    except KeyboardInterrupt:
        hub.stop()
