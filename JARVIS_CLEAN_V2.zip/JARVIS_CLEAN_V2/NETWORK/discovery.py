import socket
import threading
import concurrent.futures
import requests
import logging
import sys
from pathlib import Path

logger = logging.getLogger("NODE-DISCOVERY")
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

class NodeDiscovery:
    """
    JARVIS এজেন্ট নোড খোঁজার জন্য প্যারালাল নেটওয়ার্ক স্ক্যানার।
    উইন্ডোজ কমপ্যাটিবল এবং Nmap ছাড়াই লোকাল নেটওয়ার্ক স্ক্যান করে।
    """

    def __init__(self, target_port=5002):
        self.target_port = target_port

    def _get_local_ip(self) -> str:
        """ডিভাইসের লোকাল IP এড্রেস বের করে।"""
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # doesn't even have to be reachable
            s.connect(('10.255.255.255', 1))
            ip = s.getsockname()[0]
        except Exception:
            ip = '192.168.1.1'
        finally:
            s.close()
        return ip

    def _get_subnet_base(self, ip: str) -> str:
        """IP এড্রেস থেকে সাবনেট বেস বের করে (e.g., 192.168.1.)."""
        parts = ip.split('.')
        return f"{parts[0]}.{parts[1]}.{parts[2]}."

    def _check_port(self, ip: str) -> bool:
        """একটি নির্দিষ্ট IP তে টার্গেট পোর্ট খোলা আছে কিনা চেক করে।"""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.3)  # Fast timeout for parallel scanning
        try:
            result = sock.connect_ex((ip, self.target_port))
            if result == 0:
                return True
        except Exception:
            pass
        finally:
            sock.close()
        return False

    def _query_node_info(self, ip: str) -> dict:
        """পোর্টে রেসপন্স পেলে নোডের ইনফরমেশন ফেচ করে।"""
        url = f"http://{ip}:{self.target_port}/info"
        try:
            response = requests.get(url, timeout=1.5)
            if response.status_code == 200:
                data = response.json()
                return {
                    "ip": ip,
                    "name": data.get("name", f"Node-{ip}"),
                    "capabilities": data.get("capabilities", []),
                    "status": "ONLINE"
                }
        except requests.exceptions.RequestException:
            pass
        
        # Fallback if API doesn't exist but port is open
        return {
            "ip": ip,
            "name": f"Unknown-Node-{ip}",
            "capabilities": ["unknown"],
            "status": "UNRESPONSIVE_API"
        }

    def _scan_ip(self, ip: str) -> dict:
        """একটি IP স্ক্যান করে এবং নোড পেলে তথ্য রিটার্ন করে।"""
        if self._check_port(ip):
            return self._query_node_info(ip)
        return None

    def scan_network(self) -> list:
        """
        লোকাল সাবনেটের ২৫৪টি IP প্যারালালি স্ক্যান করে।
        দ্রুত রেজাল্টের জন্য ThreadPoolExecutor ব্যবহার করা হয়েছে।
        """
        local_ip = self._get_local_ip()
        subnet_base = self._get_subnet_base(local_ip)
        
        logger.info(f"Starting network scan on subnet: {subnet_base}0/24 for port {self.target_port}")
        
        # Generate all IPs in the /24 subnet
        ips_to_scan = [f"{subnet_base}{i}" for i in range(1, 255)]
        
        found_nodes = []
        
        # Using ThreadPoolExecutor for fast parallel scanning
        with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
            # Map IPs to the scanning function
            future_to_ip = {executor.submit(self._scan_ip, ip): ip for ip in ips_to_scan}
            
            for future in concurrent.futures.as_completed(future_to_ip):
                result = future.result()
                if result:
                    found_nodes.append(result)
                    logger.info(f"Found node: {result['name']} at {result['ip']}")
                    
        logger.info(f"Scan complete. Discovered {len(found_nodes)} nodes.")
        return found_nodes

if __name__ == "__main__":
    print("="*50)
    print(" LOCAL NETWORK DISCOVERY TEST ")
    print("="*50)
    scanner = NodeDiscovery()
    nodes = scanner.scan_network()
    print(f"\nDiscovery Results:")
    for n in nodes:
        print(n)
