import os
import sys
import time
import logging
import threading
import requests
from flask import Flask, request, jsonify
from pathlib import Path

logger = logging.getLogger("SENTINEL-NODE")
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

class SentinelAgent:
    """
    JARVIS Sentinel Node (Worker).
    Secondary Windows PC এ রান করবে এবং Hub থেকে টাস্ক গ্রহণ করবে।
    Capabilities: code execution, heavy computation, browser automation.
    """

    def __init__(self, node_name="Sentinel-Alpha", hub_url="http://192.168.1.100:5001"):
        self.node_name = node_name
        self.hub_url = hub_url
        self.capabilities = ["code_execution", "computation", "browser_automation"]
        self.app = Flask(__name__)
        self.running = False
        
        self._setup_routes()
        logger.info(f"Sentinel Agent '{self.node_name}' initialized.")

    def _setup_routes(self):
        @self.app.route('/info', methods=['GET'])
        def api_info():
            return jsonify({
                "name": self.node_name,
                "capabilities": self.capabilities,
                "status": "ONLINE"
            })

        @self.app.route('/ping', methods=['GET'])
        def api_ping():
            return jsonify({"status": "OK"})

        @self.app.route('/task', methods=['POST'])
        def api_task():
            data = request.json
            if not data or 'task_type' not in data:
                return jsonify({"error": "Missing task_type"}), 400
                
            task_type = data['task_type']
            payload = data.get('payload', {})
            
            # Start task in background thread to avoid blocking the REST API
            threading.Thread(target=self._process_and_report, args=(task_type, payload), daemon=True).start()
            
            return jsonify({"status": "Task accepted, processing in background."})

    def _process_and_report(self, task_type: str, payload: dict):
        """টাস্ক এক্সিকিউট করে এবং হাব-এ রেজাল্ট পাঠায়।"""
        logger.info(f"Processing task: {task_type}")
        try:
            result = self.execute_task(task_type, payload)
            self._send_result_to_hub(task_type, result, success=True)
        except Exception as e:
            logger.error(f"Task execution failed: {e}")
            self._send_result_to_hub(task_type, {"error": str(e)}, success=False)

    def execute_task(self, task_type: str, payload: dict) -> dict:
        """টাস্ক টাইপ অনুযায়ী সঠিক হ্যান্ডলার কল করে।"""
        if task_type == "code_execution":
            code = payload.get("code", "")
            logger.info("Executing remote code...")
            # For security, you should normally sandbox this. Here we just simulate or execute safely.
            return {"output": "Code executed (Simulation mode)"}
            
        elif task_type == "computation":
            data = payload.get("data", [])
            logger.info("Performing heavy computation...")
            return {"result": f"Computed {len(data)} items"}
            
        elif task_type == "browser_automation":
            url = payload.get("url", "")
            logger.info(f"Running browser automation for: {url}")
            return {"status": "Browser task completed"}
            
        else:
            raise ValueError(f"Unknown task_type: {task_type}")

    def _send_result_to_hub(self, task_type: str, result: dict, success: bool):
        """টাস্কের রেজাল্ট মেইন JARVIS Hub-এ পাঠায়।"""
        try:
            endpoint = f"{self.hub_url}/api/result"
            data = {
                "node_name": self.node_name,
                "task_type": task_type,
                "success": success,
                "result": result
            }
            # Hub needs a /api/result endpoint for this to work
            response = requests.post(endpoint, json=data, timeout=5)
            logger.info(f"Result reported to Hub. Status Code: {response.status_code}")
        except Exception as e:
            logger.error(f"Failed to report result to Hub: {e}")

    def _heartbeat_loop(self):
        """প্রতি ১৫ সেকেন্ডে হাব-কে স্ট্যাটাস রিপোর্ট করে।"""
        while self.running:
            try:
                endpoint = f"{self.hub_url}/api/register"
                data = {
                    "name": self.node_name,
                    "ip": self._get_local_ip(),
                    "port": 5002,
                    "capabilities": ",".join(self.capabilities)
                }
                requests.post(endpoint, json=data, timeout=3)
                logger.debug("Heartbeat sent to Hub.")
            except Exception as e:
                logger.warning(f"Heartbeat failed. Hub unreachable: {e}")
            time.sleep(15)

    def _get_local_ip(self) -> str:
        """লোকাল IP বের করে।"""
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('10.255.255.255', 1))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return '127.0.0.1'

    def start_server(self, port=5002):
        """Sentinel সার্ভার চালু করে।"""
        self.running = True
        threading.Thread(target=self._heartbeat_loop, daemon=True).start()
        
        logger.info(f"Starting Sentinel Agent on port {port}...")
        self.app.run(host='0.0.0.0', port=port, debug=False, threaded=True, use_reloader=False)

    def stop(self):
        self.running = False

if __name__ == "__main__":
    # Modify hub_url to match your JARVIS Master Node IP
    agent = SentinelAgent(node_name="Sentinel-Alpha", hub_url="http://192.168.1.100:5001")
    try:
        agent.start_server(port=5002)
    except KeyboardInterrupt:
        agent.stop()
