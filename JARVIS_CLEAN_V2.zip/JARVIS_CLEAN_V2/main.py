# ================================================================
# JARVIS AETHER-CORE V2.0 — MAIN ENTRY POINT
# ================================================================
# Codename : AETHER-BOOT
# Role     : System initialisation and lifecycle management
# Platform : Windows 11 / CPU-only
# ================================================================

import sys
import os
import time
import logging
import asyncio
import threading
from pathlib import Path
from typing import NoReturn
from datetime import datetime

# ── Fix Windows Terminal Encoding ───────────────────────────────
# Prevents UnicodeEncodeError for box-drawing chars (╔═╗) on cp1252
if sys.stdout and hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
elif os.name == 'nt':
    os.environ.setdefault('PYTHONIOENCODING', 'utf-8')

# ── 1. Load environment ─────────────────────────────────────────
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    print("[BOOT] python-dotenv not installed. Skipping .env load.")

# ── Configure Logging ───────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("AETHER-BOOT")

# ── Project Root Setup ──────────────────────────────────────────
_PROJECT_ROOT = Path(__file__).resolve().parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

# ── 2. Core Imports ─────────────────────────────────────────────
try:
    from HEAP.database import Atlas
    from HEAP.cache import CacheNode
    from KERNEL.scheduler import SignalBus
    from KERNEL.president_agent import PresidentAgent
    from KERNEL.voice_pipeline import VoicePipeline
    from RENDERER.eel_server import NeuralInterface
except ImportError as e:
    logger.critical(f"Failed to import core modules: {e}")
    sys.exit(1)

# ── Phase 2 Stabilization Imports ───────────────────────────────
try:
    from CONFIG.secure_config import config
    from AGENT.heartbeat import heartbeat_monitor
    from AGENT.registry import agent_registry
    from MONITOR.health_dashboard import print_health_dashboard, print_compact_status, get_dashboard_data
    _SWARM_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Swarm modules not fully available: {e}")
    _SWARM_AVAILABLE = False

# ── ANSI Colour Codes ───────────────────────────────────────────
_GREEN = "\033[92m"
_YELLOW = "\033[93m"
_RED = "\033[91m"
_CYAN = "\033[96m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_RESET = "\033[0m"


def start_president_loop(president: PresidentAgent) -> None:
    """Run the async PresidentAgent loop in a dedicated thread."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(president.start())
    except Exception as e:
        logger.error(f"PresidentAgent loop terminated with error: {e}")
    finally:
        loop.close()


def print_startup_health_report(
    atlas, cache, bus, president_thread, pipeline, interface
):
    """
    Print the comprehensive JARVIS startup health report.
    Shows core system status, swarm agent status, and capabilities.
    """
    # Enable ANSI on Windows
    try:
        import os
        os.system("")
    except Exception:
        pass

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    w = 62

    print()
    print(f"╔{'═' * w}╗")
    print(f"║{_BOLD}{_CYAN}{'JARVIS AETHER-CORE V2.0':^{w}}{_RESET}║")
    print(f"║{_DIM}{'System Boot Complete':^{w}}{_RESET}║")
    print(f"╠{'═' * w}╣")

    # ── Core Systems ──────────────────────────────────────────
    print(f"║{_BOLD}  {'CORE SYSTEMS':^{w - 2}}{_RESET}║")
    print(f"╠{'─' * w}╣")

    core_items = [
        ("OS Platform", "Windows 11 (CPU-Only)"),
        ("Boot Time", now),
        ("Database (Atlas)", f"{_GREEN}ONLINE{_RESET}" if atlas else f"{_RED}OFFLINE{_RESET}"),
        ("Cache (CacheNode)", f"{_GREEN}ONLINE{_RESET}" if cache else f"{_RED}OFFLINE{_RESET}"),
        ("Signal Bus", f"{_GREEN}ONLINE{_RESET}" if bus else f"{_RED}OFFLINE{_RESET}"),
        ("President Agent", f"{_GREEN}ONLINE{_RESET} (Thread: Main)"),
        ("Voice Pipeline", f"{_GREEN}LISTENING{_RESET}" if getattr(pipeline, 'listening', False) else f"{_YELLOW}STANDBY{_RESET}"),
        ("Web UI", f"{_GREEN}ONLINE{_RESET} (Port: {interface.port})"),
    ]

    for label, value in core_items:
        # Pad manually since ANSI codes are zero-width
        raw_label_len = len(label)
        line = f"  {label:<22} : {value}"
        print(f"║{line}{'':>{w - 27 - len(label)}}║")

    # ── Security ──────────────────────────────────────────────
    print(f"╠{'─' * w}╣")
    print(f"║{_BOLD}  {'SECURITY STATUS':^{w - 2}}{_RESET}║")
    print(f"╠{'─' * w}╣")

    if _SWARM_AVAILABLE:
        groq_status = f"{_GREEN}[OK] Active{_RESET}" if config.has_groq else f"{_RED}[FAIL] Missing{_RESET}"
        gemini_status = f"{_GREEN}[OK] Active{_RESET}" if config.has_gemini else f"{_RED}[FAIL] Missing{_RESET}"
        print(f"║  {'Config Source':<22} : .env (SecureConfig){'':<17}║")
        print(f"║  {'Groq API Key':<22} : {groq_status}{'':>20}║")
        print(f"║  {'Gemini API Key':<22} : {gemini_status}{'':>18}║")
    else:
        print(f"║  {'Config':<22} : Legacy Mode (no SecureConfig){'':>5}║")

    # ── Swarm Agent Fleet ─────────────────────────────────────
    print(f"╠{'─' * w}╣")
    print(f"║{_BOLD}  {'AGENT FLEET':^{w - 2}}{_RESET}║")
    print(f"╠{'─' * w}╣")

    if _SWARM_AVAILABLE:
        agents = agent_registry.list_agents()
        active = agent_registry.list_active()
        caps = agent_registry.get_capabilities()

        total_capabilities = sum(len(v) for v in caps.values())

        print(f"║  {'Registered Agents':<22} : {_BOLD}{len(agents)}{_RESET}{'':>{w - 28 - len(str(len(agents)))}}║")
        print(f"║  {'Active Instances':<22} : {len(active)}{'':>{w - 28 - len(str(len(active)))}}║")
        print(f"║  {'Total Capabilities':<22} : {total_capabilities}{'':>{w - 28 - len(str(total_capabilities))}}║")
        print(f"╠{'─' * w}╣")

        for agent_id in sorted(agents):
            agent_caps = caps.get(agent_id, [])
            cap_str = ", ".join(agent_caps[:3])
            if len(agent_caps) > 3:
                cap_str += f" +{len(agent_caps) - 3}"
            is_active = agent_id in active
            status_icon = f"{_GREEN}●{_RESET}" if is_active else f"{_DIM}○{_RESET}"

            line = f"  {status_icon} {agent_id:<20} {cap_str}"
            print(f"║{line}{'':>{max(1, w - 25 - len(cap_str))}}║")
    else:
        print(f"║  {'Swarm':<22} : Not Available{'':>22}║")

    # ── Footer ────────────────────────────────────────────────
    print(f"╠{'═' * w}╣")
    print(f"║{_DIM}  Press Ctrl+C to initiate shutdown sequence{'':>{w - 45}}║{_RESET}")
    print(f"╚{'═' * w}╝")
    print()


def main() -> NoReturn:
    logger.info("Initiating JARVIS Aether-Core Boot Sequence...")

    # ── 1. Init Core Memory & Bus ────────────────────────────────
    logger.info("Initialising Core Components...")
    atlas = Atlas()
    cache = CacheNode()
    bus = SignalBus()

    # ── 2. Init PresidentAgent ───────────────────────────────────
    president = PresidentAgent(bus, atlas, cache)

    # ── 3. Start Voice Pipeline ──────────────────────────────────
    pipeline = VoicePipeline(
        bus=bus,
        atlas=atlas,
        cache=cache,
        president=president,
        auto_play=True
    )
    # The pipeline internally manages its own listener threads
    pipeline.start_listening()

    # ── 4. Start Neural Interface (Flask Server) ─────────────────
    # Suppress werkzeug request logging spam
    logging.getLogger('werkzeug').setLevel(logging.ERROR)

    interface = NeuralInterface(host="0.0.0.0", port=5000, debug=False)
    interface.president = president
    interface.pipeline = pipeline  # Pass pipeline for live state telemetry
    
    interface_thread = threading.Thread(target=interface.start, daemon=True, name="NeuralInterface-Thread")
    interface_thread.start()

    # Give servers a moment to bind ports
    time.sleep(2)

    # Note: Flask NeuralInterface on port 5000 serves both the HUD
    # (index.html) and all /api/* endpoints. No separate Eel server needed.

    # ── Print Startup Health Report (delayed) ─────────────────
    # Banner prints AFTER agents have registered inside president.start()
    def _delayed_banner():
        time.sleep(8)  # Wait for PresidentAgent.start() to register all agents
        print_startup_health_report(
            atlas, cache, bus, None, pipeline, interface
        )
        if _SWARM_AVAILABLE:
            try:
                print_compact_status()
            except Exception as e:
                logger.error(f"Swarm health dashboard error: {e}")
        logger.info("System is fully operational. All agents registered.")

    banner_thread = threading.Thread(target=_delayed_banner, daemon=True, name="Banner-Thread")
    banner_thread.start()

    logger.info("Starting main agent loop...")

    # ── 6. Start Main Agent Loop (Blocking) ──────────────────────
    try:
        start_president_loop(president)
    except KeyboardInterrupt:
        print("\n")
        logger.info("Shutdown signal received (Ctrl+C).")

    # ── Graceful Shutdown ────────────────────────────────────────
    logger.info("Initiating graceful shutdown...")

    # Stop Voice Pipeline
    try:
        pipeline.stop_listening()
    except Exception as e:
        logger.error(f"Error stopping VoicePipeline: {e}")

    # Stop Neural Interface
    try:
        interface.stop()
    except Exception as e:
        logger.error(f"Error stopping NeuralInterface: {e}")

    # Signal PresidentAgent to shutdown
    if hasattr(president, "running"):
        president.running = False

    # Stop Heartbeat Monitor
    if _SWARM_AVAILABLE:
        try:
            heartbeat_monitor.stop()
        except Exception as e:
            logger.error(f"Error stopping HeartbeatMonitor: {e}")

    logger.info("JARVIS powered down successfully.")
    sys.exit(0)


if __name__ == "__main__":
    main()
