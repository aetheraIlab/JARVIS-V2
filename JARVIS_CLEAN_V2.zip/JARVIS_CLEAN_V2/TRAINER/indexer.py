# ================================================================
# JARVIS AETHER-CORE V2.0 — LEXICON (LAYER 9 / PHANTOM)
# ================================================================
# Codename : LEXICON
# Role     : Knowledge Base Agent — stores & indexes knowledge
# Tech     : SQLite + text search
# ================================================================

import sys, os
from datetime import datetime
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class Lexicon:
    """
    JARVIS LEXICON — জ্ঞানভাণ্ডার এজেন্ট।
    নতুন তথ্য সংগ্রহ, সংরক্ষণ, এবং দ্রুত খোঁজা।
    """

    def __init__(self, atlas=None):
        self.atlas = atlas
        self._ensure_table()
        print("[LEXICON] Knowledge base agent initialized.")

    def _ensure_table(self):
        if not self.atlas:
            return
        try:
            self.atlas.conn.execute("""
                CREATE TABLE IF NOT EXISTS knowledge (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    topic TEXT NOT NULL,
                    content TEXT NOT NULL,
                    source TEXT DEFAULT 'learned',
                    tags TEXT DEFAULT '',
                    created_at TEXT NOT NULL
                )
            """)
            self.atlas.conn.commit()
        except Exception:
            pass

    def learn(self, topic, content, source="conversation", tags=""):
        """নতুন তথ্য শেখে।"""
        if not self.atlas:
            return "No ATLAS connection."
        now = datetime.now().isoformat()
        self.atlas.conn.execute(
            "INSERT INTO knowledge (topic, content, source, tags, created_at) VALUES (?, ?, ?, ?, ?)",
            (topic, content, source, tags, now)
        )
        self.atlas.conn.commit()
        return f"Learned: {topic}"

    def search(self, query, limit=5):
        """তথ্য খোঁজে (topic এবং content-এ)।"""
        if not self.atlas:
            return []
        rows = self.atlas.conn.execute(
            "SELECT * FROM knowledge WHERE topic LIKE ? OR content LIKE ? OR tags LIKE ? ORDER BY id DESC LIMIT ?",
            (f"%{query}%", f"%{query}%", f"%{query}%", limit)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_all_topics(self):
        """সব টপিকের তালিকা।"""
        if not self.atlas:
            return []
        rows = self.atlas.conn.execute(
            "SELECT DISTINCT topic FROM knowledge ORDER BY topic"
        ).fetchall()
        return [r["topic"] for r in rows]

    def get_knowledge_count(self):
        """মোট জ্ঞানের পরিমাণ।"""
        if not self.atlas:
            return 0
        row = self.atlas.conn.execute("SELECT COUNT(*) as cnt FROM knowledge").fetchone()
        return row["cnt"] if row else 0

    def forget(self, topic):
        """নির্দিষ্ট টপিকের তথ্য মুছে দেয়।"""
        if not self.atlas:
            return "No ATLAS."
        self.atlas.conn.execute("DELETE FROM knowledge WHERE topic=?", (topic,))
        self.atlas.conn.commit()
        return f"Forgotten: {topic}"


if __name__ == "__main__":
    print("=" * 50)
    print("  LEXICON — Unit Test")
    print("=" * 50)
    from HEAP.database import Atlas
    atlas = Atlas()
    lex = Lexicon(atlas)
    lex.learn("Python", "Python is a high-level programming language.", tags="programming,language")
    lex.learn("Bangladesh", "Capital is Dhaka. Population 170 million.", tags="country,geography")
    print(f"\n[TEST] Knowledge count: {lex.get_knowledge_count()}")
    print(f"[TEST] Topics: {lex.get_all_topics()}")
    print(f"[TEST] Search 'Python': {lex.search('Python')}")
    print("\n[LEXICON] Unit test complete. ✓")
