# ================================================================
# JARVIS AETHER-CORE V2.0 — NEURAL (LAYER 9 / PHANTOM)
# ================================================================
# Codename : NEURAL
# Role     : Learning Agent — Analyzes conversations, improves
# Tech     : Python + SQLite analytics
# ================================================================

import sys, os
from datetime import datetime
from collections import Counter

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class Neural:
    """
    JARVIS NEURAL — শেখার এজেন্ট।
    কথোপকথন বিশ্লেষণ করে প্যাটার্ন শিখে।
    """

    def __init__(self, atlas=None):
        self.atlas = atlas
        self.learned_patterns = {}
        print("[NEURAL] Learning agent initialized.")

    def analyze_conversations(self, limit=100):
        """সাম্প্রতিক কথোপকথন বিশ্লেষণ করে।"""
        if not self.atlas:
            return {"error": "No ATLAS connection."}

        rows = self.atlas.query(
            "SELECT * FROM signals WHERE signal_type='CONVERSATION' ORDER BY id DESC LIMIT ?",
            (limit,)
        )

        if not rows:
            return {"total": 0, "analysis": "No conversations yet."}

        # কে কতবার কথা বলেছে
        speakers = Counter()
        word_freq = Counter()
        for r in rows:
            speakers[r["sender"]] += 1
            words = str(r["data"]).lower().split()
            word_freq.update(words)

        # সবচেয়ে বেশি ব্যবহৃত শব্দ (স্টপ ওয়ার্ড বাদে)
        stop_words = {"the", "a", "is", "i", "in", "to", "and", "it", "of", "for", "you", "my", "me"}
        top_words = [(w, c) for w, c in word_freq.most_common(30) if w not in stop_words and len(w) > 2][:10]

        return {
            "total_messages": len(rows),
            "speakers": dict(speakers),
            "top_words": top_words,
            "timestamp": datetime.now().isoformat(),
        }

    def detect_preferences(self, limit=50):
        """ইউজারের পছন্দ/প্যাটার্ন শনাক্ত করে।"""
        if not self.atlas:
            return {}

        rows = self.atlas.query(
            "SELECT data FROM signals WHERE sender != 'JARVIS' AND signal_type='CONVERSATION' ORDER BY id DESC LIMIT ?",
            (limit,)
        )

        preferences = {}
        for r in rows:
            text = str(r["data"]).lower()
            if "bangla" in text or "bengali" in text or "বাংলা" in text:
                preferences["language_preference"] = "Bengali"
            if "dark" in text or "night" in text:
                preferences["theme_preference"] = "Dark"
            if "code" in text or "python" in text or "programming" in text:
                preferences["interest"] = "Programming"

        return preferences

    def get_insight(self):
        """শেখা তথ্যের সারসংক্ষেপ।"""
        analysis = self.analyze_conversations()
        prefs = self.detect_preferences()
        return {
            "analysis": analysis,
            "detected_preferences": prefs,
        }


if __name__ == "__main__":
    print("=" * 50)
    print("  NEURAL — Unit Test")
    print("=" * 50)

    from HEAP.database import Atlas
    atlas = Atlas()
    n = Neural(atlas)
    insight = n.get_insight()
    print(f"\n[TEST] Analysis: {insight['analysis']}")
    print(f"[TEST] Preferences: {insight['detected_preferences']}")
    print("\n[NEURAL] Unit test complete. ✓")
