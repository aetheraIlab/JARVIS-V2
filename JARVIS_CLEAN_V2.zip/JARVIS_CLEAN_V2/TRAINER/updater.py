# ================================================================
# JARVIS AETHER-CORE V2.0 — PATCH (LAYER 9 / PHANTOM)
# ================================================================
# Codename : PATCH
# Role     : Auto-Update Agent — checks & applies updates
# Tech     : pip + subprocess
# ================================================================

import sys, os, subprocess
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class Patch:
    """
    JARVIS PATCH — আপডেট এজেন্ট।
    pip প্যাকেজ আপডেট চেক করে, মালিকের অনুমতিতে আপডেট করে।
    """

    def __init__(self):
        print("[PATCH] Auto-update agent initialized.")

    def check_outdated(self):
        """পুরোনো pip প্যাকেজের তালিকা দেয়।"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "list", "--outdated", "--format=json"],
                capture_output=True, text=True, timeout=60
            )
            if result.returncode == 0:
                import json
                packages = json.loads(result.stdout)
                return [{"name": p["name"], "current": p["version"],
                         "latest": p["latest_version"]} for p in packages]
            return []
        except Exception as e:
            print(f"[PATCH] Check error: {e}")
            return []

    def update_package(self, package_name):
        """নির্দিষ্ট প্যাকেজ আপডেট করে।"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", package_name],
                capture_output=True, text=True, timeout=120
            )
            if result.returncode == 0:
                return f"Updated: {package_name}"
            return f"Update failed: {result.stderr[:200]}"
        except Exception as e:
            return f"Update error: {e}"

    def get_installed_version(self, package_name):
        """ইনস্টল করা প্যাকেজের ভার্সন।"""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", package_name],
                capture_output=True, text=True, timeout=15
            )
            for line in result.stdout.split('\n'):
                if line.startswith('Version:'):
                    return line.split(':')[1].strip()
            return "unknown"
        except Exception:
            return "unknown"

    def check_ollama_models(self):
        """Ollama মডেল আপডেট আছে কিনা চেক করে।"""
        try:
            result = subprocess.run(
                ["ollama", "list"],
                capture_output=True, text=True, timeout=15
            )
            if result.returncode == 0:
                return result.stdout.strip()
            return "Ollama not available."
        except FileNotFoundError:
            return "Ollama not installed."
        except Exception as e:
            return f"Ollama check error: {e}"


if __name__ == "__main__":
    print("=" * 50)
    print("  PATCH — Unit Test")
    print("=" * 50)
    p = Patch()
    print(f"\n[TEST] psutil version: {p.get_installed_version('psutil')}")
    print(f"[TEST] Ollama models: {p.check_ollama_models()}")
    outdated = p.check_outdated()
    print(f"[TEST] Outdated packages: {len(outdated)}")
    for pkg in outdated[:5]:
        print(f"  {pkg['name']}: {pkg['current']} → {pkg['latest']}")
    print("\n[PATCH] Unit test complete. ✓")
