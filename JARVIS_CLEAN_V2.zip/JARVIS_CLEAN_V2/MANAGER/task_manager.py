# ================================================================
# JARVIS AETHER-CORE V2.0 — TASK MANAGER (RAM MANAGER 2/4)
# ================================================================
# Codename : TASKMASTER
# Role     : Task lifecycle manager — create, prioritize, track,
#            schedule, complete, and report on all system tasks
# Tech     : SQLite (ATLAS) + priority queue
# ================================================================

import sys
import os
import threading
import time
import uuid
from datetime import datetime, timedelta
from enum import Enum

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from HEAP.database import Atlas
from HEAP.cache import CacheNode


# ================================================================
# TASK ENUMS — টাস্কের ধরন ও অবস্থা
# ================================================================
class TaskStatus:
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    DEFERRED = "deferred"


class TaskPriority:
    CRITICAL = 5    # জরুরি — এখনই করতে হবে
    HIGH = 4        # গুরুত্বপূর্ণ
    MEDIUM = 3      # সাধারণ
    LOW = 2         # কম গুরুত্বপূর্ণ
    BACKGROUND = 1  # পটভূমিতে চলবে


class TaskCategory:
    SYSTEM = "system"           # সিস্টেম অপারেশন
    USER_REQUEST = "user_request"  # ইউজারের সরাসরি অনুরোধ
    SCHEDULED = "scheduled"     # নির্ধারিত সময়ে চালানো
    AI_GENERATED = "ai_generated"  # AI নিজে তৈরি করেছে
    MAINTENANCE = "maintenance"  # রক্ষণাবেক্ষণ
    REMINDER = "reminder"       # রিমাইন্ডার


# ================================================================
# TASK MANAGER — মূল টাস্ক ম্যানেজার
# ================================================================
class TaskManager:
    """
    JARVIS TASKMASTER — টাস্ক লাইফসাইকেল ম্যানেজার।

    কাজ:
    1. টাস্ক তৈরি করা (ইউজার বা AI দ্বারা)
    2. অগ্রাধিকার অনুসারে সাজানো
    3. অবস্থা ট্র্যাক করা (pending → in_progress → completed/failed)
    4. ডেডলাইন ও শিডিউল ম্যানেজ করা
    5. টাস্ক রিপোর্ট ও পরিসংখ্যান দেওয়া
    """

    def __init__(self, atlas=None, cache=None):
        self.atlas = atlas or Atlas()
        self.cache = cache or CacheNode()
        self._lock = threading.RLock()

        # অ্যাক্টিভ টাস্ক ক্যাশ (দ্রুত অ্যাক্সেসের জন্য)
        self._active_tasks = {}

        # ইনিশিয়ালাইজেশন
        self._ensure_tables()
        self._load_active_tasks()

        print(f"[TASKMASTER] Task Manager online. Active tasks: {len(self._active_tasks)}")

    # ================================================================
    # DATABASE SCHEMA
    # ================================================================
    def _ensure_tables(self):
        """টাস্ক ম্যানেজারের জন্য প্রয়োজনীয় টেবিল তৈরি করে।"""
        cursor = self.atlas.conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                description TEXT DEFAULT '',
                category TEXT DEFAULT 'user_request',
                priority INTEGER DEFAULT 3,
                status TEXT DEFAULT 'pending',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                deadline TEXT,
                completed_at TEXT,
                assigned_agent TEXT DEFAULT 'APEX',
                result TEXT DEFAULT '',
                retry_count INTEGER DEFAULT 0,
                max_retries INTEGER DEFAULT 3,
                parent_task_id TEXT,
                tags TEXT DEFAULT ''
            )
        """)

        # টাস্ক লগ টেবিল — প্রতিটি স্ট্যাটাস পরিবর্তন ট্র্যাক করে
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                old_status TEXT,
                new_status TEXT NOT NULL,
                detail TEXT DEFAULT '',
                FOREIGN KEY (task_id) REFERENCES tasks(id)
            )
        """)

        self.atlas.conn.commit()

    def _load_active_tasks(self):
        """স্টার্টআপে অসম্পূর্ণ টাস্কগুলো মেমোরিতে লোড করে।"""
        try:
            rows = self.atlas.query(
                """SELECT * FROM tasks 
                   WHERE status IN ('pending', 'in_progress', 'deferred')
                   ORDER BY priority DESC, created_at ASC"""
            )
            for row in rows:
                task = dict(row)
                self._active_tasks[task["id"]] = task
        except Exception:
            pass

    # ================================================================
    # TASK CREATION
    # ================================================================
    def create_task(self, title, description="", category=TaskCategory.USER_REQUEST,
                    priority=TaskPriority.MEDIUM, deadline=None,
                    assigned_agent="APEX", tags=None, parent_task_id=None):
        """
        নতুন টাস্ক তৈরি করে।

        Args:
            title: টাস্কের শিরোনাম
            description: বিস্তারিত বিবরণ
            category: টাস্কের ক্যাটাগরি
            priority: অগ্রাধিকার (1-5)
            deadline: কখন শেষ করতে হবে (ISO format বা None)
            assigned_agent: কোন এজেন্ট করবে
            tags: ট্যাগ তালিকা
            parent_task_id: প্যারেন্ট টাস্ক (সাব-টাস্কের জন্য)

        Returns:
            str: টাস্ক ID
        """
        task_id = f"TASK-{uuid.uuid4().hex[:8].upper()}"
        now = datetime.now().isoformat()
        tags_str = ",".join(tags) if tags else ""

        task = {
            "id": task_id,
            "title": title,
            "description": description,
            "category": category,
            "priority": priority,
            "status": TaskStatus.PENDING,
            "created_at": now,
            "updated_at": now,
            "deadline": deadline,
            "completed_at": None,
            "assigned_agent": assigned_agent,
            "result": "",
            "retry_count": 0,
            "max_retries": 3,
            "parent_task_id": parent_task_id,
            "tags": tags_str,
        }

        with self._lock:
            self.atlas.conn.execute(
                """INSERT INTO tasks 
                   (id, title, description, category, priority, status,
                    created_at, updated_at, deadline, assigned_agent,
                    parent_task_id, tags)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (task_id, title, description, category, priority,
                 TaskStatus.PENDING, now, now, deadline, assigned_agent,
                 parent_task_id, tags_str)
            )
            self._log_status_change(task_id, None, TaskStatus.PENDING, "Task created")
            self.atlas.conn.commit()

            # ক্যাশে যোগ
            self._active_tasks[task_id] = task

        print(f"[TASKMASTER] Created: {task_id} — \"{title}\" [P{priority}]")
        return task_id

    # ================================================================
    # STATUS MANAGEMENT
    # ================================================================
    def start_task(self, task_id):
        """টাস্ক শুরু করে (pending → in_progress)।"""
        return self._update_status(task_id, TaskStatus.IN_PROGRESS, "Task started")

    def complete_task(self, task_id, result=""):
        """টাস্ক সফলভাবে সম্পন্ন করে।"""
        with self._lock:
            now = datetime.now().isoformat()
            self.atlas.conn.execute(
                "UPDATE tasks SET status=?, completed_at=?, result=?, updated_at=? WHERE id=?",
                (TaskStatus.COMPLETED, now, result, now, task_id)
            )
            self._log_status_change(task_id, TaskStatus.IN_PROGRESS, TaskStatus.COMPLETED, result)
            self.atlas.conn.commit()

            # ক্যাশ থেকে সরানো
            self._active_tasks.pop(task_id, None)

        print(f"[TASKMASTER] Completed: {task_id}")
        return True

    def fail_task(self, task_id, reason=""):
        """টাস্ক ব্যর্থ হিসেবে চিহ্নিত করে। রিট্রাই সম্ভব হলে করে।"""
        with self._lock:
            task = self._get_task(task_id)
            if not task:
                return False

            retry_count = task.get("retry_count", 0) + 1
            max_retries = task.get("max_retries", 3)

            if retry_count < max_retries:
                # রিট্রাই — pending-এ ফেরত পাঠানো
                now = datetime.now().isoformat()
                self.atlas.conn.execute(
                    "UPDATE tasks SET status=?, retry_count=?, updated_at=? WHERE id=?",
                    (TaskStatus.PENDING, retry_count, now, task_id)
                )
                self._log_status_change(
                    task_id, TaskStatus.IN_PROGRESS, TaskStatus.PENDING,
                    f"Retry {retry_count}/{max_retries}: {reason}"
                )
                self.atlas.conn.commit()
                if task_id in self._active_tasks:
                    self._active_tasks[task_id]["retry_count"] = retry_count
                    self._active_tasks[task_id]["status"] = TaskStatus.PENDING
                print(f"[TASKMASTER] Retrying: {task_id} ({retry_count}/{max_retries})")
            else:
                # সব রিট্রাই শেষ — ব্যর্থ
                now = datetime.now().isoformat()
                self.atlas.conn.execute(
                    "UPDATE tasks SET status=?, result=?, updated_at=? WHERE id=?",
                    (TaskStatus.FAILED, reason, now, task_id)
                )
                self._log_status_change(task_id, TaskStatus.IN_PROGRESS, TaskStatus.FAILED, reason)
                self.atlas.conn.commit()
                self._active_tasks.pop(task_id, None)
                print(f"[TASKMASTER] Failed: {task_id} — {reason}")

        return True

    def cancel_task(self, task_id, reason="User cancelled"):
        """টাস্ক বাতিল করে।"""
        with self._lock:
            now = datetime.now().isoformat()
            self.atlas.conn.execute(
                "UPDATE tasks SET status=?, result=?, updated_at=? WHERE id=?",
                (TaskStatus.CANCELLED, reason, now, task_id)
            )
            self._log_status_change(task_id, None, TaskStatus.CANCELLED, reason)
            self.atlas.conn.commit()
            self._active_tasks.pop(task_id, None)

        print(f"[TASKMASTER] Cancelled: {task_id}")
        return True

    def defer_task(self, task_id, reason="Deferred by system"):
        """টাস্ক পরে করার জন্য স্থগিত করে।"""
        return self._update_status(task_id, TaskStatus.DEFERRED, reason)

    def _update_status(self, task_id, new_status, detail=""):
        """অভ্যন্তরীণ — স্ট্যাটাস আপডেট করে।"""
        with self._lock:
            task = self._get_task(task_id)
            old_status = task["status"] if task else None
            now = datetime.now().isoformat()

            self.atlas.conn.execute(
                "UPDATE tasks SET status=?, updated_at=? WHERE id=?",
                (new_status, now, task_id)
            )
            self._log_status_change(task_id, old_status, new_status, detail)
            self.atlas.conn.commit()

            if task_id in self._active_tasks:
                self._active_tasks[task_id]["status"] = new_status

        return True

    def _log_status_change(self, task_id, old_status, new_status, detail=""):
        """স্ট্যাটাস পরিবর্তন লগ করে।"""
        now = datetime.now().isoformat()
        self.atlas.conn.execute(
            "INSERT INTO task_log (task_id, timestamp, old_status, new_status, detail) VALUES (?, ?, ?, ?, ?)",
            (task_id, now, old_status, new_status, detail[:500])
        )

    # ================================================================
    # TASK QUERIES
    # ================================================================
    def _get_task(self, task_id):
        """একটি নির্দিষ্ট টাস্ক ফিরিয়ে দেয়।"""
        # প্রথমে ক্যাশ চেক
        if task_id in self._active_tasks:
            return self._active_tasks[task_id]
        # ক্যাশে না থাকলে ডাটাবেস
        rows = self.atlas.query("SELECT * FROM tasks WHERE id = ?", (task_id,))
        return dict(rows[0]) if rows else None

    def get_task(self, task_id):
        """পাবলিক — একটি টাস্কের বিস্তারিত দেখায়।"""
        return self._get_task(task_id)

    def get_pending_tasks(self, limit=20):
        """অমীমাংসিত টাস্কগুলো অগ্রাধিকার অনুসারে দেখায়।"""
        rows = self.atlas.query(
            """SELECT * FROM tasks 
               WHERE status = 'pending' 
               ORDER BY priority DESC, created_at ASC 
               LIMIT ?""",
            (limit,)
        )
        return [dict(r) for r in rows]

    def get_in_progress(self, limit=20):
        """চলমান টাস্কগুলো দেখায়।"""
        rows = self.atlas.query(
            """SELECT * FROM tasks 
               WHERE status = 'in_progress' 
               ORDER BY priority DESC 
               LIMIT ?""",
            (limit,)
        )
        return [dict(r) for r in rows]

    def get_completed_tasks(self, limit=20):
        """সম্পন্ন টাস্কগুলো দেখায়।"""
        rows = self.atlas.query(
            """SELECT * FROM tasks 
               WHERE status = 'completed' 
               ORDER BY completed_at DESC 
               LIMIT ?""",
            (limit,)
        )
        return [dict(r) for r in rows]

    def get_failed_tasks(self, limit=10):
        """ব্যর্থ টাস্কগুলো দেখায়।"""
        rows = self.atlas.query(
            """SELECT * FROM tasks 
               WHERE status = 'failed' 
               ORDER BY updated_at DESC 
               LIMIT ?""",
            (limit,)
        )
        return [dict(r) for r in rows]

    def get_overdue_tasks(self):
        """ডেডলাইন পার হয়ে যাওয়া টাস্কগুলো দেখায়।"""
        now = datetime.now().isoformat()
        rows = self.atlas.query(
            """SELECT * FROM tasks 
               WHERE deadline IS NOT NULL 
               AND deadline < ? 
               AND status IN ('pending', 'in_progress')
               ORDER BY deadline ASC""",
            (now,)
        )
        return [dict(r) for r in rows]

    def get_tasks_by_agent(self, agent_name, limit=20):
        """নির্দিষ্ট এজেন্টের টাস্কগুলো দেখায়।"""
        rows = self.atlas.query(
            """SELECT * FROM tasks 
               WHERE assigned_agent = ? 
               AND status IN ('pending', 'in_progress')
               ORDER BY priority DESC 
               LIMIT ?""",
            (agent_name, limit)
        )
        return [dict(r) for r in rows]

    def get_next_task(self, agent_name=None):
        """
        পরবর্তী কোন টাস্ক করতে হবে তা নির্ধারণ করে।
        সবচেয়ে বেশি অগ্রাধিকারের অমীমাংসিত টাস্ক ফিরিয়ে দেয়।
        """
        if agent_name:
            rows = self.atlas.query(
                """SELECT * FROM tasks 
                   WHERE status = 'pending' AND assigned_agent = ?
                   ORDER BY priority DESC, created_at ASC 
                   LIMIT 1""",
                (agent_name,)
            )
        else:
            rows = self.atlas.query(
                """SELECT * FROM tasks 
                   WHERE status = 'pending'
                   ORDER BY priority DESC, created_at ASC 
                   LIMIT 1"""
            )
        return dict(rows[0]) if rows else None

    def get_subtasks(self, parent_task_id):
        """একটি টাস্কের সাব-টাস্কগুলো দেখায়।"""
        rows = self.atlas.query(
            "SELECT * FROM tasks WHERE parent_task_id = ? ORDER BY priority DESC",
            (parent_task_id,)
        )
        return [dict(r) for r in rows]

    def get_task_history(self, task_id):
        """একটি টাস্কের সম্পূর্ণ লগ ইতিহাস দেখায়।"""
        rows = self.atlas.query(
            "SELECT * FROM task_log WHERE task_id = ? ORDER BY timestamp ASC",
            (task_id,)
        )
        return [dict(r) for r in rows]

    # ================================================================
    # STATISTICS & REPORTING
    # ================================================================
    def get_stats(self):
        """টাস্ক সিস্টেমের পরিসংখ্যান ফিরিয়ে দেয়।"""
        stats = {}
        for status in [TaskStatus.PENDING, TaskStatus.IN_PROGRESS,
                       TaskStatus.COMPLETED, TaskStatus.FAILED,
                       TaskStatus.CANCELLED, TaskStatus.DEFERRED]:
            rows = self.atlas.query(
                "SELECT COUNT(*) as cnt FROM tasks WHERE status = ?",
                (status,)
            )
            stats[status] = rows[0]["cnt"] if rows else 0

        total = self.atlas.query("SELECT COUNT(*) as cnt FROM tasks")
        stats["total"] = total[0]["cnt"] if total else 0
        stats["active_cached"] = len(self._active_tasks)

        return stats

    def get_summary_report(self):
        """
        মানুষের পড়ার উপযোগী সারাংশ রিপোর্ট তৈরি করে।
        President Agent এটি TTS দিয়ে বলতে পারবে।
        """
        stats = self.get_stats()
        overdue = self.get_overdue_tasks()

        lines = [
            f"Sir, here is your task report.",
            f"Total tasks: {stats['total']}.",
            f"Pending: {stats['pending']}, In progress: {stats['in_progress']}.",
            f"Completed: {stats['completed']}, Failed: {stats['failed']}.",
        ]

        if overdue:
            lines.append(f"Warning: {len(overdue)} tasks are overdue.")
            for t in overdue[:3]:
                lines.append(f"  - {t['title']} (deadline: {t['deadline'][:10]})")

        return " ".join(lines)

    # ================================================================
    # BULK OPERATIONS
    # ================================================================
    def cancel_all_pending(self, reason="Bulk cancel"):
        """সব অমীমাংসিত টাস্ক বাতিল করে।"""
        pending = self.get_pending_tasks(limit=100)
        count = 0
        for task in pending:
            self.cancel_task(task["id"], reason)
            count += 1
        print(f"[TASKMASTER] Bulk cancelled: {count} tasks.")
        return count

    def cleanup_old_tasks(self, days=30):
        """পুরোনো সম্পন্ন/বাতিল টাস্ক মুছে দেয়।"""
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()
        with self._lock:
            self.atlas.conn.execute(
                """DELETE FROM tasks 
                   WHERE status IN ('completed', 'cancelled', 'failed')
                   AND updated_at < ?""",
                (cutoff,)
            )
            self.atlas.conn.commit()
        print(f"[TASKMASTER] Cleaned up tasks older than {days} days.")


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  TASKMASTER (Task Manager) — Unit Test")
    print("=" * 60)

    tm = TaskManager()

    # === TEST 1: Create tasks ===
    print("\n[TEST 1] Creating tasks...")
    t1 = tm.create_task(
        title="Check system health",
        description="Run full diagnostic on CPU, RAM, Disk",
        category=TaskCategory.SYSTEM,
        priority=TaskPriority.HIGH,
        assigned_agent="EXECUTOR_MONITOR",
    )
    t2 = tm.create_task(
        title="Search for Python tutorials",
        description="User wants Python beginner tutorials",
        category=TaskCategory.USER_REQUEST,
        priority=TaskPriority.MEDIUM,
        assigned_agent="CRAWLER_NEXUS",
        tags=["search", "python", "learning"],
    )
    t3 = tm.create_task(
        title="Remind user about meeting",
        description="Meeting at 5 PM with team",
        category=TaskCategory.REMINDER,
        priority=TaskPriority.CRITICAL,
        deadline=(datetime.now() + timedelta(hours=2)).isoformat(),
        assigned_agent="DAEMON_REMINDER",
    )
    t4 = tm.create_task(
        title="Clean temp files",
        description="Background cleanup of temporary files",
        category=TaskCategory.MAINTENANCE,
        priority=TaskPriority.BACKGROUND,
        assigned_agent="EXECUTOR_FILESYSTEM",
    )

    # === TEST 2: Task lifecycle ===
    print("\n[TEST 2] Task lifecycle...")
    tm.start_task(t1)
    print(f"  {t1} started.")
    tm.complete_task(t1, result="All systems nominal. CPU: 25%, RAM: 60%")
    print(f"  {t1} completed.")

    tm.start_task(t2)
    print(f"  {t2} started.")
    tm.fail_task(t2, reason="Network timeout — will retry")
    print(f"  {t2} failed (will auto-retry).")

    # === TEST 3: Query tasks ===
    print("\n[TEST 3] Querying tasks...")
    pending = tm.get_pending_tasks()
    print(f"  Pending tasks: {len(pending)}")
    for t in pending:
        print(f"    [{t['id']}] P{t['priority']} — {t['title']}")

    completed = tm.get_completed_tasks()
    print(f"  Completed tasks: {len(completed)}")

    # === TEST 4: Next task ===
    print("\n[TEST 4] Next task to work on...")
    next_task = tm.get_next_task()
    if next_task:
        print(f"  Next: [{next_task['id']}] P{next_task['priority']} — {next_task['title']}")

    # === TEST 5: Task history ===
    print("\n[TEST 5] Task history for {0}...".format(t2))
    history = tm.get_task_history(t2)
    for h in history:
        print(f"  [{h['timestamp'][:19]}] {h['old_status']} → {h['new_status']}: {h['detail'][:60]}")

    # === TEST 6: Subtasks ===
    print("\n[TEST 6] Creating subtasks...")
    sub1 = tm.create_task("Step 1: Scan disk", parent_task_id=t4, priority=TaskPriority.LOW)
    sub2 = tm.create_task("Step 2: Delete temp", parent_task_id=t4, priority=TaskPriority.LOW)
    subtasks = tm.get_subtasks(t4)
    print(f"  Parent: {t4} has {len(subtasks)} subtasks")
    for s in subtasks:
        print(f"    → {s['id']}: {s['title']}")

    # === TEST 7: Summary report ===
    print("\n[TEST 7] Summary report...")
    report = tm.get_summary_report()
    print(f"  {report}")

    # === TEST 8: Stats ===
    print("\n[TEST 8] Task stats...")
    stats = tm.get_stats()
    for k, v in stats.items():
        print(f"  {k}: {v}")

    print("\n" + "=" * 60)
    print("  [TASKMASTER] All unit tests complete. ✓")
    print("=" * 60)
