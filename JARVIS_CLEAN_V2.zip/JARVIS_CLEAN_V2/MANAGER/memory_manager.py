"""
DEPRECATED WRAPPER: Use MANAGER.memory.MemoryManager instead.

This file is kept ONLY for backward compatibility during the Phase 1 transition.
All calls are forwarded to the modular MANAGER.memory system.

PHASE 1 FIX: Added forwarding stubs for every legacy method that external
code might still reference, so nothing breaks during the transition.
"""
import logging
from MANAGER.memory import MemoryManager as ModularMemoryManager

logger = logging.getLogger("MEMORY_MANAGER_LEGACY")

class MemoryManager:
    """
    DEPRECATED WRAPPER: Use MANAGER.memory.MemoryManager instead.
    This file is kept temporarily for backward compatibility.
    
    All methods now either forward to the modular system or are safe no-ops.
    """
    _deprecation_warned = False
    
    def __init__(self, atlas=None, cache=None):
        if not MemoryManager._deprecation_warned:
            logger.warning(
                "Legacy MemoryManager is DEPRECATED! "
                "Migrate to: from MANAGER.memory import MemoryManager"
            )
            MemoryManager._deprecation_warned = True
        self._memory = ModularMemoryManager(atlas=atlas)
        self._short_term = []
        self._user_profile = {}
        self.retrieval_cache = []

    # ── Forwarded to modular system ──────────────────────────

    def add_interaction(self, user_text, response, emotion="neutral", category="conversation"):
        """Forward to working memory add_turn."""
        self._memory.add_turn("user", user_text)
        self._memory.add_turn("assistant", response)

    def retrieve_context(self, text, top_k=2, threshold=0.6):
        """Synchronous retrieval — returns formatted string for backward compat."""
        import asyncio
        try:
            loop = asyncio.get_running_loop()
            # If we're in an async context, we can't block — return empty
            return ""
        except RuntimeError:
            pass
        # No running loop — safe to use asyncio.run
        try:
            results = asyncio.run(self._memory.retrieval.search_all(text, top_k=top_k))
            if results:
                lines = [f"- {r.record.content[:200]}" for r in results]
                return "\n".join(lines)
        except Exception:
            pass
        return ""

    def clear_short_term(self):
        self._memory.working.clear()
        self._short_term.clear()
        self.retrieval_cache.clear()

    def consolidate(self):
        """Handled by background decay_manager automatically."""
        return 0

    def search_memory(self, query, limit=3):
        """Synchronous search is deprecated."""
        return []
        
    def learn_about_user(self, key, value, confidence=1.0, source="auto"):
        """Forward to modular fact memory via sync wrapper."""
        self._user_profile[key] = {"value": value, "confidence": confidence, "source": source}
        import asyncio
        try:
            asyncio.get_running_loop()
            # Can't block in async context
            return
        except RuntimeError:
            pass
        try:
            asyncio.run(self._memory.learn_fact(key, value, confidence, source))
        except Exception:
            pass

    def remember_short(self, role, content):
        """Legacy short-term memory — forwards to working memory."""
        normalized_role = "user" if role.lower() in ("user", "adil") else "assistant"
        self._short_term.append({"role": normalized_role, "content": content})
        self._memory.add_turn(normalized_role, content)

    def remember_long(self, content, memory_type="episodic", importance=5, tags=None, source="auto"):
        """Legacy long-term memory — forwards to episodic add_episode."""
        import asyncio
        try:
            asyncio.get_running_loop()
            return
        except RuntimeError:
            pass
        try:
            asyncio.run(self._memory.episodic.add_episode(
                content=content,
                importance=min(importance / 10.0, 1.0),
                metadata={"tags": str(tags or []), "source": source, "type": memory_type}
            ))
        except Exception:
            pass

    def get_context_for_ai(self, limit=20):
        """Legacy API — returns list of {role, content} dicts."""
        window = self._memory.working.get_sliding_window(limit=limit)
        messages = []
        for turn in window:
            role = "user" if turn.role.lower() in ("user", "adil") else "assistant"
            messages.append({"role": role, "content": turn.content})
        return messages

    def get_stats(self):
        """Return stats for backward compatibility."""
        return {
            "short_term_entries": len(self._memory.working.get_sliding_window()),
            "user_profile_attributes": len(self._user_profile),
            "vector_mode": getattr(self._memory.episodic, 'vector_mode', False),
        }
