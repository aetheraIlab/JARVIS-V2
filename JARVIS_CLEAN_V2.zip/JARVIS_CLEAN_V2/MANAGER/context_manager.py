import logging
from MANAGER.memory import MemoryManager as NewMemoryManager

logger = logging.getLogger("CONTEXT_MANAGER_LEGACY")

class ContextManager:
    """
    DEPRECATED WRAPPER: Use MANAGER.memory.MemoryManager instead.
    This file is kept temporarily for backward compatibility.
    """
    def __init__(self, atlas=None, cache=None):
        logger.warning("ContextManager is DEPRECATED! Please migrate to MANAGER.memory.MemoryManager.")
        self._memory = NewMemoryManager(atlas=atlas)

    def add_turn(self, role: str, content: str, metadata: dict = None):
        self._memory.add_turn(role, content, metadata)

    def clear_window(self):
        self._memory.working.clear()

    def get_current_topic(self):
        return self._memory.working.current_topic

    def end_session(self, summary=None):
        self._memory.end_session()

    def get_ai_messages(self):
        return self._memory.working.get_sliding_window()
        
    def pin_fact(self, fact_text):
        pass # Ignored in legacy wrapper
        
    def set_system_context(self, key, value):
        pass # Ignored in legacy wrapper
