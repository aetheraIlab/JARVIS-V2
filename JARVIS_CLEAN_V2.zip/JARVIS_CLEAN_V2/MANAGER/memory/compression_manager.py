import asyncio
import logging
import json
from typing import List
from MANAGER.memory.schemas import Turn
from MONITOR.tracer import TraceManager

logger = logging.getLogger("COMPRESSION-MANAGER")

class CompressionManager:
    """
    Handles asynchronous context compression and pruning.
    Prevents inference path from blocking by queueing compression tasks.
    Maintains a HOT and COLD memory separation.
    """
    def __init__(self, semantic_memory, arbiter):
        self.semantic = semantic_memory
        self.arbiter = arbiter
        self._queue = asyncio.Queue()
        self._task = None
        self._is_running = False
        
    def start(self):
        if not self._is_running:
            self._is_running = True
            self._task = asyncio.create_task(self._compression_worker())
            logger.info("CompressionManager background worker started.")

    def stop(self):
        self._is_running = False
        if self._task:
            self._task.cancel()

    async def compress_turns(self, turns: List[Turn], trace_id: str):
        """
        Enqueues a list of old turns to be summarized and converted into COLD (semantic) memory.
        """
        await self._queue.put({"type": "summarize_turns", "turns": turns, "trace_id": trace_id})
        logger.debug(f"Queued {len(turns)} turns for async compression.")

    async def _compression_worker(self):
        while self._is_running:
            try:
                task = await self._queue.get()
                t_type = task.get("type")
                trace_id = task.get("trace_id", "unknown")
                
                span = TraceManager.start_span("async_compression", metadata={"task_type": t_type})
                
                if t_type == "summarize_turns":
                    await self._handle_summarize(task["turns"], trace_id)
                    
                span.end("SUCCESS")
                self._queue.task_done()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Compression worker failed: {e}")

    async def _handle_summarize(self, turns: List[Turn], trace_id: str):
        """
        Summarizes a batch of turns using the offline/online arbiter.
        Stores the result in semantic memory.
        """
        if not turns:
            return
            
        convo_text = "\n".join([f"{t.role}: {t.content}" for t in turns])
        prompt = (
            "Summarize the following conversation segment concisely. "
            "Extract key facts, decisions, and outcomes. Omit pleasantries.\n\n"
            f"{convo_text}"
        )
        
        # We use Arbiter to summarize. This happens in the background.
        # We wrap it in run_in_executor to ensure it doesn't block the event loop.
        loop = asyncio.get_running_loop()
        summary, provider = await loop.run_in_executor(
            None, self.arbiter.think, prompt, []
        )
        
        if summary and "apologize" not in summary.lower():
            await self.semantic.add_semantic(
                content=f"Conversation Summary: {summary}",
                importance=0.6,
                trace_id=trace_id
            )
            logger.info(f"Summarized {len(turns)} turns into semantic memory.")
        else:
            logger.warning("Summarization failed or returned empty.")
