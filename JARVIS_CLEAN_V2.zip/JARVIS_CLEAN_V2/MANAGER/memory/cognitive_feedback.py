import asyncio
import logging
import json
import re
from typing import List, Dict, Any
from MONITOR.tracer import TraceManager
from MANAGER.memory.schemas import MemoryRecord

logger = logging.getLogger("COGNITIVE-FEEDBACK")

class CognitiveFeedbackLoop:
    """
    Subscribes to 'interaction_completed' events.
    Evaluates whether the retrieved context was helpful.
    Updates Memory Importance scores and extracts user preferences asynchronously.
    """
    def __init__(self, episodic_memory, semantic_memory, facts_memory, event_bus):
        self.episodic = episodic_memory
        self.semantic = semantic_memory
        self.facts = facts_memory
        self.bus = event_bus
        
        self.bus.subscribe("interaction_completed", self._on_interaction)
        logger.info("CognitiveFeedbackLoop initialized and subscribed to EventBus.")

    async def _on_interaction(self, payload: Dict[str, Any]):
        """
        Triggered after every JARVIS response.
        """
        user_msg = payload.get("user", "")
        jarvis_msg = payload.get("jarvis", "")
        trace_id = payload.get("trace_id", "")
        provider = payload.get("provider", "unknown")
        retrieved_ids = payload.get("retrieved_ids", [])
        
        span = TraceManager.start_span("cognitive_feedback_evaluation", metadata={"trace_id": trace_id})
        try:
            # 1. Determine Success
            # Simple heuristic: if provider is not a fallback/error, and no error indicators.
            is_successful = provider not in ["system", "emergency_static", "all_online_failed"]
            error_keywords = ["apologize", "error", "failed", "cannot process"]
            if any(k in jarvis_msg.lower() for k in error_keywords):
                is_successful = False
                
            # 2. Extract Preferences (Implicit learning)
            await self._extract_and_learn_preferences(user_msg, trace_id)
            
            # 3. Reinforce Memories used in this trace
            if is_successful:
                await self._reinforce_successful_memories(trace_id, retrieved_ids)
            else:
                await self._penalize_failed_memories(trace_id, retrieved_ids)
                
            span.end("SUCCESS", result={"successful_interaction": is_successful})
        except Exception as e:
            logger.error(f"Cognitive feedback loop error: {e}")
            span.end("FAILED", error=str(e))

    async def _extract_and_learn_preferences(self, user_msg: str, trace_id: str):
        """Extracts structural user preferences from natural language."""
        user_lower = user_msg.lower()
        
        # Heuristics for preferences
        if "call me" in user_lower or "my name is" in user_lower:
            match = re.search(r"(?:call me|my name is) (\w+)", user_lower)
            if match:
                name = match.group(1).capitalize()
                await self.facts.learn_fact("user_preferred_name", name, confidence=1.0, source="cognitive_feedback")
                logger.info(f"Learned preference: user_preferred_name = {name}")

        if "i prefer" in user_lower or "i like" in user_lower:
            # Simple extraction for demo. In production, this would use a lightweight LLM call.
            topic_match = re.search(r"(?:i prefer|i like) (.*?)(?:\.|$|because|when)", user_lower)
            if topic_match:
                preference = topic_match.group(1).strip()
                # Store as semantic memory instead of rigid fact
                await self.semantic.add_semantic(
                    content=f"User prefers: {preference}",
                    importance=0.8,
                    trace_id=trace_id
                )

    async def _reinforce_successful_memories(self, trace_id: str, retrieved_ids: List[str]):
        """
        Finds memories retrieved during this trace and slightly boosts their importance.
        """
        for mem_id in retrieved_ids:
            try:
                # We fetch the current metadata from episodic memory
                record = await self.episodic.get_by_id(mem_id)
                if record:
                    # Increase importance by 10% (max 1.0)
                    new_importance = min(1.0, record.importance * 1.1)
                    await self.episodic.update_importance(mem_id, new_importance)
                    logger.debug(f"[CognitiveFeedback] Reinforced memory {mem_id}: {record.importance:.2f} -> {new_importance:.2f}")
            except Exception as e:
                logger.warning(f"Failed to reinforce memory {mem_id}: {e}")

    async def _penalize_failed_memories(self, trace_id: str, retrieved_ids: List[str]):
        """Reduces importance of memories that led to failure/hallucination."""
        for mem_id in retrieved_ids:
            try:
                record = await self.episodic.get_by_id(mem_id)
                if record:
                    # Decrease importance by 20%
                    new_importance = max(0.1, record.importance * 0.8)
                    await self.episodic.update_importance(mem_id, new_importance)
                    logger.debug(f"[CognitiveFeedback] Penalized memory {mem_id}: {record.importance:.2f} -> {new_importance:.2f}")
            except Exception as e:
                logger.warning(f"Failed to penalize memory {mem_id}: {e}")
