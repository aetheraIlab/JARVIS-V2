import asyncio
import logging
from typing import Callable, Dict, List, Any

logger = logging.getLogger("MEMORY_BUS")

class MemoryEventBus:
    """
    Lightweight internal event dispatcher. Prevents circular dependencies by allowing
    components to emit events (e.g., memory_consolidated, fact_learned) that other
    components can listen to.
    """
    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}

    def subscribe(self, event_type: str, callback: Callable) -> None:
        """
        Subscribes a callback to an event type.
        Callback must be an async function.
        """
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(callback)

    def publish(self, event_type: str, payload: Any = None) -> None:
        """
        Publishes an event to all subscribers asynchronously without blocking.
        """
        if event_type not in self._subscribers:
            return

        for callback in self._subscribers[event_type]:
            try:
                # Fire and forget
                asyncio.create_task(self._safe_invoke(callback, event_type, payload))
            except Exception as e:
                logger.error(f"Failed to publish event {event_type} to subscriber {callback}: {e}")

    async def _safe_invoke(self, callback: Callable, event_type: str, payload: Any):
        try:
            await callback(payload)
        except Exception as e:
            logger.error(f"Error in event subscriber for {event_type}: {e}")
