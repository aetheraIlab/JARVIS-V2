import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, Any, List

@dataclass
class MemoryRecord:
    id: str
    content: str
    type: str          # 'episodic', 'semantic', 'fact'
    timestamp: float
    importance: float  # 0.0 to 1.0
    trace_id: str
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Fact:
    key: str
    value: str
    confidence: float
    source: str
    updated_at: float

@dataclass
class ScoredMemory:
    record: MemoryRecord
    score: float       # Computed by RetrievalEngine

@dataclass
class Turn:
    role: str
    content: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
