import asyncio
import time
import logging
import math
from typing import Optional

logger = logging.getLogger("DECAY")

class MemoryDecayManager:
    """
    Background async daemon. Periodically scans Working Memory and Episodic Memory
    to archive, compress, or delete obsolete tokens based on an exponential decay curve.
    """
    def __init__(self, episodic_memory, semantic_memory, half_life_days: float = 7.0):
        self.episodic_memory = episodic_memory
        self.semantic_memory = semantic_memory
        self.half_life_seconds = half_life_days * 24 * 3600
        self._running = False
        self._task: Optional[asyncio.Task] = None

    def start(self):
        """Start the decay loop. Safe to call before or after event loop is running."""
        if self._running:
            return
        self._running = True
        try:
            loop = asyncio.get_running_loop()
            self._task = loop.create_task(self._decay_loop())
            logger.info("MemoryDecayManager started on running loop.")
        except RuntimeError:
            # No event loop running yet — caller must call start() again
            # once inside an async context (PresidentAgent.start() does this)
            self._running = False
            logger.info("MemoryDecayManager deferred — no running event loop.")

    def stop(self):
        self._running = False
        if self._task:
            self._task.cancel()
            logger.info("MemoryDecayManager stopped.")

    async def _decay_loop(self):
        while self._running:
            try:
                # Sleep for 1 hour between decay cycles
                await asyncio.sleep(3600)
                await self._run_decay_cycle()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in decay loop: {e}")
                await asyncio.sleep(60) # Wait a bit before retrying

    async def _run_decay_cycle(self):
        """
        Calculates decay and prunes episodic memory.
        In a full implementation, this would iterate through ChromaDB entries
        and delete those whose decayed importance is below a threshold.
        """
        # Note: ChromaDB doesn't easily support iterating over all items and updating them.
        # Often, decay is computed at retrieval time (as done in RetrievalEngine).
        # But we can delete extremely old/useless memories.
        
        # This is a placeholder for actual pruning logic:
        # 1. Query all items from Episodic collection (can be expensive)
        # 2. For each item:
        #      age = time.time() - item.timestamp
        #      score = item.importance * (0.5 ** (age / self.half_life_seconds))
        #      if score < 0.05:
        #          delete(item)
        logger.debug("Running memory decay pruning cycle.")
        pass

    async def consolidate_session(self, session_turns):
        """
        Converts short-term RAM into long-term Semantic/Episodic storage.
        """
        if not session_turns:
            return
            
        # 1. Format the session text
        transcript = "\n".join([f"{t.role}: {t.content}" for t in session_turns])
        
        # 2. Store in Episodic memory
        try:
            await self.episodic_memory.add_episode(
                content=f"Session Summary:\n{transcript[:1000]}...", # Truncate for now
                importance=0.5,
                metadata={"category": "consolidation"}
            )
            logger.info("Consolidated session into episodic memory.")
        except Exception as e:
            logger.error(f"Failed to consolidate session: {e}")
