import logging
from typing import Dict, Any, List

from MANAGER.memory.working_memory import WorkingMemory
from MANAGER.memory.episodic_memory import EpisodicMemory
from MANAGER.memory.semantic_memory import SemanticMemory
from MANAGER.memory.fact_memory import FactMemory
from MANAGER.memory.retrieval_engine import RetrievalEngine
from MANAGER.memory.context_assembler import ContextAssembler
from MANAGER.memory.decay_manager import MemoryDecayManager
from MANAGER.memory.event_system import MemoryEventBus
from MANAGER.memory.cognitive_feedback import CognitiveFeedbackLoop
from MANAGER.memory.compression_manager import CompressionManager
from INFERENCE.pipeline import Arbiter

logger = logging.getLogger("MEMORY_MANAGER")

class MemoryManager:
    """
    The main orchestrator for JARVIS's Modular Cognitive System.
    Provides a unified API for the rest of the application.
    """
    def __init__(self, atlas=None):
        self.bus = MemoryEventBus()
        
        # Initialize Core Memory Modules
        self.working = WorkingMemory()
        self.episodic = EpisodicMemory()
        self.semantic = SemanticMemory()
        self.facts = FactMemory(atlas=atlas)
        
        # Initialize Processing Engines
        self.retrieval = RetrievalEngine(
            fact_memory=self.facts,
            episodic_memory=self.episodic,
            semantic_memory=self.semantic
        )
        self.assembler = ContextAssembler(max_tokens=4000)
        
        # Initialize Background Daemons
        self.decay = MemoryDecayManager(
            episodic_memory=self.episodic,
            semantic_memory=self.semantic
        )
        self.feedback_loop = CognitiveFeedbackLoop(
            episodic_memory=self.episodic,
            semantic_memory=self.semantic,
            facts_memory=self.facts,
            event_bus=self.bus
        )
        self._arbiter_for_compression = Arbiter()
        self.compression = CompressionManager(
            semantic_memory=self.semantic,
            arbiter=self._arbiter_for_compression
        )
        
        # State Tracking for Feedback
        self._last_retrieved_ids = []
        
        # Wire up event listeners
        self.bus.subscribe("session_ended", self._on_session_ended)
        self.bus.subscribe("interaction_completed", self._on_interaction_completed)
        
        logger.info("Modular Memory Manager initialized.")

    def start_daemons(self):
        """Start background daemons safely when event loop is running."""
        self.decay.start()
        self.compression.start()
        logger.info("Memory daemons started.")

    async def _on_session_ended(self, payload: Any):
        """Event handler for when a session is cleared/ended."""
        logger.info("Handling session_ended event...")
        await self.decay.consolidate_session(payload)
        
    async def _on_interaction_completed(self, payload: dict):
        """Event handler to automatically save episodic memory in the background."""
        user_msg = payload.get("user")
        jarvis_msg = payload.get("jarvis")
        trace_id = payload.get("trace_id", "")
        provider = payload.get("provider", "unknown")
        
        content = f"User: {user_msg}\nJARVIS: {jarvis_msg}"
        await self.episodic.add_episode(
            content=content,
            importance=0.5,
            trace_id=trace_id
        )
        
        # We also pass retrieved_ids into the payload before publishing so cognitive_feedback can use them.
        payload["retrieved_ids"] = self._last_retrieved_ids
        self._last_retrieved_ids = []

    def add_turn(self, role: str, content: str, metadata: dict = None):
        """Adds a turn to working memory."""
        self.working.add_turn(role, content, metadata)

    async def build_ai_context(self, system_prompt: str, current_query: str, budget_tokens: int = None) -> List[Dict[str, str]]:
        """
        The unified retrieval and assembly pipeline.
        1. Search all long-term memories using the current query.
        2. Get the sliding window from working memory.
        3. Assemble them into a strict AI payload, enforcing token limits.
        """
        # Step 1: Retrieval
        ranked_memories = await self.retrieval.search_all(current_query, top_k=5)
        
        # Cache retrieved IDs for feedback loop
        self._last_retrieved_ids = [mem.record.id for mem in ranked_memories]
        
        # Step 2: Working Memory
        window = self.working.get_sliding_window()
        
        # Step 3: Assembly
        payload, dropped_turns = self.assembler.assemble(
            system_prompt=system_prompt,
            ranked_memories=ranked_memories,
            sliding_window=window,
            budget_tokens=budget_tokens
        )
        
        # Step 4: Background Compression of Dropped Turns
        if dropped_turns:
            from MONITOR.tracer import TraceManager
            trace_id = TraceManager.get_current_trace_id() or "unknown"
            
            # Queue the dropped turns for summarization
            await self.compression.compress_turns(dropped_turns, trace_id)
            
            # Remove them from active working memory so they don't pile up
            for dt in dropped_turns:
                try:
                    self.working.window.remove(dt)
                except ValueError:
                    pass
            
        return payload

    async def learn_fact(self, key: str, value: str, confidence: float = 1.0, source: str = "auto"):
        """Directly learns a high-confidence structural fact."""
        await self.facts.learn_fact(key, value, confidence, source)
        
    def end_session(self):
        """Clears working memory and triggers consolidation."""
        window_copy = self.working.get_sliding_window()
        self.working.clear()
        self.bus.publish("session_ended", window_copy)

    def stop(self):
        self.decay.stop()
        self.compression.stop()
