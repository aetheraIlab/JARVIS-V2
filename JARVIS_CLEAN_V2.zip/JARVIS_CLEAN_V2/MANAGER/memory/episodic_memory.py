import os
import uuid
import time
import logging
from typing import List, Dict, Any
from MANAGER.memory.schemas import MemoryRecord

try:
    import chromadb
    from chromadb.utils import embedding_functions
    VECTOR_AVAILABLE = True
except ImportError:
    VECTOR_AVAILABLE = False

logger = logging.getLogger("EPISODIC")

class EpisodicMemory:
    """
    Interface to ChromaDB for storing event-based semantic vectors.
    """
    def __init__(self, db_path: str = None):
        self.vector_mode = VECTOR_AVAILABLE
        self.collection = None
        
        if self.vector_mode:
            try:
                if not db_path:
                    db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "HEAP", "chroma_db")
                os.makedirs(db_path, exist_ok=True)
                self.chroma_client = chromadb.PersistentClient(path=db_path)
                self.embed_fn = embedding_functions.SentenceTransformerEmbeddingFunction(model_name="all-MiniLM-L6-v2")
                self.collection = self.chroma_client.get_or_create_collection(
                    name="episodic_memory",
                    embedding_function=self.embed_fn,
                    metadata={"hnsw:space": "cosine"}
                )
            except Exception as e:
                logger.error(f"Failed to initialize ChromaDB for EpisodicMemory: {e}")
                self.vector_mode = False

    async def add_episode(self, content: str, importance: float = 0.5, trace_id: str = "", metadata: Dict[str, Any] = None) -> str:
        """
        Stores an episodic event. Returns the record ID.
        """
        mem_id = f"ep_{uuid.uuid4().hex[:12]}"
        meta = metadata or {}
        meta["timestamp"] = time.time()
        meta["importance"] = importance
        meta["trace_id"] = trace_id
        meta["type"] = "episodic"
        
        if self.vector_mode and self.collection:
            try:
                # Chroma metadata values must be str, int, float or bool
                safe_meta = {k: (v if isinstance(v, (str, int, float, bool)) else str(v)) for k, v in meta.items()}
                self.collection.add(
                    documents=[content],
                    metadatas=[safe_meta],
                    ids=[mem_id]
                )
            except Exception as e:
                logger.error(f"Error adding episode to vector db: {e}")
                
        return mem_id

    async def search(self, query: str, top_k: int = 5) -> List[MemoryRecord]:
        """
        Searches for semantically similar episodes.
        """
        if not self.vector_mode or not self.collection:
            return []
            
        try:
            results = self.collection.query(
                query_texts=[query],
                n_results=top_k
            )
            
            records = []
            if results and results.get("documents") and results["documents"][0]:
                docs = results["documents"][0]
                metas = results["metadatas"][0]
                distances = results["distances"][0]
                
                for doc, meta, distance in zip(docs, metas, distances):
                    relevance = max(0.0, 1.0 - distance)
                    meta["relevance"] = relevance
                    record = MemoryRecord(
                        id=meta.get("id", str(uuid.uuid4())),
                        content=doc,
                        type="episodic",
                        timestamp=float(meta.get("timestamp", time.time())),
                        importance=float(meta.get("importance", 0.5)),
                        trace_id=str(meta.get("trace_id", "")),
                        metadata=meta
                    )
                    records.append(record)
            return records
        except Exception as e:
            logger.error(f"Error searching episodes: {e}")
            return []
