import time
import threading
import logging
import re
from typing import List, Optional
from MANAGER.memory.schemas import Fact

logger = logging.getLogger("FACTS")

class FactMemory:
    """
    SQLite-based key-value and graph storage for rigid, high-confidence data.
    """
    def __init__(self, atlas=None):
        if not atlas:
            from HEAP.database import Atlas
            self.atlas = Atlas()
        else:
            self.atlas = atlas
            
        self._lock = threading.RLock()
        self._ensure_tables()
        self._cache = {}
        self._load_cache()

    def _ensure_tables(self):
        with self._lock:
            cursor = self.atlas.conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_profile (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    attribute TEXT UNIQUE NOT NULL,
                    value TEXT NOT NULL,
                    confidence REAL DEFAULT 1.0,
                    learned_from TEXT DEFAULT '',
                    last_updated REAL NOT NULL
                )
            """)
            self.atlas.conn.commit()

    def _load_cache(self):
        with self._lock:
            try:
                rows = self.atlas.query("SELECT attribute, value, confidence, learned_from, last_updated FROM user_profile")
                for row in rows:
                    self._cache[row["attribute"]] = Fact(
                        key=row["attribute"],
                        value=row["value"],
                        confidence=row["confidence"],
                        source=row["learned_from"],
                        updated_at=row["last_updated"]
                    )
            except Exception as e:
                logger.error(f"Error loading fact cache: {e}")

    async def learn_fact(self, key: str, value: str, confidence: float = 1.0, source: str = "auto") -> None:
        key = key.lower().strip()
        now = time.time()
        with self._lock:
            self.atlas.conn.execute(
                """INSERT OR REPLACE INTO user_profile 
                   (attribute, value, confidence, learned_from, last_updated)
                   VALUES (?, ?, ?, ?, ?)""",
                (key, value, confidence, source, now)
            )
            self.atlas.conn.commit()
            self._cache[key] = Fact(key=key, value=value, confidence=confidence, source=source, updated_at=now)
            logger.info(f"Learned fact: {key} = {value}")

    async def exact_match(self, query: str) -> List[Fact]:
        """
        Returns facts whose keys or values match keywords in the query.
        """
        query_words = set(re.sub(r'[^\w\s]', '', query.lower()).split())
        query_str_lower = query.lower()
        
        results = []
        with self._lock:
            for attr, fact in self._cache.items():
                attr_words = set(attr.split("_"))
                if attr_words & query_words or str(fact.value).lower() in query_str_lower:
                    results.append(fact)
                    
        return results
