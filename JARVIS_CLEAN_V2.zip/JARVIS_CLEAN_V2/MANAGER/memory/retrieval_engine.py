import asyncio
import time
from typing import List, Set, Protocol
from MANAGER.memory.schemas import MemoryRecord, ScoredMemory, Fact

class MemorySource(Protocol):
    async def search(self, query: str, top_k: int) -> List[MemoryRecord]:
        ...

class FactSource(Protocol):
    async def exact_match(self, query: str) -> List[Fact]:
        ...

class RetrievalEngine:
    """
    Queries Fact, Episodic, and Semantic memory in parallel.
    Scores results based on Relevance, Recency, and Importance.
    Deduplicates chunks using fuzzy overlap detection.
    """
    def __init__(self, fact_memory: FactSource, episodic_memory: MemorySource, semantic_memory: MemorySource):
        self.fact_memory = fact_memory
        self.episodic_memory = episodic_memory
        self.semantic_memory = semantic_memory
        
        # Scoring Weights
        self.WEIGHT_RELEVANCE = 0.6
        self.WEIGHT_IMPORTANCE = 0.2
        self.WEIGHT_RECENCY = 0.2
        
        # Decay half-life in seconds (default: 7 days)
        self.DECAY_HALF_LIFE = 7 * 24 * 3600

    def _compute_score(self, record: MemoryRecord, relevance: float, query: str = "") -> float:
        """
        Calculates the final score for a retrieved memory.
        Adaptive Recall Weighting: Adjusts weights based on query heuristics.
        """
        now = time.time()
        age = max(0.0, now - record.timestamp)
        
        # Exponential decay for recency
        recency = 0.5 ** (age / self.DECAY_HALF_LIFE)
        
        # Default Weights
        w_rel = self.WEIGHT_RELEVANCE
        w_imp = self.WEIGHT_IMPORTANCE
        w_rec = self.WEIGHT_RECENCY
        
        # Adaptive Weighting
        query_lower = query.lower()
        if any(w in query_lower for w in ["recently", "yesterday", "last", "just now", "today"]):
            # Boost Recency
            w_rec += 0.3
            w_rel -= 0.15
            w_imp -= 0.15
        elif any(w in query_lower for w in ["important", "critical", "always", "never", "rule"]):
            # Boost Importance
            w_imp += 0.3
            w_rel -= 0.15
            w_rec -= 0.15
            
        score = (
            w_rel * relevance +
            w_imp * record.importance +
            w_rec * recency
        )
        return min(1.0, max(0.0, score))

    def _deduplicate(self, scored_memories: List[ScoredMemory], threshold: float = 0.8) -> List[ScoredMemory]:
        """
        Fuzzy deduplication based on word overlap.
        """
        unique_texts: List[Set[str]] = []
        final_list: List[ScoredMemory] = []
        
        for mem in scored_memories:
            words = set(mem.record.content.lower().split())
            if not words:
                continue
                
            is_dup = False
            for u_words in unique_texts:
                if not u_words:
                    continue
                overlap = len(words & u_words)
                if (overlap / max(len(words), len(u_words))) > threshold:
                    is_dup = True
                    break
                    
            if not is_dup:
                unique_texts.append(words)
                final_list.append(mem)
                
        return final_list

    async def search_all(self, query: str, top_k: int = 5) -> List[ScoredMemory]:
        """
        Parallel retrieval across all memory sources.
        """
        results = await asyncio.gather(
            self.fact_memory.exact_match(query),
            self.episodic_memory.search(query, top_k),
            self.semantic_memory.search(query, top_k),
            return_exceptions=True
        )
        
        facts = results[0] if not isinstance(results[0], Exception) else []
        episodes = results[1] if not isinstance(results[1], Exception) else []
        semantics = results[2] if not isinstance(results[2], Exception) else []
        
        all_scored: List[ScoredMemory] = []
        
        # Facts have absolute highest score naturally
        for fact in facts:
            record = MemoryRecord(
                id=fact.key,
                content=f"{fact.key} is {fact.value}",
                type="fact",
                timestamp=fact.updated_at,
                importance=fact.confidence,
                trace_id="",
                metadata={"source": fact.source}
            )
            # Facts override standard scoring, assigning max relevance
            all_scored.append(ScoredMemory(record=record, score=1.0))
            
        # Add Episodic and Semantic
        for record in episodes:
            # We assume the metadata holds the raw cosine relevance score from ChromaDB
            relevance = float(record.metadata.get("relevance", 0.5))
            score = self._compute_score(record, relevance, query)
            all_scored.append(ScoredMemory(record=record, score=score))
            
        for record in semantics:
            relevance = float(record.metadata.get("relevance", 0.5))
            score = self._compute_score(record, relevance, query)
            all_scored.append(ScoredMemory(record=record, score=score))
            
        # Sort by score descending
        all_scored.sort(key=lambda x: x.score, reverse=True)
        
        # Deduplicate and trim to top_k
        deduped = self._deduplicate(all_scored)
        return deduped[:top_k]
