import threading
from datetime import datetime
from typing import List, Optional
from MANAGER.memory.schemas import Turn
import time

class WorkingMemory:
    """
    Manages the current conversation sliding window.
    Tracks active session state and current topic.
    """
    def __init__(self, max_window: int = 40):
        self._lock = threading.RLock()
        self._window: List[Turn] = []
        self._max_window = max_window
        self._session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._current_topic = "general"
        
    def add_turn(self, role: str, content: str, metadata: dict = None) -> None:
        with self._lock:
            turn = Turn(
                role=role,
                content=content,
                timestamp=time.time(),
                metadata=metadata or {}
            )
            self._window.append(turn)
            if len(self._window) > self._max_window:
                self._window = self._window[-self._max_window:]
                
    def get_sliding_window(self, limit: Optional[int] = None) -> List[Turn]:
        with self._lock:
            if limit:
                return self._window[-limit:]
            return self._window.copy()
            
    def clear(self):
        with self._lock:
            self._window.clear()
            self._session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
            self._current_topic = "general"
            
    @property
    def session_id(self) -> str:
        return self._session_id
        
    @property
    def current_topic(self) -> str:
        return self._current_topic
        
    def set_topic(self, topic: str):
        with self._lock:
            self._current_topic = topic
