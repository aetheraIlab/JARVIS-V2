from typing import List, Dict, Any
from MANAGER.memory.schemas import ScoredMemory, Turn

class ContextAssembler:
    """
    Formats retrieved memories and working memory turns into the final AI context payload.
    Enforces token constraints (rough estimation by char count).
    """
    def __init__(self, max_tokens: int = 4000, chars_per_token: int = 4):
        self.max_chars = max_tokens * chars_per_token
        
    def assemble(self, system_prompt: str, ranked_memories: List[ScoredMemory], sliding_window: List[Turn], budget_tokens: int = None) -> tuple[List[Dict[str, str]], List[Turn]]:
        """
        Assembles the context payload.
        Returns: (messages_payload, dropped_turns_for_compression)
        """
        messages = []
        current_chars = 0
        
        max_chars = (budget_tokens or (self.max_chars // 4)) * 4
        
        # 1. System Prompt (Always included)
        base_system = {"role": "system", "content": system_prompt}
        messages.append(base_system)
        current_chars += len(system_prompt)
        
        # 2. Inject Facts into System Prompt
        facts = [mem.record for mem in ranked_memories if mem.record.type == "fact"]
        if facts:
            fact_str = "\n[RELEVANT FACTS]:\n" + "\n".join(f"- {f.content}" for f in facts)
            messages[0]["content"] += fact_str
            current_chars += len(fact_str)
            
        # 3. Add Working Memory (Turns)
        turn_messages = []
        dropped_turns = []
        
        # We iterate from newest to oldest
        for turn in reversed(sliding_window):
            turn_len = len(turn.content)
            if current_chars + turn_len > max_chars * 0.8: # Reserve 20% for episodic
                # This turn and all older ones are dropped
                dropped_turns.insert(0, turn)
                continue
            
            role = "user" if turn.role.lower() in ["user", "adil"] else "assistant"
            turn_messages.insert(0, {"role": role, "content": turn.content})
            current_chars += turn_len
            
        # 4. Inject Episodic/Semantic Memories
        episodes = [mem.record for mem in ranked_memories if mem.record.type in ("episodic", "semantic")]
        if episodes:
            epi_str = "\n[RECALLED MEMORIES]:\n"
            for ep in episodes:
                ep_content = f"- [{ep.timestamp}] {ep.content}\n"
                if current_chars + len(ep_content) > max_chars:
                    break # Stop injecting memories if full
                epi_str += ep_content
                current_chars += len(ep_content)
                
            messages[0]["content"] += epi_str
            
        # Append window turns
        messages.extend(turn_messages)
        
        return messages, dropped_turns
