# ================================================================
# JARVIS AETHER-CORE V2.0 — SKILL MANAGER (RAM MANAGER 3/4)
# ================================================================
# Codename : ARTIFICER
# Role     : Skill registry, capability mapping, agent routing,
#            and dynamic skill discovery for all JARVIS agents
# Tech     : SQLite (ATLAS) + in-memory skill registry
# ================================================================

import sys
import os
import threading
import time
from datetime import datetime

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from HEAP.database import Atlas
from HEAP.cache import CacheNode


# ================================================================
# SKILL DEFINITION — একটি দক্ষতার সংজ্ঞা
# ================================================================
class Skill:
    """JARVIS-এর একটি নির্দিষ্ট দক্ষতার বর্ণনা।"""

    def __init__(self, skill_id, name, description, agent, category,
                 trigger_words=None, enabled=True, cooldown=0,
                 requires_internet=False, requires_hardware=None):
        self.skill_id = skill_id
        self.name = name
        self.description = description
        self.agent = agent              # কোন এজেন্ট এটি চালাবে
        self.category = category
        self.trigger_words = trigger_words or []
        self.enabled = enabled
        self.cooldown = cooldown        # সেকেন্ডে — পরপর কত দ্রুত চালানো যাবে
        self.requires_internet = requires_internet
        self.requires_hardware = requires_hardware or []  # e.g. ["microphone", "camera"]
        self.usage_count = 0
        self.last_used = None
        self.success_rate = 1.0

    def to_dict(self):
        return {
            "skill_id": self.skill_id,
            "name": self.name,
            "description": self.description,
            "agent": self.agent,
            "category": self.category,
            "trigger_words": ",".join(self.trigger_words),
            "enabled": self.enabled,
            "cooldown": self.cooldown,
            "requires_internet": self.requires_internet,
            "requires_hardware": ",".join(self.requires_hardware),
            "usage_count": self.usage_count,
            "success_rate": self.success_rate,
        }


# ================================================================
# SKILL MANAGER — মূল স্কিল ম্যানেজার
# ================================================================
class SkillManager:
    """
    JARVIS ARTIFICER — দক্ষতা ম্যানেজার।

    কাজ:
    1. সব দক্ষতার রেজিস্ট্রি রক্ষণাবেক্ষণ
    2. ইউজারের কথা থেকে সঠিক দক্ষতা খোঁজা (ট্রিগার ম্যাচিং)
    3. এজেন্ট-টু-স্কিল ম্যাপিং
    4. দক্ষতার ব্যবহার ট্র্যাকিং ও সাফল্যের হার
    5. ডায়নামিক স্কিল যোগ/বাদ দেওয়া
    """

    def __init__(self, atlas=None, cache=None):
        self.atlas = atlas or Atlas()
        self.cache = cache or CacheNode()
        self._lock = threading.RLock()

        # ইন-মেমোরি স্কিল রেজিস্ট্রি
        self._skills = {}       # skill_id → Skill
        self._agent_map = {}    # agent_name → [skill_id, ...]
        self._trigger_index = {}  # trigger_word → [skill_id, ...]

        # ইনিশিয়ালাইজেশন
        self._ensure_tables()
        self._register_core_skills()
        self._build_indexes()

        print(f"[ARTIFICER] Skill Manager online. {len(self._skills)} skills registered.")

    # ================================================================
    # DATABASE SCHEMA
    # ================================================================
    def _ensure_tables(self):
        """স্কিল ম্যানেজারের টেবিল তৈরি করে।"""
        cursor = self.atlas.conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS skill_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                skill_id TEXT NOT NULL,
                agent TEXT NOT NULL,
                trigger_text TEXT DEFAULT '',
                success INTEGER DEFAULT 1,
                execution_time REAL DEFAULT 0.0,
                detail TEXT DEFAULT ''
            )
        """)

        self.atlas.conn.commit()

    # ================================================================
    # CORE SKILLS REGISTRY — ডিফল্ট দক্ষতাগুলো
    # ================================================================
    def _register_core_skills(self):
        """JARVIS-এর সব মূল দক্ষতা রেজিস্টার করে।"""

        core_skills = [
            # --- SENSORY SKILLS ---
            Skill("SPEAK", "Text to Speech", "Converts text to spoken audio",
                  "AUDIO-OUT", "sensory",
                  trigger_words=["say", "speak", "tell", "read aloud"],
                  requires_hardware=["speaker"]),

            Skill("LISTEN", "Speech to Text", "Listens to microphone and transcribes",
                  "AUDIO-IN", "sensory",
                  trigger_words=["listen", "hear", "record"],
                  requires_hardware=["microphone"]),

            Skill("SEE", "Camera Vision", "Captures camera feed and detects faces",
                  "OPTIC", "sensory",
                  trigger_words=["camera", "see", "look", "face", "webcam", "photo"],
                  requires_hardware=["camera"]),

            # --- INTELLIGENCE SKILLS ---
            Skill("THINK", "AI Conversation", "General AI conversation and Q&A",
                  "ARBITER", "intelligence",
                  trigger_words=["think", "explain", "what is", "tell me", "how to"]),

            Skill("RESEARCH", "Deep Web Research", "Autonomous deep internet research and reporting",
                  "RESEARCH_AGENT", "intelligence",
                  trigger_words=["research", "deep search", "investigate", "study", "analyze"],
                  requires_internet=True),

            Skill("THINK_CODE", "Code Assistance", "Help with coding and debugging",
                  "ARBITER", "intelligence",
                  trigger_words=["code", "python", "debug", "function", "error", "script", "program"]),

            Skill("THINK_CREATIVE", "Creative Writing", "Stories, poems, and creative content",
                  "ARBITER", "intelligence",
                  trigger_words=["write", "story", "poem", "creative", "imagine"]),

            # --- SYSTEM SKILLS ---
            Skill("OPEN_APP", "Application Launcher", "Opens desktop applications",
                  "DRIVER_LAUNCHER", "system",
                  trigger_words=["open", "launch", "start", "run"],
                  requires_hardware=[]),

            Skill("SCREENSHOT", "Screen Capture", "Takes a screenshot of the screen",
                  "EXECUTOR_SYSCALL", "system",
                  trigger_words=["screenshot", "screen capture", "capture screen"],
                  cooldown=5),

            Skill("SYS_INFO", "System Monitor", "Shows CPU, RAM, disk usage",
                  "EXECUTOR_MONITOR", "system",
                  trigger_words=["status", "health", "cpu", "ram", "disk", "system check", "diagnostic"]),

            Skill("PROCESS_MNG", "Process Manager", "Lists and manages running processes",
                  "EXECUTOR_PROCESS", "system",
                  trigger_words=["process", "task manager", "kill", "running apps"]),

            Skill("FILE_OP", "File Operations", "Create, read, delete, move files",
                  "EXECUTOR_FILESYSTEM", "system",
                  trigger_words=["file", "folder", "create file", "delete", "move", "copy", "rename"]),

            Skill("SHUTDOWN", "Power Control", "Shutdown, restart, sleep, lock",
                  "EXECUTOR_SYSCALL", "system",
                  trigger_words=["shutdown", "restart", "sleep", "hibernate", "lock", "log off"],
                  cooldown=10),

            # --- CONNECTIVITY SKILLS ---
            Skill("WEB_SEARCH", "Web Search", "Searches the internet for information",
                  "CRAWLER_NEXUS", "connectivity",
                  trigger_words=["search", "google", "find", "look up", "browse", "wikipedia"],
                  requires_internet=True),

            # --- BROWSER AUTOMATION SKILLS ---
            Skill("BROWSE_WEB", "Browse Website", "Opens a website in headless browser",
                  "DRIVER_BROWSER", "connectivity",
                  trigger_words=["browse", "website", "open site", "visit", "navigate", "go to"],
                  requires_internet=True),

            Skill("BROWSE_SEARCH", "Browser Search", "Searches Google via headless browser",
                  "DRIVER_BROWSER", "connectivity",
                  trigger_words=["browser search", "google search", "search google", "search web"],
                  requires_internet=True),

            Skill("BROWSE_READ", "Read Page", "Reads and extracts text content from a webpage",
                  "DRIVER_BROWSER", "connectivity",
                  trigger_words=["read page", "extract", "scrape", "get content", "read website"],
                  requires_internet=True),

            Skill("BROWSE_SCREENSHOT", "Page Screenshot", "Takes a screenshot of a webpage",
                  "DRIVER_BROWSER", "connectivity",
                  trigger_words=["page screenshot", "capture page", "website screenshot"],
                  requires_internet=True, cooldown=5),

            Skill("BROWSE_FILL", "Fill Form", "Fills out web forms automatically",
                  "DRIVER_BROWSER", "connectivity",
                  trigger_words=["fill form", "submit form", "fill out", "enter data"],
                  requires_internet=True),

            Skill("BROWSE_LOGIN", "Auto Login", "Automated website login",
                  "DRIVER_BROWSER", "connectivity",
                  trigger_words=["login", "sign in", "log in", "authenticate"],
                  requires_internet=True),

            Skill("EMAIL", "Email Manager", "Send, read, and manage Gmail",
                  "EMAIL_AGENT", "connectivity",
                  trigger_words=["email", "mail", "gmail", "send email", "inbox", "compose", "check email", "draft email"],
                  requires_internet=True),

            # --- AWARENESS SKILLS ---
            Skill("REMIND", "Reminder", "Sets reminders and alarms",
                  "DAEMON_REMINDER", "awareness",
                  trigger_words=["remind", "reminder", "alarm", "timer", "schedule", "wake me"]),

            Skill("TRACK", "Activity Tracker", "Tracks system and user activity",
                  "DAEMON_TRACKER", "awareness",
                  trigger_words=["track", "activity", "history", "log"]),

            Skill("NOTIFY", "Notification", "Sends desktop notifications",
                  "DAEMON_WATCHDOG", "awareness",
                  trigger_words=["notify", "notification", "alert"]),

            # --- SELF-AWARENESS SKILLS ---
            Skill("IDENTITY", "Self Identity", "Answers questions about JARVIS itself",
                  "PRESIDENT", "self",
                  trigger_words=["who are you", "your name", "who made you", "who created"]),

            Skill("TIME_DATE", "Time & Date", "Tells current time and date",
                  "PRESIDENT", "self",
                  trigger_words=["time", "date", "day", "today", "clock", "calendar"]),

            Skill("GREETING", "Greeting", "Responds to greetings appropriately",
                  "PRESIDENT", "self",
                  trigger_words=["hello", "hi", "hey", "good morning", "good evening",
                                "good night", "salam", "namaste"]),
        ]

        for skill in core_skills:
            self._skills[skill.skill_id] = skill

    def _build_indexes(self):
        """দ্রুত খোঁজার জন্য ইনডেক্স তৈরি করে।"""
        self._agent_map.clear()
        self._trigger_index.clear()

        for skill_id, skill in self._skills.items():
            # এজেন্ট ম্যাপ
            if skill.agent not in self._agent_map:
                self._agent_map[skill.agent] = []
            self._agent_map[skill.agent].append(skill_id)

            # ট্রিগার ইনডেক্স
            for word in skill.trigger_words:
                word_lower = word.lower()
                if word_lower not in self._trigger_index:
                    self._trigger_index[word_lower] = []
                self._trigger_index[word_lower].append(skill_id)

    # ================================================================
    # SKILL MATCHING — ইউজারের কথা থেকে দক্ষতা খোঁজা
    # ================================================================
    def find_skill(self, text, is_online=True):
        """
        ইউজারের কথা বিশ্লেষণ করে সবচেয়ে উপযুক্ত দক্ষতা খুঁজে বের করে।

        Returns:
            Skill object or None
        """
        if not text:
            return None

        text_lower = text.lower().strip()
        candidates = {}  # skill_id → score

        for trigger_word, skill_ids in self._trigger_index.items():
            if trigger_word in text_lower:
                for sid in skill_ids:
                    skill = self._skills.get(sid)
                    if not skill or not skill.enabled:
                        continue

                    # ইন্টারনেট প্রয়োজন কিন্তু অফলাইন — বাদ দাও
                    if skill.requires_internet and not is_online:
                        continue

                    # কুলডাউন চেক
                    if skill.cooldown > 0 and skill.last_used:
                        elapsed = (datetime.now() - datetime.fromisoformat(skill.last_used)).total_seconds()
                        if elapsed < skill.cooldown:
                            continue

                    # স্কোরিং — দীর্ঘ ট্রিগারকে বেশি ওজন
                    word_count = len(trigger_word.split())
                    if sid not in candidates:
                        candidates[sid] = 0
                    candidates[sid] += word_count + (skill.success_rate * 0.5)

        if not candidates:
            return None

        # সর্বোচ্চ স্কোরের দক্ষতা
        best_id = max(candidates, key=candidates.get)
        return self._skills.get(best_id)

    def find_skills_by_category(self, category):
        """একটি ক্যাটাগরির সব দক্ষতা দেখায়।"""
        return [s for s in self._skills.values() if s.category == category and s.enabled]

    def get_agent_skills(self, agent_name):
        """একটি এজেন্টের সব দক্ষতা দেখায়।"""
        skill_ids = self._agent_map.get(agent_name, [])
        return [self._skills[sid] for sid in skill_ids if sid in self._skills]

    # ================================================================
    # DYNAMIC SKILL MANAGEMENT
    # ================================================================
    def register_skill(self, skill):
        """নতুন দক্ষতা রেজিস্টার করে (রানটাইমে)।"""
        with self._lock:
            self._skills[skill.skill_id] = skill
            self._build_indexes()
        print(f"[ARTIFICER] New skill registered: {skill.skill_id} — {skill.name}")

    def disable_skill(self, skill_id):
        """একটি দক্ষতা নিষ্ক্রিয় করে।"""
        if skill_id in self._skills:
            self._skills[skill_id].enabled = False
            print(f"[ARTIFICER] Skill disabled: {skill_id}")
            return True
        return False

    def enable_skill(self, skill_id):
        """একটি দক্ষতা সক্রিয় করে।"""
        if skill_id in self._skills:
            self._skills[skill_id].enabled = True
            print(f"[ARTIFICER] Skill enabled: {skill_id}")
            return True
        return False

    def remove_skill(self, skill_id):
        """একটি দক্ষতা সম্পূর্ণ মুছে দেয়।"""
        with self._lock:
            if skill_id in self._skills:
                del self._skills[skill_id]
                self._build_indexes()
                print(f"[ARTIFICER] Skill removed: {skill_id}")
                return True
        return False

    # ================================================================
    # USAGE TRACKING — ব্যবহারের ট্র্যাকিং
    # ================================================================
    def record_usage(self, skill_id, trigger_text="", success=True, execution_time=0.0, detail=""):
        """একটি দক্ষতার ব্যবহার রেকর্ড করে।"""
        now = datetime.now().isoformat()

        with self._lock:
            # ডাটাবেসে লগ
            self.atlas.conn.execute(
                """INSERT INTO skill_usage 
                   (timestamp, skill_id, agent, trigger_text, success, execution_time, detail)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (now, skill_id, self._skills.get(skill_id, Skill("", "", "", "", "")).agent,
                 trigger_text[:200], 1 if success else 0, execution_time, detail[:500])
            )
            self.atlas.conn.commit()

            # ইন-মেমোরি আপডেট
            if skill_id in self._skills:
                skill = self._skills[skill_id]
                skill.usage_count += 1
                skill.last_used = now

                # সাফল্যের হার আপডেট (চলমান গড়)
                if skill.usage_count > 1:
                    success_val = 1.0 if success else 0.0
                    skill.success_rate = (
                        skill.success_rate * 0.9 + success_val * 0.1
                    )
                elif not success:
                    skill.success_rate = 0.0

    def get_skill_usage(self, skill_id, limit=20):
        """একটি দক্ষতার ব্যবহারের ইতিহাস দেখায়।"""
        rows = self.atlas.query(
            """SELECT * FROM skill_usage 
               WHERE skill_id = ? 
               ORDER BY timestamp DESC 
               LIMIT ?""",
            (skill_id, limit)
        )
        return [dict(r) for r in rows]

    def get_most_used_skills(self, limit=10):
        """সবচেয়ে বেশি ব্যবহৃত দক্ষতাগুলো দেখায়।"""
        rows = self.atlas.query(
            """SELECT skill_id, COUNT(*) as uses, 
                      AVG(success) as avg_success,
                      AVG(execution_time) as avg_time
               FROM skill_usage 
               GROUP BY skill_id 
               ORDER BY uses DESC 
               LIMIT ?""",
            (limit,)
        )
        return [dict(r) for r in rows]

    # ================================================================
    # STATISTICS & LISTING
    # ================================================================
    def list_all_skills(self):
        """সব দক্ষতার সারাংশ তালিকা।"""
        result = []
        for sid, skill in sorted(self._skills.items()):
            result.append({
                "id": sid,
                "name": skill.name,
                "agent": skill.agent,
                "category": skill.category,
                "enabled": skill.enabled,
                "usage_count": skill.usage_count,
                "success_rate": f"{skill.success_rate:.0%}",
            })
        return result

    def list_categories(self):
        """সব ক্যাটাগরি এবং তাদের দক্ষতার সংখ্যা।"""
        categories = {}
        for skill in self._skills.values():
            cat = skill.category
            if cat not in categories:
                categories[cat] = {"total": 0, "enabled": 0}
            categories[cat]["total"] += 1
            if skill.enabled:
                categories[cat]["enabled"] += 1
        return categories

    def get_stats(self):
        """স্কিল সিস্টেমের পরিসংখ্যান।"""
        total = len(self._skills)
        enabled = sum(1 for s in self._skills.values() if s.enabled)
        internet_required = sum(1 for s in self._skills.values() if s.requires_internet)
        hardware_required = sum(1 for s in self._skills.values() if s.requires_hardware)

        total_usage = self.atlas.query("SELECT COUNT(*) as cnt FROM skill_usage")
        usage_count = total_usage[0]["cnt"] if total_usage else 0

        return {
            "total_skills": total,
            "enabled_skills": enabled,
            "disabled_skills": total - enabled,
            "internet_dependent": internet_required,
            "hardware_dependent": hardware_required,
            "total_agents": len(self._agent_map),
            "trigger_words_indexed": len(self._trigger_index),
            "total_usage_records": usage_count,
        }

    def get_capability_report(self):
        """
        JARVIS কী কী করতে পারে তার একটি রিপোর্ট।
        ইউজার "what can you do?" জিজ্ঞেস করলে এটি ব্যবহার হবে।
        """
        categories = self.list_categories()
        lines = ["Sir, here are my current capabilities:"]

        cat_names = {
            "sensory": "Sensory (Audio & Vision)",
            "intelligence": "Intelligence (AI & Reasoning)",
            "system": "System Control",
            "connectivity": "Internet & Communication",
            "awareness": "Awareness & Scheduling",
            "self": "Self-Awareness",
        }

        for cat, info in sorted(categories.items()):
            display = cat_names.get(cat, cat.title())
            skills_in_cat = [s for s in self._skills.values()
                           if s.category == cat and s.enabled]
            names = [s.name for s in skills_in_cat]
            lines.append(f"  {display}: {', '.join(names)}")

        return "\n".join(lines)


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  ARTIFICER (Skill Manager) — Unit Test")
    print("=" * 60)

    sm = SkillManager()

    # === TEST 1: List all skills ===
    print("\n[TEST 1] All registered skills...")
    skills = sm.list_all_skills()
    for s in skills:
        status = "ON" if s["enabled"] else "OFF"
        print(f"  [{status}] {s['id']:15s} | {s['name']:25s} | Agent: {s['agent']}")

    # === TEST 2: Skill matching ===
    print("\n[TEST 2] Skill matching tests...")
    test_phrases = [
        "Open Chrome browser",
        "What time is it?",
        "Take a screenshot",
        "Search for Python tutorials",
        "Send an email to John",
        "Remind me at 5 PM",
        "Check system health",
        "Help me debug this code",
        "Hello JARVIS",
        "Who created you?",
        "Tell me a joke",
        "Turn off the computer",
    ]

    for phrase in test_phrases:
        skill = sm.find_skill(phrase, is_online=True)
        if skill:
            print(f"  \"{phrase}\"")
            print(f"    -> {skill.skill_id} ({skill.name}) via {skill.agent}")
        else:
            print(f"  \"{phrase}\" -> No match (AI fallback)")

    # === TEST 3: Offline matching ===
    print("\n[TEST 3] Offline skill matching (no internet)...")
    skill = sm.find_skill("Search for Python tutorials", is_online=False)
    print(f"  Web search (offline): {'Blocked (correct)' if skill is None else 'ERROR: should be blocked'}")

    skill = sm.find_skill("What time is it?", is_online=False)
    print(f"  Time query (offline): {'Available (correct)' if skill else 'ERROR'}")

    # === TEST 4: Usage tracking ===
    print("\n[TEST 4] Usage tracking...")
    sm.record_usage("SPEAK", "say hello", success=True, execution_time=0.5)
    sm.record_usage("THINK", "what is AI", success=True, execution_time=2.1)
    sm.record_usage("WEB_SEARCH", "search python", success=False, execution_time=5.0, detail="timeout")
    sm.record_usage("SPEAK", "read this", success=True, execution_time=0.8)

    most_used = sm.get_most_used_skills(5)
    for m in most_used:
        print(f"  {m['skill_id']:15s} | Uses: {m['uses']} | Success: {m['avg_success']:.0%}")

    # === TEST 5: Categories ===
    print("\n[TEST 5] Skill categories...")
    categories = sm.list_categories()
    for cat, info in sorted(categories.items()):
        print(f"  {cat:15s}: {info['enabled']}/{info['total']} enabled")

    # === TEST 6: Dynamic skill ===
    print("\n[TEST 6] Dynamic skill registration...")
    custom = Skill(
        "TRANSLATE", "Language Translator", "Translates text between languages",
        "ARBITER", "intelligence",
        trigger_words=["translate", "translation", "convert language"],
        requires_internet=True,
    )
    sm.register_skill(custom)

    skill = sm.find_skill("translate this to French")
    print(f"  Dynamic match: {skill.skill_id if skill else 'None'} — {skill.name if skill else 'N/A'}")

    # === TEST 7: Capability report ===
    print("\n[TEST 7] Capability report...")
    report = sm.get_capability_report()
    print(report)

    # === TEST 8: Stats ===
    print("\n[TEST 8] Skill system stats...")
    stats = sm.get_stats()
    for k, v in stats.items():
        print(f"  {k}: {v}")

    print("\n" + "=" * 60)
    print("  [ARTIFICER] All unit tests complete. ✓")
    print("=" * 60)
