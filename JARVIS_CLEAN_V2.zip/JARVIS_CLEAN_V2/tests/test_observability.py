import os
import json
import pytest
import asyncio
from datetime import datetime

from MONITOR.tracer import Tracer, Span
from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse

# A mock agent for testing
class MockAgent(BaseAgent):
    AGENT_ID = "MOCK_AGENT"
    AGENT_NAME = "Mock Agent"
    
    async def execute(self, action: str, params: dict) -> AgentResponse:
        if action == "fail":
            return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="Simulated failure")
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result=f"Did {action}")

@pytest.fixture
def clean_log():
    log_file = Tracer.LOG_FILE
    if os.path.exists(log_file):
        os.remove(log_file)
    yield
    if os.path.exists(log_file):
        os.remove(log_file)

@pytest.mark.asyncio
async def test_tracer_basic(clean_log):
    trace_id = Tracer.generate_trace_id()
    assert trace_id.startswith("trace_")
    
    span = Tracer.start_span("test_span", metadata={"key": "value"})
    assert span.trace_id == trace_id
    assert span.name == "test_span"
    
    span.end(status="success", result={"data": "test"})
    
    # Read the log
    assert os.path.exists(Tracer.LOG_FILE)
    with open(Tracer.LOG_FILE, "r") as f:
        lines = f.readlines()
        assert len(lines) == 1
        data = json.loads(lines[0])
        
        assert data["trace_id"] == trace_id
        assert data["name"] == "test_span"
        assert data["status"] == "success"
        assert data["metadata"]["key"] == "value"
        assert "execution_time_ms" in data
        assert data["result"] == "{'data': 'test'}" # Converted to str

@pytest.mark.asyncio
async def test_agent_tracing(clean_log):
    Tracer.generate_trace_id()
    agent = MockAgent()
    
    # Execute with state
    res = await agent.execute_with_state("test_action", {"param1": 1})
    assert res.success
    
    with open(Tracer.LOG_FILE, "r") as f:
        lines = f.readlines()
        assert len(lines) == 1
        data = json.loads(lines[0])
        assert data["name"] == "AGENT_EXECUTE_MOCK_AGENT"
        assert data["metadata"]["action"] == "test_action"

@pytest.mark.asyncio
async def test_agent_validation_tracing(clean_log):
    Tracer.generate_trace_id()
    agent = MockAgent()
    
    # Execute with validation (fail)
    res = await agent.execute_with_validation("fail", {}, max_retries=1)
    assert not res.success
    
    with open(Tracer.LOG_FILE, "r") as f:
        lines = f.readlines()
        # Should have: VALIDATION_MOCK_AGENT, and 2 retries = 2 AGENT_EXECUTE spans -> Total 3 spans
        # Actually validation calls execute_with_state which also logs.
        assert len(lines) == 3 
        
        validation_span = json.loads(lines[-1])
        assert validation_span["name"] == "VALIDATION_MOCK_AGENT"
        assert validation_span["status"] == "failed"
        assert validation_span["metadata"]["retries"] == 2
