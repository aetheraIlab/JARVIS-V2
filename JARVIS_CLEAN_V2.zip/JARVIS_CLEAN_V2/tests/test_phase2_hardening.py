import os
import sys
import time
import json
import asyncio
from concurrent.futures import ThreadPoolExecutor

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from AGENT.safe_executor_v2 import SafeExecutorV2
from MONITOR.tracer import TraceManager
from KERNEL.scheduler import SignalBus

class HardeningBenchmark:
    def __init__(self):
        self.report = {
            "total_tests": 0,
            "passed": 0,
            "failed": 0,
            "results": []
        }
        self.executor = SafeExecutorV2()
        
    def add(self, category, name, passed, detail="", elapsed_s=0.0):
        self.report["total_tests"] += 1
        if passed:
            self.report["passed"] += 1
        else:
            self.report["failed"] += 1
            
        self.report["results"].append({
            "category": category,
            "name": name,
            "passed": passed,
            "detail": str(detail),
            "elapsed_s": round(elapsed_s, 4)
        })
        print(f"[{'PASS' if passed else 'FAIL'}] {name} ({elapsed_s:.3f}s)")
        if not passed and detail:
            print(f"  -> {detail}")

    def run_all(self):
        print("="*50)
        print(" PHASE 2 HARDENING VALIDATION SUITE")
        print("="*50)
        
        self.test_timeout_validation()
        self.test_infinite_loop()
        self.test_crash_recovery()
        self.test_risk_scoring()
        self.test_trace_telemetry()
        self.test_parallel_stress()
        
        # Save Report
        report_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "PHASE2_HARDENING_REPORT.json")
        with open(report_path, "w") as f:
            json.dump(self.report, f, indent=2)
            
        print("\n" + "="*50)
        print(f" Tests: {self.report['passed']}/{self.report['total_tests']} Passed")
        print(f" Report saved to {report_path}")
        print("="*50)

    def test_timeout_validation(self):
        t0 = time.time()
        # Sleep for 10 seconds, but timeout is 2 seconds
        res = self.executor.execute_python("import time\ntime.sleep(10)", timeout=2)
        elapsed = time.time() - t0
        
        passed = not res.success and res.timed_out and res.killed
        self.add("security", "Timeout enforcement", passed, res.error_summary, elapsed)

    def test_infinite_loop(self):
        t0 = time.time()
        res = self.executor.execute_python("while True: pass", timeout=2)
        elapsed = time.time() - t0
        
        passed = not res.success and res.timed_out and res.killed
        self.add("security", "Infinite loop attack", passed, res.error_summary, elapsed)

    def test_crash_recovery(self):
        t0 = time.time()
        res = self.executor.execute_python("1 / 0", timeout=2)
        elapsed = time.time() - t0
        
        passed = not res.success and "ZeroDivisionError" in res.stderr
        self.add("isolation", "Subprocess crash recovery", passed, res.error_summary, elapsed)

    def test_risk_scoring(self):
        t0 = time.time()
        res_safe = self.executor.execute_python("print('hello')", timeout=2)
        res_high = self.executor.execute_python("import os\nos.system('echo hi')", timeout=2)
        elapsed = time.time() - t0
        
        passed = (res_safe.risk_score == "LOW" and res_high.risk_score == "HIGH")
        detail = f"Safe: {res_safe.risk_score}, High: {res_high.risk_score}"
        self.add("security", "Execution risk scoring", passed, detail, elapsed)

    def test_trace_telemetry(self):
        t0 = time.time()
        test_trace = TraceManager.generate_trace_id()
        res = self.executor.execute_python("print('telemetry test')", timeout=2)
        
        # Check if span was written
        spans = TraceManager.get_trace(res.trace_id)
        
        passed = len(spans) > 0 and any(s["name"] == "execute_python" for s in spans)
        self.add("telemetry", "TraceManager integration", passed, f"Spans found: {len(spans)}", time.time()-t0)

    def test_parallel_stress(self):
        t0 = time.time()
        
        def run_task(i):
            return self.executor.execute_python(f"print('task {i}')", timeout=3)
            
        with ThreadPoolExecutor(max_workers=10) as ex:
            results = list(ex.map(run_task, range(20)))
            
        success_count = sum(1 for r in results if r.success)
        elapsed = time.time() - t0
        
        passed = success_count == 20
        self.add("stress", "Parallel isolated execution (20 tasks)", passed, f"Successful: {success_count}/20", elapsed)

if __name__ == "__main__":
    benchmark = HardeningBenchmark()
    benchmark.run_all()
