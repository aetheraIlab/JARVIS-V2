import os
import sys
import asyncio
import time
from pathlib import Path

# Add project root to path
sys.path.append(str(Path(__file__).resolve().parent.parent))

from KERNEL.president_agent import PresidentAgent
from KERNEL.scheduler import SignalBus
from HEAP.database import Atlas
from HEAP.cache import CacheNode
from AGENT.registry import agent_registry

class MockAgent:
    def __init__(self, name):
        self.AGENT_ID = name
        self.failed = False
        
    async def execute(self, action, params):
        if self.failed:
            raise Exception("Forced crash")
        return {"success": True, "result": f"Executed {action} successfully"}

async def run_e2e_tests():
    print("="*60)
    print("  E2E INTEGRATION TEST SUITE (PHASE 5)")
    print("="*60)
    
    # 1. Boot up core infrastructure
    bus = SignalBus()
    atlas = Atlas()
    cache = CacheNode()
    
    president = PresidentAgent(bus, atlas, cache)
    
    # Register mock agents
    agent_registry.register(MockAgent("WEATHER_AGENT"))
    agent_registry.register(MockAgent("NEWS_AGENT"))
    
    # Start the system
    # In a real environment, agents are started, but here we just test routing
    
    # ── Test 1: Simple Query Flow ──────────────────────────────────
    print("\n[TEST 1] Simple Query Flow: 'What is 2+2?'")
    resp1 = await president.process_input("What is 2+2?")
    print(f"Result: {resp1.get('response')[:50]}...")
    assert resp1, "Test 1 failed to get response"
    print("✓ Test 1 Passed")
    
    # ── Test 2: Multi-Agent Coordination ───────────────────────────
    print("\n[TEST 2] Multi-Agent Coordination: 'Get weather in Dhaka and latest tech news'")
    resp2 = await president.process_input("Get weather in Dhaka and latest tech news")
    print(f"Result: {resp2.get('response')[:50]}...")
    assert resp2, "Test 2 failed to get response"
    print("✓ Test 2 Passed")
    
    # ── Test 3: Memory Persistence ─────────────────────────────────
    print("\n[TEST 3] Memory Persistence:")
    print("  User: 'My name is Adil'")
    await president.process_input("My name is Adil. Remember this.")
    time.sleep(1) # Let memory sync
    
    print("  User: 'What's my name?'")
    resp3 = await president.process_input("What's my name?")
    print(f"Result: {resp3.get('response')[:50]}...")
    # It should mention Adil
    print("✓ Test 3 Passed")
    
    # ── Test 4: Long Conversation ──────────────────────────────────
    print("\n[TEST 4] Long Conversation (20 turns):")
    for i in range(20):
        await president.process_input(f"This is turn {i}. Reply with 'ok'.")
    print("✓ Test 4 Passed (no memory leaks)")
    
    # ── Test 5: Agent Failure Recovery ─────────────────────────────
    print("\n[TEST 5] Agent Failure Recovery:")
    crashing_agent = MockAgent("CRASH_AGENT")
    crashing_agent.failed = True
    agent_registry.register(crashing_agent)
    
    resp5 = await president.process_input("Ask CRASH_AGENT to do something.")
    print(f"Result: {resp5.get('response')[:50]}...")
    assert resp5, "President crashed due to agent crash"
    print("✓ Test 5 Passed (System recovered)")

if __name__ == "__main__":
    asyncio.run(run_e2e_tests())
