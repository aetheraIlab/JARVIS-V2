import pytest
from MANAGER.memory.working_memory import WorkingMemory

def test_working_memory():
    wm = WorkingMemory(max_window=2)
    
    wm.add_turn("user", "Hello")
    assert len(wm.get_sliding_window()) == 1
    
    wm.add_turn("assistant", "Hi")
    wm.add_turn("user", "How are you?")
    
    # Should only keep the last 2 due to max_window=2
    window = wm.get_sliding_window()
    assert len(window) == 2
    assert window[0].role == "assistant"
    assert window[0].content == "Hi"
    assert window[1].role == "user"
    assert window[1].content == "How are you?"
    
    wm.set_topic("greeting")
    assert wm.current_topic == "greeting"
    
    old_session = wm.session_id
    wm.clear()
    assert len(wm.get_sliding_window()) == 0
    assert wm.session_id != old_session
    assert wm.current_topic == "general"

if __name__ == "__main__":
    test_working_memory()
    print("Working Memory tests passed.")
