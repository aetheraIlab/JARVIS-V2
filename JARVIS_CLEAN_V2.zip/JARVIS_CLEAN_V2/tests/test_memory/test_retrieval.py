import pytest
import time
from MANAGER.memory.schemas import MemoryRecord, Fact
from MANAGER.memory.retrieval_engine import RetrievalEngine

class MockMemorySource:
    def __init__(self, records):
        self.records = records
    
    async def search(self, query: str, top_k: int):
        return self.records

class MockFactSource:
    def __init__(self, facts):
        self.facts = facts
        
    async def exact_match(self, query: str):
        return self.facts

@pytest.mark.asyncio
async def test_retrieval_engine():
    now = time.time()
    
    fact_source = MockFactSource([
        Fact(key="user.name", value="Adil", confidence=1.0, source="test", updated_at=now)
    ])
    
    episodes = [
        MemoryRecord(id="e1", content="Hello world", type="episodic", timestamp=now, importance=0.8, trace_id="t1", metadata={"relevance": 0.9}),
        MemoryRecord(id="e2", content="Hello world", type="episodic", timestamp=now, importance=0.8, trace_id="t2", metadata={"relevance": 0.9})
    ]
    episodic_source = MockMemorySource(episodes)
    semantic_source = MockMemorySource([])
    
    engine = RetrievalEngine(fact_source, episodic_source, semantic_source)
    
    results = await engine.search_all("world", top_k=5)
    
    assert len(results) == 2  # 1 fact, 1 deduped episode
    assert results[0].record.type == "fact"
    assert results[0].score == 1.0
    
    assert results[1].record.id == "e1"
    assert results[1].score > 0.5

if __name__ == "__main__":
    import asyncio
    asyncio.run(test_retrieval_engine())
    print("Retrieval Engine tests passed.")
