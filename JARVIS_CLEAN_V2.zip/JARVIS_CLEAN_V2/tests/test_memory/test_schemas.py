import time
from MANAGER.memory.schemas import MemoryRecord, Fact, ScoredMemory, Turn

def test_schemas():
    now = time.time()
    
    mem = MemoryRecord(
        id="test_mem_1",
        content="Hello world",
        type="episodic",
        timestamp=now,
        importance=0.5,
        trace_id="trace_1",
        metadata={"source": "test"}
    )
    assert mem.id == "test_mem_1"
    
    fact = Fact(
        key="test_key",
        value="test_value",
        confidence=1.0,
        source="system",
        updated_at=now
    )
    assert fact.key == "test_key"
    
    scored = ScoredMemory(record=mem, score=0.8)
    assert scored.score == 0.8
    
    turn = Turn(role="user", content="Hello", timestamp=now)
    assert turn.role == "user"
    assert turn.content == "Hello"

if __name__ == "__main__":
    test_schemas()
    print("Schemas tests passed.")
