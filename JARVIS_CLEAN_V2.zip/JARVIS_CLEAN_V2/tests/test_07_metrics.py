import pytest
import asyncio
import time
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from MONITOR.metrics import MetricsManager, metrics_manager
from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse


# ================================================================
# MOCK AGENTS
# ================================================================

class FastAgent(BaseAgent):
    AGENT_ID = "FAST_AGENT"
    AGENT_NAME = "Fast Agent"

    async def execute(self, action: str, params: dict) -> AgentResponse:
        await asyncio.sleep(0.01)
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result="fast")


class SlowAgent(BaseAgent):
    AGENT_ID = "SLOW_AGENT"
    AGENT_NAME = "Slow Agent"

    async def execute(self, action: str, params: dict) -> AgentResponse:
        await asyncio.sleep(0.15)
        return AgentResponse(success=True, agent_id=self.AGENT_ID, action=action, result="slow")


class BrokenAgent(BaseAgent):
    AGENT_ID = "BROKEN_AGENT"
    AGENT_NAME = "Broken Agent"

    async def execute(self, action: str, params: dict) -> AgentResponse:
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="Always broken")


# ================================================================
# TEST GROUP 1: Core Recording
# ================================================================

class TestMetricsRecording:

    def setup_method(self):
        self.mm = MetricsManager(window_size=10)

    def test_record_success(self):
        """A successful record must increment total and success counts."""
        self.mm.record("AGENT_A", "action_1", True, 100.0)
        m = self.mm.get_metrics()
        assert m["total_requests"] == 1
        assert m["window_requests"] == 1
        assert m["success_rate"] == 1.0
        assert m["failure_rate"] == 0.0

    def test_record_failure(self):
        """A failed record must increment failure count."""
        self.mm.record("AGENT_A", "action_1", False, 50.0, error="Timeout")
        m = self.mm.get_metrics()
        assert m["total_requests"] == 1
        assert m["failure_rate"] == 1.0
        assert m["success_rate"] == 0.0
        assert len(m["recent_errors"]) == 1
        assert m["recent_errors"][0]["error"] == "Timeout"

    def test_mixed_success_rate(self):
        """3 successes + 2 failures = 60% success rate."""
        for _ in range(3):
            self.mm.record("A", "act", True, 10.0)
        for _ in range(2):
            self.mm.record("A", "act", False, 10.0, error="fail")

        m = self.mm.get_metrics()
        assert m["success_rate"] == 0.6
        assert m["failure_rate"] == 0.4

    def test_rolling_window_eviction(self):
        """Window size = 10, so inserting 15 records should keep only 10."""
        for i in range(15):
            self.mm.record("A", "act", True, float(i))

        m = self.mm.get_metrics()
        assert m["window_requests"] == 10
        assert m["total_requests"] == 15  # Lifetime counter preserves all


# ================================================================
# TEST GROUP 2: Response Time Analytics
# ================================================================

class TestResponseTimeAnalytics:

    def setup_method(self):
        self.mm = MetricsManager(window_size=100)

    def test_avg_response_time(self):
        """Average of [100, 200, 300] = 200ms."""
        self.mm.record("A", "act", True, 100.0)
        self.mm.record("A", "act", True, 200.0)
        self.mm.record("A", "act", True, 300.0)

        m = self.mm.get_metrics()
        assert m["avg_response_time_ms"] == 200.0

    def test_p95_response_time(self):
        """P95 of 20 records should be the 19th sorted value."""
        for i in range(1, 21):
            self.mm.record("A", "act", True, float(i * 10))

        m = self.mm.get_metrics()
        assert m["p95_response_time_ms"] == 190.0  # 19th of 20


# ================================================================
# TEST GROUP 3: Slowest Agents
# ================================================================

class TestSlowestAgents:

    def setup_method(self):
        self.mm = MetricsManager(window_size=100)

    def test_slowest_agents_ranked(self):
        """Agents must be ranked by average duration, descending."""
        self.mm.record("FAST", "act", True, 10.0)
        self.mm.record("FAST", "act", True, 20.0)
        self.mm.record("SLOW", "act", True, 500.0)
        self.mm.record("SLOW", "act", True, 600.0)
        self.mm.record("MED", "act", True, 100.0)

        m = self.mm.get_metrics()
        agents = m["slowest_agents"]

        assert len(agents) == 3
        assert agents[0]["agent_id"] == "SLOW"
        assert agents[0]["avg_ms"] == 550.0
        assert agents[1]["agent_id"] == "MED"
        assert agents[2]["agent_id"] == "FAST"
        assert agents[2]["avg_ms"] == 15.0


# ================================================================
# TEST GROUP 4: Retry & Fallback Frequency
# ================================================================

class TestRetryFallbackFrequency:

    def setup_method(self):
        self.mm = MetricsManager(window_size=100)

    def test_retry_frequency(self):
        """2 requests with 3 total retries = 1.5 retry frequency."""
        self.mm.record("A", "act", True, 10.0, retries=1)
        self.mm.record("A", "act", True, 10.0, retries=2)

        m = self.mm.get_metrics()
        assert m["retry_frequency"] == 1.5

    def test_fallback_frequency(self):
        """1 out of 4 requests used fallback = 25%."""
        self.mm.record("A", "act", True, 10.0)
        self.mm.record("A", "act", True, 10.0)
        self.mm.record("A", "act", True, 10.0, used_fallback=True)
        self.mm.record("A", "act", True, 10.0)

        m = self.mm.get_metrics()
        assert m["fallback_frequency"] == 0.25


# ================================================================
# TEST GROUP 5: Agent Integration (Live Metrics from BaseAgent)
# ================================================================

class TestAgentMetricsIntegration:

    @pytest.mark.asyncio
    async def test_agent_execution_records_metrics(self):
        """execute_with_validation must auto-record into MetricsManager."""
        mm_before = metrics_manager.get_metrics()["total_requests"]

        agent = FastAgent()
        await agent.execute_with_validation("test_action", {})

        mm_after = metrics_manager.get_metrics()["total_requests"]
        assert mm_after > mm_before, "MetricsManager was not updated after agent execution"

    @pytest.mark.asyncio
    async def test_failed_agent_records_failure(self):
        """A failed agent must record a failure metric."""
        agent = BrokenAgent()
        await agent.execute_with_validation("doomed", {}, max_retries=0)

        m = metrics_manager.get_metrics()
        assert m["total_requests"] > 0
        assert len(m["recent_errors"]) > 0


# ================================================================
# TEST GROUP 6: Dashboard Formatting
# ================================================================

class TestDashboardFormatting:

    def test_print_metrics_contains_sections(self):
        """print_metrics must contain all dashboard sections."""
        mm = MetricsManager()
        mm.record("TEST_AGENT", "act", True, 42.0)
        mm.record("TEST_AGENT", "act", False, 99.0, error="Boom")

        output = mm.print_metrics()

        assert "JARVIS RUNTIME METRICS" in output
        assert "Success Rate" in output
        assert "Failure Rate" in output
        assert "Avg Response Time" in output
        assert "P95 Response Time" in output
        assert "SLOWEST AGENTS" in output
        assert "RECENT ERRORS" in output
        assert "TEST_AGENT" in output

    def test_empty_metrics_no_crash(self):
        """print_metrics on empty data must not crash."""
        mm = MetricsManager()
        output = mm.print_metrics()
        assert "No agent data yet" in output

    def test_reset_clears_everything(self):
        """reset() must zero out all counters and records."""
        mm = MetricsManager()
        mm.record("A", "act", True, 10.0)
        mm.reset()

        m = mm.get_metrics()
        assert m["total_requests"] == 0
        assert m["window_requests"] == 0
