"""
test_04_memory.py — Modular Cognitive Memory System Tests
PHASE 1: Rewritten to test MANAGER.memory.* (modular system) directly.
"""
import pytest
import asyncio
import time
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from MANAGER.memory import MemoryManager
from MANAGER.memory.schemas import MemoryRecord, ScoredMemory, Turn


# ================================================================
# TEST GROUP 1: Working Memory (Sliding Window)
# ================================================================

class TestWorkingMemory:
    """Tests the sliding-window working memory module."""

    def test_add_and_retrieve_turns(self):
        """Turns added to working memory should be retrievable."""
        mm = MemoryManager()
        mm.add_turn("user", "Hello JARVIS")
        mm.add_turn("assistant", "Hello Sir, how can I help?")

        window = mm.working.get_sliding_window()
        assert len(window) == 2
        assert window[0].role == "user"
        assert window[0].content == "Hello JARVIS"
        assert window[1].role == "assistant"

    def test_sliding_window_limit(self):
        """Window should not exceed max_window size."""
        mm = MemoryManager()
        # Default max_window is 40
        for i in range(50):
            mm.add_turn("user", f"Message {i}")
        
        window = mm.working.get_sliding_window()
        assert len(window) == 40
        # Should have kept the most recent
        assert "Message 49" in window[-1].content

    def test_clear_working_memory(self):
        """Clearing should empty the window and reset topic."""
        mm = MemoryManager()
        mm.add_turn("user", "Test message")
        assert len(mm.working.get_sliding_window()) == 1

        mm.working.clear()
        assert len(mm.working.get_sliding_window()) == 0
        assert mm.working.current_topic == "general"

    def test_set_topic(self):
        """Topic should be updatable."""
        mm = MemoryManager()
        mm.working.set_topic("weather")
        assert mm.working.current_topic == "weather"

    def test_session_id_resets_on_clear(self):
        """Session ID should change when cleared."""
        mm = MemoryManager()
        old_session = mm.working.session_id
        time.sleep(1.1)  # Ensure different timestamp
        mm.working.clear()
        assert mm.working.session_id != old_session

    def test_thread_safety(self):
        """Multiple threads adding turns should not corrupt state."""
        import threading
        mm = MemoryManager()
        errors = []

        def add_turns(start):
            try:
                for i in range(100):
                    mm.add_turn("user", f"Thread-{start}-Msg-{i}")
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=add_turns, args=(t,)) for t in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        window = mm.working.get_sliding_window()
        # 500 messages added, max_window is 40
        assert len(window) == 40


# ================================================================
# TEST GROUP 2: Fact Memory
# ================================================================

class TestFactMemory:
    """Tests structural fact storage and retrieval."""

    def test_learn_and_recall_fact(self):
        """A learned fact must be retrievable."""
        mm = MemoryManager()
        asyncio.run(mm.learn_fact("favorite_language", "Python", confidence=1.0, source="test"))

        facts = asyncio.run(mm.facts.exact_match("favorite_language"))
        assert len(facts) >= 1
        assert any(f.value == "Python" for f in facts)

    def test_fact_overwrite(self):
        """Updating a fact must replace the old value."""
        mm = MemoryManager()
        asyncio.run(mm.learn_fact("location", "New York", confidence=0.8))
        asyncio.run(mm.learn_fact("location", "London", confidence=1.0))

        facts = asyncio.run(mm.facts.exact_match("location"))
        # Should have the latest value
        assert any(f.value == "London" for f in facts)


# ================================================================
# TEST GROUP 3: Context Assembler
# ================================================================

class TestContextAssembler:
    """Tests the context assembly pipeline."""

    def test_assemble_basic(self):
        """Assembler should produce a valid message list."""
        mm = MemoryManager()
        mm.add_turn("user", "What is the weather?")
        mm.add_turn("assistant", "It is sunny today.")

        payload = asyncio.run(mm.build_ai_context(
            system_prompt="You are JARVIS.",
            current_query="Weather update"
        ))

        assert isinstance(payload, list)
        assert len(payload) >= 1  # At least system prompt
        assert payload[0]["role"] == "system"
        assert "JARVIS" in payload[0]["content"]

    def test_assemble_includes_turns(self):
        """Assembled payload should include conversation turns."""
        mm = MemoryManager()
        mm.add_turn("user", "Hello")
        mm.add_turn("assistant", "Hi there")

        payload = asyncio.run(mm.build_ai_context(
            system_prompt="System",
            current_query="test"
        ))

        roles = [msg["role"] for msg in payload]
        assert "user" in roles
        assert "assistant" in roles

    def test_assemble_token_limit(self):
        """Assembler should not exceed token budget."""
        mm = MemoryManager()
        # Add a lot of turns
        for i in range(100):
            mm.add_turn("user", f"Long message number {i} " * 50)
            mm.add_turn("assistant", f"Response {i} " * 50)

        payload = asyncio.run(mm.build_ai_context(
            system_prompt="Short system prompt",
            current_query="test"
        ))

        # Total char count should be bounded (4000 tokens * 4 chars = 16000 chars)
        total_chars = sum(len(msg["content"]) for msg in payload)
        assert total_chars <= 20000  # Allow some margin


# ================================================================
# TEST GROUP 4: End Session
# ================================================================

class TestSessionLifecycle:
    """Tests session management."""

    def test_end_session_clears_working(self):
        """Ending a session should clear working memory."""
        mm = MemoryManager()
        mm.add_turn("user", "Test")
        mm.end_session()

        assert len(mm.working.get_sliding_window()) == 0

    def test_stop_halts_decay(self):
        """stop() should mark decay as not running."""
        mm = MemoryManager()
        mm.stop()
        assert mm.decay._running is False


# ================================================================
# TEST GROUP 5: Schema Validation
# ================================================================

class TestSchemas:
    """Tests that dataclass schemas work correctly."""

    def test_memory_record_creation(self):
        record = MemoryRecord(
            id="test_1",
            content="Test content",
            type="episodic",
            timestamp=time.time(),
            importance=0.7,
            trace_id="trace_123"
        )
        assert record.id == "test_1"
        assert record.type == "episodic"
        assert record.importance == 0.7

    def test_turn_creation(self):
        turn = Turn(role="user", content="Hello")
        assert turn.role == "user"
        assert turn.timestamp > 0

    def test_scored_memory_creation(self):
        record = MemoryRecord(
            id="test_2", content="Content", type="fact",
            timestamp=time.time(), importance=1.0, trace_id=""
        )
        scored = ScoredMemory(record=record, score=0.95)
        assert scored.score == 0.95
        assert scored.record.type == "fact"


# ================================================================
# TEST GROUP 6: Legacy Wrapper Backward Compatibility
# ================================================================

class TestLegacyWrappers:
    """Ensures deprecated wrappers still function for backward compat."""

    def test_legacy_memory_manager_import(self):
        """Legacy import path should still work."""
        from MANAGER.memory_manager import MemoryManager as LegacyMM
        mm = LegacyMM()
        assert mm is not None

    def test_legacy_context_manager_import(self):
        """Legacy import path should still work."""
        from MANAGER.context_manager import ContextManager
        cm = ContextManager()
        assert cm is not None

    def test_legacy_add_interaction(self):
        """Legacy add_interaction should not crash."""
        from MANAGER.memory_manager import MemoryManager as LegacyMM
        mm = LegacyMM()
        mm.add_interaction("Hello", "Hi there", emotion="neutral")
        # Should have forwarded to working memory
        window = mm._memory.working.get_sliding_window()
        assert len(window) >= 2

    def test_legacy_remember_short(self):
        """Legacy remember_short should forward to working memory."""
        from MANAGER.memory_manager import MemoryManager as LegacyMM
        mm = LegacyMM()
        mm.remember_short("User", "Hello JARVIS")
        mm.remember_short("JARVIS", "Hello Sir")

        messages = mm.get_context_for_ai(limit=10)
        assert len(messages) == 2
        assert messages[0]["role"] == "user"
        assert messages[1]["role"] == "assistant"

    def test_legacy_get_stats(self):
        """Legacy get_stats should return valid dict."""
        from MANAGER.memory_manager import MemoryManager as LegacyMM
        mm = LegacyMM()
        mm.remember_short("User", "A")
        mm.remember_short("User", "B")

        stats = mm.get_stats()
        assert "short_term_entries" in stats
        assert stats["short_term_entries"] == 2
