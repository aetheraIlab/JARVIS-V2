import pytest
import asyncio
import time
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse


# ================================================================
# MOCK AGENTS (Tasks that take a known duration)
# ================================================================

class SlowAgentA(BaseAgent):
    """Takes exactly ~1 second to complete."""
    AGENT_ID = "SLOW_A"
    AGENT_NAME = "Slow Agent A"

    async def execute(self, action: str, params: dict) -> AgentResponse:
        start = time.monotonic()
        await asyncio.sleep(1.0)
        elapsed = time.monotonic() - start
        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action=action,
            result=f"A_DONE", metadata={"start": start, "elapsed": elapsed}
        )


class SlowAgentB(BaseAgent):
    """Takes exactly ~1 second to complete."""
    AGENT_ID = "SLOW_B"
    AGENT_NAME = "Slow Agent B"

    async def execute(self, action: str, params: dict) -> AgentResponse:
        start = time.monotonic()
        await asyncio.sleep(1.0)
        elapsed = time.monotonic() - start
        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action=action,
            result=f"B_DONE", metadata={"start": start, "elapsed": elapsed}
        )


class SlowAgentC(BaseAgent):
    """Takes exactly ~1 second to complete."""
    AGENT_ID = "SLOW_C"
    AGENT_NAME = "Slow Agent C"

    async def execute(self, action: str, params: dict) -> AgentResponse:
        start = time.monotonic()
        await asyncio.sleep(1.0)
        elapsed = time.monotonic() - start
        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action=action,
            result=f"C_DONE", metadata={"start": start, "elapsed": elapsed}
        )


# ================================================================
# TEST GROUP: Parallel Execution
# ================================================================

class TestParallelExecution:
    """Validates that agents truly run concurrently, not sequentially."""

    @pytest.mark.asyncio
    async def test_three_agents_parallel_faster_than_sequential(self):
        """
        3 agents each sleep 1s.
        Sequential would take >=3s. Parallel should take ~1s.
        STRICT: total time MUST be < 2.0s (proving true concurrency).
        """
        a = SlowAgentA()
        b = SlowAgentB()
        c = SlowAgentC()

        wall_start = time.monotonic()

        results = await asyncio.gather(
            a.execute_with_state("task", {}),
            b.execute_with_state("task", {}),
            c.execute_with_state("task", {}),
        )

        wall_elapsed = time.monotonic() - wall_start

        # All must succeed
        for i, res in enumerate(results):
            assert res.success is True, f"Agent {i} failed: {res.error}"

        # Results must contain expected markers
        result_texts = [r.result for r in results]
        assert "A_DONE" in result_texts
        assert "B_DONE" in result_texts
        assert "C_DONE" in result_texts

        # STRICT TIME ASSERTION: Must be parallel
        assert wall_elapsed < 2.0, \
            f"NOT PARALLEL! 3x1s tasks took {wall_elapsed:.2f}s (should be <2.0s)"

        # STRICT: Must be faster than sequential baseline
        sequential_baseline = 3.0
        speedup = sequential_baseline / wall_elapsed
        assert speedup > 1.5, \
            f"Speedup too low: {speedup:.2f}x (expected >1.5x)"

    @pytest.mark.asyncio
    async def test_task_overlap_detected(self):
        """
        Verify that tasks actually overlapped in time (not just fast).
        We record the start timestamp of each task and assert overlap.
        """
        a = SlowAgentA()
        b = SlowAgentB()

        ref_time = time.monotonic()

        results = await asyncio.gather(
            a.execute_with_state("task", {}),
            b.execute_with_state("task", {}),
        )

        # Both must succeed
        assert results[0].success and results[1].success

        # Extract start times from metadata
        start_a = results[0].metadata.get("start", 0)
        start_b = results[1].metadata.get("start", 0)

        # OVERLAP ASSERTION: Both tasks must have started within 0.2s of each other
        start_delta = abs(start_a - start_b)
        assert start_delta < 0.2, \
            f"Tasks did NOT overlap! Start delta: {start_delta:.3f}s (should be <0.2s)"
