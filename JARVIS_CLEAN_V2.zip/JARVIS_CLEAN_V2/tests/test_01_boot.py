"""
test_01_boot.py — JARVIS Boot Validation Test
PHASE 1 FIX: Updated to use modular memory system references.
"""
import pytest
from MANAGER.memory import MemoryManager
from MANAGER.skill_manager import SkillManager
from MANAGER.task_manager import TaskManager


@pytest.mark.asyncio
async def test_president_boot(president):
    """Verifies that the PresidentAgent boots correctly and initializes core managers."""
    assert president is not None
    assert president.is_online is False  # Should be offline until started
    assert president.running is False
    
    # Verify RAM Managers — PHASE 1: memory is now MemoryManager from MANAGER.memory
    assert isinstance(president.memory, MemoryManager)
    assert isinstance(president.skills, SkillManager)
    assert isinstance(president.tasks, TaskManager)
    
    # Verify modular memory sub-systems exist
    assert hasattr(president.memory, 'working')
    assert hasattr(president.memory, 'episodic')
    assert hasattr(president.memory, 'semantic')
    assert hasattr(president.memory, 'facts')
    assert hasattr(president.memory, 'retrieval')
    assert hasattr(president.memory, 'assembler')
    assert hasattr(president.memory, 'decay')
    
    # Verify core skills registered
    skills = president.skills.get_all_skills()
    assert len(skills) > 0
    assert any("web_search" in str(s) for s in skills)
