import pytest
import asyncio
import os
import sys

# Ensure JARVIS root is in path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from HEAP.database import Atlas
from HEAP.cache import CacheNode
from KERNEL.scheduler import SignalBus
from KERNEL.president_agent import PresidentAgent

@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for each test case."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture
def test_atlas():
    """Provides a fresh in-memory Atlas database for each test."""
    atlas = Atlas(db_path=":memory:")
    # Initialize basic schema needed for testing
    atlas.conn.execute("CREATE TABLE IF NOT EXISTS signal_logs (id INTEGER PRIMARY KEY, module TEXT, type TEXT, status TEXT, payload TEXT, timestamp TEXT)")
    atlas.conn.commit()
    yield atlas

@pytest.fixture
def test_cache():
    """Provides a clean CacheNode."""
    cache = CacheNode()
    cache.clear()
    yield cache

@pytest.fixture
def test_bus(test_atlas, test_cache):
    """Provides a fresh SignalBus."""
    bus = SignalBus()
    yield bus

@pytest.fixture
def president(test_bus, test_atlas, test_cache):
    """Provides an initialized PresidentAgent."""
    agent = PresidentAgent(bus=test_bus, atlas=test_atlas, cache=test_cache)
    yield agent
