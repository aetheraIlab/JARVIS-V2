import pytest
import asyncio
import time
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse


# ================================================================
# MOCK AGENTS
# ================================================================

class RetrySuccessAgent(BaseAgent):
    """Fails N times, then succeeds. Tracks exact attempt count."""
    AGENT_ID = "RETRY_SUCCESS"
    AGENT_NAME = "Retry Success Agent"

    def __init__(self, fail_count=2):
        super().__init__()
        self.fail_count = fail_count
        self.attempt_log = []

    async def execute(self, action: str, params: dict) -> AgentResponse:
        attempt = len(self.attempt_log) + 1
        self.attempt_log.append({"attempt": attempt, "action": action, "time": time.monotonic()})

        if action == "primary" and attempt <= self.fail_count:
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action=action,
                error=f"Simulated failure #{attempt}"
            )
        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action=action,
            result=f"Success on attempt {attempt}"
        )


class PermanentFailAgent(BaseAgent):
    """Always fails on primary. Succeeds on fallback. Tracks all calls."""
    AGENT_ID = "PERM_FAIL"
    AGENT_NAME = "Permanent Fail Agent"

    def __init__(self):
        super().__init__()
        self.call_log = []

    async def execute(self, action: str, params: dict) -> AgentResponse:
        self.call_log.append({"action": action, "time": time.monotonic()})

        if action == "primary":
            return AgentResponse(
                success=False, agent_id=self.AGENT_ID, action=action,
                error="Permanent API failure"
            )
        elif action == "fallback":
            return AgentResponse(
                success=True, agent_id=self.AGENT_ID, action=action,
                result="Fallback data retrieved successfully"
            )
        return AgentResponse(success=False, agent_id=self.AGENT_ID, action=action, error="Unknown")


class TotalFailAgent(BaseAgent):
    """Fails on ALL actions, including fallback."""
    AGENT_ID = "TOTAL_FAIL"
    AGENT_NAME = "Total Fail Agent"

    def __init__(self):
        super().__init__()
        self.call_log = []

    async def execute(self, action: str, params: dict) -> AgentResponse:
        self.call_log.append(action)
        return AgentResponse(
            success=False, agent_id=self.AGENT_ID, action=action,
            error=f"Total failure on {action}"
        )


# ================================================================
# TEST GROUP 1: Retry Mechanics
# ================================================================

class TestRetryMechanics:
    """Validates the exponential backoff retry loop."""

    @pytest.mark.asyncio
    async def test_retry_count_exact(self):
        """Agent must be called exactly (max_retries + 1) times before giving up."""
        agent = RetrySuccessAgent(fail_count=99)  # Will never succeed

        res = await agent.execute_with_validation("primary", {}, max_retries=3)

        assert res.success is False
        # max_retries=3 means 4 total attempts (0, 1, 2, 3)
        assert len(agent.attempt_log) == 4, \
            f"Expected exactly 4 attempts, got {len(agent.attempt_log)}"
        assert res.retries == 4, \
            f"Expected retries=4, got {res.retries}"

    @pytest.mark.asyncio
    async def test_retry_succeeds_on_last_attempt(self):
        """Agent fails twice, succeeds on 3rd. Retries field must be 2."""
        agent = RetrySuccessAgent(fail_count=2)

        res = await agent.execute_with_validation("primary", {}, max_retries=2)

        assert res.success is True, f"Should have succeeded on 3rd attempt: {res.error}"
        assert res.retries == 2, f"Expected retries=2, got {res.retries}"
        assert res.confidence == 1.0, "Primary success should have full confidence"
        assert res.used_fallback is False
        assert len(agent.attempt_log) == 3, \
            f"Expected 3 attempts (2 fails + 1 success), got {len(agent.attempt_log)}"

    @pytest.mark.asyncio
    async def test_retry_succeeds_on_first_attempt(self):
        """If agent succeeds immediately, retries must be 0."""
        agent = RetrySuccessAgent(fail_count=0)

        res = await agent.execute_with_validation("primary", {}, max_retries=5)

        assert res.success is True
        assert res.retries == 0, f"Expected retries=0, got {res.retries}"
        assert len(agent.attempt_log) == 1

    @pytest.mark.asyncio
    async def test_exponential_backoff_timing(self):
        """
        Verify that retry delays follow exponential backoff.
        With base_delay=1.0: wait 1s, then 2s between retries.
        Total for 3 attempts should be ~3s (1 + 2).
        """
        agent = RetrySuccessAgent(fail_count=99)

        start = time.monotonic()
        res = await agent.execute_with_validation("primary", {}, max_retries=2)
        elapsed = time.monotonic() - start

        assert res.success is False
        # Exponential backoff: sleep(1.0) + sleep(2.0) = 3.0s minimum
        assert elapsed >= 2.5, \
            f"Backoff too fast: {elapsed:.2f}s (expected >=2.5s for exponential delays)"
        assert elapsed < 6.0, \
            f"Backoff too slow: {elapsed:.2f}s (expected <6.0s)"


# ================================================================
# TEST GROUP 2: Fallback Path
# ================================================================

class TestFallbackPath:
    """Validates that the fallback mechanism triggers correctly."""

    @pytest.mark.asyncio
    async def test_fallback_triggered_after_exhausted_retries(self):
        """When primary fails all retries, fallback must be called."""
        agent = PermanentFailAgent()

        res = await agent.execute_with_validation(
            "primary", {}, max_retries=1, fallback_action="fallback"
        )

        assert res.success is True, f"Fallback should have succeeded: {res.error}"
        assert res.used_fallback is True, "used_fallback flag must be True"
        assert res.confidence == 0.5, f"Fallback confidence should be 0.5, got {res.confidence}"
        assert res.result == "Fallback data retrieved successfully"

        # Verify the call sequence: primary was tried (max_retries+1) times, then fallback once
        primary_calls = [c for c in agent.call_log if c["action"] == "primary"]
        fallback_calls = [c for c in agent.call_log if c["action"] == "fallback"]
        assert len(primary_calls) == 2, f"Expected 2 primary calls, got {len(primary_calls)}"
        assert len(fallback_calls) == 1, f"Expected 1 fallback call, got {len(fallback_calls)}"

    @pytest.mark.asyncio
    async def test_no_fallback_when_primary_succeeds(self):
        """If primary succeeds, fallback must NEVER be called."""
        agent = RetrySuccessAgent(fail_count=0)

        res = await agent.execute_with_validation(
            "primary", {}, max_retries=2, fallback_action="fallback"
        )

        assert res.success is True
        assert res.used_fallback is False
        assert res.confidence == 1.0
        # Only 1 call should have been made (the successful primary)
        assert len(agent.attempt_log) == 1

    @pytest.mark.asyncio
    async def test_both_primary_and_fallback_fail(self):
        """When BOTH primary and fallback fail, confidence must be 0.0."""
        agent = TotalFailAgent()

        res = await agent.execute_with_validation(
            "primary", {}, max_retries=0, fallback_action="fallback"
        )

        assert res.success is False
        assert res.used_fallback is True
        assert res.confidence == 0.0, f"Total failure confidence should be 0.0, got {res.confidence}"

        # Verify both were attempted
        assert "primary" in agent.call_log
        assert "fallback" in agent.call_log

    @pytest.mark.asyncio
    async def test_no_fallback_provided(self):
        """When no fallback_action is given and primary fails, response must have confidence=0.0."""
        agent = PermanentFailAgent()

        res = await agent.execute_with_validation(
            "primary", {}, max_retries=0, fallback_action=None
        )

        assert res.success is False
        assert res.used_fallback is False
        assert res.confidence == 0.0
        assert "max retries" in res.error.lower() or "exceeded" in res.error.lower()


# ================================================================
# TEST GROUP 3: Response Schema Integrity
# ================================================================

class TestResponseSchema:
    """Validates that AgentResponse fields are always populated correctly."""

    @pytest.mark.asyncio
    async def test_response_fields_on_success(self):
        """Successful response must have all validation fields set."""
        agent = RetrySuccessAgent(fail_count=0)
        res = await agent.execute_with_validation("primary", {})

        assert hasattr(res, "confidence")
        assert hasattr(res, "retries")
        assert hasattr(res, "used_fallback")
        assert isinstance(res.confidence, float)
        assert isinstance(res.retries, int)
        assert isinstance(res.used_fallback, bool)

    @pytest.mark.asyncio
    async def test_to_dict_includes_validation_fields(self):
        """to_dict() must include the new validation fields."""
        agent = RetrySuccessAgent(fail_count=0)
        res = await agent.execute_with_validation("primary", {})
        d = res.to_dict()

        assert "confidence" in d, "to_dict() missing 'confidence'"
        assert "retries" in d, "to_dict() missing 'retries'"
        assert "used_fallback" in d, "to_dict() missing 'used_fallback'"
