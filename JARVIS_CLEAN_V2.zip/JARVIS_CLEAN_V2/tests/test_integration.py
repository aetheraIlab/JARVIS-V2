# ================================================================
# JARVIS AETHER-CORE V2.0 — MASTER INTEGRATION TEST
# ================================================================
# Verifies every module created in Phases 1-4 imports correctly,
# the registry discovers agents, and the infrastructure boots.
# ================================================================

import sys
import os
import time

# ── Project root on sys.path ─────────────────────────────────────
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# ── Load .env ────────────────────────────────────────────────────
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(PROJECT_ROOT, ".env"))
except ImportError:
    pass

# ── Test Harness ─────────────────────────────────────────────────
PASS = "\033[92m[OK] PASS\033[0m"
FAIL = "\033[91m[FAIL] FAIL\033[0m"
WARN = "\033[93m[WARN] WARN\033[0m"

results = []

def test(name, fn):
    """Run a test function and record the result."""
    try:
        result = fn()
        if result is True:
            print(f"  {PASS}  {name}")
            results.append(("PASS", name))
        elif result is None:
            # Treat None as pass (function ran without error)
            print(f"  {PASS}  {name}")
            results.append(("PASS", name))
        else:
            print(f"  {WARN}  {name} — {result}")
            results.append(("WARN", name, result))
    except Exception as e:
        print(f"  {FAIL}  {name} — {e}")
        results.append(("FAIL", name, str(e)))


# ================================================================
# PHASE 1: SECURITY HARDENING
# ================================================================
print("\n" + "=" * 60)
print(" PHASE 1: Security Hardening")
print("=" * 60)

def test_secure_config_import():
    from CONFIG.secure_config import config
    return True

def test_secure_config_has_keys():
    from CONFIG.secure_config import config
    assert hasattr(config, "groq_key"), "Missing groq_key property"
    assert hasattr(config, "gemini_key"), "Missing gemini_key property"
    assert hasattr(config, "has_groq"), "Missing has_groq property"
    assert hasattr(config, "has_gemini"), "Missing has_gemini property"
    return True

def test_env_file_exists():
    env_path = os.path.join(PROJECT_ROOT, ".env")
    assert os.path.exists(env_path), f".env not found at {env_path}"
    return True

test("CONFIG/secure_config.py imports", test_secure_config_import)
test("SecureConfig has all properties", test_secure_config_has_keys)
test(".env file exists", test_env_file_exists)

# ================================================================
# PHASE 2: SWARM STABILIZATION
# ================================================================
print("\n" + "=" * 60)
print(" PHASE 2: Swarm Stabilization")
print("=" * 60)

def test_state_machine_import():
    from AGENT.state_machine import AgentStateMachine, AgentState
    return True

def test_state_machine_transitions():
    from AGENT.state_machine import AgentStateMachine, AgentState
    sm = AgentStateMachine("TEST_AGENT")
    assert sm.current_state == AgentState.CREATED
    sm.transition(AgentState.INITIALIZING, reason="test")
    assert sm.current_state == AgentState.INITIALIZING
    sm.transition(AgentState.IDLE, reason="test")
    assert sm.current_state == AgentState.IDLE
    sm.transition(AgentState.BUSY, reason="test")
    assert sm.current_state == AgentState.BUSY
    return True

def test_heartbeat_import():
    from AGENT.heartbeat import HeartbeatMonitor, heartbeat_monitor
    return True

def test_heartbeat_register():
    from AGENT.heartbeat import heartbeat_monitor
    heartbeat_monitor.register_agent("TEST_INTEGRATION", metadata={"test": True})
    heartbeat_monitor.heartbeat("TEST_INTEGRATION")
    status = heartbeat_monitor.get_health_status()
    assert "TEST_INTEGRATION" in status.get("agents", {}), "Agent not found in health status"
    return True

def test_base_agent_import():
    from AGENT.base_agent import BaseAgent
    return True

def test_registry_import():
    from AGENT.registry import AgentRegistry, agent_registry
    return True

def test_health_dashboard_import():
    from MONITOR.health_dashboard import print_health_dashboard, print_compact_status, get_dashboard_data
    return True

def test_dashboard_data():
    from MONITOR.health_dashboard import get_dashboard_data
    data = get_dashboard_data()
    assert "timestamp" in data, "Missing timestamp"
    assert "summary" in data, "Missing summary"
    assert "agents" in data, "Missing agents"
    return True

test("AGENT/state_machine.py imports", test_state_machine_import)
test("AgentStateMachine transitions work", test_state_machine_transitions)
test("AGENT/heartbeat.py imports", test_heartbeat_import)
test("HeartbeatMonitor register + heartbeat", test_heartbeat_register)
test("AGENT/base_agent.py imports", test_base_agent_import)
test("AGENT/registry.py imports", test_registry_import)
test("MONITOR/health_dashboard.py imports", test_health_dashboard_import)
test("get_dashboard_data() returns valid data", test_dashboard_data)

# ================================================================
# PHASE 3: AGENT DISCOVERY
# ================================================================
print("\n" + "=" * 60)
print(" PHASE 3: Agent Discovery & New Agents")
print("=" * 60)

def test_agent_discovery():
    from pathlib import Path
    from AGENT.registry import agent_registry
    discovered = agent_registry.discover_agents(Path(PROJECT_ROOT) / "AGENT" / "agents")
    return True

def test_new_agents_calendar():
    from AGENT.agents.calendar_agent import CalendarAgent
    assert CalendarAgent.AGENT_ID == "CALENDAR_AGENT"
    return True

def test_new_agents_weather():
    from AGENT.agents.weather_agent import WeatherAgent
    assert WeatherAgent.AGENT_ID == "WEATHER_AGENT"
    return True

def test_new_agents_news():
    from AGENT.agents.news_agent import NewsAgent
    assert NewsAgent.AGENT_ID == "NEWS_AGENT"
    return True

def test_new_agents_finance():
    from AGENT.agents.finance_agent import FinanceAgent
    assert FinanceAgent.AGENT_ID == "FINANCE_AGENT"
    return True

def test_new_agents_planner():
    from AGENT.agents.planner_agent import PlannerAgent
    assert PlannerAgent.AGENT_ID == "PLANNER_AGENT"
    return True

def test_registry_capabilities():
    from AGENT.registry import agent_registry
    caps = agent_registry.get_capabilities()
    assert len(caps) > 0, "No capabilities registered"
    return True

def test_registry_list():
    from AGENT.registry import agent_registry
    agents = agent_registry.list_agents()
    return f"{len(agents)} agents registered: {agents}"

test("Agent auto-discovery runs", test_agent_discovery)
test("CalendarAgent imports + AGENT_ID", test_new_agents_calendar)
test("WeatherAgent imports + AGENT_ID", test_new_agents_weather)
test("NewsAgent imports + AGENT_ID", test_new_agents_news)
test("FinanceAgent imports + AGENT_ID", test_new_agents_finance)
test("PlannerAgent imports + AGENT_ID", test_new_agents_planner)
test("Registry has capabilities", test_registry_capabilities)
test("Registry agent list", test_registry_list)

# ================================================================
# PHASE 4: VISION SYSTEM
# ================================================================
print("\n" + "=" * 60)
print(" PHASE 4: Vision System")
print("=" * 60)

def test_vision_import():
    from SENSOR.vision import MultiBackendVision, vision_system
    return True

def test_vision_status():
    from SENSOR.vision import vision_system
    status = vision_system.get_status()
    assert "is_available" in status, "Missing is_available"
    assert "backend" in status, "Missing backend"
    return True

def test_vision_legacy_compat():
    from SENSOR.vision import Optic
    assert Optic is not None, "Legacy Optic alias missing"
    return True

test("SENSOR/vision.py imports", test_vision_import)
test("vision_system.get_status() works", test_vision_status)
test("Legacy Optic alias exists", test_vision_legacy_compat)

# ================================================================
# CROSS-SYSTEM INTEGRATION
# ================================================================
print("\n" + "=" * 60)
print(" CROSS-SYSTEM: Integration Points")
print("=" * 60)

def test_inference_pipeline():
    from INFERENCE.pipeline import Arbiter
    return True

def test_kernel_scheduler():
    from KERNEL.scheduler import SignalBus
    bus = SignalBus()
    assert hasattr(bus, "emit"), "SignalBus missing emit"
    assert hasattr(bus, "subscribe"), "SignalBus missing subscribe"
    return True

def test_kernel_router():
    from KERNEL.router import KernelCore
    return True

test("INFERENCE/pipeline.py (Arbiter) imports", test_inference_pipeline)
test("KERNEL/scheduler.py (SignalBus) imports", test_kernel_scheduler)
test("KERNEL/router.py (KernelCore) imports", test_kernel_router)


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print(" TEST SUMMARY")
    print("=" * 60)

    passed = sum(1 for r in results if r[0] == "PASS")
    warned = sum(1 for r in results if r[0] == "WARN")
    failed = sum(1 for r in results if r[0] == "FAIL")
    total = len(results)

    print(f"\n  Total:   {total}")
    print(f"  Passed:  {passed}")
    print(f"  Warned:  {warned}")
    print(f"  Failed:  {failed}")

    if failed == 0:
        print(f"\n  \033[92m[OK] ALL CRITICAL TESTS PASSED\033[0m\n")
    else:
        print(f"\n  \033[91m[WARN] {failed} TESTS FAILED — See above for details\033[0m")
        print("  Failed tests:")
        for r in results:
            if r[0] == "FAIL":
                print(f"    [FAIL] {r[1]}: {r[2]}")
        print()

    sys.exit(0 if failed == 0 else 1)
