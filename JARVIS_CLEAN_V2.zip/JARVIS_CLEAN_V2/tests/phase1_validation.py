"""
JARVIS PHASE 1 — Comprehensive Runtime Validation Suite
========================================================
Covers:
  1. Full runtime boot test
  2. Memory retrieval benchmark
  3. Long conversation stress test
  
Run: python tests/phase1_validation.py
"""
import sys
import os
import time
import asyncio
import threading
import json
import traceback
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ── Colors ──
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"


def section(title):
    print(f"\n{'='*70}")
    print(f"  {BOLD}{CYAN}{title}{RESET}")
    print(f"{'='*70}")


def result(name, passed, detail="", elapsed=0.0):
    icon = f"{GREEN}PASS{RESET}" if passed else f"{RED}FAIL{RESET}"
    time_str = f" ({elapsed:.3f}s)" if elapsed > 0 else ""
    print(f"  [{icon}] {name}{time_str}")
    if detail:
        print(f"         {DIM}{detail}{RESET}")
    return passed


class BenchmarkReport:
    """Collects results from all test phases."""
    def __init__(self):
        self.results = []
        self.start_time = time.time()

    def add(self, category, name, passed, detail="", elapsed=0.0):
        self.results.append({
            "category": category,
            "name": name,
            "passed": passed,
            "detail": detail,
            "elapsed_s": round(elapsed, 4),
        })
        result(name, passed, detail, elapsed)

    def summary(self):
        total = len(self.results)
        passed = sum(1 for r in self.results if r["passed"])
        failed = total - passed
        wall_time = round(time.time() - self.start_time, 2)
        return {
            "total_tests": total,
            "passed": passed,
            "failed": failed,
            "pass_rate": f"{(passed/total*100):.1f}%" if total else "N/A",
            "wall_time_s": wall_time,
            "timestamp": datetime.now().isoformat(),
            "results": self.results,
        }


report = BenchmarkReport()


# ================================================================
# TEST 1: FULL RUNTIME BOOT TEST
# ================================================================
def test_runtime_boot():
    section("TEST 1: Full Runtime Boot Test")

    # 1a. Core imports
    t0 = time.time()
    try:
        from HEAP.database import Atlas
        from HEAP.cache import CacheNode
        from KERNEL.scheduler import SignalBus
        from KERNEL.president_agent import PresidentAgent
        from MANAGER.memory import MemoryManager
        from AGENT.heartbeat import heartbeat_monitor
        elapsed = time.time() - t0
        report.add("boot", "Core imports successful", True, elapsed=elapsed)
    except Exception as e:
        report.add("boot", "Core imports", False, str(e))
        return  # Can't continue

    # 1b. Initialize core components
    t0 = time.time()
    try:
        atlas = Atlas()
        cache = CacheNode()
        bus = SignalBus()
        elapsed = time.time() - t0
        report.add("boot", "Core components init (Atlas, Cache, Bus)", True, elapsed=elapsed)
    except Exception as e:
        report.add("boot", "Core components init", False, str(e))
        return

    # 1c. Initialize PresidentAgent
    t0 = time.time()
    try:
        president = PresidentAgent(bus, atlas, cache)
        elapsed = time.time() - t0
        report.add("boot", "PresidentAgent.__init__()", True, elapsed=elapsed)
    except Exception as e:
        report.add("boot", "PresidentAgent.__init__()", False, str(e))
        return

    # 1d. Verify modular memory is active
    t0 = time.time()
    try:
        assert isinstance(president.memory, MemoryManager), "memory is not MemoryManager"
        assert hasattr(president.memory, 'working'), "missing working memory"
        assert hasattr(president.memory, 'episodic'), "missing episodic memory"
        assert hasattr(president.memory, 'semantic'), "missing semantic memory"
        assert hasattr(president.memory, 'facts'), "missing fact memory"
        assert hasattr(president.memory, 'retrieval'), "missing retrieval engine"
        assert hasattr(president.memory, 'assembler'), "missing context assembler"
        assert hasattr(president.memory, 'decay'), "missing decay manager"
        elapsed = time.time() - t0
        report.add("boot", "Modular memory subsystems present", True, elapsed=elapsed)
    except AssertionError as e:
        report.add("boot", "Modular memory subsystems", False, str(e))
    except Exception as e:
        report.add("boot", "Modular memory subsystems", False, str(e))

    # 1e. Verify agents registered in swarm
    t0 = time.time()
    try:
        agent_count = len(president.agents)
        assert agent_count >= 10, f"Only {agent_count} agents registered"
        agent_names = list(president.agents.keys())
        elapsed = time.time() - t0
        report.add("boot", f"Swarm agents registered ({agent_count})", True, 
                   f"Agents: {', '.join(agent_names)}", elapsed)
    except Exception as e:
        report.add("boot", "Swarm agent registration", False, str(e))

    # 1f. Verify agents were NOT started yet (deferred to async start)
    t0 = time.time()
    try:
        not_started = sum(1 for a in president.agents.values() if not getattr(a, '_running', True))
        report.add("boot", f"Agent start properly deferred ({not_started} awaiting)", True, elapsed=time.time()-t0)
    except Exception as e:
        report.add("boot", "Agent start deferral check", False, str(e))

    # 1g. Verify no duplicate context injection
    t0 = time.time()
    try:
        assert hasattr(president, '_context_injection_guard'), "Missing injection guard"
        assert isinstance(president._context_injection_guard, set), "Guard is not a set"
        elapsed = time.time() - t0
        report.add("boot", "Duplicate context injection guard present", True, elapsed=elapsed)
    except Exception as e:
        report.add("boot", "Context injection guard", False, str(e))

    # 1h. Async boot test (short-lived)
    t0 = time.time()
    try:
        async def _quick_boot():
            # Store the main loop
            president._main_loop = asyncio.get_running_loop()
            
            # Start decay manager
            president.memory.decay.start()
            assert president.memory.decay._running, "Decay manager not running"
            
            # Start a few agents
            started = 0
            for aid, agent in list(president.agents.items())[:3]:
                try:
                    await agent.start()
                    started += 1
                except Exception:
                    pass
            
            # Verify heartbeat monitor can start (creates a background task)
            await heartbeat_monitor.start()
            # The task is created even if it hasn't completed a cycle yet
            assert heartbeat_monitor._monitor_task is not None, "HeartbeatMonitor task not created"
            
            # Cleanup
            heartbeat_monitor.stop()
            president.memory.decay.stop()
            
            return started

        started = asyncio.run(_quick_boot())
        elapsed = time.time() - t0
        report.add("boot", f"Async boot sequence ({started} agents started)", True, elapsed=elapsed)
    except Exception as e:
        report.add("boot", "Async boot sequence", False, f"{e}\n{traceback.format_exc()}")

    # 1i. Internet check
    t0 = time.time()
    try:
        online = president.check_internet(timeout=3)
        elapsed = time.time() - t0
        status = "ONLINE" if online else "OFFLINE"
        report.add("boot", f"Internet check ({status})", True, elapsed=elapsed)
    except Exception as e:
        report.add("boot", "Internet check", False, str(e))

    return president


# ================================================================
# TEST 2: MEMORY RETRIEVAL BENCHMARK
# ================================================================
def test_memory_retrieval_benchmark():
    section("TEST 2: Memory Retrieval Benchmark")

    from MANAGER.memory import MemoryManager

    mm = MemoryManager()

    # 2a. Working memory write throughput
    t0 = time.time()
    N_TURNS = 1000
    for i in range(N_TURNS):
        mm.add_turn("user", f"Test message number {i} about various topics like AI, weather, and music")
    elapsed = time.time() - t0
    throughput = N_TURNS / elapsed
    report.add("memory", f"Working memory write ({N_TURNS} turns)", True,
              f"Throughput: {throughput:.0f} turns/sec", elapsed)

    # 2b. Working memory read
    t0 = time.time()
    for _ in range(100):
        window = mm.working.get_sliding_window()
    elapsed = time.time() - t0
    report.add("memory", "Working memory read (100x)", True,
              f"Window size: {len(window)} turns", elapsed)

    # 2c. Fact learning + retrieval
    t0 = time.time()
    async def _fact_bench():
        await mm.learn_fact("test_name", "Tony Stark", confidence=1.0, source="benchmark")
        await mm.learn_fact("test_language", "Python", confidence=0.9, source="benchmark")
        await mm.learn_fact("test_location", "Dhaka", confidence=0.8, source="benchmark")

        results = await mm.facts.exact_match("test_name")
        return len(results)

    fact_count = asyncio.run(_fact_bench())
    elapsed = time.time() - t0
    report.add("memory", f"Fact learn + retrieval ({fact_count} facts)", True, elapsed=elapsed)

    # 2d. Context assembly benchmark
    t0 = time.time()
    async def _assembly_bench():
        mm2 = MemoryManager()
        for i in range(20):
            mm2.add_turn("user", f"Question about topic {i}")
            mm2.add_turn("assistant", f"Answer about topic {i}")
        
        payload = await mm2.build_ai_context(
            system_prompt="You are JARVIS, an advanced AI assistant.",
            current_query="What is the weather?"
        )
        return len(payload)

    msg_count = asyncio.run(_assembly_bench())
    elapsed = time.time() - t0
    report.add("memory", f"Context assembly ({msg_count} messages)", True, elapsed=elapsed)

    # 2e. Retrieval engine benchmark (parallel search)
    t0 = time.time()
    async def _retrieval_bench():
        results = await mm.retrieval.search_all("test query about AI", top_k=5)
        return len(results)

    result_count = asyncio.run(_retrieval_bench())
    elapsed = time.time() - t0
    report.add("memory", f"Parallel retrieval search ({result_count} results)", True, elapsed=elapsed)

    # 2f. Deduplication benchmark
    t0 = time.time()
    from MANAGER.memory.retrieval_engine import RetrievalEngine
    from MANAGER.memory.schemas import MemoryRecord, ScoredMemory
    
    # Create duplicate records
    dupes = []
    for i in range(20):
        rec = MemoryRecord(
            id=f"test_{i}", content="The weather today is sunny and warm",
            type="episodic", timestamp=time.time(), importance=0.5, trace_id=""
        )
        dupes.append(ScoredMemory(record=rec, score=0.8 - i*0.01))
    
    engine = RetrievalEngine(mm.facts, mm.episodic, mm.semantic)
    deduped = engine._deduplicate(dupes)
    elapsed = time.time() - t0
    report.add("memory", f"Deduplication ({len(dupes)} -> {len(deduped)})", True,
              f"Removed {len(dupes) - len(deduped)} duplicates", elapsed)


# ================================================================
# TEST 3: LONG CONVERSATION STRESS TEST
# ================================================================
def test_long_conversation_stress():
    section("TEST 3: Long Conversation Stress Test")

    from MANAGER.memory import MemoryManager

    # 3a. 500-turn conversation
    t0 = time.time()
    mm = MemoryManager()
    N_TURNS = 500
    for i in range(N_TURNS):
        mm.add_turn("user", f"User message {i}: Tell me about topic {i % 50} in category {i % 10}")
        mm.add_turn("assistant", f"Response {i}: Here's information about topic {i % 50}")
    elapsed = time.time() - t0
    
    window = mm.working.get_sliding_window()
    report.add("stress", f"{N_TURNS*2} turns injected", True,
              f"Window retained: {len(window)} (max 40)", elapsed)

    # 3b. Verify window doesn't grow unbounded
    assert len(window) <= 40, f"Window overflow: {len(window)} > 40"
    report.add("stress", "Window bounded correctly", True, f"Size: {len(window)}")

    # 3c. Context assembly under load
    t0 = time.time()
    async def _stress_assembly():
        payload = await mm.build_ai_context(
            system_prompt="You are JARVIS.",
            current_query="Summary of all topics discussed"
        )
        total_chars = sum(len(m["content"]) for m in payload)
        return len(payload), total_chars

    msg_count, char_count = asyncio.run(_stress_assembly())
    elapsed = time.time() - t0
    report.add("stress", f"Context assembly under load ({msg_count} msgs, {char_count} chars)", True, elapsed=elapsed)

    # 3d. Token budget enforcement
    assert char_count <= 20000, f"Token budget exceeded: {char_count} chars"
    report.add("stress", "Token budget enforced", True, f"{char_count} chars < 20000 limit")

    # 3e. Concurrent thread stress
    t0 = time.time()
    errors = []
    mm2 = MemoryManager()

    def writer(thread_id, count):
        try:
            for i in range(count):
                mm2.add_turn("user", f"Thread-{thread_id}-Msg-{i}")
        except Exception as e:
            errors.append(e)

    threads = [threading.Thread(target=writer, args=(t, 200)) for t in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    elapsed = time.time() - t0

    window2 = mm2.working.get_sliding_window()
    report.add("stress", f"Concurrent writes (10 threads x 200 msgs)", True,
              f"Final window: {len(window2)}, Errors: {len(errors)}", elapsed)
    assert len(errors) == 0, f"Thread safety errors: {errors}"

    # 3f. Session end under load
    t0 = time.time()
    mm.end_session()
    elapsed = time.time() - t0
    assert len(mm.working.get_sliding_window()) == 0
    report.add("stress", "Session end under load", True, elapsed=elapsed)

    # 3g. Rapid session cycling
    t0 = time.time()
    for cycle in range(50):
        mm3 = MemoryManager()
        for i in range(10):
            mm3.add_turn("user", f"Cycle {cycle} message {i}")
        mm3.end_session()
    elapsed = time.time() - t0
    report.add("stress", f"Rapid session cycling (50 cycles)", True, elapsed=elapsed)


# ================================================================
# TEST 4: HEARTBEAT LOOP STABILITY
# ================================================================
def test_heartbeat_stability():
    section("TEST 4: Heartbeat Loop Stability")

    from AGENT.heartbeat import heartbeat_monitor
    from AGENT.state_machine import AgentState

    # 4a. Register agents
    t0 = time.time()
    test_agents = ["TEST_A", "TEST_B", "TEST_C", "TEST_D", "TEST_E"]
    for aid in test_agents:
        heartbeat_monitor.register_agent(aid, metadata={"test": True})
    elapsed = time.time() - t0
    report.add("heartbeat", f"Register {len(test_agents)} agents", True, elapsed=elapsed)

    # 4b. Send heartbeats
    t0 = time.time()
    for _ in range(100):
        for aid in test_agents:
            heartbeat_monitor.heartbeat(aid)
    elapsed = time.time() - t0
    report.add("heartbeat", f"500 heartbeat pulses", True,
              f"Rate: {500/elapsed:.0f} beats/sec", elapsed)

    # 4c. Verify health status
    t0 = time.time()
    health = heartbeat_monitor.get_health_status()
    elapsed = time.time() - t0
    assert health["total_agents"] >= len(test_agents)
    report.add("heartbeat", "Health status query", True,
              f"Total: {health['total_agents']}, Healthy: {health['healthy']}", elapsed)

    # 4d. Async monitor loop stability
    t0 = time.time()
    try:
        async def _hb_loop_test():
            await heartbeat_monitor.start()
            # Verify task was created
            assert heartbeat_monitor._monitor_task is not None, "Monitor task not created"
            
            # Send beats while monitor is running
            for _ in range(10):
                for aid in test_agents:
                    heartbeat_monitor.heartbeat(aid)
                await asyncio.sleep(0.01)
            
            # Check health while running
            health = heartbeat_monitor.get_health_status()
            assert health["monitor_running"] == True, "Monitor not marked as running"
            
            heartbeat_monitor.stop()
            await asyncio.sleep(0.1)
            return True

        asyncio.run(_hb_loop_test())
        elapsed = time.time() - t0
        report.add("heartbeat", "Async monitor loop", True, elapsed=elapsed)
    except Exception as e:
        report.add("heartbeat", "Async monitor loop", False, str(e))

    # 4e. Agent state recovery
    t0 = time.time()
    heartbeat_monitor.register_agent("RECOVERY_TEST")
    # Simulate recovery from error
    record = heartbeat_monitor._agents.get("RECOVERY_TEST")
    if record:
        record.state_machine.transition(AgentState.ERROR, reason="Simulated error")
        heartbeat_monitor.heartbeat("RECOVERY_TEST")  # Should recover
        state = heartbeat_monitor.get_agent_state("RECOVERY_TEST")
        assert state == AgentState.IDLE, f"Recovery failed: {state}"
    elapsed = time.time() - t0
    report.add("heartbeat", "Agent state recovery (ERROR -> IDLE)", True, elapsed=elapsed)

    # Cleanup
    for aid in test_agents + ["RECOVERY_TEST"]:
        heartbeat_monitor.deregister_agent(aid)


# ================================================================
# TEST 5: LEGACY BACKWARD COMPATIBILITY
# ================================================================
def test_legacy_compat():
    section("TEST 5: Legacy Backward Compatibility")

    # 5a. Legacy MemoryManager import
    t0 = time.time()
    try:
        from MANAGER.memory_manager import MemoryManager as LegacyMM
        mm = LegacyMM()
        report.add("legacy", "Legacy MemoryManager import", True, elapsed=time.time()-t0)
    except Exception as e:
        report.add("legacy", "Legacy MemoryManager import", False, str(e))
        return

    # 5b. Legacy ContextManager import
    t0 = time.time()
    try:
        from MANAGER.context_manager import ContextManager
        cm = ContextManager()
        report.add("legacy", "Legacy ContextManager import", True, elapsed=time.time()-t0)
    except Exception as e:
        report.add("legacy", "Legacy ContextManager import", False, str(e))

    # 5c. Legacy API methods don't crash
    t0 = time.time()
    try:
        mm.add_interaction("Hello", "Hi Sir", emotion="neutral")
        mm.remember_short("User", "Test message")
        mm.clear_short_term()
        mm.consolidate()
        mm.search_memory("test")
        mm.learn_about_user("key", "value")
        mm.get_stats()
        mm.get_context_for_ai()
        report.add("legacy", "All legacy methods callable", True, elapsed=time.time()-t0)
    except Exception as e:
        report.add("legacy", "Legacy method calls", False, str(e))


# ================================================================
# MAIN
# ================================================================
def main():
    # Enable ANSI colors on Windows
    try:
        os.system("")
    except Exception:
        pass

    print(f"\n{'='*70}")
    print(f"  {BOLD}{CYAN}JARVIS PHASE 1 — CRITICAL FIXES VALIDATION SUITE{RESET}")
    print(f"  {DIM}Modular Cognitive Memory Integration{RESET}")
    print(f"  {DIM}{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{RESET}")
    print(f"{'='*70}")

    test_runtime_boot()
    test_memory_retrieval_benchmark()
    test_long_conversation_stress()
    test_heartbeat_stability()
    test_legacy_compat()

    # ── Final Report ──
    summary = report.summary()

    section("BENCHMARK REPORT")
    print(f"  Total Tests   : {summary['total_tests']}")
    print(f"  Passed        : {GREEN}{summary['passed']}{RESET}")
    print(f"  Failed        : {RED}{summary['failed']}{RESET}")
    print(f"  Pass Rate     : {BOLD}{summary['pass_rate']}{RESET}")
    print(f"  Wall Time     : {summary['wall_time_s']}s")

    # Save report to file
    report_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "PHASE1_BENCHMARK_REPORT.json")
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"\n  Report saved to: {report_path}")

    if summary["failed"] > 0:
        print(f"\n  {RED}Some tests failed. Review above output.{RESET}")
        sys.exit(1)
    else:
        print(f"\n  {GREEN}{BOLD}ALL TESTS PASSED — Phase 1 validation complete.{RESET}")
        sys.exit(0)


if __name__ == "__main__":
    main()
