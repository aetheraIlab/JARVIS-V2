import pytest
import asyncio
import time
import collections
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from MONITOR.tracer import Tracer, TraceManager, Span
from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse


# ================================================================
# MOCK AGENT
# ================================================================

class TracedMockAgent(BaseAgent):
    """Mock agent that succeeds immediately, used to generate trace spans."""
    AGENT_ID = "TRACED_MOCK"
    AGENT_NAME = "Traced Mock Agent"

    async def execute(self, action: str, params: dict) -> AgentResponse:
        await asyncio.sleep(0.05)  # Simulate work
        return AgentResponse(
            success=True, agent_id=self.AGENT_ID, action=action,
            result="Mock result from traced agent"
        )


class TracedFailAgent(BaseAgent):
    """Mock agent that always fails, used to test error spans."""
    AGENT_ID = "TRACED_FAIL"
    AGENT_NAME = "Traced Fail Agent"

    async def execute(self, action: str, params: dict) -> AgentResponse:
        return AgentResponse(
            success=False, agent_id=self.AGENT_ID, action=action,
            error="Simulated traced failure"
        )


# ================================================================
# TEST GROUP 1: TraceManager Core
# ================================================================

class TestTraceManagerCore:
    """Validates the in-memory trace buffer and span lifecycle."""

    def test_generate_trace_id(self):
        """generate_trace_id must return a unique trace ID and store it in context."""
        tid = TraceManager.generate_trace_id()
        assert tid.startswith("trace_"), f"trace_id format wrong: {tid}"
        assert TraceManager.get_current_trace_id() == tid

    def test_trace_ids_are_unique(self):
        """Each call to generate_trace_id must produce a different ID."""
        ids = set()
        for _ in range(50):
            ids.add(TraceManager.generate_trace_id())
        assert len(ids) == 50, "Duplicate trace IDs detected"

    def test_max_traces_bounded(self):
        """In-memory buffer must not exceed MAX_TRACES."""
        original_max = TraceManager.MAX_TRACES
        original_traces = TraceManager._traces_in_memory
        TraceManager._traces_in_memory = collections.OrderedDict()
        TraceManager.MAX_TRACES = 5

        for _ in range(10):
            TraceManager.generate_trace_id()

        assert len(TraceManager._traces_in_memory) <= 5, \
            f"Buffer exceeded max: {len(TraceManager._traces_in_memory)}"

        TraceManager.MAX_TRACES = original_max
        TraceManager._traces_in_memory = original_traces

    def test_get_last_trace_id(self):
        """get_last_trace_id must return the most recently generated ID."""
        t1 = TraceManager.generate_trace_id()
        t2 = TraceManager.generate_trace_id()
        assert TraceManager.get_last_trace_id() == t2


# ================================================================
# TEST GROUP 2: Span Lifecycle
# ================================================================

class TestSpanLifecycle:
    """Validates that spans record correct timing and status data."""

    def test_span_records_start_end(self):
        """A span must record start_time, end_time, and execution_time_ms."""
        tid = TraceManager.generate_trace_id()
        span = TraceManager.start_span("TEST_SPAN")

        assert span.trace_id == tid
        assert span.start_time is not None
        assert span.status == "running"

        time.sleep(0.1)
        span.end(status="success")

        assert span.end_time is not None
        assert span.end_time > span.start_time
        assert span.status == "success"

        # Verify it was recorded in memory
        spans = TraceManager.get_trace(tid)
        assert len(spans) >= 1

        recorded = spans[-1]
        assert recorded["name"] == "TEST_SPAN"
        assert recorded["execution_time_ms"] >= 80  # at least ~100ms
        assert recorded["status"] == "success"
        assert "start_time" in recorded
        assert "end_time" in recorded

    def test_span_records_error(self):
        """A failed span must include the error string."""
        tid = TraceManager.generate_trace_id()
        span = TraceManager.start_span("FAIL_SPAN")
        span.end(status="failed", error="Something broke")

        spans = TraceManager.get_trace(tid)
        recorded = spans[-1]
        assert recorded["status"] == "failed"
        assert recorded["error"] == "Something broke"

    def test_span_records_metadata(self):
        """Metadata passed to start_span must be preserved."""
        tid = TraceManager.generate_trace_id()
        span = TraceManager.start_span("META_SPAN", metadata={"agent": "TERMINAL", "retries": 2})
        span.end(status="success")

        spans = TraceManager.get_trace(tid)
        recorded = spans[-1]
        assert recorded["metadata"]["agent"] == "TERMINAL"
        assert recorded["metadata"]["retries"] == 2


# ================================================================
# TEST GROUP 3: Agent Integration (BaseAgent → Tracer)
# ================================================================

class TestAgentTraceIntegration:
    """Validates that BaseAgent.execute_with_state generates trace spans."""

    @pytest.mark.asyncio
    async def test_execute_with_state_creates_span(self):
        """execute_with_state must produce an AGENT_EXECUTE span in the trace."""
        tid = TraceManager.generate_trace_id()
        agent = TracedMockAgent()

        res = await agent.execute_with_state("test_action", {"key": "val"})

        assert res.success is True

        spans = TraceManager.get_trace(tid)
        span_names = [s["name"] for s in spans]
        assert f"AGENT_EXECUTE_{agent.AGENT_ID}" in span_names, \
            f"Expected AGENT_EXECUTE_TRACED_MOCK in spans, got: {span_names}"

        agent_span = [s for s in spans if s["name"] == f"AGENT_EXECUTE_{agent.AGENT_ID}"][-1]
        assert agent_span["status"] == "success"
        assert agent_span["execution_time_ms"] >= 40  # ~50ms sleep

    @pytest.mark.asyncio
    async def test_execute_with_validation_creates_span(self):
        """execute_with_validation must produce a VALIDATION span."""
        tid = TraceManager.generate_trace_id()
        agent = TracedMockAgent()

        res = await agent.execute_with_validation("test_action", {}, max_retries=1)

        assert res.success is True

        spans = TraceManager.get_trace(tid)
        span_names = [s["name"] for s in spans]
        assert f"VALIDATION_{agent.AGENT_ID}" in span_names, \
            f"Expected VALIDATION_TRACED_MOCK in spans, got: {span_names}"

    @pytest.mark.asyncio
    async def test_failed_agent_creates_failed_span(self):
        """A failed agent must produce a span with status='failed' and an error."""
        tid = TraceManager.generate_trace_id()
        agent = TracedFailAgent()

        res = await agent.execute_with_state("doomed_action", {})

        assert res.success is False

        spans = TraceManager.get_trace(tid)
        agent_span = [s for s in spans if s["name"] == f"AGENT_EXECUTE_{agent.AGENT_ID}"][-1]
        assert agent_span["status"] == "failed"

    @pytest.mark.asyncio
    async def test_full_execution_path_traced(self):
        """
        A full execute_with_validation call must produce BOTH
        a VALIDATION span and an AGENT_EXECUTE span in the correct order.
        """
        tid = TraceManager.generate_trace_id()
        agent = TracedMockAgent()

        await agent.execute_with_validation("full_path_test", {})

        spans = TraceManager.get_trace(tid)
        span_names = [s["name"] for s in spans]

        assert f"VALIDATION_{agent.AGENT_ID}" in span_names
        assert f"AGENT_EXECUTE_{agent.AGENT_ID}" in span_names

        # AGENT_EXECUTE should appear before VALIDATION ends
        val_span = [s for s in spans if s["name"] == f"VALIDATION_{agent.AGENT_ID}"][-1]
        exec_span = [s for s in spans if s["name"] == f"AGENT_EXECUTE_{agent.AGENT_ID}"][-1]
        assert exec_span["start_time"] >= val_span["start_time"], \
            "AGENT_EXECUTE should start after VALIDATION begins"


# ================================================================
# TEST GROUP 4: Trace Formatting
# ================================================================

class TestTraceFormatting:
    """Validates the human-readable trace output."""

    def test_format_trace_output(self):
        """format_trace_output must return a readable summary."""
        tid = TraceManager.generate_trace_id()
        s1 = TraceManager.start_span("STEP_ONE", metadata={"agent": "TEST"})
        s1.end(status="success")
        s2 = TraceManager.start_span("STEP_TWO")
        s2.end(status="failed", error="Timeout")

        output = TraceManager.format_trace_output(tid)

        assert f"[TRACE: {tid}]" in output
        assert "STEP_ONE" in output
        assert "STEP_TWO" in output
        assert "SUCCESS" in output
        assert "FAILED" in output
        assert "Timeout" in output

    def test_format_unknown_trace(self):
        """Requesting a non-existent trace must return a 'not found' message."""
        output = TraceManager.format_trace_output("trace_nonexistent_12345")
        assert "not found" in output.lower()
