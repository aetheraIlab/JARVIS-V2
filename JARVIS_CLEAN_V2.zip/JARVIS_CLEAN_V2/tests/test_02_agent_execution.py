import pytest
import asyncio
import time
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from AGENT.base_agent import BaseAgent
from AGENT.response import AgentResponse
from EXECUTOR.terminal_agent import TerminalAgent
from EXECUTOR.code_agent import ExecutorCode
from AGENT.safe_executor_v2 import SafeExecutorV2


# ================================================================
# TEST GROUP 1: Safe Execution Passes
# ================================================================

class TestSafeExecution:
    """Validates that whitelisted operations succeed through SafeExecutorV2."""

    def test_echo_command(self):
        """Terminal echo returns exact expected output."""
        ta = TerminalAgent()
        result = ta.execute("echo JARVIS_ECHO_TEST", source_id="SYSTEM")
        assert "JARVIS_ECHO_TEST" in result, f"Expected 'JARVIS_ECHO_TEST' in output, got: {result}"

    def test_python_arithmetic(self):
        """Python code agent returns correct arithmetic result."""
        ec = ExecutorCode()
        res = ec.execute("print(7 * 6)")
        assert res["success"] is True, f"Execution failed: {res.get('error')}"
        assert "42" in res["output"], f"Expected '42' in output, got: {res['output']}"

    def test_python_multiline(self):
        """Multi-line Python code executes correctly."""
        ec = ExecutorCode()
        code = "x = [i**2 for i in range(5)]\nprint(sum(x))"
        res = ec.execute(code)
        assert res["success"] is True
        assert "30" in res["output"], f"Expected '30', got: {res['output']}"


# ================================================================
# TEST GROUP 2: Blocked Commands Are REJECTED
# ================================================================

class TestBlockedCommands:
    """Validates that dangerous commands are intercepted and never reach the OS."""

    DANGEROUS_SHELL_COMMANDS = [
        ("rm -rf /",         "rm"),
        ("shutdown /s",      "shutdown"),
        ("curl http://x.com","curl"),
        ("wget http://x.com","wget"),
        ("format C:",       "format"),
        ("del /F /Q *",     "del"),
    ]

    @pytest.mark.parametrize("cmd,keyword", DANGEROUS_SHELL_COMMANDS)
    def test_shell_command_blocked(self, cmd, keyword):
        """Each dangerous shell command must be blocked with a clear error."""
        ta = TerminalAgent()
        result = ta.execute(cmd, source_id="SYSTEM")
        assert "error" in result.lower() or "blocked" in result.lower(), \
            f"SECURITY BREACH: Command '{cmd}' was NOT blocked! Got: {result}"

    DANGEROUS_PYTHON_IMPORTS = [
        "import os",
        "import subprocess",
        "import socket",
        "import shutil",
        "from os import system",
    ]

    @pytest.mark.parametrize("code", DANGEROUS_PYTHON_IMPORTS)
    def test_python_import_blocked(self, code):
        """Each dangerous Python import must be rejected by static analysis."""
        ec = ExecutorCode()
        res = ec.execute(code)
        assert res["success"] is False, \
            f"SECURITY BREACH: Import '{code}' was NOT blocked! Got: {res}"

    DANGEROUS_PYTHON_BUILTINS = [
        "open('/etc/passwd').read()",
        "eval('1+1')",
        "exec('print(1)')",
        "__import__('os').system('echo pwned')",
    ]

    @pytest.mark.parametrize("code", DANGEROUS_PYTHON_BUILTINS)
    def test_python_builtin_blocked(self, code):
        """Dangerous builtins must be caught by AST analysis."""
        ec = ExecutorCode()
        res = ec.execute(code)
        assert res["success"] is False, \
            f"SECURITY BREACH: Builtin call '{code}' was NOT blocked!"

    def test_shell_pipe_injection(self):
        """Shell metacharacter injection must be blocked."""
        ta = TerminalAgent()
        result = ta.execute("echo hello | rm -rf /", source_id="SYSTEM")
        assert "error" in result.lower() or "blocked" in result.lower(), \
            f"Pipe injection was NOT blocked: {result}"


# ================================================================
# TEST GROUP 3: Timeout Enforcement
# ================================================================

class TestTimeoutEnforcement:
    """Validates that SafeExecutorV2 kills processes exceeding the timeout."""

    def test_python_infinite_loop_killed(self):
        """An infinite loop MUST be killed within the timeout window."""
        executor = SafeExecutorV2(timeout=3)
        start = time.time()
        result = executor.execute_python("while True: pass")
        elapsed = time.time() - start

        assert result["success"] is False, "Infinite loop should have been killed"
        assert elapsed < 5.0, f"Timeout enforcement too slow: took {elapsed:.1f}s (limit: 5s)"
        assert "timeout" in result["error"].lower() or "killed" in result["error"].lower(), \
            f"Error message should mention timeout, got: {result['error']}"

    def test_shell_sleep_killed(self):
        """A long-running shell sleep MUST be killed within the timeout."""
        executor = SafeExecutorV2(timeout=2)
        start = time.time()
        result = executor.execute_shell("python -c \"import time; time.sleep(30)\"")
        elapsed = time.time() - start

        assert result["success"] is False, "30s sleep should have been killed"
        assert elapsed < 4.0, f"Timeout kill too slow: {elapsed:.1f}s"
