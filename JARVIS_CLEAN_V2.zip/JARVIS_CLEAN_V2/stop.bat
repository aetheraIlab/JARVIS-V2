@echo off
title JARVIS Shutdown
color 0C

echo ================================================================
echo    J.A.R.V.I.S  —  SHUTDOWN SEQUENCE
echo ================================================================
echo.

REM ── Kill JARVIS Core window ───────────────────────────────────
echo [STOP] Terminating JARVIS Core process...
taskkill /F /FI "WINDOWTITLE eq JARVIS Core*" >nul 2>&1

REM ── Kill any orphaned python processes on port 5000 ───────────
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":5000 " ^| findstr "LISTENING"') do (
    echo [STOP] Killing process on port 5000 ^(PID: %%a^)...
    taskkill /F /PID %%a >nul 2>&1
)

echo.
echo [DONE] JARVIS has been shut down.
echo ================================================================
echo.
pause
