# ================================================================
# JARVIS AETHER-CORE V2.0 — VOICE PIPELINE (KERNEL LAYER)
# ================================================================
# Codename : VOICE-PIPELINE
# Role     : End-to-end voice conversation orchestrator (Duplex/Low-Latency)
# Tech     : STT (faster-whisper) → AI (President) → TTS (edge-tts)
# ================================================================

import sys
import os
import asyncio
import threading
import time

# Ensure parent directory is in path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

try:
    from SENSOR.wake_word import WakeWordDetector
    from SENSOR.microphone import AudioIn
    from SENSOR.tts import AudioOut
    from KERNEL.president_agent import PresidentAgent
    from KERNEL.scheduler import SignalBus
    from HEAP.database import Atlas
    from HEAP.cache import CacheNode
except ImportError as e:
    print(f"[VOICE-PIPELINE] [WARNING] Import error: {e}")
    WakeWordDetector = None
    AudioIn = None
    AudioOut = None
    PresidentAgent = None
    SignalBus = None
    Atlas = None
    CacheNode = None


class VoicePipeline:
    """
    JARVIS VOICE-PIPELINE — Conversational Engine.
    
    Features:
    - Real-time VAD detection
    - Instant speech interruption (Duplex communication)
    - Low latency processing
    """

    def __init__(self, bus=None, atlas=None, cache=None, president=None,
                 wake_word="hey jarvis", auto_play=True):
        self.wake_word = wake_word.lower()
        self.auto_play = auto_play
        
        # Shared infrastructure
        self.bus = bus or (SignalBus() if SignalBus else None)
        self.atlas = atlas or (Atlas() if Atlas else None)
        self.cache = cache or (CacheNode() if CacheNode else None)
        
        # Audio Components
        self.audio_in = AudioIn() if AudioIn else None
        self.speaker = AudioOut() if AudioOut else None
        
        # President Agent
        self.president = president
        if not self.president and PresidentAgent and self.bus and self.atlas and self.cache:
            try:
                self.president = PresidentAgent(self.bus, self.atlas, self.cache)
            except Exception as e:
                print(f"[VOICE-PIPELINE] PresidentAgent init error: {e}")
                self.president = None
        
        # State Machine: IDLE, LISTENING, THINKING, SPEAKING, INTERRUPTED
        self.state = "IDLE"
        self.running = False
        self._listen_thread = None
        self._current_inference_task = None
        
        # Metrics
        self.conversations_count = 0
        self.interruptions_count = 0
        self.errors_count = 0
        self.avg_ttfb = 0.0 # Time to first byte
        self.session_start = time.time()
        
        self._init_component()

    def _init_component(self):
        print("[VOICE-PIPELINE] Initializing Real-Time Duplex Voice Pipeline...")
        status = {
            "audio_in (VAD)": "[OK]" if self.audio_in else "[FAIL]",
            "audio_out (Streaming TTS)": "[OK]" if self.speaker else "[FAIL]",
            "president_agent": "[OK]" if self.president else "[FAIL]",
        }
        for component, status_mark in status.items():
            print(f"  {component}: {status_mark}")
        print("[VOICE-PIPELINE] [OK] Initialization complete.")

    def set_state(self, new_state):
        if self.state != new_state:
            self.state = new_state
            # Optional: publish state change to UI/bus

    def start_listening(self):
        if self.running: return
        self.running = True
        self.set_state("LISTENING")
        self._listen_thread = threading.Thread(target=self._orchestration_loop, daemon=True)
        self._listen_thread.start()
        print("[VOICE-PIPELINE] [MIC] Real-time duplex listening started.")

    def stop_listening(self):
        self.running = False
        self.set_state("IDLE")
        if self.audio_in: self.audio_in.stop()
        if self.speaker: self.speaker.stop()
        if self._listen_thread and self._listen_thread.is_alive():
            self._listen_thread.join(timeout=2)
        print("[VOICE-PIPELINE] [STOP] Listening stopped.")

    def _on_speech_detected(self):
        """Callback fired by AudioIn exactly when VAD detects human voice."""
        if self.state in ["SPEAKING", "THINKING"]:
            print("\n[VOICE-PIPELINE] 🛑 BARGE-IN DETECTED! Stopping JARVIS...")
            self.set_state("INTERRUPTED")
            self.interruptions_count += 1
            if self.speaker:
                self.speaker.interrupt()
            if self._current_inference_task and not self._current_inference_task.done():
                self._current_inference_task.cancel()
            self.set_state("LISTENING")

    def _orchestration_loop(self):
        if not self.audio_in: return
        
        self.audio_in.start_continuous_listen(on_speech_start=self._on_speech_detected)
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            while self.running:
                command = self.audio_in.get_command(block=True, timeout=0.5)
                
                if command and self.state == "LISTENING":
                    if self.audio_in.is_stop_command(command):
                        if self.speaker: self.speaker.interrupt()
                        continue
                        
                    # Process the command async
                    self._current_inference_task = loop.create_task(self._process_command_stream(command))
                    loop.run_until_complete(self._current_inference_task)
                    self.set_state("LISTENING")
                    
        except Exception as e:
            print(f"[VOICE-PIPELINE] Orchestration error: {e}")
        finally:
            loop.close()

    async def _process_command_stream(self, command):
        self.set_state("THINKING")
        start_time = time.time()
        
        try:
            if not self.president: return
            print(f"\n[VOICE-PIPELINE] [USER]: '{command}'")
            
            # Use Arbiter for streaming
            # To preserve traces and MemoryManager logic, we construct AI context
            # Normally PresidentAgent does this in process_input.
            # We'll call president._think_with_ai directly or modify president to support stream.
            # For phase 4, we use arbiter stream directly for low latency, bypassing some President routing overhead
            
            from MONITOR.tracer import Tracer
            Tracer.generate_trace_id()
            
            system_prompt = "You are JARVIS. Answer concisely and conversationally."
            context = await self.president.memory.build_ai_context(system_prompt, command)
            
            stream_gen = self.president.arbiter.think_stream(command, context)
            
            # Wrapper to measure TTFB and handle state changes
            async def ttfb_wrapper():
                first_byte_time = None
                full_text = ""
                provider_used = "unknown"
                
                try:
                    async for chunk, provider in stream_gen:
                        if self.state == "INTERRUPTED":
                            print("\n[VOICE-PIPELINE] Inference cancelled due to barge-in.")
                            break
                        if chunk:
                            if first_byte_time is None:
                                first_byte_time = time.time()
                                elapsed = first_byte_time - start_time
                                self.avg_ttfb = (self.avg_ttfb + elapsed) / 2
                                self.set_state("SPEAKING")
                                print(f"[VOICE-PIPELINE] TTFB: {elapsed:.2f}s")
                            full_text += chunk
                            provider_used = provider
                            yield chunk
                finally:
                    # Finalize response into memory
                    if full_text.strip():
                        self.president._finalize_response(command, full_text.strip(), "voice_stream", provider_used, time.time()-start_time, "VOICE")
            
            if self.auto_play and self.speaker:
                # Pass the wrapped generator to TTS queue
                await self.speaker.speak_stream(ttfb_wrapper())
                
                # Wait until TTS queue is empty (or interrupted)
                while self.speaker.is_speaking() and self.state != "INTERRUPTED":
                    await asyncio.sleep(0.1)
            else:
                # Just consume the generator if no TTS
                async for _ in ttfb_wrapper(): pass
                
            self.conversations_count += 1
            
        except asyncio.CancelledError:
            pass
        except Exception as e:
            print(f"[VOICE-PIPELINE] Streaming error: {e}")
            self.errors_count += 1
            self.set_state("LISTENING")

    def get_status(self):
        uptime = time.time() - self.session_start
        return {
            "state": self.state,
            "running": self.running,
            "conversations": self.conversations_count,
            "interruptions": self.interruptions_count,
            "errors": self.errors_count,
            "avg_ttfb": f"{self.avg_ttfb:.2f}s",
            "uptime": f"{uptime:.1f}s"
        }


# ================================================================
# UNIT TESTS
# ================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("  VOICE-PIPELINE (DUPLEX) — Unit Test")
    print("=" * 60)
    
    pipeline = VoicePipeline(auto_play=True)
    
    print("\n[TEST] Starting live duplex listening...")
    print("  => Speak normally. JARVIS will reply.")
    print("  => Speak while JARVIS is talking to interrupt him.")
    print("  => Press Ctrl+C to exit.\n")
    
    try:
        pipeline.start_listening()
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pipeline.stop_listening()
        print("\n[VOICE-PIPELINE] Exited cleanly.")
