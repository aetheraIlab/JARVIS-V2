# ================================================================
# JARVIS AETHER-CORE V2.0 — PRESIDENT AGENT (KERNEL)
# ================================================================
# Codename : PRESIDENT
# Role     : Supreme Command Agent — Intent Classifier + Dispatcher
# Flow     : User Input → Internet Check → AI Model Selection →
#            Intent Classification → Agent Dispatch → TTS Output
# ================================================================

import sys
import os
import asyncio
import threading
import time
import socket
import re
import logging
from datetime import datetime, timezone
from MONITOR.tracer import Tracer

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from KERNEL.scheduler import SignalBus
from HEAP.database import Atlas
from HEAP.cache import CacheNode
from SENSOR.logger import HeapNode
from INFERENCE.pipeline import Arbiter
from CONFIG.constants import (
    NAME, CODENAME, VERSION, DESIGNER,
    WAKE_WORD, STOP_WORDS, MAX_CONVERSATION_HISTORY
)

# RAM Managers — PresidentAgent-এর সাব-সিস্টেম হিসেবে ইন্টিগ্রেটেড
from MANAGER.memory import MemoryManager
from MANAGER.skill_manager import SkillManager
from MANAGER.task_manager import TaskManager, TaskCategory, TaskPriority
from SELF_HEAL.crash_monitor import CrashMonitor
from SWARM.orchestrator import SwarmOrchestrator

# সিকিউরিটি লেয়ার (GATEWAY/KERNEL)
from KERNEL.defense_layer import DefenseLayer
from NETWORK.hub import JARVISHub

# UAF Agents
from AGENT.agents.browser_agent import BrowserAgent
from AGENT.agents.research_agent import ResearchAgent
from AGENT.agents.email_agent import EmailAgent
from AGENT.agents.code_agent import CodeAgent
from AGENT.agents.file_agent import FileAgent
from AGENT.agents.terminal_agent import TerminalAgent
from AGENT.agents.memory_agent import MemoryAgent
from AGENT.agents.voice_agent import VoiceAgent
from AGENT.agents.security_agent import SecurityAgent
from AGENT.agents.self_healing_agent import SelfHealingAgent
from AGENT.heartbeat import heartbeat_monitor

# ================================================================
# INTENT_MAP REMOVED — SkillManager is now the sole routing source.
# All intent-to-agent mapping is handled by SkillManager._register_core_skills().
# ================================================================


# AGENT_SIGNAL_MAP REMOVED — Dynamic routing via AgentRegistry is now used.

class PresidentAgent:
    """
    JARVIS PRESIDENT AGENT — সুপ্রিম কমান্ড এজেন্ট।

    এটি JARVIS-এর মস্তিষ্ক। সব কিছু এখান দিয়ে যায়:
    1. ইউজার ইনপুট নেয় (ভয়েস বা টেক্সট)
    2. ইন্টারনেট আছে কিনা চেক করে
    3. ইনটেন্ট ক্লাসিফাই করে (কী করতে চায়)
    4. সঠিক এজেন্ট/মডেলে পাঠায়
    5. রেসপন্স পেয়ে TTS দিয়ে বলে
    6. সব কিছু SQLite-এ লগ করে

    RAM Managers (integrated):
    - PRISM (ContextManager): কথোপকথনের প্রসঙ্গ উইন্ডো
    - MNEMONIC (MemoryManager): শর্ট/লং-টার্ম মেমোরি
    - ARTIFICER (SkillManager): দক্ষতা রেজিস্ট্রি ও ম্যাচিং
    - TASKMASTER (TaskManager): টাস্ক লাইফসাইকেল ম্যানেজমেন্ট
    """

    def __init__(self, bus: SignalBus, atlas: Atlas, cache: CacheNode):
        # লগিং সেটআপ
        self.logger = logging.getLogger("PRESIDENT")
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter(
                '[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

        self.bus = bus
        self.atlas = atlas
        self.cache = cache
        self.heap = HeapNode(atlas, cache)
        self.arbiter = Arbiter()

        # ============================================================
        # RAM MANAGERS — President Agent-এর সাব-সিস্টেম
        # ============================================================
        self.memory = MemoryManager(atlas=atlas)        # SYNAPSE (Unified Modular System)
        self.skills = SkillManager(atlas, cache)        # ARTIFICER
        self.tasks = TaskManager(atlas, cache)          # TASKMASTER
        self.defense = DefenseLayer()                   # GATEWAY DEFENSE
        
        # SELF-HEALING ENGINE (Phase 8)
        self.healer = CrashMonitor(bus)
        self.healer.start()
        
        # SWARM ORCHESTRATOR (Phase 9 — HIVEMIND)
        self.swarm = SwarmOrchestrator(signal_bus=self.bus)
        self._initialize_swarm()

        
        self.network_hub = JARVISHub()                  # NETWORK MASTER
        # স্টেট ম্যানেজমেন্ট
        self.running = False
        self.is_online = False
        self.active_session = True
        self.wake_mode = False

        # Duplicate context injection guard
        self._context_injection_guard = set()

        # থ্রেড লক (PHASE 3 FIX: _history_lock removed — using ContextManager as single source)
        self._state_lock = threading.Lock()
        self._history_lock = threading.Lock()  # Added as requested for legacy compatibility

        # সেশন তথ্য (PHASE 3 FIX: _history removed — ContextManager._context_window is the single source)
        self._session_start = datetime.now(timezone.utc).isoformat()
        self._command_count = 0

        # ব্যাকগ্রাউন্ড থ্রেড রেফারেন্স
        self._internet_check_thread = None
        self._heartbeat_thread = None
        self._consolidation_thread = None

        # Async event loop reference (for safe heartbeat emission)
        self._main_loop = None

        self.logger.info(f"{NAME} V{VERSION} — Supreme Command Agent initialized.")
        self.logger.info(f"Designer: {DESIGNER} | Codename: {CODENAME}")
        self.logger.info("INTEGRATION PHASE: Autonomous Swarm Runtime Active.")

    def _initialize_swarm(self):
        """Register all existing agents into the Swarm WorkerPool at boot.
        
        NOTE: Agent .start() is async and is deferred to PresidentAgent.start().
        At __init__ time we only instantiate and register with the swarm.
        """
        try:
            # 1. Initialize UAF Agents
            self.agents = {
                "BROWSER":      BrowserAgent(bus=self.bus, atlas=self.atlas, cache=self.cache),
                "RESEARCH":     ResearchAgent(bus=self.bus, atlas=self.atlas, cache=self.cache),
                "EMAIL":        EmailAgent(bus=self.bus, atlas=self.atlas, cache=self.cache),
                "CODE":         CodeAgent(bus=self.bus, atlas=self.atlas, cache=self.cache),
                "FILE":         FileAgent(bus=self.bus, atlas=self.atlas, cache=self.cache),
                "TERMINAL":     TerminalAgent(bus=self.bus, atlas=self.atlas, cache=self.cache),
                "MEMORY":       MemoryAgent(bus=self.bus, atlas=self.atlas, cache=self.cache),
                "VOICE":        VoiceAgent(bus=self.bus, atlas=self.atlas, cache=self.cache),
                "SECURITY":     SecurityAgent(bus=self.bus, atlas=self.atlas, cache=self.cache),
                "SELF_HEALING": SelfHealingAgent(bus=self.bus, atlas=self.atlas, cache=self.cache)
            }

            # 2. Register with Swarm (but do NOT start — start is async, deferred to start())
            for agent_id, agent_ref in self.agents.items():
                self.swarm.register_agent(
                    agent_id=agent_id,
                    agent_ref=agent_ref,
                    capabilities=[cap["name"] for cap in getattr(agent_ref, "CAPABILITIES", [])]
                )
            
            self.logger.info(f"Swarm registered {len(self.agents)} agents (start deferred to async boot).")

        except Exception as e:
            self.logger.error(f"Failed to initialize swarm agents: {e}")

        # Healing Approval State
        self.pending_healing_approval = None

    # ================================================================
    # INITIALIZATION
    # ================================================================
    def check_internet(self, timeout=3):
        """
        ইন্টারনেট সংযোগ আছে কিনা চেক করে।
        DNS lookup দিয়ে দ্রুত পরীক্ষা করা হয়।
        """
        targets = [
            ("8.8.8.8", 53),       # Google DNS
            ("1.1.1.1", 53),       # Cloudflare DNS
            ("208.67.222.222", 53), # OpenDNS
        ]
        for host, port in targets:
            sock = None
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(timeout)
                sock.connect((host, port))
                with self._state_lock:
                    self.is_online = True
                return True
            except (socket.timeout, socket.error, OSError):
                continue
            finally:
                if sock:
                    try:
                        sock.close()
                    except Exception:
                        pass
        with self._state_lock:
            self.is_online = False
        return False

    def _background_internet_check(self):
        """প্রতি ৩০ সেকেন্ডে ব্যাকগ্রাউন্ডে ইন্টারনেট চেক করে।"""
        while self.running:
            with self._state_lock:
                was_online = self.is_online

            self.check_internet()

            with self._state_lock:
                is_online_now = self.is_online

            # অবস্থা বদলালে লগ করে
            if was_online != is_online_now:
                status = "ONLINE" if is_online_now else "OFFLINE"
                self.logger.info(f"Network status changed: {status}")
                self.heap.record_event("PRESIDENT", "NETWORK_CHANGE", status)

            time.sleep(30)

    def _background_heartbeat(self):
        """
        প্রতি ৩০ সেকেন্ডে ওয়াচডগের জন্য হার্টবিট পাঠায়।
        Uses the stored main event loop reference for thread-safe async emission.
        """
        while self.running:
            try:
                if self._main_loop and self._main_loop.is_running():
                    asyncio.run_coroutine_threadsafe(
                        self.bus.emit("PRESIDENT", "WATCHDOG", {
                            "type": "HEARTBEAT",
                            "component": "PRESIDENT",
                            "status": "OK",
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        }),
                        self._main_loop
                    )
            except Exception:
                pass  # হার্টবিট ব্যর্থ হলে সিস্টেম চলতে থাকবে
            time.sleep(30)

    def _background_memory_consolidation(self):
        """DEPRECATED - Handled by modular MemoryDecayManager"""
        pass

    # ================================================================
    # INTENT CLASSIFICATION — কী করতে চায় তা বোঝা
    # ================================================================
    async def classify_intent(self, text):
        """
        [REFACTORED] Dynamically classify user intent using LLM and AgentRegistry.
        Returns:
            (intent_name/capability, agent_target, extracted_params)
        """
        if not text:
            return "conversation", "AI_THINK", {}

        text_lower = text.lower().strip()

        # 1. Fast local regex matching for self-handled basics
        if any(w in text_lower for w in ["time", "date", "day", "clock", "today"]):
            if len(text_lower.split()) < 6:
                return "time_date", "SELF", {}
                
        if any(w in text_lower for w in ["who are you", "your name", "who made you"]):
            return "identity", "SELF", {}
            
        if any(w == text_lower for w in ["hello", "hi", "hey", "good morning", "good evening", "good night"]):
            return "greeting", "SELF", {}

        # 2. Dynamic Routing via LLM based on AgentRegistry capabilities
        from AGENT.registry import agent_registry
        caps_dict = agent_registry.get_capabilities()
        
        prompt = f"""You are the JARVIS Kernel Router. Analyze the user request: "{text}"
Available agents and capabilities:
{caps_dict}

RULES:
1. MULTIPLE INTENTS DETECTION: If the request contains multiple distinct tasks, uses conjunctions like "and", "also", or contains multiple verbs indicating different actions (e.g., "Get weather AND show news"), YOU MUST set "is_multi_step" to true and "capability" to null. This guarantees routing to the PlannerAgent.
2. SINGLE INTENT FALLBACK: If the request is strictly a single intent, find the EXACT matching capability name from the list and set "is_multi_step" to false.
3. CONVERSATION: If it requires basic conversation or no capability matches, set capability to null.
4. PARAMS: Extract any relevant parameters (e.g., 'city' for weather, 'query' for research) into the params object.

Output ONLY valid JSON matching this structure:
{{"is_multi_step": false, "capability": "current_weather", "params": {{"city": "Dhaka"}}}}
"""
        import json
        
        # Execute LLM classification
        try:
            loop = asyncio.get_running_loop()
            response_text, provider = await loop.run_in_executor(
                None, self.arbiter.think, "Classify this request.", [{"role": "system", "content": prompt}]
            )
            
            # Parse JSON
            cleaned = response_text.strip()
            if cleaned.startswith("```"):
                lines = cleaned.split("\\n")
                lines = [l for l in lines if not l.strip().startswith("```")]
                cleaned = "\\n".join(lines)
                
            data = json.loads(cleaned)
            
            is_multi_step = data.get("is_multi_step", False)
            capability = data.get("capability")
            params = data.get("params", {})
            params["text"] = text  # Always include raw text
            
            if is_multi_step:
                params["goal"] = text
                return "create_plan", "PLANNER_AGENT", params
                
            if capability:
                agent = agent_registry.find_agent_for_capability(capability)
                if agent:
                    return capability, agent, params
                    
            return "conversation", "AI_THINK", {}
            
        except Exception as e:
            self.logger.warning(f"Dynamic routing failed: {e}. Falling back to AI_THINK.")
            return "conversation", "AI_THINK", {}

    # ================================================================
    # SELF-HANDLED COMMANDS — নিজেই উত্তর দিতে পারে
    # ================================================================
    def _handle_self(self, intent, text):
        """
        সাধারণ প্রশ্নের উত্তর AI কল ছাড়াই দেয়।
        এতে লেটেন্সি কমে এবং অফলাইনেও কাজ করে।
        """
        text_lower = text.lower()

        # --- গ্রিটিং ---
        if intent == "greeting":
            hour = datetime.now().hour
            if hour < 12:
                greeting = "Good morning"
            elif hour < 17:
                greeting = "Good afternoon"
            elif hour < 21:
                greeting = "Good evening"
            else:
                greeting = "Good night"
            return f"{greeting}, Sir. {NAME} is fully operational and at your service."

        # --- সময় / তারিখ ---
        if intent in ("time_date", "time_date"):
            now = datetime.now()
            if any(w in text_lower for w in ["time", "clock"]):
                return f"The current time is {now.strftime('%I:%M %p')}."
            elif any(w in text_lower for w in ["date", "today"]):
                return f"Today is {now.strftime('%A, %B %d, %Y')}."
            elif "day" in text_lower:
                return f"Today is {now.strftime('%A')}."
            else:
                return (
                    f"It is currently {now.strftime('%I:%M %p')} on "
                    f"{now.strftime('%A, %B %d, %Y')}."
                )

        # --- আইডেন্টিটি ---
        if intent == "identity":
            return (
                f"I am {NAME} — Joint Autonomous Responsive Virtual Intelligent System. "
                f"I was exclusively created by Aether AI Lab, designed by {DESIGNER}. "
                f"Currently running version {VERSION}, codename {CODENAME}. "
                f"I am your personal AI assistant, Sir."
            )

        # --- ক্যাপাবিলিটি ---
        if intent == "capability":
            return self.skills.get_capability_report()

        # --- টাস্ক ম্যানেজমেন্ট ---
        if intent == "task_management":
            return self.tasks.get_summary_report()

        # --- মেমোরি রিকল ---
        if intent == "memory_recall":
            # "my name is X" → learn about user
            if "my name is" in text_lower:
                import re as _re
                match = _re.search(r"my name is (\w+)", text_lower)
                if match:
                    name = match.group(1).capitalize()
                    asyncio.run_coroutine_threadsafe(
                        self.memory.learn_fact("preferred_name", name), self._main_loop
                    )
                    return f"Noted, Sir. I will remember that your name is {name}."

            # "do you remember" / "recall" → search memory
            if self._main_loop and self._main_loop.is_running():
                future = asyncio.run_coroutine_threadsafe(
                    self.memory.retrieval.search_all(text, top_k=3),
                    self._main_loop
                )
                try:
                    results = future.result(timeout=5)
                    if results:
                        memories = "; ".join([r.record.content[:100] for r in results])
                        return f"Yes Sir, I recall: {memories}"
                except Exception:
                    pass
            return "I don't have any specific memories about that, Sir."

        return None

    # ================================================================
    # AGENT DISPATCH — নন-SELF ইনটেন্ট সঠিক বাস কন্ট্রোলারে পাঠানো
    # ================================================================
    async def _dispatch_to_agent(self, intent, agent_target, text, params=None):
        """
        [REFACTORED] Direct delegation to UAF Agents via AgentRegistry.
        Returns:
            (response_text, provider)
        """
        if params is None:
            params = {"text": text, "query": text}
            
        from AGENT.registry import agent_registry
        
        # 1. PLANNER_AGENT (Multi-step orchestration)
        if agent_target == "PLANNER_AGENT":
            agent_inst = agent_registry.get_instance("PLANNER_AGENT")
            if not agent_inst: 
                agent_inst = agent_registry.instantiate("PLANNER_AGENT")
            
            self.logger.info(f"Delegating complex task to PLANNER_AGENT")
            res = await agent_inst.execute("create_plan", {"goal": text})
            
            if res and hasattr(res, "success") and res.success:
                plan_id = res.result.get("plan_id")
                # Auto-execute the plan
                await agent_inst.execute("execute_plan", {"plan_id": plan_id})
                return f"I have orchestrated a complex plan to handle your request, Sir. Tasks are executing asynchronously.", f"dispatch:{agent_target}"
            else:
                return f"Planning failed: {res.error if hasattr(res, 'error') else 'Unknown error'}", f"dispatch:{agent_target}"
                
        # 2. General Agent Dispatch
        agent_inst = agent_registry.get_instance(agent_target)
        if not agent_inst:
            agent_inst = agent_registry.instantiate(agent_target)
            
        if agent_inst:
            self.logger.info(f"Delegating execution to {agent_target} for {intent}")
            
            # Execution Validation Layer (Retry + Fallback)
            fallback_map = {
                "weather_api": "weather_cached",
                "search_web": "search_duckduckgo",
                "extract_dom": "extract_text"
            }
            fallback_action = fallback_map.get(intent)
            
            try:
                if hasattr(agent_inst, "execute_with_validation"):
                    res = await agent_inst.execute_with_validation(intent, params, max_retries=2, fallback_action=fallback_action)
                elif hasattr(agent_inst, "execute_with_state"):
                    res = await agent_inst.execute_with_state(intent, params)
                else:
                    res = await agent_inst.execute(intent, params)
                    
                if res and hasattr(res, "success") and res.success:
                    result_text = str(res.result)
                    if hasattr(res, "used_fallback") and res.used_fallback:
                        result_text = f"[Degraded Performance - Fallback Used] {result_text}"
                    return result_text, f"dispatch:{agent_target}"
                elif hasattr(agent_inst, "process"):
                    # Fallback for legacy agents with process() method
                    res = await agent_inst.process(text)
                    return str(res), f"dispatch:{agent_target}"
                else:
                    self.logger.error(f"Agent {agent_target} returned failure: {res.error if hasattr(res, 'error') else 'Unknown error'}")
            except Exception as e:
                self.logger.error(f"Agent {agent_target} execution failed: {e}", exc_info=True)
                
        # 3. Fallback to AI
        self.logger.warning(f"No execution path found for {agent_target}. Falling back to AI_THINK.")
        return await self._think_with_ai(text)


    def _build_signal_data(self, intent, agent_target, text):
        """ইনটেন্ট অনুযায়ী সিগন্যাল ডাটা তৈরি করে।"""

        # App open/close
        if agent_target == "DRIVER_LAUNCHER":
            # "open chrome" → extract app name
            app_name = text.lower()
            for prefix in ["open ", "launch ", "start ", "run ", "execute "]:
                if app_name.startswith(prefix):
                    app_name = app_name[len(prefix):].strip()
                    break
            return {"name": app_name, "raw_text": text}

        # Browser automation
        if agent_target == "DRIVER_BROWSER":
            import re as _re
            # Extract URL if present
            url_match = _re.search(r'https?://\S+', text)
            url = url_match.group(0) if url_match else ""
            return {"url": url, "text": text, "raw_text": text}

        # File operations
        if agent_target == "EXECUTOR_FILESYSTEM":
            return {"pattern": "*", "directory": os.path.expanduser("~"), "raw_text": text}

        # System calls (volume, brightness, screenshot, shutdown)
        if agent_target == "EXECUTOR_SYSCALL":
            if intent == "screenshot":
                return {"action": "screenshot"}
            elif intent == "shutdown":
                return {"action": "shutdown", "raw_text": text}
            elif intent == "volume_control":
                if "up" in text.lower() or "louder" in text.lower():
                    return {"action": "volume_up", "steps": 5}
                elif "down" in text.lower() or "quieter" in text.lower():
                    return {"action": "volume_down", "steps": 5}
                elif "mute" in text.lower():
                    return {"action": "mute"}
            return {"action": intent, "raw_text": text}

        # Reminder
        if agent_target == "DAEMON_REMINDER":
            return {"message": text, "raw_text": text}

        # Default — raw text
        return {"text": text, "raw_text": text}

    def distribute_task(self, task_type: str, payload: dict, preferred_node: str = None) -> dict:
        """
        ডিস্ট্রিবিউটেড নেটওয়ার্কে টাস্ক পাঠায়।
        টাস্ক টাইপ অনুযায়ী নোড সিলেক্ট করে, রিমোট নোড ফেইল করলে লোকাল ফলব্যাক করে।
        """
        self.logger.info(f"Distributing task '{task_type}'...")
        
        target_node = preferred_node
        
        # Determine target node based on task type if not explicitly provided
        if not target_node:
            nodes = self.network_hub._get_all_nodes()
            online_nodes = [n for n in nodes if n.get('status') == 'ONLINE']
            
            for node in online_nodes:
                caps = node.get('capabilities', '')
                if task_type in ["heavy_compute", "code_execution"] and "computation" in caps:
                    target_node = node['name']
                    break
                elif task_type in ["file_storage", "backup_jarvis_data"] and "storage" in caps:
                    target_node = node['name']
                    break
                elif task_type in ["alert", "get_sensor_data", "play_alert_sound"] and ("gpio_sensors" in caps or "alerts" in caps):
                    target_node = node['name']
                    break
        
        # If a remote node is found, dispatch task
        if target_node:
            self.logger.info(f"Routing task to remote node: {target_node}")
            res = self.network_hub.send_task(target_node, task_type, payload)
            if res.get("success"):
                return res.get("response", {})
            else:
                self.logger.warning(f"Remote execution failed on {target_node}. Falling back to LOCAL execution.")
        else:
            self.logger.warning(f"No suitable remote node found for '{task_type}'. Falling back to LOCAL execution.")
            
        # LOCAL FALLBACK
        try:
            if task_type in ["alert", "play_alert_sound"]:
                import platform
                if platform.system() == "Windows":
                    import winsound
                    winsound.Beep(1000, 1000)
                return {"status": "Local simulated alert played."}
            elif task_type == "heavy_compute":
                return {"result": f"Locally computed {len(payload.get('data', []))} items"}
            elif task_type == "file_storage":
                return {"error": "Local storage not configured for this specific task format."}
            elif task_type == "get_sensor_data":
                import random
                return {"success": True, "temperature_c": round(random.uniform(20.0, 30.0), 1), "humidity_percent": round(random.uniform(40.0, 70.0), 1), "simulated": True}
            else:
                return {"error": f"Task {task_type} not supported locally."}
        except Exception as e:
            return {"error": f"Local fallback failed: {e}"}

    def _build_dispatch_acknowledgement(self, intent, agent_target, text):
        """ডিসপ্যাচ করার পরে ইউজারকে কী বলবে তা তৈরি করে।"""
        ack_map = {
            "EXECUTOR_MONITOR": "Running system diagnostics now, Sir.",
            "CRAWLER_NEXUS": f"Searching the web for you, Sir.",
            "DRIVER_LAUNCHER": f"Opening that for you, Sir.",
            "DRIVER_BROWSER": "Opening that in the browser for you, Sir.",
            "EXECUTOR_FILESYSTEM": "Processing your file operation, Sir.",
            "EMAIL_AGENT": "Accessing your secure inbox, Sir.",
            "DAEMON_REMINDER": "Setting that reminder for you, Sir.",
            "EXECUTOR_SYSCALL": "Executing system command, Sir.",
            "SENSOR_OPTIC": "Activating camera, Sir.",
            "EXECUTOR_PROCESS": "Checking running processes, Sir.",
            "RESEARCH_AGENT": "Initiating deep autonomous research, Sir. This might take a moment.",
        }
        return ack_map.get(agent_target, f"Processing your {intent} request, Sir.")

    # ================================================================
    # MAIN PROCESSING PIPELINE — মূল কমান্ড প্রসেসিং
    # ================================================================
    async def process_input(self, text, source="TEXT"):
        """
        মূল প্রসেসিং ফাংশন — সবকিছু এখান দিয়ে যায়। (Wrapper for tracing)
        """
        Tracer.generate_trace_id()
        span = Tracer.start_span("PRESIDENT_PROCESS_INPUT", metadata={"source": source, "text": text})
        
        try:
            result = await self._process_input_internal(text, source)
            span.end(status="success", result=result)
            return result
        except Exception as e:
            span.end(status="failed", error=str(e))
            self.logger.error(f"Global Exception in process_input: {e}", exc_info=True)
            return {
                "response": f"I encountered an error processing your request, Sir: {e}",
                "intent": "error",
                "provider": "system",
                "elapsed": 0.0,
            }

    async def _process_input_internal(self, text, source="TEXT"):
        """
        Internal implementation of process_input.
        """
        if not text or not text.strip():
            return {
                "response": "I didn't catch that, Sir. Could you repeat?",
                "intent": "empty",
                "provider": "self",
                "elapsed": 0.0,
            }

        try:
            start_time = time.time()
            
            # Defense Layer Check
            defense_check = self.defense.is_safe(text, source_id=source)
            if not defense_check["safe"]:
                self.logger.warning(f"Input blocked by DefenseLayer: {defense_check['reason']}")
                return {
                    "response": f"Security Alert: {defense_check['reason']}",
                    "intent": "security_block",
                    "provider": "defense",
                    "elapsed": 0.0,
                }
                
            # Use sanitized text from DefenseLayer
            text = defense_check["sanitized_text"]
            text_lower = text.lower().strip()
            
            # Handle Trace Manager Commands
            if text_lower == "show last trace":
                trace_id = Tracer.get_last_trace_id()
                if not trace_id:
                    return {
                        "response": "There are no recent traces in memory, Sir.",
                        "intent": "trace_inspect",
                        "provider": "tracer",
                        "elapsed": 0.0,
                    }
                trace_output = Tracer.format_trace_output(trace_id)
                return {
                    "response": f"Here is the execution trace:\n\n{trace_output}",
                    "intent": "trace_inspect",
                    "provider": "tracer",
                    "elapsed": 0.0,
                }
                
            if text_lower.startswith("show trace "):
                trace_id = text_lower.replace("show trace ", "").strip()
                trace_output = Tracer.format_trace_output(trace_id)
                return {
                    "response": f"Here is the execution trace:\n\n{trace_output}",
                    "intent": "trace_inspect",
                    "provider": "tracer",
                    "elapsed": 0.0,
                }
            
            if text_lower in ("show metrics", "system metrics", "performance metrics"):
                from MONITOR.metrics import metrics_manager
                dashboard = metrics_manager.print_metrics()
                return {
                    "response": f"Here are the runtime metrics, Sir:\n\n{dashboard}",
                    "intent": "metrics_inspect",
                    "provider": "metrics",
                    "elapsed": 0.0,
                }
                
            if text_lower in ("show agent stats", "agent stats"):
                from MONITOR.metrics import metrics_manager
                stats_dashboard = metrics_manager.print_agent_stats()
                return {
                    "response": f"Here are the agent statistics, Sir:\n\n{stats_dashboard}",
                    "intent": "metrics_inspect",
                    "provider": "metrics",
                    "elapsed": 0.0,
                }

            # Handle Pending Healing Approval
            if self.pending_healing_approval:
                text_lower = text.lower()
                is_yes = any(word in text_lower for word in ["yes", "approve", "go ahead", "do it", "sure", "apply"])
                is_no = any(word in text_lower for word in ["no", "cancel", "stop", "abort", "reject", "wait"])
                
                if is_yes:
                    self.pending_healing_approval = False # Approved
                    return {
                        "response": "Applying the self-healing patch now, Sir.",
                        "intent": "healing_approved",
                        "provider": "self",
                        "elapsed": 0.0,
                    }
                elif is_no:
                    self.pending_healing_approval = False # Rejected
                    return {
                        "response": "Healing patch aborted. The code remains untouched.",
                        "intent": "healing_rejected",
                        "provider": "self",
                        "elapsed": 0.0,
                    }
                else:
                    return {
                        "response": "I am awaiting your approval for the code patch. Please say Yes to apply or No to abort.",
                        "intent": "healing_waiting",
                        "provider": "self",
                        "elapsed": 0.0,
                    }

            with self._state_lock:
                self._command_count += 1
                cmd_id = self._command_count
                network_status = 'ONLINE' if self.is_online else 'OFFLINE'

            self.logger.info(
                f"Command #{cmd_id} from {source}: \"{text}\" [Network: {network_status}]"
            )

            # Step 1: MemoryManager আপডেট (single context source)
            # PHASE 1 FIX: Guard against duplicate context injection
            turn_key = f"user:{hash(text)}:{Tracer.get_last_trace_id()}"
            if turn_key not in self._context_injection_guard:
                self._context_injection_guard.add(turn_key)
                # Keep guard set bounded (last 200 entries)
                if len(self._context_injection_guard) > 200:
                    self._context_injection_guard = set(list(self._context_injection_guard)[-100:])
                self.memory.add_turn("user", text, metadata={"source": source, "trace_id": Tracer.get_last_trace_id()})

            # Step 2: ইনটেন্ট ক্লাসিফাই
            intent, agent_target, params = await self.classify_intent(text)
            self.logger.info(f"Intent: {intent} -> Agent: {agent_target}")

            # Step 3: SELF-হ্যান্ডেল চেক (AI কল ছাড়া)
            if agent_target == "SELF":
                response = self._handle_self(intent, text)
                if response:
                    elapsed = time.time() - start_time
                    self._finalize_response(text, response, intent, "self", elapsed, source)
                    return {
                        "response": response,
                        "intent": intent,
                        "provider": "self",
                        "elapsed": elapsed,
                    }
                # SELF handler returned None → AI ফলব্যাক
                agent_target = "AI_THINK"

            # Step 4: AI_THINK → সরাসরি AI মডেল দিয়ে চিন্তা
            if agent_target == "AI_THINK":
                response, provider = await self._think_with_ai(text)
                elapsed = time.time() - start_time
                self._finalize_response(text, response, intent, provider, elapsed, source)
                return {
                    "response": response,
                    "intent": intent,
                    "provider": provider,
                    "elapsed": elapsed,
                }

            # Step 5: Agent Dispatch → সঠিক বাস কন্ট্রোলারে পাঠানো
            response, provider = await self._dispatch_to_agent(intent, agent_target, text, params)
            elapsed = time.time() - start_time
            self._finalize_response(text, response, intent, provider, elapsed, source)
            return {
                "response": response,
                "intent": intent,
                "provider": provider,
                "elapsed": elapsed,
            }

        except Exception as e:
            raise e

    def _finalize_response(self, user_text, response, intent, provider, elapsed, source):
        """
        প্রতিটি রেসপন্সের পরে: লগিং, কনটেক্সট আপডেট।
        PHASE 3 FIX: Single context source — no double-writing.
        """
        # HeapNode-এ কথোপকথন সেভ (persistent log)
        self.heap.record_conversation("User", user_text, "PRESIDENT")
        self.heap.record_conversation("JARVIS", response, provider.upper())

        # MemoryManager-এ অ্যাসিস্ট্যান্ট টার্ন যোগ (single context source)
        self.memory.add_turn("assistant", response, metadata={"provider": provider, "trace_id": Tracer.get_last_trace_id()})
        
        # Publish interaction_completed event for Background Daemon (Episodic Save)
        if self._main_loop and self._main_loop.is_running():
            asyncio.run_coroutine_threadsafe(
                self.memory.bus.publish("interaction_completed", {
                    "user": user_text,
                    "jarvis": response,
                    "trace_id": Tracer.get_last_trace_id()
                }),
                self._main_loop
            )

        # ক্যাশে সেশন ডাটা আপডেট
        with self._state_lock:
            cmd_count = self._command_count

        self.cache.set("last_intent", intent)
        self.cache.set("last_provider", provider)
        self.cache.set("last_elapsed", f"{elapsed:.2f}s")
        self.cache.set("total_commands", cmd_count)
        self.cache.set("session_start", self._session_start)

        # কনসোল সামারি
        self.logger.info(f"[OK] Response ready ({elapsed:.1f}s via {provider})")

    # ================================================================
    # AI THINKING — Arbiter ফলব্যাক চেইন
    # ================================================================
    async def _think_with_ai(self, text):
        """
        ARBITER-কে দিয়ে AI রেসপন্স নেওয়া হয়।
        ব্লকিং কলকে একটি আলাদা থ্রেডে চালানো হয়।
        Context-aware: ContextManager থেকে কনটেক্সট ইনজেক্ট করে + Vector Memory
        """
        try:
            loop = asyncio.get_running_loop()
            
            # Use modular Context Assembler
            system_prompt = (
                f"You are {NAME}, created by Aether AI Lab and designed by {DESIGNER}. "
                "You are an advanced, helpful, and concise AI assistant. "
                "Use the provided context to answer accurately."
            )
            
            context_payload = await self.memory.build_ai_context(system_prompt, text)
            
            response, provider = await loop.run_in_executor(
                None, self.arbiter.think, text, context_payload
            )
            if response:
                return response, provider
        except Exception as e:
            self.logger.error(f"AI think error: {e}")

        return (
            "I apologize, Sir. All my neural pathways are currently unreachable. "
            "Please check your internet connection or ensure Ollama is running.",
            "emergency_static"
        )

    # ================================================================
    # SIGNAL BUS INTEGRATION — বাসের সাথে সংযুক্তি
    # ================================================================
    async def start(self):
        """
        PRESIDENT Agent চালু করে।
        সিগন্যাল বাসে সাবস্ক্রাইব করে এবং Swarm ও ব্যাকগ্রাউন্ড টাস্ক শুরু করে।
        """
        self.running = True

        # Store the main event loop FIRST — needed by memory decay and agent heartbeats
        try:
            self._main_loop = asyncio.get_running_loop()
        except RuntimeError:
            self._main_loop = None

        # Start the MemoryDaemons now that we have an event loop
        try:
            self.memory.start_daemons()
            self.logger.info("[PRESIDENT] Memory Daemons activated on async loop.")
        except Exception as e:
            self.logger.warning(f"[PRESIDENT] Memory Daemons start deferred: {e}")

        # Start Swarm Infrastructure (PHASE 9 INTEGRATION)
        await self.swarm.start()
        self.logger.info("[PRESIDENT] Swarm Orchestrator activated.")

        # Start Heartbeat Monitor (PHASE 2 STABILIZATION)
        await heartbeat_monitor.start()
        self.logger.info("[PRESIDENT] HeartbeatMonitor activated.")

        # PHASE 1 FIX: Properly await agent.start() now that we are in async context
        agents_started = 0
        for agent_id, agent_ref in self.agents.items():
            try:
                if hasattr(agent_ref, "start"):
                    await agent_ref.start()
                    agents_started += 1
            except Exception as e:
                self.logger.warning(f"[PRESIDENT] Failed to start agent {agent_id}: {e}")
        self.logger.info(f"[PRESIDENT] {agents_started}/{len(self.agents)} agents started successfully.")

        # ইন্টারনেট চেক — প্রথমবার
        self.check_internet()
        with self._state_lock:
            net_status = "ONLINE" if self.is_online else "OFFLINE"
        self.logger.info(f"Initial network status: {net_status}")

        # ব্যাকগ্রাউন্ড ইন্টারনেট মনিটরিং শুরু
        self._internet_check_thread = threading.Thread(
            target=self._background_internet_check, daemon=True
        )
        self._internet_check_thread.start()

        # ব্যাকগ্রাউন্ড হার্টবিট
        self._heartbeat_thread = threading.Thread(
            target=self._background_heartbeat, daemon=True
        )
        self._heartbeat_thread.start()

        # সিগন্যাল বাসে সাবস্ক্রাইব
        await self.bus.subscribe("USER_INPUT", self._on_user_input)
        await self.bus.subscribe("TEXT_INPUT", self._on_text_input)
        await self.bus.subscribe("SYSTEM_STATUS_REQUEST", self._on_status_request)
        await self.bus.subscribe("CLEAR_HISTORY", self._on_clear_history)
        await self.bus.subscribe("SYS_HEAL_REQUEST", self._on_heal_request)

        # সিস্টেম বুট সিগন্যাল
        await self.bus.emit("PRESIDENT", "SYSTEM_BOOT", {
            "status": "active",
            "network": net_status,
            "version": VERSION,
            "codename": CODENAME,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        # মেমোরিতে বুট ইভেন্ট সেভ
        self.heap.record_event(
            "PRESIDENT", "BOOT", f"JARVIS V{VERSION} online — {net_status}"
        )
        self.heap.set_identity("owner_name", DESIGNER)
        self.heap.set_identity("last_boot", datetime.now(timezone.utc).isoformat())

        # Learn system facts directly (we're already in async context)
        try:
            await self.memory.learn_fact("creator", f"JARVIS was created by Aether AI Lab, designed by {DESIGNER}")
        except Exception as e:
            self.logger.warning(f"Failed to learn boot fact: {e}")

        self.logger.info(f"Listening for commands... (Network: {net_status})")

        # মেইন লুপ
        while self.running:
            await asyncio.sleep(0.5)

    async def _on_user_input(self, signal):
        """ভয়েস ইনপুট থেকে আসা কমান্ড প্রসেস করে।"""
        data = signal["data"]
        if isinstance(data, dict):
            text = data.get("text", "")
        else:
            text = str(data)

        if not text:
            return

        # STOP কমান্ড চেক
        if any(word in text.lower() for word in STOP_WORDS):
            await self.bus.emit("PRESIDENT", "STOP_SPEECH", {"reason": "User command"})
            return

        # প্রসেস করে রেসপন্স পাঠানো হচ্ছে
        result = await self.process_input(text, source="VOICE")

        # SPEAK সিগন্যাল পাঠানো — TTS-এর জন্য
        await self.bus.emit("PRESIDENT", "SPEAK", {"text": result["response"]})

        # AI_RESPONSE সিগন্যাল পাঠানো — HUD/UI-এর জন্য
        await self.bus.emit("PRESIDENT", "AI_RESPONSE", {
            "text": result["response"],
            "intent": result["intent"],
            "provider": result["provider"],
            "elapsed": result["elapsed"],
            "query": text,
        })

    async def _on_text_input(self, signal):
        """টেক্সট ইনপুট (HUD/টাইপিং) থেকে আসা কমান্ড প্রসেস করে।"""
        data = signal["data"]
        if isinstance(data, dict):
            text = data.get("text", "")
        else:
            text = str(data)

        if not text:
            return

        result = await self.process_input(text, source="TEXT")

        await self.bus.emit("PRESIDENT", "AI_RESPONSE", {
            "text": result["response"],
            "intent": result["intent"],
            "provider": result["provider"],
            "elapsed": result["elapsed"],
            "query": text,
        })

    async def _on_status_request(self, signal):
        """সিস্টেম স্ট্যাটাস রিপোর্ট করে।"""
        ai_status = self.arbiter.get_status()

        with self._state_lock:
            is_onn = self.is_online
            cmd_count = self._command_count

        status_report = {
            "system": {
                "name": NAME,
                "version": VERSION,
                "codename": CODENAME,
                "designer": DESIGNER,
                "uptime_since": self._session_start,
                "total_commands": cmd_count,
                "network": "ONLINE" if is_onn else "OFFLINE",
            },
            "ai": ai_status,
            "memory": {
                "conversations": self.heap.get_conversation_count(),
                "history_length": len(self.memory.working.get_sliding_window()),
                "last_context": self.heap.get_last_context(),
                "short_term": len(self.memory.working.get_sliding_window()),
                "current_topic": self.memory.working.current_topic,
            },
            "skills": self.skills.get_stats(),
            "tasks": self.tasks.get_stats(),
        }

        await self.bus.emit("PRESIDENT", "SYSTEM_STATUS_REPORT", status_report)

    async def _on_clear_history(self, signal):
        """কথোপকথনের ইতিহাস মুছে দেয় (PHASE 3 FIX: uses MemoryManager)।"""
        self.memory.working.clear()
        self.arbiter.clear_history()
        with self._state_lock:
            self._command_count = 0
        self.logger.info("History cleared. Fresh session started.")
        await self.bus.emit("PRESIDENT", "HISTORY_CLEARED", {"status": "done"})

    async def _on_heal_request(self, signal):
        """AutoHealer থেকে মানুষের অনুমোদনের সিগন্যাল গ্রহণ করে।"""
        data = signal.get("data", {})
        message = data.get("message", "Sir, I require approval for a self-healing patch.")
        self.logger.warning(f"HEAL REQUEST RECEIVED: {message}")
        
        # Set pending approval state
        self.pending_healing_approval = True
        
        # Emit it to the frontend via TEXT_OUT or trigger TTS
        await self.bus.emit("PRESIDENT", "TEXT_OUT", {"response": message, "intent": "heal_request"})

    async def shutdown(self):
        """সিস্টেম গ্রেসফুল শাটডাউন।"""
        self.logger.info("Initiating graceful shutdown...")
        self.running = False

        # সেশন সমাপ্ত
        with self._state_lock:
            cmd_count = self._command_count
        self.memory.end_session()
        self.memory.stop()

        # Clean up threads
        for thread in [self._internet_check_thread,
                       self._heartbeat_thread]:
            if thread and thread.is_alive():
                thread.join(timeout=2)

        with self._state_lock:
            final_command_count = self._command_count

        self.heap.record_event("PRESIDENT", "SHUTDOWN", "User requested shutdown")
        await self.bus.emit("PRESIDENT", "SYSTEM_SHUTDOWN", {
            "reason": "User request",
            "total_commands": final_command_count,
        })

        # Flush logs
        for handler in self.logger.handlers:
            handler.flush()
        self.logger.info(
            f"JARVIS shutdown complete. Total commands: {final_command_count}"
        )

    # ================================================================
    # DIRECT API — বাস ছাড়াই সরাসরি ব্যবহার করার জন্য
    # ================================================================
    def process_input_safe(self, text, source="DIRECT", timeout=30):
        """
        Thread-safe synchronous wrapper for process_input().

        ISSUE #3 FIX: Uses asyncio.run_coroutine_threadsafe() to submit
        work to the main event loop instead of creating nested loops.
        Safe to call from ANY thread (voice pipeline, Flask, unit tests).

        Args:
            text: User input text
            source: Input source identifier
            timeout: Max seconds to wait for response

        Returns:
            dict: {"response": str, "intent": str, "provider": str, "elapsed": float}
        """
        if not text or not text.strip():
            return {
                "response": "I didn't catch that, Sir. Could you repeat?",
                "intent": "empty",
                "provider": "self",
                "elapsed": 0.0,
            }

        # Case 1: Main loop is running — submit safely via run_coroutine_threadsafe
        if self._main_loop and self._main_loop.is_running():
            future = asyncio.run_coroutine_threadsafe(
                self.process_input(text, source),
                self._main_loop
            )
            try:
                return future.result(timeout=timeout)
            except Exception as e:
                self.logger.error(f"process_input_safe error: {e}")
                return {
                    "response": f"Processing error: {e}",
                    "intent": "error",
                    "provider": "system",
                    "elapsed": 0.0,
                }

        # Case 2: No running loop (standalone / unit test) — create one
        try:
            return asyncio.run(self.process_input(text, source))
        except RuntimeError as e:
            self.logger.error(f"Async fallback error: {e}")
            return {
                "response": "System loop error. Please restart JARVIS.",
                "intent": "error",
                "provider": "system",
                "elapsed": 0.0,
            }

    # DEPRECATED: think_sync() removed — use process_input_safe() instead.
    def think_sync(self, text, source="DIRECT"):
        """DEPRECATED — redirects to process_input_safe(). Do not use in new code."""
        self.logger.warning("think_sync() is DEPRECATED. Use process_input_safe().")
        return self.process_input_safe(text, source)

    def get_status_sync(self):
        """সিঙ্ক্রোনাস স্ট্যাটাস রিপোর্ট।"""
        ai_status = self.arbiter.get_status()
        with self._state_lock:
            cmd = self._command_count
            is_onn = self.is_online

        return {
            "name": NAME,
            "version": VERSION,
            "codename": CODENAME,
            "network": "ONLINE" if is_onn else "OFFLINE",
            "total_commands": cmd,
            "session_start": self._session_start,
            "ai_online": ai_status["online_available"],
            "ai_offline": ai_status["offline_available"],
            "conversation_count": self.heap.get_conversation_count(),
            "context_topic": self.memory.working.current_topic,
            "memory_items": len(self.memory.working.get_sliding_window()),
            "skills_registered": len(self.skills._skills),
            "active_tasks": len(self.tasks._active_tasks),
        }


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  PRESIDENT AGENT — Unit Test")
    print("=" * 60)

    # কম্পোনেন্ট ইনিশিয়ালাইজ
    bus = SignalBus()
    atlas = Atlas()
    cache = CacheNode()

    president = PresidentAgent(bus, atlas, cache)

    # === TEST 1: Internet Check ===
    print("\n[TEST 1] Internet connectivity check...")
    online = president.check_internet()
    print(f"  Result: {'ONLINE ✓' if online else 'OFFLINE ✗'}")

    # === TEST 2: Intent Classification ===
    print("\n[TEST 2] Intent classification tests...")
    test_inputs = [
        "Hello JARVIS",
        "What time is it?",
        "Who are you?",
        "Open Chrome",
        "Search for Python tutorials",
        "Send an email to John",
        "Remind me at 5 PM",
        "Take a screenshot",
        "What is quantum computing?",
        "Good morning",
        "Tell me about the weather",
        "Shut down the computer",
        "Help me debug this Python code",
        "What can you do?",
        "Show me my tasks",
        "Remember my name is Adil",
    ]

    for inp in test_inputs:
        intent, agent = president.classify_intent(inp)
        print(f"  \"{inp}\"")
        print(f"    → Intent: {intent} | Agent: {agent}")

    # === TEST 3: Self-handled commands ===
    print("\n[TEST 3] Self-handled responses...")
    self_tests = [
        ("greeting", "Hello JARVIS"),
        ("time_date", "What time is it?"),
        ("identity", "Who created you?"),
        ("capability", "What can you do?"),
        ("task_management", "Show me my tasks"),
    ]

    for intent, text in self_tests:
        result = president._handle_self(intent, text)
        if result:
            print(f"  \"{text}\"")
            print(f"    → \"{result[:120]}...\"")

    # === TEST 4: Full pipeline (thread-safe sync) ===
    print("\n[TEST 4] Full AI pipeline test (process_input_safe)...")
    print("  Sending: 'What is the capital of France?'")

    result = president.process_input_safe("What is the capital of France?")
    if result:
        print(f"  Intent   : {result['intent']}")
        print(f"  Provider : {result['provider']}")
        print(f"  Elapsed  : {result['elapsed']:.2f}s")
        print(f"  Response : \"{result['response'][:300]}\"")

    # === TEST 5: System status ===
    print("\n[TEST 5] System status report...")
    status = president.get_status_sync()
    for key, value in status.items():
        print(f"  {key}: {value}")

    # === TEST 6: RAM Managers ===
    print("\n[TEST 6] RAM Manager integration...")
    print(f"  Context topic: {president.memory.working.current_topic}")
    print(f"  Memory items: {len(president.memory.working.get_sliding_window())}")
    print(f"  Skills registered: {len(president.skills._skills)}")
    print(f"  Active tasks: {len(president.tasks._active_tasks)}")

    print("\n" + "=" * 60)
    print("  [PRESIDENT] All unit tests complete. ✓")
    print("=" * 60)
