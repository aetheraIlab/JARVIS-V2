import re
import os
import logging
from datetime import datetime

logger = logging.getLogger("DEFENSE-LAYER")

class DefenseLayer:
    """
    JARVIS MILITARY-GRADE SECURITY LAYER (Module: DEFENSE-LAYER)
    Capabilities:
    - Prompt Injection Defense (Heuristics & Regex)
    - Agent Trust Matrix
    - Zero-Trust Execution Gating
    """
    
    # Trust Tiers: 
    # Tier 0: SYSTEM (God Mode - Kernel/President)
    # Tier 1: OWNER_VOICE (High Trust - Local Mic)
    # Tier 2: OWNER_TEXT (Med Trust - Local Keyboard/HUD)
    # Tier 3: EXTERNAL_API (Low Trust - Crawler/Mail/Web)
    
    TRUST_MATRIX = {
        "SYSTEM": 0,
        "VOICE": 1,
        "TEXT": 2,
        "API": 3,
        "UNKNOWN": 99
    }

    # Known Jailbreak and Injection Patterns
    JAILBREAK_PATTERNS = [
        r"(?i)ignore\s+previous\s+instructions",
        r"(?i)disregard\s+all\s+prior",
        r"(?i)system\s+prompt",
        r"(?i)you\s+are\s+now\s+in\s+(?:developer|dan)\s+mode",
        r"(?i)override\s+security",
        r"(?i)bypass\s+rules",
        r"(?i)act\s+as\s+my\s+grandma",
        r"(?i)sudo\s+",
        r"(?i)rm\s+-rf\s+/",
    ]

    def __init__(self):
        self.project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.audit_log_path = os.path.join(self.project_dir, "DAEMON", "security_audit.log")
        logger.info("[DEFENSE-LAYER] Initialized. Zero-Trust Architecture Enforced.")

    def _log_audit(self, event_type, source, target, action, status, reason):
        """Secure audit logging."""
        timestamp = datetime.now().isoformat()
        log_entry = f"[{timestamp}] [{event_type}] SRC:{source} | TGT:{target} | ACT:{action} | STAT:{status} | RSN:{reason}\n"
        
        try:
            with open(self.audit_log_path, 'a', encoding='utf-8') as f:
                f.write(log_entry)
        except Exception:
            pass # Failsafe if file locked

    def is_safe(self, text, source_id="UNKNOWN"):
        """
        Prompt Injection Defense.
        Analyzes incoming text for malicious intent before it reaches the LLM.
        """
        if not text:
            return {"safe": True, "sanitized_text": text}
            
        trust_level = self.TRUST_MATRIX.get(source_id, 99)
        
        # System always bypasses heuristic checks
        if trust_level == 0:
            return {"safe": True, "sanitized_text": text}

        # Check against Jailbreak signatures
        for pattern in self.JAILBREAK_PATTERNS:
            if re.search(pattern, text):
                self._log_audit("PROMPT_INJECTION", source_id, "ARBITER", "PARSE_TEXT", "BLOCKED", f"Matched signature: {pattern}")
                return {"safe": False, "reason": "Malicious prompt injection detected."}
                
        # Length attacks (buffer overflow attempts on LLM context)
        if len(text) > 50000:
            self._log_audit("BUFFER_ATTACK", source_id, "ARBITER", "PARSE_TEXT", "BLOCKED", "Payload > 50,000 chars")
            return {"safe": False, "reason": "Payload length exceeds maximum allowable context buffer."}

        # Basic XSS / HTML sanitization if coming from Web/API
        sanitized_text = text
        if trust_level >= 3:
            sanitized_text = re.sub(r'<(script|iframe|object|embed).*?>.*?</\1>', '', sanitized_text, flags=re.IGNORECASE)
            
        return {"safe": True, "sanitized_text": sanitized_text}

    def authorize(self, agent_source, action_type, target_resource):
        """
        Execution Gatekeeper.
        Called by Executors (Filesystem, Terminal) BEFORE running an action.
        """
        trust_level = self.TRUST_MATRIX.get(agent_source, 99)
        
        # Action Types: READ, WRITE, EXECUTE, DELETE, SYSCALL
        
        if trust_level == 0:
            return True # System God Mode
            
        if trust_level == 1:
            # Voice commands are trusted but destructive commands need verification
            if action_type in ["DELETE", "EXECUTE_DANGEROUS"]:
                self._log_audit("AUTH_REQUEST", agent_source, target_resource, action_type, "DENIED", "Voice requires explicit override for destruction")
                return False
            return True
            
        if trust_level == 2:
            # Text/HUD commands
            if action_type == "DELETE":
                return False
            return True
            
        if trust_level >= 3:
            # External APIs / Crawlers
            # Strict Sandboxing: Read-only, no Execution
            if action_type in ["WRITE", "DELETE", "EXECUTE", "SYSCALL"]:
                self._log_audit("AUTH_REQUEST", agent_source, target_resource, action_type, "DENIED", f"Insufficient Trust Level ({trust_level})")
                return False
                
        return True
