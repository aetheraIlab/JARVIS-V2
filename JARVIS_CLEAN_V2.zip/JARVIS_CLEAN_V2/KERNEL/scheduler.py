# ================================================================
# JARVIS AETHER-CORE V2.0 — SIGNAL-BUS (KERNEL)
# ================================================================
# Codename: SIGNAL-BUS
# Role: Event Bus / Pub-Sub System (AsyncIO)

import asyncio
from collections import defaultdict
from datetime import datetime

class SignalBus:
    """
    JARVIS Communication Highway.
    Allows agents to subscribe to specific signals and publish new ones.
    """
    def __init__(self):
        self.subscribers = defaultdict(list)
        self.signal_history = []
        print("[SIGNAL-BUS] Hardware communication bus initialized.")

    async def subscribe(self, signal_type, callback):
        """এজেন্ট যখন নির্দিষ্ট কোনো সিগন্যাল শুনতে চায়।"""
        self.subscribers[signal_type].append(callback)
        # print(f"[SIGNAL-BUS] New subscriber for: {signal_type}")

    async def emit(self, sender, signal_type, data=None):
        """একটি সিগন্যাল পাবলিশ করা হয় যা সব সাবস্ক্রাইবারের কাছে পৌঁছে যাবে।"""
        signal = {
            "ts": datetime.now().isoformat(),
            "sender": sender,
            "type": signal_type,
            "data": data
        }
        
        # হিউম্যান রিড-এবল লগ (ঐচ্ছিক)
        # print(f"[SIGNAL-BUS] {sender} -> {signal_type}")

        # হিস্ট্রি ট্র্যাক রাখা (অডিটের জন্য)
        self.signal_history.append(signal)
        # Keep only the last 1000 signals (efficient slice instead of pop)
        if len(self.signal_history) > 1000:
            self.signal_history = self.signal_history[-1000:]

        # সাবস্ক্রাইবারদের নোটিফাই করা (AsyncIO Task হিসেবে যেন কেউ কাউকে ব্লক না করে)
        if signal_type in self.subscribers:
            tasks = [cb(signal) for cb in self.subscribers[signal_type]]
            if tasks:
                results = await asyncio.gather(*tasks, return_exceptions=True)
                # Log any errors that occurred
                for i, result in enumerate(results):
                    if isinstance(result, Exception):
                        print(f"[SIGNAL-BUS] [ERROR] Subscriber task {i} failed: {result}")

    def get_history(self, limit=10):
        return self.signal_history[-limit:]

# --- Unit Test ---
async def test_subscriber(signal):
    print(f"  [TEST-AGENT] Received Signal: {signal['type']} from {signal['sender']}")

async def main():
    bus = SignalBus()
    await bus.subscribe("AUDIO_INPUT", test_subscriber)
    await bus.emit("USER", "AUDIO_INPUT", "Hello JARVIS")

if __name__ == "__main__":
    asyncio.run(main())
