# ================================================================
# JARVIS AETHER-CORE V2.0 — KERNEL ROUTER
# ================================================================
# Codename : ROUTER
# Role     : Dynamic capability-based routing via AgentRegistry,
#            with LLM-driven planning for complex multi-step tasks,
#            and fallback to the Arbiter inference pipeline.
# ================================================================

import logging
import sys
import os
import asyncio
import json
from typing import Optional

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from INFERENCE.pipeline import Arbiter

# Dynamic agent system (graceful import)
try:
    from AGENT.registry import agent_registry
    from AGENT.response import AgentResponse
    _REGISTRY_AVAILABLE = True
except ImportError:
    _REGISTRY_AVAILABLE = False

# Legacy bus imports (graceful — some systems may not have all busses)
try:
    from BUS.bus_sensory import BusCtrlSen
    from BUS.bus_intel import BusCtrlInt
    from BUS.bus_aware import BusCtrlAwr
    from BUS.bus_motor import BusCtrlMot
    _BUS_AVAILABLE = True
except ImportError:
    _BUS_AVAILABLE = False

try:
    from MANAGER.cognitive_manager import CognitiveManager
    _COGNITIVE_AVAILABLE = True
except ImportError:
    _COGNITIVE_AVAILABLE = False

try:
    from KERNEL.president_agent import PresidentAgent
    _PRESIDENT_AVAILABLE = True
except ImportError:
    _PRESIDENT_AVAILABLE = False

# Phase 8: DAEMON Self-Healing Imports
try:
    from DAEMON.bug_detector import BugDetector
    from DAEMON.dep_monitor import DependencyMonitor
    _DAEMON_AVAILABLE = True
except ImportError:
    _DAEMON_AVAILABLE = False

logger = logging.getLogger("ROUTER")

# ── Intent-to-Capability Mapping ─────────────────────────────────
# Maps natural language intent keywords to agent capability names.
# The router uses this to resolve which agent should handle a request
# BEFORE falling back to the LLM for intent classification.
INTENT_MAP = {
    # Weather
    "weather": "current_weather",
    "forecast": "forecast_5day",
    "temperature": "current_weather",
    "air quality": "air_quality",
    "sunrise": "sunrise_sunset",
    "sunset": "sunrise_sunset",
    # News
    "news": "top_headlines",
    "headlines": "top_headlines",
    "trending": "trending",
    "tech news": "tech_news",
    # Calendar
    "schedule": "get_today_schedule",
    "calendar": "list_events",
    "meeting": "create_event",
    "reminder": "set_reminder",
    "event": "list_events",
    "availability": "get_availability",
    # Finance
    "bitcoin": "crypto_price",
    "crypto": "crypto_price",
    "stock": "stock_price",
    "currency": "currency_convert",
    "exchange rate": "bdt_rates",
    "portfolio": "portfolio_track",
    "price alert": "price_alert",
    # Email
    "email": "check_emails",
    "inbox": "check_emails",
    "draft": "draft_email",
    "send email": "send_email",
    # Code
    "run code": "code_gen",
    "execute code": "code_gen",
    "python": "code_gen",
    # File
    "create file": "file_ops",
    "delete file": "file_ops",
    "search files": "file_ops",
    # Terminal
    "terminal": "shell_exec",
    "command": "shell_exec",
    # Research
    "research": "deep_research",
    "fact check": "fact_checking",
    # Browser
    "browse": "navigate",
    "open website": "navigate",
    "search google": "web_search",
    "web search": "web_search",
}

# Keywords that hint the request requires multi-step planning
COMPLEX_KEYWORDS = [
    "plan", "step by step", "build", "create a project",
    "set up", "organize", "automate", "workflow",
    "compare and", "research and then", "first do", "and then",
    "multiple", "sequence",
]


class KernelCore:
    """
    JARVIS Kernel Router — Dynamic Capability-Based Routing.

    Routing strategy (in priority order):
    1. **Keyword match** → route to the agent owning that capability
    2. **LLM intent classification** → Arbiter determines intent,
       route to matched agent
    3. **Complex multi-step** → route to PlannerAgent for DAG decomposition
    4. **Fallback** → Arbiter generates a pure AI response
    """

    def __init__(self, enable_voice=False):
        self._print_banner()
        self._enable_voice = enable_voice

        # Phase 8: Initialize Self-Healing & Diagnostics First
        if _DAEMON_AVAILABLE:
            try:
                logger.info("Initializing BugDetector (Self-Healing Layer)...")
                self.bug_detector = BugDetector()
                logger.info("Running pre-flight Dependency Health Check...")
                self.dep_monitor = DependencyMonitor()
                self.dep_monitor.health_check()
            except Exception as e:
                logger.error(f"Diagnostics initialization failed: {e}")

        # ১. সিস্টেম ম্যানেজারস (Merged Cognitive Manager)
        self.cognitive_manager = CognitiveManager() if _COGNITIVE_AVAILABLE else None
        self.arbiter = Arbiter()

        # ২. বাস কন্ট্রোলারস
        if _BUS_AVAILABLE:
            self.bus_sen = BusCtrlSen()
            self.bus_int = BusCtrlInt()
            self.bus_awa = BusCtrlAwr()
            self.bus_mot = BusCtrlMot()
        else:
            self.bus_sen = self.bus_int = self.bus_awa = self.bus_mot = None

        # ৩. প্রেসিডেন্ট এজেন্ট (সিঙ্গেল ডিসিশন অথরিটি)
        self.president = PresidentAgent() if _PRESIDENT_AVAILABLE else None
        logger.info("Kernel Core initialized. Architecture cleaned and hardened.")

    def _print_banner(self):
        print("=" * 50)
        print(" JARVIS AETHER-CORE V2.0 - ROUTER ACTIVE (SAFE MODE) ")
        print("=" * 50)

    def boot(self):
        """সিস্টেম বুট সিকোয়েন্স।"""
        logger.info("Booting JARVIS AETHER-CORE V2.0...")
        try:
            if self._enable_voice and self.bus_sen:
                self.bus_sen.start_listening(self.route_input)
            else:
                self._terminal_loop()
        except KeyboardInterrupt:
            self.shutdown()
        except Exception as e:
            logger.critical(f"Critical Boot Failure: {e}")
            self.shutdown()

    # ── Dynamic Routing Engine ────────────────────────────────────

    def route_input(self, user_input) -> str:
        """
        Dynamic routing:
        1. Check for keyword → capability match → route to agent
        2. Check if complex multi-step → route to PlannerAgent
        3. Fall back to PresidentAgent / Arbiter
        """
        if not user_input or not str(user_input).strip():
            return ""

        user_text = str(user_input).strip()
        logger.info(f"User Input: {user_text}")

        response = "I encountered a system error, but I am still online."

        try:
            # ── TIER 1: Direct Capability Routing ──────────────────
            if _REGISTRY_AVAILABLE:
                agent_id, capability = self._match_capability(user_text)
                if agent_id:
                    logger.info(f"[ROUTER] Keyword match → {agent_id}.{capability}")
                    result = self._execute_agent(agent_id, capability, {"text": user_text})
                    if result:
                        return result

            # ── TIER 2: Complex Multi-Step → PlannerAgent ──────────
            if _REGISTRY_AVAILABLE and self._is_complex_request(user_text):
                logger.info("[ROUTER] Complex request detected → PlannerAgent")
                planner_result = self._execute_agent(
                    "PLANNER_AGENT", "create_plan", {"goal": user_text}
                )
                if planner_result:
                    return planner_result

            # ── TIER 3: Legacy PresidentAgent Routing ──────────────
            if self.president:
                response = self.president.process_input(
                    user_text, self.cognitive_manager, self.arbiter
                )
                if not response:
                    response = "I have processed your request."

            # ── TIER 4: Pure Arbiter Fallback ──────────────────────
            else:
                text, provider = self.arbiter.think(user_text)
                response = text or "I apologize, I could not process that."

        except Exception as e:
            logger.error(f"Crash prevented in route_input: {e}")
            response = "An internal error occurred during processing. I am recovering."
        finally:
            try:
                if self.bus_mot:
                    self.bus_mot.speak(response)
            except Exception as se:
                logger.error(f"Speech motor failed: {se}")
                print(f"[JARVIS FALLBACK]: {response}")

        return response

    def _match_capability(self, text: str):
        """
        Match user text against the INTENT_MAP, then find the
        registered agent that owns the capability.

        Returns:
            (agent_id, capability) or (None, None)
        """
        text_lower = text.lower()

        # Check longest keyword matches first to avoid false positives
        # (e.g., "send email" before "email")
        sorted_intents = sorted(INTENT_MAP.keys(), key=len, reverse=True)

        for keyword in sorted_intents:
            if keyword in text_lower:
                capability = INTENT_MAP[keyword]
                agent_id = agent_registry.find_agent_for_capability(capability)
                if agent_id:
                    return agent_id, capability

        return None, None

    def _is_complex_request(self, text: str) -> bool:
        """Check if the request likely needs multi-step planning."""
        text_lower = text.lower()
        return any(kw in text_lower for kw in COMPLEX_KEYWORDS)

    def _execute_agent(self, agent_id: str, action: str, params: dict) -> Optional[str]:
        """
        Execute an agent action synchronously (from the sync router context).

        Returns the formatted response string, or None if execution failed.
        """
        instance = agent_registry.get_instance(agent_id)
        if not instance:
            instance = agent_registry.instantiate(agent_id)
        if not instance:
            logger.warning(f"[ROUTER] Agent '{agent_id}' not available.")
            return None

        try:
            # Run the async execute in a new event loop
            loop = asyncio.new_event_loop()
            try:
                if hasattr(instance, "execute_with_state"):
                    result = loop.run_until_complete(
                        instance.execute_with_state(action, params)
                    )
                else:
                    result = loop.run_until_complete(
                        instance.execute(action, params)
                    )
            finally:
                loop.close()

            if isinstance(result, AgentResponse):
                if result.success:
                    # Format the result for speech/display
                    return self._format_agent_result(agent_id, action, result.result)
                else:
                    logger.warning(f"[ROUTER] Agent {agent_id} returned error: {result.error}")
                    return None
            return str(result)

        except Exception as e:
            logger.error(f"[ROUTER] Agent execution error ({agent_id}.{action}): {e}")
            return None

    @staticmethod
    def _format_agent_result(agent_id: str, action: str, result) -> str:
        """Convert agent result data to a human-readable string."""
        if isinstance(result, str):
            return result
        if isinstance(result, dict):
            # Try to produce a clean summary
            if "message" in result:
                return str(result["message"])
            # For plans, show the goal
            if "goal" in result:
                return f"Plan created for: {result['goal']} ({result.get('progress', {}).get('total', '?')} steps)"
            # For weather/financial data, let the LLM summarize
            try:
                return json.dumps(result, indent=2, default=str)[:500]
            except Exception:
                return str(result)[:500]
        if isinstance(result, list):
            return json.dumps(result[:5], indent=2, default=str)[:500]
        return str(result)[:500]

    # ── Terminal Loop ─────────────────────────────────────────────

    def _terminal_loop(self):
        """টার্মিনাল ইনপুট লুপ।"""
        while True:
            try:
                user_input = input("\n[USER] > ")
                if user_input.lower() in ['exit', 'quit']:
                    self.shutdown()
                    break
                self.route_input(user_input)
            except Exception as e:
                logger.error(f"Error in terminal loop: {e}")

    def shutdown(self):
        """সিস্টেম শাটডাউন।"""
        logger.info("Shutting down system safely...")
        sys.exit(0)
