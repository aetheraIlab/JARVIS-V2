import os
import sys
import time
import logging
import threading
from datetime import datetime
import hashlib

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from KERNEL.defense_layer import DefenseLayer

logger = logging.getLogger("SENTINEL-DAEMON")
log_file_path = os.path.join(os.path.dirname(__file__), "system.log")
if not logger.handlers:
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] JARVIS: %(message)s')
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.setLevel(logging.INFO)

class SentinelDaemon:
    """
    JARVIS MILITARY-GRADE SECURITY LAYER (Module: SENTINEL)
    Capabilities:
    - Background File Integrity Monitoring
    - Unauthorized Process Isolation Detection
    - Immutable Audit Log enforcement
    """
    
    def __init__(self):
        self.project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.defense = DefenseLayer()
        self.running = False
        
        # Files to actively monitor for tampering (Core System Files)
        self.critical_files = [
            "KERNEL/president_agent.py",
            "KERNEL/defense_layer.py",
            "HEAP/vault.py",
            "DAEMON/auto_healer.py"
        ]
        self.file_hashes = {}
        
    def _hash_file(self, rel_path):
        """Returns the SHA-256 hash of a file."""
        abs_path = os.path.join(self.project_dir, rel_path)
        if not os.path.exists(abs_path):
            return None
        hasher = hashlib.sha256()
        try:
            with open(abs_path, 'rb') as f:
                hasher.update(f.read())
            return hasher.hexdigest()
        except Exception:
            return None

    def _init_hashes(self):
        """Initial baseline for critical files."""
        for f in self.critical_files:
            h = self._hash_file(f)
            if h:
                self.file_hashes[f] = h
        logger.info("[SENTINEL] Baseline file integrity hashes generated.")

    def _monitor_loop(self):
        """Continuously monitors the system for security breaches."""
        while self.running:
            try:
                # 1. File Integrity Check
                for f in self.critical_files:
                    current_hash = self._hash_file(f)
                    if current_hash and f in self.file_hashes:
                        if current_hash != self.file_hashes[f]:
                            logger.critical(f"[SECURITY ALERT] Unauthorized modification detected in core file: {f}")
                            self.defense._log_audit("FILE_INTEGRITY", "SENTINEL", f, "MODIFIED", "DETECTED", "File hash changed during runtime")
                            # Update hash so we don't spam
                            self.file_hashes[f] = current_hash
                            
                # 2. Audit Log Size Monitor (Prevent log exhaustion attack)
                audit_log = self.defense.audit_log_path
                if os.path.exists(audit_log):
                    size_mb = os.path.getsize(audit_log) / (1024 * 1024)
                    if size_mb > 50:
                        logger.warning(f"[SENTINEL] Audit log exceeds 50MB. Rotating log...")
                        os.rename(audit_log, audit_log + f".{int(time.time())}.bak")
                        
            except Exception as e:
                logger.error(f"[SENTINEL] Monitor Error: {e}")
                
            time.sleep(10) # Check every 10 seconds

    def start(self):
        if self.running:
            return
        self.running = True
        self._init_hashes()
        self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.thread.start()
        logger.info("[SENTINEL] Security Daemon active. Monitoring process isolation and integrity.")

    def stop(self):
        self.running = False
        if hasattr(self, 'thread'):
            self.thread.join(timeout=2)
        logger.info("[SENTINEL] Security Daemon deactivated.")

if __name__ == "__main__":
    sentinel = SentinelDaemon()
    sentinel.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        sentinel.stop()
