import sys
import os
import subprocess
import logging
import psutil

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# লগার এবং ফাইল লগিং সেটআপ
log_file_path = os.path.join(os.path.dirname(__file__), "system.log")
logger = logging.getLogger("DEP-MONITOR")
if not logger.handlers:
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s')
    
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    logger.setLevel(logging.INFO)

class DependencyMonitor:
    """এই ক্লাস সিস্টেমের র্যাম, ডিস্ক, এবং প্যাকেজ ডিপেন্ডেন্সি মনিটর করে।"""

    def __init__(self):
        self.req_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "requirements.txt")
        logger.info("Dependency Monitor initialized.")

    def health_check(self):
        """পুরো সিস্টেমের হেলথ চেক রান করে।"""
        logger.info("Starting System Health Check...")
        self._check_hardware()
        self._check_pip_packages()
        self._check_ollama()
        logger.info("System Health Check complete.")

    def _check_hardware(self):
        """RAM, CPU এবং Disk স্পেস চেক করে।"""
        # RAM
        ram = psutil.virtual_memory()
        logger.info(f"RAM Usage: {ram.percent}% (Available: {ram.available / (1024**3):.2f} GB)")

        # CPU
        cpu = psutil.cpu_percent(interval=1)
        logger.info(f"CPU Usage: {cpu}%")

        # Cross-platform Disk Check Fix
        disk_path = os.path.abspath(os.sep)
        try:
            disk = psutil.disk_usage(disk_path)
            logger.info(f"Disk Usage: {disk.percent}% (Free: {disk.free / (1024**3):.2f} GB)")
        except Exception as e:
            logger.error(f"Failed to read disk usage: {e}")

        # Temperature (graceful fallback on Windows)
        try:
            temps = psutil.sensors_temperatures()
            if temps:
                for name, entries in temps.items():
                    for entry in entries:
                        logger.info(f"Temp ({name}): {entry.current}°C")
            else:
                logger.debug("Hardware temperature sensors not supported/available on this OS.")
        except AttributeError:
            logger.debug("Hardware temperature sensors not supported/available on this OS.")

    def _check_pip_packages(self):
        """pip check চালিয়ে ব্রোকেন ডিপেন্ডেন্সি খুঁজে বের করে।"""
        try:
            result = subprocess.run([sys.executable, "-m", "pip", "check"], capture_output=True, text=True)
            if result.returncode == 0:
                logger.info("Pip packages: All dependencies are clean and intact.")
            else:
                logger.warning(f"Pip packages issue detected:\n{result.stdout}")
                self._auto_install_missing()
        except Exception as e:
            logger.error(f"Failed to check pip packages: {e}")

    def _auto_install_missing(self):
        """requirements.txt থেকে মিসিং প্যাকেজ ইন্সটল করার চেষ্টা করে।"""
        if os.path.exists(self.req_file):
            logger.info("Attempting auto-install from requirements.txt...")
            try:
                subprocess.run([sys.executable, "-m", "pip", "install", "-r", self.req_file], check=True)
                logger.info("Auto-installation complete.")
            except subprocess.CalledProcessError as e:
                logger.error(f"Auto-installation failed: {e}")
        else:
            logger.warning("requirements.txt not found. Cannot auto-install.")

    def _check_ollama(self):
        """অফলাইন মডেল (Ollama) এর স্ট্যাটাস চেক করে।"""
        try:
            result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
            if result.returncode == 0:
                models = [line.split()[0] for line in result.stdout.split('\n')[1:] if line.strip()]
                logger.info(f"Ollama Online. Available models: {', '.join(models)}")
            else:
                logger.warning("Ollama daemon might be offline.")
        except FileNotFoundError:
            logger.warning("Ollama is not installed or not in system PATH.")
        except Exception as e:
            logger.error(f"Ollama check failed: {e}")

if __name__ == "__main__":
    monitor = DependencyMonitor()
    monitor.health_check()
