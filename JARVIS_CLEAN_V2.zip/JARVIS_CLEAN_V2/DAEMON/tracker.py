# ================================================================
# JARVIS AETHER-CORE V2.0 — ACTIVITY TRACKER (DAEMON LAYER)
# ================================================================
# Codename : SENTINEL-TRACKER
# Role     : User activity and behavior monitoring
# Tech     : psutil + pygetwindow + SQLite persistence
# ================================================================

import sys
import os
import threading
import time
from datetime import datetime, timedelta

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    import pygetwindow as gw
    WINDOW_TRACKING = True
except ImportError:
    gw = None
    WINDOW_TRACKING = False

try:
    from HEAP.database import Atlas
except ImportError:
    Atlas = None


class ActivityTracker:
    """
    JARVIS SENTINEL-TRACKER — ব্যবহারকারী কার্যকলাপ নিরীক্ষক।
    শোধন, স্মৃতি এবং উত্পাদনশীলতা ট্র্যাকিং।
    """

    def __init__(self):
        self.running = False
        self.atlas = Atlas() if Atlas else None
        self.current_window = ""
        self.activity_log = []
        self.process_stats = {}
        self.session_start = time.time()
        self.max_log_size = 1000
        self.keyboard_events = 0
        self.mouse_events = 0
        self._tracking_thread = None
        self._window_lock = threading.Lock()  # Thread safety for current_window
        print("[SENTINEL-TRACKER] Activity tracker initialized.")

    def start(self, interval=5):
        """Start background activity tracking."""
        if self.running:
            return
        
        self.running = True
        self.session_start = time.time()
        self._tracking_thread = threading.Thread(
            target=self._track_loop, args=(interval,), daemon=True
        )
        self._tracking_thread.start()
        print(f"[SENTINEL-TRACKER] [OK] Tracking started.")

    def _track_loop(self, interval):
        """Background tracking loop."""
        while self.running:
            try:
                # Get active window
                window_name = "Unknown"
                if gw:
                    try:
                        win = gw.getActiveWindow()
                        window_name = win.title if win else "Desktop"
                    except:
                        pass
                
                # Get process metrics
                cpu_percent = 0
                memory_percent = 0
                if PSUTIL_AVAILABLE:
                    try:
                        process = psutil.Process()
                        cpu_percent = process.cpu_percent(interval=0.1)
                        memory_percent = process.memory_percent()
                    except:
                        pass
                
                # Log activity
                with self._window_lock:
                    window_changed = window_name != self.current_window
                    if window_changed:
                        self.current_window = window_name
                
                if window_changed:
                    entry = {
                        "timestamp": datetime.now().isoformat(),
                        "window": window_name,
                        "cpu": cpu_percent,
                        "memory": memory_percent,
                    }
                    self.activity_log.append(entry)
                    
                    if self.atlas:
                        try:
                            self.atlas.conn.execute(
                                """INSERT INTO activity_log 
                                   (timestamp, window, cpu, memory)
                                   VALUES (?, ?, ?, ?)""",
                                (entry["timestamp"], entry["window"],
                                 entry["cpu"], entry["memory"])
                            )
                            self.atlas.conn.commit()
                        except Exception:
                            pass
                    
                    if len(self.activity_log) > self.max_log_size:
                        self.activity_log = self.activity_log[-self.max_log_size:]
                
                time.sleep(interval)
            
            except Exception as e:
                print(f"[SENTINEL-TRACKER] [ERROR] Tracking error: {e}")

    def stop(self):
        """Stop activity tracking."""
        self.running = False
        if self._tracking_thread:
            self._tracking_thread.join(timeout=2)
        print("[SENTINEL-TRACKER] [OK] Tracking stopped.")

    def get_active_window(self):
        """Get current window (thread-safe)."""
        with self._window_lock:
            return self.current_window

    def get_recent_activity(self, count=20):
        """Get recent activity log."""
        return self.activity_log[-count:]

    def get_productivity_score(self):
        """Calculate productivity (0-100)."""
        if not self.activity_log:
            return 0
        
        unique_windows = len(set(log["window"] for log in self.activity_log))
        apps = {}
        for log in self.activity_log:
            w = log.get("window", "Unknown")
            apps[w] = apps.get(w, 0) + 1
        
        focus_time = max(apps.values()) if apps else 0
        score = min(100, int((focus_time / len(self.activity_log)) * 100))
        return score

    def get_status(self):
        """Get tracker status."""
        uptime = time.time() - self.session_start
        return {
            "running": self.running,
            "current_window": self.current_window,
            "uptime_seconds": int(uptime),
            "activities_logged": len(self.activity_log),
            "unique_apps": len(self.process_stats),
            "productivity_score": self.get_productivity_score(),
        }


if __name__ == "__main__":
    print("=" * 60)
    print("  SENTINEL-TRACKER — Unit Test")
    print("=" * 60)
    
    # Test 1: Initialization
    print("\n[TEST 1] Tracker initialization...")
    tracker = ActivityTracker()
    print(f"  [OK] Tracker created")
    
    # Test 2: Start tracking
    print("\n[TEST 2] Starting tracker...")
    tracker.start(interval=2)
    print(f"  [OK] Tracking started")
    
    # Test 3: Collect data
    print("\n[TEST 3] Collecting data (6 seconds)...")
    for i in range(3):
        time.sleep(2)
        print(f"  [{i+1}/3] Window: {tracker.get_active_window()[:40]}")
    
    # Test 4: Recent activity
    print("\n[TEST 4] Recent activity...")
    recent = tracker.get_recent_activity(5)
    print(f"  Total logged: {len(tracker.activity_log)}")
    for log in recent:
        print(f"    - {log.get('window', 'Unknown')[:40]}")
    
    # Test 5: Status
    print("\n[TEST 5] Tracker status...")
    status = tracker.get_status()
    for key, value in status.items():
        if key != "current_window":
            print(f"  {key}: {value}")
    
    # Test 6: Stop
    print("\n[TEST 6] Stopping tracker...")
    tracker.stop()
    print(f"  [OK] Tracker stopped")
    
    print("\n" + "=" * 60)
    print("  [SENTINEL-TRACKER] Test complete. [OK]")
    print("=" * 60)
