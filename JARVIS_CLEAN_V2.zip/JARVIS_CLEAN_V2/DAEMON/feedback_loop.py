import os
import sys
import json
import uuid
import pytest
import tempfile
import logging
from datetime import datetime, timezone

# Project root setup
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from INFERENCE.pipeline import Arbiter

logger = logging.getLogger("FEEDBACK_LOOP")
if not logger.handlers:
    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] FEEDBACK: %(message)s')
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    logger.setLevel(logging.INFO)


class FeedbackLoop:
    """
    Testing Feedback Loop Pipeline
    1. Run tests
    2. Capture failures
    3. Store failures in memory
    4. Analyze failure patterns
    5. Suggest fixes
    """
    def __init__(self):
        self.arbiter = Arbiter()
        self.project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.memory_file = os.path.join(self.project_root, "HEAP", "failure_memory.json")
        self.report_file = os.path.join(self.project_root, "PROJECT_ANALYSIS", "FAILURE_REPORT.md")
        self._ensure_dirs()
        self._load_memory()

    def _ensure_dirs(self):
        os.makedirs(os.path.dirname(self.memory_file), exist_ok=True)
        os.makedirs(os.path.dirname(self.report_file), exist_ok=True)

    def _load_memory(self):
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    self.memory = json.load(f)
            except Exception:
                self.memory = {"history": []}
        else:
            self.memory = {"history": []}

    def _save_memory(self):
        with open(self.memory_file, 'w', encoding='utf-8') as f:
            json.dump(self.memory, f, indent=4)

    def run_pipeline(self):
        logger.info("Starting Testing Feedback Loop...")
        failures = self._run_tests_and_capture()
        if not failures:
            logger.info("No failures detected. System is stable.")
            self._write_stable_report()
            return
        
        logger.info(f"Captured {len(failures)} failures. Clustering...")
        clusters = self._cluster_failures(failures)
        
        logger.info("Storing failures in memory...")
        self._store_failures(clusters)
        
        logger.info("Analyzing patterns and suggesting fixes...")
        analysis = self._analyze_and_suggest(clusters)
        
        logger.info("Generating FailureReport...")
        self._generate_report(clusters, analysis)
        logger.info(f"Feedback Loop complete. Report saved to {self.report_file}")

    def _run_tests_and_capture(self):
        """Runs pytest programmatically and captures a JSON report."""
        tests_dir = os.path.join(self.project_root, "tests")
        if not os.path.exists(tests_dir):
            logger.warning("No tests directory found.")
            return []

        fd, temp_path = tempfile.mkstemp(suffix=".xml")
        os.close(fd)
        
        try:
            # Run pytest and output junit xml
            pytest.main([tests_dir, f"--junitxml={temp_path}", "-q"])
            
            # Parse XML to extract failures
            import xml.etree.ElementTree as ET
            tree = ET.parse(temp_path)
            root = tree.getroot()
            
            failures = []
            for testsuite in root.iter('testsuite'):
                for testcase in testsuite.iter('testcase'):
                    for failure in testcase.iter('failure'):
                        failures.append({
                            "test_name": testcase.attrib.get('name'),
                            "file": testcase.attrib.get('file'),
                            "message": failure.attrib.get('message', ''),
                            "traceback": failure.text or ""
                        })
            return failures
        except Exception as e:
            logger.error(f"Failed to run tests: {e}")
            return []
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

    def _cluster_failures(self, failures):
        """Clusters failures based on error messages or files."""
        clusters = {}
        for f in failures:
            # simple clustering by error message (first line)
            msg = f['message'].split('\n')[0] if f['message'] else "Unknown Error"
            # Normalize to avoid too many unique clusters
            msg_head = msg[:100]
            if msg_head not in clusters:
                clusters[msg_head] = []
            clusters[msg_head].append(f)
        return clusters

    def _store_failures(self, clusters):
        timestamp = datetime.now(timezone.utc).isoformat()
        run_data = {
            "id": f"run_{uuid.uuid4().hex[:8]}",
            "timestamp": timestamp,
            "clusters": clusters
        }
        self.memory["history"].append(run_data)
        # Keep last 10 runs
        if len(self.memory["history"]) > 10:
            self.memory["history"] = self.memory["history"][-10:]
        self._save_memory()

    def _analyze_and_suggest(self, clusters):
        """Uses LLM to analyze the clustered failures and suggest fixes."""
        analysis_results = {}
        for cluster_name, fails in clusters.items():
            sample_fail = fails[0]
            prompt = (
                f"You are a Senior Python Developer. Analyze this test failure cluster which occurred {len(fails)} times.\n"
                f"Test Name: {sample_fail['test_name']}\n"
                f"File: {sample_fail['file']}\n"
                f"Error: {sample_fail['message']}\n"
                f"Traceback:\n{sample_fail['traceback'][:1500]}\n\n"
                f"Provide a brief analysis of why this is failing, potential performance bottlenecks if applicable, and a suggested fix (code snippet if possible). Do not apply the fix."
            )
            response, provider = self.arbiter.think(prompt)
            analysis_results[cluster_name] = response
        return analysis_results

    def _generate_report(self, clusters, analysis):
        lines = []
        lines.append("# JARVIS Testing Feedback Loop — Failure Report")
        lines.append(f"**Date:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
        lines.append(f"**Total Failures:** {sum(len(f) for f in clusters.values())}")
        lines.append(f"**Unique Clusters:** {len(clusters)}\n")
        
        lines.append("## Executive Summary")
        lines.append("The feedback loop detected failures during the automated test suite. The failures have been clustered and analyzed below. **No fixes have been automatically applied.**\n")
        
        for idx, (cluster_name, fails) in enumerate(clusters.items(), 1):
            lines.append(f"### Cluster {idx}: {cluster_name}")
            lines.append(f"- **Frequency:** {len(fails)} occurrences")
            lines.append(f"- **Affected Tests:** {', '.join(set(f['test_name'] for f in fails))}\n")
            
            lines.append("#### AI Analysis & Suggested Fix")
            ai_text = analysis.get(cluster_name, "No analysis available.")
            lines.append(f"{ai_text}\n")
            
            lines.append("#### Sample Traceback")
            lines.append("```python")
            lines.append(fails[0]['traceback'])
            lines.append("```\n")
            
        with open(self.report_file, 'w', encoding='utf-8') as f:
            f.write("\n".join(lines))

    def _write_stable_report(self):
        lines = []
        lines.append("# JARVIS Testing Feedback Loop — Failure Report")
        lines.append(f"**Date:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}\n")
        lines.append("## Executive Summary")
        lines.append("✅ **All tests passed successfully.** No failure patterns or bottlenecks detected. System is stable.")
        with open(self.report_file, 'w', encoding='utf-8') as f:
            f.write("\n".join(lines))


if __name__ == "__main__":
    loop = FeedbackLoop()
    loop.run_pipeline()
