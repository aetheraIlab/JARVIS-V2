# ================================================================
# JARVIS AETHER-CORE V2.0 — HERALD (LAYER 6 / AWARENESS)
# ================================================================
# Codename : HERALD
# Role     : Context-Aware Speech Generator
# Tech     : TTS + Vision context injection
# ================================================================

import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class Herald:
    """
    JARVIS HERALD — কনটেক্সট-সচেতন স্পিচ জেনারেটর।
    OPTIC-এর ভিজুয়াল ডাটা এবং WATCHDOG-এর অ্যাক্টিভিটি ডাটা ব্যবহার করে
    পরিস্থিতি অনুযায়ী JARVIS-কে কথা বলতে দেয়।
    """

    def __init__(self):
        self.greetings = {
            "morning": "Good morning, Sir. Systems are nominal.",
            "afternoon": "Good afternoon, Sir. All agents operational.",
            "evening": "Good evening, Sir. AETHER-CORE standing by.",
            "night": "It's getting late, Sir. Shall I enable night mode?",
        }
        print("[HERALD] Context speech generator initialized.")

    def get_time_greeting(self):
        """সময় অনুযায়ী শুভেচ্ছা বার্তা।"""
        from datetime import datetime
        hour = datetime.now().hour
        if 5 <= hour < 12:
            return self.greetings["morning"]
        elif 12 <= hour < 17:
            return self.greetings["afternoon"]
        elif 17 <= hour < 21:
            return self.greetings["evening"]
        else:
            return self.greetings["night"]

    def generate_context_speech(self, active_window="", faces_detected=0, cpu_percent=0):
        """
        বর্তমান পরিস্থিতি অনুযায়ী কথা তৈরি করে।
        """
        parts = []

        # ফেস ডিটেকশন কনটেক্সট
        if faces_detected > 1:
            parts.append(f"I detect {faces_detected} persons in front of the camera.")
        elif faces_detected == 1:
            parts.append("I see you, Sir.")

        # সিস্টেম লোড কনটেক্সট
        if cpu_percent > 85:
            parts.append(f"Warning: CPU is at {cpu_percent}%. Consider closing heavy applications.")
        elif cpu_percent > 60:
            parts.append(f"CPU load is moderate at {cpu_percent}%.")

        # অ্যাক্টিভ উইন্ডো কনটেক্সট
        if active_window:
            if "code" in active_window.lower() or "visual studio" in active_window.lower():
                parts.append("I see you're coding. Need any assistance?")
            elif "chrome" in active_window.lower() or "firefox" in active_window.lower():
                parts.append("Browsing the web. Shall I search for anything?")
            elif "discord" in active_window.lower():
                parts.append("Discord is active. Any messages to relay?")

        return " ".join(parts) if parts else self.get_time_greeting()

    def boot_announcement(self):
        """সিস্টেম বুট হওয়ার পর ঘোষণা।"""
        return "JARVIS AETHER-CORE version 2.0 is now online. All neural pathways active. Awaiting your command, Sir."

    def shutdown_announcement(self):
        """সিস্টেম শাটডাউনের সময় ঘোষণা।"""
        return "Shutting down all systems. It was a pleasure serving you, Sir. Allah Hafez."


if __name__ == "__main__":
    print("=" * 50)
    print("  HERALD — Unit Test")
    print("=" * 50)
    h = Herald()
    print(f"\n[TEST] Greeting: {h.get_time_greeting()}")
    print(f"[TEST] Boot: {h.boot_announcement()}")
    print(f"[TEST] Context: {h.generate_context_speech('Visual Studio Code', 1, 45)}")
    print("\n[HERALD] Unit test complete. ✓")
