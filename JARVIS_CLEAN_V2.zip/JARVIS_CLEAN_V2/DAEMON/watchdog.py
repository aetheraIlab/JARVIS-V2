# ================================================================
# JARVIS AETHER-CORE V2.0 — SYSTEM WATCHDOG (DAEMON LAYER)
# ================================================================
# Codename : SENTINEL-WATCHDOG
# Role     : System health monitoring and alerting
# Tech     : psutil + threshold-based alerts
# ================================================================

import sys
import os
import time
import threading
from datetime import datetime

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    print("[SENTINEL-WATCHDOG] [WARNING] psutil not installed.")
    PSUTIL_AVAILABLE = False

try:
    from KERNEL.scheduler import SignalBus
except ImportError:
    SignalBus = None


class SystemWatchdog:
    """
    JARVIS SENTINEL-WATCHDOG — সিস্টেম স্বাস্থ্য পর্যবেক্ষক।
    CPU, RAM, ডিস্ক, ব্যাটারি এবং অন্যান্য সিস্টেম মেট্রিক্স পর্যবেক্ষণ করে।
    """

    def __init__(self):
        self.running = False
        self.bus = SignalBus() if SignalBus else None
        
        # Alert thresholds
        self.thresholds = {
            "cpu_warn": 70,
            "cpu_critical": 90,
            "memory_warn": 80,
            "memory_critical": 95,
            "disk_warn": 80,
            "disk_critical": 95,
            "battery_warn": 20,
            "battery_critical": 10,
        }
        
        # Alert tracking
        self.active_alerts = {}
        self.alert_cooldown = 60
        
        # Health metrics
        self.health_history = []
        self.max_history = 500
        self.session_start = time.time()
        
        self._monitoring_thread = None
        self._init_watchdog()
        print("[SENTINEL-WATCHDOG] System watchdog initialized.")

    def _init_watchdog(self):
        if not PSUTIL_AVAILABLE:
            print("[SENTINEL-WATCHDOG] [WARNING] psutil not available.")

    def start(self, interval=10):
        """Start system monitoring."""
        if self.running:
            return
        
        self.running = True
        self._monitoring_thread = threading.Thread(
            target=self._monitor_loop, args=(interval,), daemon=True
        )
        self._monitoring_thread.start()
        print(f"[SENTINEL-WATCHDOG] [OK] Monitoring started.")

    def _monitor_loop(self, interval):
        """Background monitoring loop."""
        while self.running:
            try:
                metrics = self._collect_metrics()
                self._check_alerts(metrics)
                self.health_history.append(metrics)
                
                if len(self.health_history) > self.max_history:
                    self.health_history = self.health_history[-self.max_history:]
                
                time.sleep(interval)
            
            except Exception as e:
                print(f"[SENTINEL-WATCHDOG] [ERROR] Error: {e}")

    def _collect_metrics(self):
        """Collect system metrics."""
        timestamp = datetime.now().isoformat()
        
        if not PSUTIL_AVAILABLE:
            return {
                "timestamp": timestamp,
                "cpu": 0,
                "memory": 0,
                "disk": 0,
                "battery": 0,
            }
        
        try:
            cpu = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory().percent
            disk = psutil.disk_usage("/").percent
            
            # Battery
            try:
                battery = psutil.sensors_battery()
                # Only report battery if it exists (laptop has battery)
                # Desktop systems will return None
                if battery is None:
                    battery_percent = 100  # Desktop = assume plugged in
                else:
                    battery_percent = battery.percent if battery else 100
            except:
                battery_percent = 100  # Error reading = assume no battery issue
            
            return {
                "timestamp": timestamp,
                "cpu": cpu,
                "memory": memory,
                "disk": disk,
                "battery": battery_percent,
            }
        
        except Exception as e:
            return {
                "timestamp": timestamp,
                "cpu": 0,
                "memory": 0,
                "disk": 0,
                "battery": 0,
            }

    def _check_alerts(self, metrics):
        """Check thresholds and emit alerts."""
        current_time = time.time()
        
        # CPU alert
        cpu = metrics.get("cpu", 0)
        if cpu > self.thresholds["cpu_critical"]:
            self._emit_alert("cpu_critical", f"CPU at {cpu}%", current_time)
        elif cpu > self.thresholds["cpu_warn"]:
            self._emit_alert("cpu_warning", f"CPU at {cpu}%", current_time)
        
        # Memory alert
        mem = metrics.get("memory", 0)
        if mem > self.thresholds["memory_critical"]:
            self._emit_alert("memory_critical", f"Memory at {mem}%", current_time)
        elif mem > self.thresholds["memory_warn"]:
            self._emit_alert("memory_warning", f"Memory at {mem}%", current_time)
        
        # Disk alert
        disk = metrics.get("disk", 0)
        if disk > self.thresholds["disk_critical"]:
            self._emit_alert("disk_critical", f"Disk at {disk}%", current_time)
        elif disk > self.thresholds["disk_warn"]:
            self._emit_alert("disk_warning", f"Disk at {disk}%", current_time)
        
        # Battery alert
        battery = metrics.get("battery", 100)
        if battery < self.thresholds["battery_critical"]:
            self._emit_alert("battery_critical", f"Battery at {battery}%", current_time)
        elif battery < self.thresholds["battery_warn"]:
            self._emit_alert("battery_warning", f"Battery at {battery}%", current_time)

    def _emit_alert(self, alert_type, message, current_time):
        """Emit alert with cooldown (thread-safe, non-async)."""
        last_trigger = self.active_alerts.get(alert_type, 0)
        if current_time - last_trigger < self.alert_cooldown:
            return
        
        self.active_alerts[alert_type] = current_time
        
        # Note: Cannot use await in thread context - this runs in background thread
        # Alert system is printed to console for immediate feedback
        # For full integration with async bus, see BUS-CTRL-AWR integration
        print(f"[SENTINEL-WATCHDOG] [ALERT] {alert_type}: {message}")

    def stop(self):
        """Stop monitoring."""
        self.running = False
        if self._monitoring_thread:
            self._monitoring_thread.join(timeout=2)
        print("[SENTINEL-WATCHDOG] [OK] Monitoring stopped.")

    def get_health_score(self):
        """Calculate health score (0-100)."""
        if not self.health_history:
            return 100
        
        latest = self.health_history[-1]
        cpu = latest.get("cpu", 0)
        mem = latest.get("memory", 0)
        disk = latest.get("disk", 0)
        battery = latest.get("battery", 100)
        
        score = 100
        score -= max(0, (cpu - 50) * 0.5)
        score -= max(0, (mem - 70) * 0.3)
        score -= max(0, (disk - 80) * 0.1)
        score -= max(0, (100 - battery) * 0.5)
        
        return max(0, min(100, int(score)))

    def get_status(self):
        """Get watchdog status."""
        latest_metrics = self.health_history[-1] if self.health_history else {}
        uptime = time.time() - self.session_start
        
        return {
            "running": self.running,
            "uptime_seconds": int(uptime),
            "health_score": self.get_health_score(),
            "active_alerts": len(self.active_alerts),
            "latest_metrics": latest_metrics,
        }


if __name__ == "__main__":
    print("=" * 60)
    print("  SENTINEL-WATCHDOG — Unit Test")
    print("=" * 60)
    
    # Test 1: Initialization
    print("\n[TEST 1] Watchdog initialization...")
    watchdog = SystemWatchdog()
    print(f"  [OK] Watchdog created")
    
    # Test 2: Start monitoring
    print("\n[TEST 2] Starting monitoring...")
    watchdog.start(interval=3)
    print(f"  [OK] Monitoring started")
    
    # Test 3: Collect metrics
    print("\n[TEST 3] Collecting metrics (9 seconds)...")
    for i in range(3):
        time.sleep(3)
        latest = watchdog.health_history[-1] if watchdog.health_history else {}
        if latest:
            cpu = latest.get("cpu", 0)
            mem = latest.get("memory", 0)
            print(f"  [{i+1}] CPU: {cpu:.1f}% | Memory: {mem:.1f}%")
    
    # Test 4: Health score
    print("\n[TEST 4] System health...")
    status = watchdog.get_status()
    print(f"  Health score: {status['health_score']}/100")
    print(f"  Active alerts: {status['active_alerts']}")
    print(f"  History entries: {len(watchdog.health_history)}")
    
    # Test 5: Alert thresholds
    print("\n[TEST 5] Alert thresholds...")
    for metric, threshold in watchdog.thresholds.items():
        print(f"  {metric}: {threshold}")
    
    # Test 6: Stop monitoring
    print("\n[TEST 6] Stopping watchdog...")
    watchdog.stop()
    print(f"  [OK] Watchdog stopped")
    
    print("\n" + "=" * 60)
    print("  [SENTINEL-WATCHDOG] Test complete. [OK]")
    print("=" * 60)
