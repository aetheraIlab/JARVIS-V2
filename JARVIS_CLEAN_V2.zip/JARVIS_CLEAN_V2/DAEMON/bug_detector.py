import sys
import os
import hashlib
import traceback
import logging
import subprocess
import threading

# Project root setup
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from HEAP.database import Atlas

# Configure logging
log_file_path = os.path.join(os.path.dirname(__file__), "errors.log")
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)s] JARVIS: %(message)s',
    handlers=[
        logging.FileHandler(log_file_path, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("BUG-DETECTOR")
logger.setLevel(logging.INFO)

class BugDetector:
    """
    JARVIS SELF-HEALING ENGINE (Module: BUG-DETECTOR)
    Capabilities:
    - Crash interception
    - Fast-path dependency repair
    - Stack trace parsing
    """
    
    def __init__(self):
        self.atlas = Atlas()
        self.error_counts = {}
        self.healing_attempts = {}
        self.project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        # Setup Exception hook
        sys.excepthook = self.custom_excepthook
        logger.info("Self-Healing Bug Detector initialized. Global exception hook active.")

    def custom_excepthook(self, exc_type, exc_value, exc_traceback):
        """Global exception handler intercept."""
        error_msg = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logging.error(f"[SYSTEM CRASH DETECTED]\n{error_msg}")
        
        # Fast-Path: Dependency Auto-Install
        if issubclass(exc_type, ImportError) or issubclass(exc_type, ModuleNotFoundError):
            if self._handle_missing_dependency(exc_value):
                # Successfully handled dependency, we can theoretically restart the module or ignore
                pass

        # Trigger advanced healing logic
        # We spawn it in a thread so the main crash doesn't get blocked
        healing_thread = threading.Thread(target=self.handle_exception, args=(exc_type, exc_value, exc_traceback))
        healing_thread.start()
        healing_thread.join(timeout=10) # wait briefly
        
        # Finally, call original excepthook for default behavior
        sys.__excepthook__(exc_type, exc_value, exc_traceback)

    def _handle_missing_dependency(self, exc_value):
        """Extracts missing module name and attempts to pip install it."""
        try:
            # "No module named 'requests'" -> requests
            msg = str(exc_value)
            if "No module named" in msg:
                module_name = msg.split("'")[1]
            else:
                return False
                
            logger.warning(f"Dependency missing: {module_name}. Attempting Auto-Repair...")
            
            # Map common import names to pip packages
            pip_map = {
                "cv2": "opencv-python",
                "bs4": "beautifulsoup4",
                "PIL": "Pillow",
                "dotenv": "python-dotenv",
                "speech_recognition": "SpeechRecognition",
                "googleapiclient": "google-api-python-client"
            }
            package_name = pip_map.get(module_name, module_name)
            
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", package_name],
                capture_output=True, text=True
            )
            
            if result.returncode == 0:
                logger.info(f"Successfully auto-installed dependency: {package_name}")
                self._log_to_db("DEPENDENCY_REPAIR", str(exc_value), "N/A", hashlib.md5(package_name.encode()).hexdigest())
                return True
            else:
                logger.error(f"Failed to auto-install {package_name}: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"Dependency auto-repair failed: {e}")
            return False

    def handle_exception(self, exc_type, exc_value, exc_traceback):
        """Parses traceback and delegates to the AutoHealer."""
        tb_lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        full_traceback = "".join(tb_lines)

        error_signature = hashlib.md5(full_traceback.encode('utf-8')).hexdigest()
        error_type = exc_type.__name__
        error_msg = str(exc_value)

        self._log_to_db(error_type, error_msg, full_traceback, error_signature)

        # Extract project file
        tb_extracted = traceback.extract_tb(exc_traceback)
        faulty_file = None
        faulty_line = None
        
        for frame in reversed(tb_extracted):
            frame_file = os.path.abspath(frame.filename)
            # Find the most recent frame that belongs to our project, ignore stdlib/site-packages
            if frame_file.startswith(self.project_dir) and "site-packages" not in frame_file.lower() and "lib\\" not in frame_file.lower():
                faulty_file = frame_file
                faulty_line = frame.lineno
                break
                
        if not faulty_file:
            logger.warning("Crash occurred outside of project scope (likely C-extension or stdlib). Aborting auto-heal.")
            return
            
        # Self-Protection
        if "auto_healer.py" in faulty_file or "bug_detector.py" in faulty_file:
            logger.warning("Error originated in Self-Healing Engine. Self-protection active. Ignoring.")
            return

        # Frequency Tracking
        if error_signature not in self.error_counts:
            self.error_counts[error_signature] = 0
            self.healing_attempts[error_signature] = 0
            
        self.error_counts[error_signature] += 1
        freq = self.error_counts[error_signature]
        attempts = self.healing_attempts[error_signature]
        
        logger.info(f"Crash Signature [{error_signature[:8]}] - Occurred {freq} times. Healing attempts: {attempts}/3")

        # Trigger AI Healer
        if freq >= 2:
            if attempts >= 3:
                logger.warning(f"Max healing attempts (3) reached for {error_signature}. Flagging as unrecoverable.")
                return
                
            self.healing_attempts[error_signature] += 1
            logger.warning(f"Triggering AutoHealer for {faulty_file}:{faulty_line}...")
            self.trigger_auto_healer(error_signature, full_traceback, faulty_file, faulty_line)

    def _log_to_db(self, error_type, error_msg, full_traceback, signature):
        try:
            payload = f"Signature: {signature} | Type: {error_type} | Msg: {error_msg}"
            self.atlas.commit_signal("BUG_DETECTOR", "AUTO_HEALER", "SYS_ERROR", payload)
        except Exception:
            pass

    def trigger_auto_healer(self, signature, tb_str, faulty_file, faulty_line):
        try:
            from DAEMON.auto_healer import AutoHealer
            healer = AutoHealer()
            healer.heal(faulty_file, faulty_line, signature, tb_str)
        except Exception as e:
            logger.error(f"Failed to trigger AutoHealer: {e}")

if __name__ == "__main__":
    detector = BugDetector()
    print("[BUG-DETECTOR] Engine ready. Simulating crash...")
    try:
        import missing_fake_module
    except Exception as e:
        sys.excepthook(type(e), e, e.__traceback__)
