# ================================================================
# JARVIS AETHER-CORE V2.0 — REMINDER AGENT (DAEMON LAYER)
# ================================================================
# Codename : SENTINEL-REMINDER
# Role     : Time-based reminder & alarm management
# Tech     : SQLite (Atlas) + threading + desktop notifications
# ================================================================

import sys
import os
import re
import threading
import time
import logging
from datetime import datetime, timedelta

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from HEAP.database import Atlas
except ImportError:
    Atlas = None

try:
    from DAEMON.reminder import Beacon
except ImportError:
    Beacon = None

logger = logging.getLogger("SENTINEL-REMINDER")


class ReminderAgent:
    """
    JARVIS SENTINEL-REMINDER — রিমাইন্ডার এজেন্ট।

    ফিচার:
    1. প্রাকৃতিক ভাষা থেকে সময় পার্স করা ("remind me in 5 minutes")
    2. SQLite-তে রিমাইন্ডার সংরক্ষণ
    3. ব্যাকগ্রাউন্ড চেকিং থ্রেড
    4. ডেস্কটপ নোটিফিকেশন (Beacon)
    5. রিকারিং রিমাইন্ডার
    """

    def __init__(self, atlas=None):
        self.atlas = atlas or (Atlas() if Atlas else None)
        self.beacon = Beacon() if Beacon else None
        self._lock = threading.RLock()
        self.running = False
        self._check_thread = None

        # টেবিল তৈরি
        self._ensure_tables()

        # অ্যাক্টিভ রিমাইন্ডার ক্যাশ
        self._active = []
        self._load_active()

        logger.info(
            f"ReminderAgent online. Active reminders: {len(self._active)}"
        )
        print(f"[SENTINEL-REMINDER] Reminder agent initialized. "
              f"Active: {len(self._active)}")

    def _ensure_tables(self):
        """রিমাইন্ডার টেবিল তৈরি করে।"""
        if not self.atlas:
            return
        cursor = self.atlas.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message TEXT NOT NULL,
                trigger_time TEXT NOT NULL,
                created_at TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                recurring TEXT DEFAULT NULL,
                source TEXT DEFAULT 'user'
            )
        """)
        self.atlas.conn.commit()

    def _load_active(self):
        """অ্যাক্টিভ রিমাইন্ডার মেমোরিতে লোড করে।"""
        if not self.atlas:
            return
        try:
            rows = self.atlas.query(
                "SELECT * FROM reminders WHERE status = 'active' "
                "ORDER BY trigger_time ASC"
            )
            self._active = [dict(r) for r in rows]
        except Exception:
            self._active = []

    # ================================================================
    # NATURAL LANGUAGE TIME PARSING
    # ================================================================
    def parse_time(self, text):
        """
        প্রাকৃতিক ভাষা থেকে সময় বের করে।

        সমর্থিত ফরম্যাট:
        - "in 5 minutes" / "in 2 hours" / "in 1 day"
        - "at 5 PM" / "at 17:30"
        - "tomorrow at 9 AM"
        - "after 30 seconds"

        Returns:
            datetime or None
        """
        text_lower = text.lower().strip()
        now = datetime.now()

        # Pattern: "in X minutes/hours/days/seconds"
        match = re.search(
            r'in\s+(\d+)\s*(second|sec|minute|min|hour|hr|day|week)s?',
            text_lower
        )
        if match:
            amount = int(match.group(1))
            unit = match.group(2)
            delta_map = {
                "second": timedelta(seconds=amount),
                "sec": timedelta(seconds=amount),
                "minute": timedelta(minutes=amount),
                "min": timedelta(minutes=amount),
                "hour": timedelta(hours=amount),
                "hr": timedelta(hours=amount),
                "day": timedelta(days=amount),
                "week": timedelta(weeks=amount),
            }
            delta = delta_map.get(unit)
            if delta:
                return now + delta

        # Pattern: "after X minutes/hours"
        match = re.search(
            r'after\s+(\d+)\s*(second|sec|minute|min|hour|hr|day)s?',
            text_lower
        )
        if match:
            amount = int(match.group(1))
            unit = match.group(2)
            delta_map = {
                "second": timedelta(seconds=amount),
                "sec": timedelta(seconds=amount),
                "minute": timedelta(minutes=amount),
                "min": timedelta(minutes=amount),
                "hour": timedelta(hours=amount),
                "hr": timedelta(hours=amount),
                "day": timedelta(days=amount),
            }
            delta = delta_map.get(unit)
            if delta:
                return now + delta

        # Pattern: "at H:MM" or "at H PM/AM"
        match = re.search(
            r'at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?',
            text_lower
        )
        if match:
            hour = int(match.group(1))
            minute = int(match.group(2)) if match.group(2) else 0
            period = match.group(3)

            if period == "pm" and hour < 12:
                hour += 12
            elif period == "am" and hour == 12:
                hour = 0

            target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            # যদি সময় পার হয়ে গেছে, পরের দিনের জন্য সেট করো
            if target <= now:
                target += timedelta(days=1)

            # "tomorrow" কিওয়ার্ড
            if "tomorrow" in text_lower:
                if target.date() == now.date():
                    target += timedelta(days=1)

            return target

        # Default: 5 minutes from now
        return now + timedelta(minutes=5)

    def _extract_message(self, text):
        """রিমাইন্ডার মেসেজ এক্সট্র্যাক্ট করে।"""
        # "remind me to X" pattern
        match = re.search(r'remind\s+(?:me\s+)?(?:to\s+)?(.+?)(?:\s+(?:in|at|after|tomorrow)\s)', text, re.IGNORECASE)
        if match:
            return match.group(1).strip()

        # "remind me X" (time at end)
        match = re.search(r'remind\s+(?:me\s+)?(?:to\s+)?(.+)', text, re.IGNORECASE)
        if match:
            msg = match.group(1).strip()
            # Remove time references from the end
            msg = re.sub(
                r'\s*(?:in\s+\d+\s*\w+|at\s+\d+[:\d]*\s*(?:am|pm)?|'
                r'after\s+\d+\s*\w+|tomorrow).*$',
                '', msg, flags=re.IGNORECASE
            ).strip()
            return msg if msg else text

        return text

    # ================================================================
    # REMINDER OPERATIONS
    # ================================================================
    def add_reminder(self, text, source="user"):
        """
        প্রাকৃতিক ভাষা থেকে রিমাইন্ডার তৈরি করে।

        Args:
            text: ইউজারের কথা (e.g., "remind me to call John in 5 minutes")
            source: কোথা থেকে এসেছে

        Returns:
            dict: {id, message, trigger_time, status}
        """
        trigger_time = self.parse_time(text)
        message = self._extract_message(text)
        now = datetime.now().isoformat()

        with self._lock:
            if self.atlas:
                self.atlas.conn.execute(
                    """INSERT INTO reminders 
                       (message, trigger_time, created_at, status, source)
                       VALUES (?, ?, ?, 'active', ?)""",
                    (message, trigger_time.isoformat(), now, source)
                )
                self.atlas.conn.commit()

                # ID রিট্রিভ
                rows = self.atlas.query(
                    "SELECT last_insert_rowid() as id"
                )
                reminder_id = rows[0]["id"] if rows else len(self._active)
            else:
                reminder_id = len(self._active) + 1

            reminder = {
                "id": reminder_id,
                "message": message,
                "trigger_time": trigger_time.isoformat(),
                "created_at": now,
                "status": "active",
                "source": source,
            }
            self._active.append(reminder)

        time_str = trigger_time.strftime("%I:%M %p")
        delta = trigger_time - datetime.now()
        minutes = int(delta.total_seconds() / 60)

        logger.info(f"Reminder #{reminder_id}: '{message}' at {time_str}")
        return {
            "id": reminder_id,
            "message": message,
            "trigger_time": time_str,
            "minutes_until": minutes,
        }

    def cancel_reminder(self, reminder_id):
        """রিমাইন্ডার বাতিল করে।"""
        with self._lock:
            if self.atlas:
                self.atlas.conn.execute(
                    "UPDATE reminders SET status = 'cancelled' WHERE id = ?",
                    (reminder_id,)
                )
                self.atlas.conn.commit()
            self._active = [r for r in self._active if r.get("id") != reminder_id]
        logger.info(f"Reminder #{reminder_id} cancelled.")
        return True

    def get_active_reminders(self):
        """সব অ্যাক্টিভ রিমাইন্ডার দেখায়।"""
        return [r for r in self._active if r.get("status") == "active"]

    def get_reminder_summary(self):
        """রিমাইন্ডার সারাংশ (TTS-friendly)।"""
        active = self.get_active_reminders()
        if not active:
            return "You have no active reminders, Sir."

        lines = [f"You have {len(active)} active reminder{'s' if len(active) > 1 else ''}:"]
        for r in active[:5]:
            try:
                t = datetime.fromisoformat(r["trigger_time"])
                time_str = t.strftime("%I:%M %p")
                lines.append(f"  - {r['message']} at {time_str}")
            except (ValueError, KeyError):
                lines.append(f"  - {r.get('message', 'Unknown')}")
        return " ".join(lines)

    # ================================================================
    # BACKGROUND CHECK LOOP
    # ================================================================
    def start(self, check_interval=30):
        """ব্যাকগ্রাউন্ড চেকিং শুরু করে।"""
        if self.running:
            return
        self.running = True
        self._check_thread = threading.Thread(
            target=self._check_loop, args=(check_interval,), daemon=True
        )
        self._check_thread.start()
        logger.info("Reminder check loop started.")

    def _check_loop(self, interval):
        """পর্যায়ক্রমে রিমাইন্ডার চেক করে।"""
        while self.running:
            try:
                self._trigger_due_reminders()
            except Exception as e:
                logger.error(f"Reminder check error: {e}")
            time.sleep(interval)

    def _trigger_due_reminders(self):
        """সময় হয়ে যাওয়া রিমাইন্ডার ট্রিগার করে।"""
        now = datetime.now()
        triggered = []

        with self._lock:
            for reminder in self._active[:]:
                if reminder.get("status") != "active":
                    continue
                try:
                    trigger_time = datetime.fromisoformat(reminder["trigger_time"])
                    if trigger_time <= now:
                        triggered.append(reminder)
                        reminder["status"] = "triggered"

                        # ডাটাবেস আপডেট
                        if self.atlas:
                            self.atlas.conn.execute(
                                "UPDATE reminders SET status = 'triggered' WHERE id = ?",
                                (reminder.get("id"),)
                            )
                except (ValueError, KeyError):
                    continue

            if self.atlas and triggered:
                self.atlas.conn.commit()

            # ট্রিগার হওয়া রিমাইন্ডার সরিয়ে দাও
            self._active = [r for r in self._active if r.get("status") == "active"]

        # নোটিফিকেশন পাঠানো
        for r in triggered:
            msg = r.get("message", "Reminder")
            logger.info(f"TRIGGERED: {msg}")
            print(f"\n[REMINDER] {msg}")

            if self.beacon:
                self.beacon.notify("JARVIS Reminder", msg, duration=10)

    def stop(self):
        """ব্যাকগ্রাউন্ড চেকিং বন্ধ করে।"""
        self.running = False
        if self._check_thread:
            self._check_thread.join(timeout=2)
        logger.info("Reminder agent stopped.")


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  SENTINEL-REMINDER — Unit Test")
    print("=" * 60)

    agent = ReminderAgent()

    # TEST 1: Time parsing
    print("\n[TEST 1] Time parsing...")
    test_phrases = [
        "remind me in 5 minutes",
        "remind me at 5 PM",
        "remind me to call John in 2 hours",
        "set a reminder after 30 seconds",
        "remind me tomorrow at 9 AM to check email",
    ]
    for phrase in test_phrases:
        t = agent.parse_time(phrase)
        msg = agent._extract_message(phrase)
        print(f"  \"{phrase}\"")
        print(f"    -> Time: {t.strftime('%I:%M %p')} | Message: \"{msg}\"")

    # TEST 2: Add reminder
    print("\n[TEST 2] Adding reminders...")
    r1 = agent.add_reminder("remind me to drink water in 1 minute")
    print(f"  Added: #{r1['id']} — \"{r1['message']}\" at {r1['trigger_time']}")

    r2 = agent.add_reminder("remind me to check email at 5 PM")
    print(f"  Added: #{r2['id']} — \"{r2['message']}\" at {r2['trigger_time']}")

    # TEST 3: List reminders
    print("\n[TEST 3] Active reminders...")
    active = agent.get_active_reminders()
    print(f"  Active: {len(active)} reminders")

    # TEST 4: Summary
    print("\n[TEST 4] Reminder summary...")
    summary = agent.get_reminder_summary()
    print(f"  {summary}")

    # TEST 5: Cancel
    print("\n[TEST 5] Cancel reminder...")
    agent.cancel_reminder(r1["id"])
    print(f"  Cancelled #{r1['id']}. Active: {len(agent.get_active_reminders())}")

    # Cleanup
    agent.cancel_reminder(r2["id"])

    print("\n" + "=" * 60)
    print("  [SENTINEL-REMINDER] All tests complete. [OK]")
    print("=" * 60)
