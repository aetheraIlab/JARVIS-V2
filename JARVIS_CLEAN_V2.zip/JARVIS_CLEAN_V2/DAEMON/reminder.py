# ================================================================
# JARVIS AETHER-CORE V2.0 — BEACON (LAYER 6 / AWARENESS)
# ================================================================
# Codename : BEACON
# Role     : Notification Agent — OS notifications & alerts
# Tech     : plyer + win10toast (Windows 11)
# ================================================================

import sys, os, platform
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

IS_WINDOWS = platform.system() == "Windows"


class Beacon:
    """
    JARVIS BEACON — নোটিফিকেশন এজেন্ট।
    উইন্ডোজ ১১ এ টোস্ট নোটিফিকেশন পাঠায়।
    """

    def __init__(self):
        self._toaster = None
        self._plyer = None
        self._init_notifier()
        print("[BEACON] Notification agent initialized.")

    def _init_notifier(self):
        if IS_WINDOWS:
            try:
                from win10toast import ToastNotifier
                self._toaster = ToastNotifier()
                print("[BEACON] win10toast loaded.")
            except ImportError:
                print("[BEACON] [WARN] win10toast not installed.")
        try:
            from plyer import notification as plyer_notif
            self._plyer = plyer_notif
            print("[BEACON] plyer loaded.")
        except ImportError:
            print("[BEACON] [WARN] plyer not installed.")

    def notify(self, title, message, duration=5):
        """ডেস্কটপ নোটিফিকেশন পাঠায়।"""
        # প্রথমে win10toast দিয়ে চেষ্টা
        if self._toaster:
            try:
                self._toaster.show_toast(
                    title, message,
                    duration=duration, threaded=True
                )
                return f"Notification sent: {title}"
            except Exception as e:
                print(f"[BEACON] win10toast error: {e}")

        # ব্যর্থ হলে plyer দিয়ে চেষ্টা
        if self._plyer:
            try:
                self._plyer.notify(
                    title=title, message=message,
                    app_name="JARVIS", timeout=duration
                )
                return f"Notification sent: {title}"
            except Exception as e:
                print(f"[BEACON] plyer error: {e}")

        # কোনোটাই না থাকলে কনসোলে দেখায়
        print(f"\n🔔 [{title}] {message}")
        return f"Console notification: {title}"

    def alert(self, message):
        """জরুরি সতর্কতা পাঠায়।"""
        return self.notify("[WARN] JARVIS ALERT", message, duration=10)

    def system_alert(self, message):
        """সিস্টেম সতর্কতা পাঠায়।"""
        return self.notify("🖥 SYSTEM", message, duration=7)


if __name__ == "__main__":
    print("=" * 50)
    print("  BEACON — Unit Test")
    print("=" * 50)
    b = Beacon()
    print(f"\n[TEST] {b.notify('JARVIS', 'Notification system test successful.')}")
    print("\n[BEACON] Unit test complete. ✓")
