@echo off
setlocal EnableDelayedExpansion

:: Enable ANSI colors for Windows 11
for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do set ESC=%%b
set CYAN=%ESC%[36m
set GREEN=%ESC%[32m
set RED=%ESC%[31m
set YELLOW=%ESC%[33m
set RESET=%ESC%[0m

:: 1. Show JARVIS banner
echo %CYAN%
echo       _   _    ___ __   __ ___  ___ 
echo      ^| ^| / \  ^| _ \\ \ / /^|_ _^|/ __^|
echo   _  ^| ^|^| - ^| ^|   / \ V /  ^| ^| \__ \
echo  \__/^|__^|_^|_^|^|_^|_\  \_/  ^|___^|^|___/
echo.
echo ================================================================
echo  JARVIS AETHER-CORE V2.0 — Installer
echo  Aether AI Lab ^| Designed by Adil
echo ================================================================%RESET%
echo.

:: 2. Check Python 3.11
echo %YELLOW%[*] Checking Python version...%RESET%
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo %RED%[ERROR] Python is not installed or not in PATH!%RESET%
    pause
    exit /b 1
)

for /f "tokens=2" %%I in ('python --version 2^>^&1') do set PYTHON_VER=%%I
echo %PYTHON_VER% | findstr /R "^3\.11" >nul
if %errorlevel% neq 0 (
    echo %RED%[ERROR] Python 3.11 is required. Found: %PYTHON_VER%%RESET%
    pause
    exit /b 1
)
echo %GREEN%[OK] Python %PYTHON_VER% detected.%RESET%
echo.

:: 3. Create venv
echo %YELLOW%[*] Checking virtual environment...%RESET%
if not exist "venv\" (
    echo %CYAN%[*] Creating virtual environment...%RESET%
    python -m venv venv
    if !errorlevel! neq 0 (
        echo %RED%[ERROR] Failed to create virtual environment!%RESET%
        pause
        exit /b 1
    )
    echo %GREEN%[OK] Virtual environment created.%RESET%
) else (
    echo %GREEN%[OK] Virtual environment already exists.%RESET%
)
echo.

:: 4. Activate venv
echo %YELLOW%[*] Activating virtual environment...%RESET%
call venv\Scripts\activate.bat
if %errorlevel% neq 0 (
    echo %RED%[ERROR] Failed to activate virtual environment!%RESET%
    pause
    exit /b 1
)
echo %GREEN%[OK] Virtual environment activated.%RESET%
echo.

:: 5. Upgrade pip
echo %YELLOW%[*] Upgrading pip...%RESET%
python -m pip install --upgrade pip
echo %GREEN%[OK] Pip upgraded.%RESET%
echo.

:: 6. Install Python Packages
echo %YELLOW%[*] Installing Python dependencies...%RESET%

:: Core
python -m pip install python-dotenv psutil
:: AI/ML
python -m pip install groq google-generativeai scikit-learn openai-whisper
:: Audio
python -m pip install SpeechRecognition pyttsx3
:: Web/API
python -m pip install flask flask-cors flask-socketio requests beautifulsoup4 eel
:: Security
python -m pip install bcrypt cryptography PyJWT
:: Network
python -m pip install duckduckgo-search
:: Utils
python -m pip install numpy opencv-python Pillow pyautogui

echo %GREEN%[OK] Python core packages installed.%RESET%
echo.

:: 7. Check PyAudio installation
echo %YELLOW%[*] Installing PyAudio...%RESET%
python -m pip install pyaudio
if %errorlevel% neq 0 (
    echo %RED%[WARNING] PyAudio standard install failed. Attempting pipwin fix...%RESET%
    python -m pip install pipwin
    python -m pipwin install pyaudio
    if !errorlevel! neq 0 (
        echo %RED%[ERROR] PyAudio installation completely failed. Voice capabilities may not work.%RESET%
    ) else (
        echo %GREEN%[OK] PyAudio installed via pipwin.%RESET%
    )
) else (
    echo %GREEN%[OK] PyAudio installed successfully.%RESET%
)
echo.

:: 8. Install NPM Packages
echo %YELLOW%[*] Installing Frontend HUD dependencies...%RESET%
if not exist "JARVIS HUD" (
    echo %RED%[ERROR] JARVIS HUD folder not found!%RESET%
) else (
    cd "JARVIS HUD"
    call npm install
    cd ..
    echo %GREEN%[OK] NPM packages installed.%RESET%
)
echo.

:: 9. Check Ollama
echo %YELLOW%[*] Checking Ollama and Models...%RESET%
ollama --version >nul 2>&1
if %errorlevel% neq 0 (
    echo %RED%[WARNING] Ollama is not installed!%RESET%
    echo %CYAN%Download Ollama from: https://ollama.com/download%RESET%
    echo %YELLOW%Without Ollama, offline inference will not work.%RESET%
    set OLLAMA_STATUS=MISSING
) else (
    echo %CYAN%[*] Pulling default offline model: gemma4:4b...%RESET%
    ollama pull gemma4:4b
    echo %GREEN%[OK] Ollama configured.%RESET%
    set OLLAMA_STATUS=OK
)
echo.

:: 10. Create .env
echo %YELLOW%[*] Checking .env file...%RESET%
if not exist ".env" (
    if exist ".env.template" (
        copy .env.template .env >nul
        echo %GREEN%[OK] .env created from template. Please configure your API keys.%RESET%
        set ENV_STATUS=CREATED
    ) else (
        echo > .env
        echo %YELLOW%[WARNING] Created blank .env file. No template found.%RESET%
        set ENV_STATUS=BLANK
    )
) else (
    echo %GREEN%[OK] .env already exists.%RESET%
    set ENV_STATUS=EXISTS
)
echo.

:: 11. Success Table
echo %CYAN%================================================================
echo                      SYSTEM STATUS
echo ================================================================%RESET%
echo %GREEN%[X] Python Packages : OK%RESET%
echo %GREEN%[X] Frontend Packages : OK%RESET%

if "%OLLAMA_STATUS%"=="OK" (
    echo %GREEN%[X] Ollama Engine   : OK%RESET%
) else (
    echo %RED%[!] Ollama Engine   : NOT FOUND%RESET%
)

if "%ENV_STATUS%"=="CREATED" (
    echo %YELLOW%[!] .env Status     : Created (Needs API Keys)%RESET%
) else if "%ENV_STATUS%"=="EXISTS" (
    echo %GREEN%[X] .env Status     : OK%RESET%
) else (
    echo %RED%[!] .env Status     : BLANK (Needs Configuration)%RESET%
)
echo %CYAN%================================================================%RESET%
echo.

:: 12. End
echo %GREEN%INSTALLATION COMPLETE — Run start.bat to boot JARVIS%RESET%
pause
