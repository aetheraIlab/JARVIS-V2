# ================================================================
# JARVIS AETHER-CORE V2.0 — DRIVER-BROWSER (LAYER 5 / DRIVER)
# ================================================================
# Codename : DRIVER-BROWSER
# Role     : Browser Automation Agent — Headless Web Interaction
# Tech     : Playwright (Chromium)
# ================================================================

import sys
import os
import re
import time
from datetime import datetime
from urllib.parse import urlparse, quote_plus

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Screenshot output directory
SCREENSHOT_DIR = os.path.join(project_root, "logs", "screenshots")


# ================================================================
# BLOCKED DOMAINS — known-bad patterns for safe browsing
# ================================================================
BLOCKED_DOMAIN_PATTERNS = [
    r".*\.onion$",
    r".*malware.*",
    r".*phishing.*",
    r".*\.tk$",          # high-abuse TLD
]


class DriverBrowser:
    """
    JARVIS DRIVER-BROWSER — ব্রাউজার অটোমেশন এজেন্ট।
    Playwright দিয়ে ওয়েবসাইট খোলা, সার্চ, ডাটা পড়া, স্ক্রিনশট নেওয়া।

    সাপোর্টেড:
    - Open URL: "open google.com"
    - Google Search: "search for Python tutorials"
    - Read page: "read content from https://example.com"
    - Screenshot: "take screenshot of wikipedia.org"
    - Form fill: structured field → value mapping
    - Login: automated credential injection
    - Multi-tab: open multiple URLs
    """

    def __init__(self, headless=True, timeout=15000):
        self._playwright = None
        self._browser = None
        self._headless = headless
        self._timeout = timeout       # milliseconds
        self._pw_module = None
        self._available = False
        self._init_playwright()
        print("[DRIVER-BROWSER] Browser agent initialized.")

    def _init_playwright(self):
        """Playwright লাইব্রেরি লোড করা হচ্ছে (lazy)।"""
        try:
            from playwright.sync_api import sync_playwright
            self._pw_module = sync_playwright
            self._available = True
            print("[DRIVER-BROWSER] Playwright loaded.")
        except ImportError:
            print("[DRIVER-BROWSER] [WARNING] Playwright not installed. Run: pip install playwright && playwright install chromium")

    def _ensure_browser(self):
        """ব্রাউজার ইনস্ট্যান্স নিশ্চিত করে (lazy start)।"""
        if not self._available:
            return False

        if self._playwright is None:
            self._playwright = self._pw_module().__enter__()
            try:
                self._browser = self._playwright.chromium.launch(headless=self._headless)
            except Exception as e:
                print(f"[DRIVER-BROWSER] Browser launch failed: {e}")
                self._playwright = None
                return False

        return self._browser is not None

    def _new_page(self):
        """নতুন ব্রাউজার পেজ তৈরি করে।"""
        if not self._ensure_browser():
            return None
        ctx = self._browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
        )
        page = ctx.new_page()
        page.set_default_timeout(self._timeout)
        return page

    def _close_page(self, page):
        """পেজ ও তার কনটেক্সট বন্ধ করে।"""
        if page:
            try:
                ctx = page.context
                page.close()
                ctx.close()
            except Exception:
                pass

    # ================================================================
    # URL VALIDATION
    # ================================================================
    def _is_safe_url(self, url):
        """URL নিরাপদ কিনা চেক করে।"""
        try:
            parsed = urlparse(url)
            if parsed.scheme not in ("http", "https", ""):
                return False, "Only HTTP/HTTPS URLs are allowed."

            domain = parsed.netloc.lower() or parsed.path.split("/")[0].lower()
            for pattern in BLOCKED_DOMAIN_PATTERNS:
                if re.match(pattern, domain):
                    return False, f"Domain blocked: {domain}"

            return True, "OK"
        except Exception as e:
            return False, f"URL parse error: {e}"

    def _normalize_url(self, url):
        """URL-এ https:// প্রিফিক্স যোগ করে যদি না থাকে।"""
        url = url.strip()
        if not url.startswith(("http://", "https://")):
            url = f"https://{url}"
        return url

    # ================================================================
    # CORE OPERATIONS
    # ================================================================
    def open_url(self, url):
        """
        URL খুলে পেজ টাইটেল ও বেসিক তথ্য রিটার্ন করে।

        Returns: {"success": bool, "title": str, "url": str, "error": str?}
        """
        if not self._available:
            return {"success": False, "error": "Playwright not installed."}

        url = self._normalize_url(url)
        safe, reason = self._is_safe_url(url)
        if not safe:
            return {"success": False, "error": reason, "url": url}

        page = self._new_page()
        if not page:
            return {"success": False, "error": "Browser launch failed."}

        try:
            page.goto(url, wait_until="domcontentloaded")
            title = page.title()
            final_url = page.url
            return {
                "success": True,
                "title": title,
                "url": final_url,
            }
        except Exception as e:
            return {"success": False, "error": str(e), "url": url}
        finally:
            self._close_page(page)

    def google_search(self, query, max_results=5):
        """
        Google-এ সার্চ করে ফলাফল রিটার্ন করে।

        Returns: [{"title": str, "url": str, "snippet": str}]
        """
        if not self._available:
            return [{"error": "Playwright not installed."}]

        page = self._new_page()
        if not page:
            return [{"error": "Browser launch failed."}]

        try:
            search_url = f"https://www.google.com/search?q={quote_plus(query)}"
            page.goto(search_url, wait_until="domcontentloaded")

            # Google search result selectors
            results = []
            items = page.query_selector_all("div.g")[:max_results]

            for item in items:
                title_el = item.query_selector("h3")
                link_el = item.query_selector("a")
                snippet_el = item.query_selector("div[data-sncf], div.VwiC3b, span.aCOpRe")

                title = title_el.inner_text() if title_el else ""
                href = link_el.get_attribute("href") if link_el else ""
                snippet = snippet_el.inner_text() if snippet_el else ""

                if title and href:
                    results.append({
                        "title": title,
                        "url": href,
                        "snippet": snippet[:200],
                    })

            return results if results else [{"info": "No results found", "query": query}]

        except Exception as e:
            return [{"error": f"Google search failed: {e}"}]
        finally:
            self._close_page(page)

    def youtube_search(self, query, max_results=5):
        """
        YouTube-তে ব্রাউজারে সার্চ করে ভিডিও কার্ড বের করে।

        Returns: [{"title": str, "url": str, "channel": str}]
        """
        if not self._available:
            return [{"error": "Playwright not installed."}]

        page = self._new_page()
        if not page:
            return [{"error": "Browser launch failed."}]

        try:
            search_url = f"https://www.youtube.com/results?search_query={quote_plus(query)}"
            page.goto(search_url, wait_until="domcontentloaded")

            # Wait for video renderers
            page.wait_for_selector("ytd-video-renderer, ytd-rich-item-renderer", timeout=8000)
            time.sleep(1)  # Allow JS render

            results = []
            items = page.query_selector_all("ytd-video-renderer")[:max_results]

            for item in items:
                title_el = item.query_selector("#video-title")
                channel_el = item.query_selector("#channel-name a, ytd-channel-name a")

                title = title_el.inner_text().strip() if title_el else ""
                href = title_el.get_attribute("href") if title_el else ""
                channel = channel_el.inner_text().strip() if channel_el else "Unknown"

                if title and href:
                    full_url = f"https://www.youtube.com{href}" if href.startswith("/") else href
                    results.append({
                        "title": title,
                        "url": full_url,
                        "channel": channel,
                    })

            return results if results else [{"info": "No results found", "query": query}]

        except Exception as e:
            return [{"error": f"YouTube search failed: {e}"}]
        finally:
            self._close_page(page)

    def read_page(self, url):
        """
        পেজের দৃশ্যমান টেক্সট কন্টেন্ট পড়ে রিটার্ন করে।

        Returns: {"success": bool, "title": str, "content": str (first 5000 chars), "url": str}
        """
        if not self._available:
            return {"success": False, "error": "Playwright not installed."}

        url = self._normalize_url(url)
        safe, reason = self._is_safe_url(url)
        if not safe:
            return {"success": False, "error": reason}

        page = self._new_page()
        if not page:
            return {"success": False, "error": "Browser launch failed."}

        try:
            page.goto(url, wait_until="domcontentloaded")
            title = page.title()
            # Extract visible text, stripping script/style content
            content = page.evaluate("""() => {
                const scripts = document.querySelectorAll('script, style, noscript');
                scripts.forEach(s => s.remove());
                return document.body ? document.body.innerText : '';
            }""")

            return {
                "success": True,
                "title": title,
                "content": content[:5000],
                "url": page.url,
                "length": len(content),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            self._close_page(page)

    def extract_data(self, url, selector):
        """
        CSS সিলেক্টর দিয়ে ডাটা এক্সট্র্যাক্ট করে।

        Returns: {"success": bool, "data": [str], "count": int}
        """
        if not self._available:
            return {"success": False, "error": "Playwright not installed."}

        url = self._normalize_url(url)
        page = self._new_page()
        if not page:
            return {"success": False, "error": "Browser launch failed."}

        try:
            page.goto(url, wait_until="domcontentloaded")
            elements = page.query_selector_all(selector)
            data = [el.inner_text().strip() for el in elements[:50]]  # Cap at 50

            return {
                "success": True,
                "data": data,
                "count": len(data),
                "selector": selector,
                "url": page.url,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            self._close_page(page)

    def take_screenshot(self, url, filename=None):
        """
        পেজের স্ক্রিনশট নেয় এবং ফাইলে সেভ করে।

        Returns: {"success": bool, "path": str}
        """
        if not self._available:
            return {"success": False, "error": "Playwright not installed."}

        url = self._normalize_url(url)
        safe, reason = self._is_safe_url(url)
        if not safe:
            return {"success": False, "error": reason}

        page = self._new_page()
        if not page:
            return {"success": False, "error": "Browser launch failed."}

        try:
            page.goto(url, wait_until="domcontentloaded")

            os.makedirs(SCREENSHOT_DIR, exist_ok=True)
            if not filename:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                domain = urlparse(url).netloc.replace(".", "_") or "page"
                filename = f"{domain}_{timestamp}.png"

            filepath = os.path.join(SCREENSHOT_DIR, filename)
            page.screenshot(path=filepath, full_page=True)

            return {
                "success": True,
                "path": filepath,
                "url": page.url,
                "title": page.title(),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            self._close_page(page)

    def fill_form(self, url, fields):
        """
        ফর্ম ফিল্ড ভরে সাবমিট করে।

        Args:
            url: ফর্ম পেজের URL
            fields: {selector: value} dict
                    e.g. {"#email": "user@mail.com", "#password": "pass123"}

        Returns: {"success": bool, "filled": int}
        """
        if not self._available:
            return {"success": False, "error": "Playwright not installed."}

        url = self._normalize_url(url)
        page = self._new_page()
        if not page:
            return {"success": False, "error": "Browser launch failed."}

        try:
            page.goto(url, wait_until="domcontentloaded")
            filled = 0

            for selector, value in fields.items():
                try:
                    page.fill(selector, value)
                    filled += 1
                except Exception as e:
                    print(f"[DRIVER-BROWSER] Fill failed for {selector}: {e}")

            return {
                "success": filled > 0,
                "filled": filled,
                "total": len(fields),
                "url": page.url,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            self._close_page(page)

    def login(self, url, username_sel, password_sel, submit_sel, username, password):
        """
        ওয়েবসাইটে লগইন করে।

        Returns: {"success": bool, "title": str, "url": str}
        """
        if not self._available:
            return {"success": False, "error": "Playwright not installed."}

        url = self._normalize_url(url)
        safe, reason = self._is_safe_url(url)
        if not safe:
            return {"success": False, "error": reason}

        page = self._new_page()
        if not page:
            return {"success": False, "error": "Browser launch failed."}

        try:
            page.goto(url, wait_until="domcontentloaded")
            page.fill(username_sel, username)
            page.fill(password_sel, password)
            page.click(submit_sel)

            # Wait for navigation after login
            page.wait_for_load_state("domcontentloaded")
            time.sleep(1)

            return {
                "success": True,
                "title": page.title(),
                "url": page.url,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            self._close_page(page)

    def click_element(self, url, selector):
        """
        নির্দিষ্ট DOM এলিমেন্টে ক্লিক করে।

        Returns: {"success": bool, "url_after": str}
        """
        if not self._available:
            return {"success": False, "error": "Playwright not installed."}

        url = self._normalize_url(url)
        page = self._new_page()
        if not page:
            return {"success": False, "error": "Browser launch failed."}

        try:
            page.goto(url, wait_until="domcontentloaded")
            page.click(selector)
            page.wait_for_load_state("domcontentloaded")

            return {
                "success": True,
                "url_after": page.url,
                "title": page.title(),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            self._close_page(page)

    def open_tabs(self, urls):
        """
        একাধিক URL আলাদা ট্যাবে খোলে।

        Returns: {"success": bool, "tabs": [{"title": str, "url": str}]}
        """
        if not self._available:
            return {"success": False, "error": "Playwright not installed."}

        if not self._ensure_browser():
            return {"success": False, "error": "Browser launch failed."}

        ctx = self._browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
        )

        tabs = []
        try:
            for raw_url in urls[:10]:  # Cap at 10 tabs
                url = self._normalize_url(raw_url)
                safe, reason = self._is_safe_url(url)
                if not safe:
                    tabs.append({"url": url, "error": reason})
                    continue

                try:
                    page = ctx.new_page()
                    page.set_default_timeout(self._timeout)
                    page.goto(url, wait_until="domcontentloaded")
                    tabs.append({"title": page.title(), "url": page.url})
                except Exception as e:
                    tabs.append({"url": url, "error": str(e)})

            return {"success": len(tabs) > 0, "tabs": tabs}
        finally:
            try:
                ctx.close()
            except Exception:
                pass

    def get_dom(self, url, selector):
        """
        CSS সিলেক্টরের innerHTML রিটার্ন করে।

        Returns: {"success": bool, "html": str, "count": int}
        """
        if not self._available:
            return {"success": False, "error": "Playwright not installed."}

        url = self._normalize_url(url)
        page = self._new_page()
        if not page:
            return {"success": False, "error": "Browser launch failed."}

        try:
            page.goto(url, wait_until="domcontentloaded")
            elements = page.query_selector_all(selector)
            html_parts = []
            for el in elements[:20]:  # Cap at 20
                html_parts.append(el.inner_html())

            return {
                "success": True,
                "html": "\n---\n".join(html_parts)[:10000],  # Cap at 10k chars
                "count": len(html_parts),
                "selector": selector,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            self._close_page(page)

    def safe_browse(self, url):
        """
        URL যাচাই করে নিরাপদ হলে খোলে, নইলে ব্লক করে।

        Returns: {"safe": bool, "reason": str, ...open_url result if safe}
        """
        url = self._normalize_url(url)
        safe, reason = self._is_safe_url(url)

        if not safe:
            return {"safe": False, "reason": reason, "url": url}

        result = self.open_url(url)
        result["safe"] = True
        result["reason"] = "URL validated and opened."
        return result

    # ================================================================
    # STATUS & CLEANUP
    # ================================================================
    def get_status(self):
        """Browser সিস্টেমের অবস্থা।"""
        return {
            "playwright_available": self._available,
            "browser_running": self._browser is not None,
            "headless": self._headless,
            "timeout_ms": self._timeout,
        }

    def close(self):
        """ব্রাউজার এবং Playwright বন্ধ করে।"""
        if self._browser:
            try:
                self._browser.close()
            except Exception:
                pass
            self._browser = None

        if self._playwright:
            try:
                self._playwright.__exit__(None, None, None)
            except Exception:
                pass
            self._playwright = None

        print("[DRIVER-BROWSER] Browser closed.")

    def __del__(self):
        self.close()


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  DRIVER-BROWSER — Unit Test")
    print("=" * 60)

    browser = DriverBrowser(headless=True)

    # === TEST 1: Status ===
    status = browser.get_status()
    print(f"\n[STATUS] Playwright available: {status['playwright_available']}")
    print(f"[STATUS] Browser running: {status['browser_running']}")
    print(f"[STATUS] Headless: {status['headless']}")

    if not status["playwright_available"]:
        print("\n[TEST] Skipping browser tests (playwright needed)")
        print("[HINT] Install with: pip install playwright && playwright install chromium")
    else:
        # === TEST 2: Open URL ===
        print("\n[TEST 2] Open URL: example.com")
        result = browser.open_url("example.com")
        print(f"  Success: {result['success']}")
        print(f"  Title: {result.get('title', 'N/A')}")

        # === TEST 3: Google Search ===
        print("\n[TEST 3] Google Search: 'Python programming'")
        results = browser.google_search("Python programming", max_results=3)
        for i, r in enumerate(results):
            if "error" not in r:
                print(f"  [{i+1}] {r.get('title', 'N/A')[:60]}")
                print(f"      URL: {r.get('url', 'N/A')[:80]}")

        # === TEST 4: Read page content ===
        print("\n[TEST 4] Read page: example.com")
        result = browser.read_page("example.com")
        print(f"  Success: {result['success']}")
        if result["success"]:
            print(f"  Title: {result['title']}")
            print(f"  Content length: {result['length']} chars")
            print(f"  Preview: {result['content'][:120]}...")

        # === TEST 5: Screenshot ===
        print("\n[TEST 5] Screenshot: example.com")
        result = browser.take_screenshot("example.com", "test_screenshot.png")
        print(f"  Success: {result['success']}")
        if result["success"]:
            print(f"  Saved: {result['path']}")

        # === TEST 6: Safe browsing ===
        print("\n[TEST 6] Safe browsing validation")
        safe_result = browser.safe_browse("example.com")
        print(f"  Safe: {safe_result.get('safe', False)}")

        blocked_result = browser.safe_browse("http://evil.onion")
        print(f"  Blocked (.onion): safe={blocked_result.get('safe', True)}, reason={blocked_result.get('reason', '')}")

        # === TEST 7: Extract data ===
        print("\n[TEST 7] Extract data: example.com <h1>")
        result = browser.extract_data("example.com", "h1")
        print(f"  Success: {result['success']}")
        if result["success"]:
            print(f"  Found: {result['data']}")

        # Cleanup
        browser.close()

    print("\n" + "=" * 60)
    print("  DRIVER-BROWSER All tests complete. ✓")
    print("=" * 60)
