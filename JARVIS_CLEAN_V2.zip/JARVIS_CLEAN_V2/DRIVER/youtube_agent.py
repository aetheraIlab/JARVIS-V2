# ================================================================
# JARVIS AETHER-CORE V2.0 — DRIVER-YOUTUBE (LAYER 5 / DRIVER)
# ================================================================
# Codename : DRIVER-YOUTUBE
# Role     : YouTube Search & Control Agent
# Tech     : yt-dlp + pytube (video search/download metadata)
# ================================================================

import sys
import os
import subprocess
import webbrowser
from datetime import datetime

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if project_root not in sys.path:
    sys.path.insert(0, project_root)


class DriverYouTube:
    """
    JARVIS DRIVER-YOUTUBE — YouTube নিয়ন্ত্রণ এজেন্ট।
    YouTube সংগীত/ভিডিও খোঁজা, স্ট্রিম করা এবং তথ্য পাওয়া।
    
    সাপোর্টেড:
    - Search: "play cat videos"
    - Video info: "get info on Python tutorial"
    - Direct play: "play https://youtube.com/watch?v=..."
    - Playlist: "play lofi beats playlist"
    """

    def __init__(self):
        self._yt_dlp = None
        self._pytube = None
        self._init_libraries()
        print("[DRIVER-YOUTUBE] YouTube agent initialized.")

    def _init_libraries(self):
        """YouTube ডাউনলোড লাইব্রেরি লোড করা হচ্ছে।"""
        try:
            import yt_dlp
            self._yt_dlp = yt_dlp
            print("[DRIVER-YOUTUBE] yt-dlp loaded.")
        except ImportError:
            print("[DRIVER-YOUTUBE] [WARN] yt-dlp not installed. Run: pip install yt-dlp")

        try:
            from pytube import Search
            self._pytube = Search
            print("[DRIVER-YOUTUBE] pytube loaded.")
        except ImportError:
            print("[DRIVER-YOUTUBE] [WARN] pytube not installed. Run: pip install pytube")

    def search(self, query, max_results=5):
        """
        YouTube-তে ভিডিও খোঁজে এবং ফলাফল রিটার্ন করে।
        
        রিটার্ন: [
            {
                "title": str,
                "url": str,
                "video_id": str,
                "channel": str,
                "duration": str,
                "views": int
            }
        ]
        """
        if not self._pytube:
            return [{"error": "pytube unavailable"}]

        try:
            search = self._pytube(query)
            results = []

            for i, video in enumerate(search.results[:max_results]):
                results.append({
                    "title": video.title,
                    "url": f"https://youtube.com/watch?v={video.video_id}",
                    "video_id": video.video_id,
                    "channel": video.author if hasattr(video, 'author') else "Unknown",
                    "duration": f"{video.length // 60}m {video.length % 60}s" if hasattr(video, 'length') else "Unknown",
                    "views": video.views if hasattr(video, 'views') else 0,
                })

            return results

        except Exception as e:
            print(f"[DRIVER-YOUTUBE] Search error: {e}")
            return [{"error": str(e)}]

    def play_url(self, url):
        """
        সরাসরি YouTube URL থেকে ভিডিও খেলে (ডিফল্ট ব্রাউজার/মিডিয়া প্লেয়ারে)।
        """
        if not self._is_valid_youtube_url(url):
            return {
                "success": False,
                "error": "Invalid YouTube URL.",
                "url": url,
            }

        try:
            webbrowser.open(url)
            return {
                "success": True,
                "message": f"Opening: {url}",
                "url": url,
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to open: {e}",
                "url": url,
            }

    def play_search_result(self, search_query, result_index=0):
        """
        সার্চ করে প্রথম ফলাফল খেলে।
        """
        results = self.search(search_query, max_results=3)

        if not results or "error" in results[0]:
            return {
                "success": False,
                "error": f"No results for '{search_query}'",
                "query": search_query,
            }

        if result_index >= len(results):
            result_index = 0

        video = results[result_index]
        return self.play_url(video["url"])

    def get_video_info(self, url):
        """
        YouTube ভিডিওর বিস্তারিত তথ্য পায়।
        """
        if not self._is_valid_youtube_url(url):
            return {"error": "Invalid YouTube URL."}

        if not self._yt_dlp:
            return {"error": "yt-dlp unavailable"}

        try:
            ydl_opts = {
                'quiet': True,
                'no_warnings': True,
            }

            with self._yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)

                return {
                    "title": info.get("title", "Unknown"),
                    "video_id": info.get("id", ""),
                    "duration_seconds": info.get("duration", 0),
                    "upload_date": info.get("upload_date", "Unknown"),
                    "uploader": info.get("uploader", "Unknown"),
                    "view_count": info.get("view_count", 0),
                    "like_count": info.get("like_count", 0),
                    "description": info.get("description", "")[:200],
                    "thumbnail": info.get("thumbnail", ""),
                }

        except Exception as e:
            print(f"[DRIVER-YOUTUBE] Video info error: {e}")
            return {"error": str(e)}

    def _is_valid_youtube_url(self, url):
        """URL YouTube-এর কিনা চেক করে।"""
        return "youtube.com" in url or "youtu.be" in url

    def get_status(self):
        """YouTube সিস্টেমের অবস্থা।"""
        return {
            "yt_dlp_available": self._yt_dlp is not None,
            "pytube_available": self._pytube is not None,
        }


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  DRIVER-YOUTUBE — Unit Test")
    print("=" * 60)

    youtube = DriverYouTube()

    # স্ট্যাটাস
    status = youtube.get_status()
    print(f"\n[STATUS] yt-dlp available: {status['yt_dlp_available']}")
    print(f"[STATUS] pytube available: {status['pytube_available']}")

    if not status['pytube_available']:
        print("\n[TEST] Skipping search tests (pytube needed)")
        print("[HINT] Install with: pip install pytube")
    else:
        # সার্চ টেস্ট
        print("\n[TEST] Search: 'lofi hip hop music'")
        results = youtube.search("lofi hip hop music", max_results=3)
        for i, result in enumerate(results):
            if "error" not in result:
                print(f"  [{i+1}] {result['title'][:50]}")
                print(f"      URL: {result['url']}")
                print(f"      Views: {result.get('views', 0)}")

    # URL টেস্ট
    print("\n[TEST] Playing sample URL")
    result = youtube.play_url("https://youtube.com/watch?v=dQw4w9WgXcQ")
    print(f"  Success: {result['success']}")
    print(f"  Message: {result.get('message', result.get('error', ''))}")

    print("\n" + "=" * 60)
    print("  DRIVER-YOUTUBE All tests complete. ✓")
    print("=" * 60)
