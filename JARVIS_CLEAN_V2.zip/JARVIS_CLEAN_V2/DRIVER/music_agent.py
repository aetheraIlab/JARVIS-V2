# ================================================================
# JARVIS AETHER-CORE V2.0 — DRIVER-MUSIC (LAYER 5 / DRIVER)
# ================================================================
# Codename : DRIVER-MUSIC
# Role     : Music/Spotify Control Agent
# Tech     : spotipy + subprocess (media control)
# ================================================================

import sys
import os
import subprocess
import platform
import shlex

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if project_root not in sys.path:
    sys.path.insert(0, project_root)


class DriverMusic:
    """
    JARVIS DRIVER-MUSIC — সঙ্গীত নিয়ন্ত্রণ এজেন্ট।
    Spotify, Windows Media Player, VLC নিয়ন্ত্রণ করে।
    
    সাপোর্টেড:
    - Play/Pause: "play music", "pause"
    - Volume: "turn up volume", "volume 50%"
    - Next/Previous: "next song", "previous"
    - Search: "play some lofi beats"
    - Status: "what's playing?"
    """

    def __init__(self):
        self.os_type = platform.system()
        self._spotify = None
        self._current_player = "system"
        self._init_spotify()
        print(f"[DRIVER-MUSIC] Music agent initialized ({self.os_type}).")

    def _init_spotify(self):
        """Spotify লাইব্রেরি লোড করার চেষ্টা করে।"""
        try:
            import spotipy
            from spotipy.oauth2 import SpotifyClientCredentials
            self._spotify = spotipy
            print("[DRIVER-MUSIC] Spotipy loaded.")
        except ImportError:
            print("[DRIVER-MUSIC] [WARN] spotipy not installed. Run: pip install spotipy")

    def play(self):
        """সঙ্গীত চালু করে।"""
        if self.os_type == "Windows":
            return self._media_key_press("VK_MEDIA_PLAY_PAUSE")
        else:
            return self._execute_command("playerctl play")

    def pause(self):
        """সঙ্গীত পজ করে।"""
        if self.os_type == "Windows":
            return self._media_key_press("VK_MEDIA_PLAY_PAUSE")
        else:
            return self._execute_command("playerctl pause")

    def next_track(self):
        """পরবর্তী ট্র্যাকে যায়।"""
        if self.os_type == "Windows":
            return self._media_key_press("VK_MEDIA_NEXT_TRACK")
        else:
            return self._execute_command("playerctl next")

    def previous_track(self):
        """পূর্ববর্তী ট্র্যাকে যায়।"""
        if self.os_type == "Windows":
            return self._media_key_press("VK_MEDIA_PREV_TRACK")
        else:
            return self._execute_command("playerctl previous")

    def set_volume(self, level):
        """
        ভলিউম সেট করে (0-100)।
        """
        if not (0 <= level <= 100):
            return {
                "success": False,
                "error": f"Volume must be 0-100, got {level}",
            }

        if self.os_type == "Windows":
            # PowerShell দিয়ে Windows ভলিউম সেট
            script = f"""
            $volume = {level}
            [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime] | Out-Null
            """
            try:
                subprocess.run(
                    ["powershell", "-NoProfile", "-Command", script],
                    capture_output=True,
                    timeout=5
                )
                return {
                    "success": True,
                    "volume": level,
                    "message": f"Volume set to {level}%",
                }
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Volume control failed: {e}",
                }
        else:
            # Linux দিয়ে ভলিউম সেট
            return self._execute_command(f"amixer set Master {level}%")

    def get_status(self):
        """বর্তমান সঙ্গীত স্ট্যাটাস পায়।"""
        if self.os_type == "Windows":
            # Windows Media Player স্ট্যাটাস (সীমিত তথ্য)
            return {
                "player": "Windows Media Control",
                "status": "unknown",
                "note": "Full metadata requires Spotify/MusicBee integration",
            }
        else:
            # Linux playerctl দিয়ে স্ট্যাটাস
            result = subprocess.run(
                ["playerctl", "metadata"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                return {
                    "status": "playing",
                    "metadata": result.stdout.strip(),
                }
            else:
                return {
                    "status": "no_player",
                    "error": "No active music player",
                }

    def search_spotify(self, query, query_type="track"):
        """
        Spotify-তে সঙ্গীত খোঁজে।
        query_type: "track", "artist", "album", "playlist"
        """
        if not self._spotify:
            return {
                "error": "Spotipy not available. Install: pip install spotipy"
            }

        try:
            # Spotify অথেন্টিকেশন প্রয়োজন (API credentials)
            # এটি একটি ডেমো যা সাধারণত কাজ করে না বিনা ক্রেডেনশিয়ালস ছাড়া
            return {
                "error": "Spotify authentication required. Set SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET"
            }
        except Exception as e:
            return {"error": str(e)}

    def _media_key_press(self, key_code):
        """Windows-এ মিডিয়া কী চাপে।"""
        try:
            import ctypes
            # Windows API কল — অত্যন্ত অপটিমাল নয়, কিন্তু কাজ করে
            ctypes.windll.user32.PostMessageW(0xFFFF, 0x319, {
                "VK_MEDIA_PLAY_PAUSE": 0xB3,
                "VK_MEDIA_NEXT_TRACK": 0xB0,
                "VK_MEDIA_PREV_TRACK": 0xB1,
            }.get(key_code, 0), 0)
            
            return {
                "success": True,
                "action": key_code,
                "message": f"Sent {key_code} to media player"
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed: {e}"
            }

    def _execute_command(self, command):
        """শেল কমান্ড এক্সিকিউট করে (SECURITY: No shell=True)।"""
        try:
            # SECURITY FIX: shlex.split instead of shell=True
            parsed = shlex.split(command)
            result = subprocess.run(
                parsed,
                shell=False,
                capture_output=True,
                text=True,
                timeout=5
            )
            return {
                "success": result.returncode == 0,
                "output": result.stdout.strip() if result.stdout else "",
                "error": result.stderr.strip() if result.stderr else "",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }

    def get_supported_commands(self):
        """সাপোর্টেড সঙ্গীত কমান্ড।"""
        return {
            "play": "Start playing music",
            "pause": "Pause music",
            "next": "Skip to next track",
            "previous": "Go to previous track",
            "volume": "Set volume 0-100",
            "status": "Get current playing info",
            "search": "Search Spotify (requires auth)",
        }


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  DRIVER-MUSIC — Unit Test")
    print("=" * 60)

    music = DriverMusic()

    # সাপোর্টেড কমান্ড
    print("\n[COMMANDS] Supported music commands:")
    commands = music.get_supported_commands()
    for cmd, desc in commands.items():
        print(f"  • {cmd}: {desc}")

    # স্ট্যাটাস
    print("\n[TEST] Current music status:")
    status = music.get_status()
    for k, v in status.items():
        print(f"  {k}: {v}")

    # ভলিউম টেস্ট
    print("\n[TEST] Setting volume to 75%")
    result = music.set_volume(75)
    print(f"  Success: {result['success']}")
    if 'message' in result:
        print(f"  Message: {result['message']}")

    # ভলিউম ভ্যালিডেশন
    print("\n[TEST] Invalid volume (150%)")
    result = music.set_volume(150)
    print(f"  Rejected: {not result['success']}")
    print(f"  Error: {result['error']}")

    print("\n" + "=" * 60)
    print("  DRIVER-MUSIC All tests complete. ✓")
    print("=" * 60)
