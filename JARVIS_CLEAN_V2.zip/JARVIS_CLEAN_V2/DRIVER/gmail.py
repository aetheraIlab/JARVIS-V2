# ================================================================
# JARVIS AETHER-CORE V2.0 — SECURE POSTMASTER (DRIVER)
# ================================================================
# Codename : POSTMASTER_SECURE
# Role     : Gmail Agent — Read, send, and draft emails securely
# Tech     : Gmail API (OAuth2) + AES-256 Vault integration
# ================================================================

import os
import sys
import json
import base64
from email.message import EmailMessage
import logging
from pathlib import Path

# Google API Imports
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from HEAP.vault import Vault

# If modifying these scopes, delete the token from the vault.
SCOPES = [
    'https://www.googleapis.com/auth/gmail.modify',
    'https://www.googleapis.com/auth/gmail.compose',
    'https://www.googleapis.com/auth/gmail.send'
]

VAULT_TOKEN_KEY = "gmail_oauth_token"

logger = logging.getLogger("POSTMASTER")

class Postmaster:
    """
    JARVIS SECURE POSTMASTER
    Uses official Gmail API (OAuth2) with Vault token storage.
    """
    def __init__(self):
        self.vault = Vault()
        self.creds = None
        self.service = None
        self.base_dir = Path(__file__).resolve().parent.parent
        self.credentials_path = self.base_dir / "CONFIG" / "credentials.json"
        
        # Initialize lazily
        self._configured = False

    def authenticate(self) -> bool:
        """Authenticate with Google, using Vault to store/retrieve the token."""
        try:
            # 1. Try to get token from vault
            token_json = self.vault.retrieve(VAULT_TOKEN_KEY)
            if token_json:
                info = json.loads(token_json)
                self.creds = Credentials.from_authorized_user_info(info, SCOPES)

            # 2. If no valid credentials, require user login
            if not self.creds or not self.creds.valid:
                if self.creds and self.creds.expired and self.creds.refresh_token:
                    logger.info("[POSTMASTER] Refreshing expired OAuth token...")
                    self.creds.refresh(Request())
                else:
                    if not os.path.exists(self.credentials_path):
                        logger.error(f"[POSTMASTER] Missing credentials.json at {self.credentials_path}")
                        logger.error("Please download OAuth 2.0 Client IDs from Google Cloud Console.")
                        return False
                    
                    logger.info("[POSTMASTER] Initiating new OAuth2 login flow. Check your browser.")
                    flow = InstalledAppFlow.from_client_secrets_file(
                        str(self.credentials_path), SCOPES
                    )
                    self.creds = flow.run_local_server(port=0)

                # Save the new token back to the Vault
                self.vault.store(VAULT_TOKEN_KEY, self.creds.to_json())
                logger.info("[POSTMASTER] OAuth token securely saved to Vault.")

            # 3. Build the service
            self.service = build('gmail', 'v1', credentials=self.creds)
            self._configured = True
            logger.info("[POSTMASTER] Gmail API authenticated successfully.")
            return True

        except Exception as e:
            logger.error(f"[POSTMASTER] Authentication failed: {e}")
            return False

    def is_configured(self):
        return self._configured

    def _ensure_auth(self):
        if not self._configured:
            if not self.authenticate():
                raise RuntimeError("Gmail API is not authenticated.")

    def get_unread_count(self) -> int:
        """Gets the total number of unread emails in the INBOX."""
        self._ensure_auth()
        try:
            results = self.service.users().messages().list(userId='me', labelIds=['INBOX', 'UNREAD']).execute()
            messages = results.get('messages', [])
            return len(messages)
        except HttpError as error:
            logger.error(f"An error occurred: {error}")
            return 0

    def read_inbox(self, max_results=5):
        """Reads recent emails from the inbox."""
        self._ensure_auth()
        try:
            results = self.service.users().messages().list(userId='me', labelIds=['INBOX'], maxResults=max_results).execute()
            messages = results.get('messages', [])

            if not messages:
                return []

            emails = []
            for msg in messages:
                msg_data = self.service.users().messages().get(userId='me', id=msg['id'], format='full').execute()
                
                # Extract headers
                headers = msg_data['payload']['headers']
                subject = next((h['value'] for h in headers if h['name'] == 'Subject'), 'No Subject')
                sender = next((h['value'] for h in headers if h['name'] == 'From'), 'Unknown Sender')
                date = next((h['value'] for h in headers if h['name'] == 'Date'), 'Unknown Date')

                # Extract body
                snippet = msg_data.get('snippet', '')

                emails.append({
                    "id": msg['id'],
                    "from": sender,
                    "subject": subject,
                    "date": date,
                    "snippet": snippet
                })
            
            return emails
        except HttpError as error:
            logger.error(f"An error occurred reading inbox: {error}")
            return [{"error": str(error)}]

    def send_email(self, to_email, subject, body, html=False) -> str:
        """Sends an email via Gmail API."""
        self._ensure_auth()
        try:
            message = EmailMessage()
            if html:
                message.add_alternative(body, subtype='html')
            else:
                message.set_content(body)

            message['To'] = to_email
            message['From'] = "me"
            message['Subject'] = subject

            encoded_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
            create_message = {'raw': encoded_message}

            send_message = self.service.users().messages().send(userId="me", body=create_message).execute()
            logger.info(f"[POSTMASTER] Email sent to {to_email}. Message ID: {send_message['id']}")
            return f"Email sent successfully. ID: {send_message['id']}"

        except HttpError as error:
            logger.error(f"Failed to send email: {error}")
            return f"Failed to send email: {error}"

    def create_draft(self, to_email, subject, body, html=False) -> str:
        """Creates an email draft via Gmail API."""
        self._ensure_auth()
        try:
            message = EmailMessage()
            if html:
                message.add_alternative(body, subtype='html')
            else:
                message.set_content(body)

            message['To'] = to_email
            message['From'] = "me"
            message['Subject'] = subject

            encoded_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
            create_message = {'message': {'raw': encoded_message}}

            draft = self.service.users().drafts().create(userId="me", body=create_message).execute()
            logger.info(f"[POSTMASTER] Draft created. Draft ID: {draft['id']}")
            return f"Draft created successfully. ID: {draft['id']}"

        except HttpError as error:
            logger.error(f"Failed to create draft: {error}")
            return f"Failed to create draft: {error}"

if __name__ == "__main__":
    print("=" * 50)
    print("  POSTMASTER (OAUTH2) — Unit Test")
    print("=" * 50)
    pm = Postmaster()
    
    # Needs credentials.json in CONFIG directory
    print("\n[TEST] Attempting authentication...")
    if pm.authenticate():
        print(f"[TEST] Unread count: {pm.get_unread_count()}")
        print("\n[TEST] Recent emails:")
        emails = pm.read_inbox(3)
        for e in emails:
             print(f"  From: {e.get('from', 'N/A')}")
             print(f"  Subject: {e.get('subject', 'N/A')}")
    else:
        print("[TEST] Setup incomplete. Place credentials.json in CONFIG folder.")
