# ================================================================
# JARVIS AETHER-CORE V2.0 — LAUNCHER (LAYER 7)
# ================================================================
# Codename : LAUNCHER
# Role     : App Control Agent — Open/Close apps by voice
# Tech     : subprocess + os + registry (Windows 11)
# ================================================================

import sys
import os
import subprocess
import platform
import shlex

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

IS_WINDOWS = platform.system() == "Windows"

# উইন্ডোজ ১১ এ কমন অ্যাপগুলোর পাথ ম্যাপ
# ইউজার নিজেও এখানে নতুন অ্যাপ যোগ করতে পারবে
APP_REGISTRY = {
    # ব্রাউজার
    "chrome":    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "firefox":   r"C:\Program Files\Mozilla Firefox\firefox.exe",
    "edge":      r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    "brave":     r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
    # কমিউনিকেশন
    "discord":   r"C:\Users\{USER}\AppData\Local\Discord\Update.exe --processStart Discord.exe",
    "telegram":  r"C:\Users\{USER}\AppData\Roaming\Telegram Desktop\Telegram.exe",
    # ডেভেলপমেন্ট
    "vscode":    r"C:\Users\{USER}\AppData\Local\Programs\Microsoft VS Code\Code.exe",
    "notepad":   "notepad.exe",
    "cmd":       "cmd.exe",
    "powershell":"powershell.exe",
    "terminal":  "wt.exe",
    # সিস্টেম
    "explorer":  "explorer.exe",
    "taskmgr":   "taskmgr.exe",
    "calc":      "calc.exe",
    "paint":     "mspaint.exe",
    "snipping":  "SnippingTool.exe",
    # মিডিয়া
    "spotify":   r"C:\Users\{USER}\AppData\Roaming\Spotify\Spotify.exe",
    "vlc":       r"C:\Program Files\VideoLAN\VLC\vlc.exe",
}


class Launcher:
    """
    JARVIS LAUNCHER — অ্যাপ কন্ট্রোল এজেন্ট।
    ভয়েস কমান্ডে অ্যাপ খোলা এবং বন্ধ করা।
    """

    def __init__(self):
        self.registry = {}
        self._build_registry()
        print(f"[LAUNCHER] App control agent initialized. {len(self.registry)} apps registered.")

    def _build_registry(self):
        """রেজিস্ট্রিতে ইউজারের নাম বসিয়ে পাথ ঠিক করে।"""
        username = os.getenv("USERNAME", "User")
        for name, path in APP_REGISTRY.items():
            resolved = path.replace("{USER}", username)
            self.registry[name] = resolved

    def open_app(self, app_name):
        """অ্যাপ খুলে দেয়।"""
        app_name = app_name.lower().strip()

        # প্রথমে রেজিস্ট্রিতে খুঁজি
        if app_name in self.registry:
            path = self.registry[app_name]
            return self._launch(path, app_name)

        # রেজিস্ট্রিতে না পাওয়া গেলে পার্শিয়াল ম্যাচ
        for key, path in self.registry.items():
            if app_name in key or key in app_name:
                return self._launch(path, key)

        # সরাসরি কমান্ড হিসেবে চেষ্টা
        return self._launch(app_name, app_name)

    def _launch(self, path, display_name):
        """প্রসেস শুরু করে (SECURITY: No shell=True)।"""
        # SECURITY: Block shell metacharacters
        if any(c in path for c in ['&&', '||', ';', '`', '$(',  '>', '<']):
            return f"BLOCKED: Unsafe characters in path for {display_name}."

        try:
            if IS_WINDOWS:
                if os.path.exists(path):
                    subprocess.Popen([path], shell=False,
                                     creationflags=subprocess.CREATE_NO_WINDOW)
                else:
                    # SECURITY FIX: shlex.split instead of shell=True
                    parsed = shlex.split(path)
                    subprocess.Popen(parsed, shell=False,
                                     creationflags=subprocess.CREATE_NO_WINDOW)
            else:
                # SECURITY FIX: shlex.split instead of shell=True
                parsed = shlex.split(path)
                subprocess.Popen(parsed, shell=False)
            return f"Opening {display_name}."
        except FileNotFoundError:
            return f"App not found: {display_name}. Check the path."
        except Exception as e:
            return f"Launch error for {display_name}: {e}"

    def close_app(self, app_name):
        """অ্যাপ বন্ধ করে (taskkill)।"""
        app_name = app_name.lower().strip()
        try:
            if IS_WINDOWS:
                # প্রসেসের নাম থেকে .exe নাম বের করা
                exe_name = app_name
                if not exe_name.endswith(".exe"):
                    exe_name = f"{app_name}.exe"

                result = subprocess.run(
                    ["taskkill", "/IM", exe_name, "/F"],
                    capture_output=True, text=True, timeout=10
                )
                if result.returncode == 0:
                    return f"Closed {app_name}."
                else:
                    return f"Could not close {app_name}: {result.stderr.strip()}"
            else:
                subprocess.run(["pkill", "-f", app_name], timeout=5)
                return f"Closed {app_name}."
        except Exception as e:
            return f"Close error: {e}"

    def list_apps(self):
        """রেজিস্টার্ড অ্যাপের তালিকা।"""
        return list(self.registry.keys())

    def register_app(self, name, path):
        """নতুন অ্যাপ রেজিস্টার করে।"""
        self.registry[name.lower()] = path
        return f"Registered: {name} → {path}"


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    print("=" * 50)
    print("  LAUNCHER — Unit Test")
    print("=" * 50)

    launcher = Launcher()

    print("\n[TEST] Registered apps:")
    for app in launcher.list_apps():
        print(f"  • {app}")

    # নোটপ্যাড দিয়ে টেস্ট (নিরাপদ)
    print(f"\n[TEST] {launcher.open_app('calc')}")

    import time
    time.sleep(3)
    print(f"[TEST] {launcher.close_app('calc')}")

    print("\n[LAUNCHER] Unit test complete. ✓")
