# ================================================================
# JARVIS AETHER-CORE V2.0 — BUS-CTRL-SEN (BUS CONTROLLER)
# ================================================================
# Codename : BUS-CTRL-SEN
# Role     : Sensory Bus Controller — manages L1_SYNAPSE agents
# Controls : OPTIC, AUDIO-IN, AUDIO-OUT, HEAP-NODE
# ================================================================

import sys
import os
import asyncio

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from BUS.base_bus import BaseBusController
from SENSOR.microphone import AudioIn
from SENSOR.tts import AudioOut
from SENSOR.vision import Optic
from SENSOR.logger import HeapNode


class BusCtrlSen(BaseBusController):
    """
    JARVIS BUS-CTRL-SEN — সেন্সরি বাস কন্ট্রোলার।
    সব ইনপুট/আউটপুট এজেন্টদের ম্যানেজ করে:
    - AUDIO-IN: মাইক্রোফোন থেকে কমান্ড নেয়
    - AUDIO-OUT: JARVIS-কে কথা বলতে দেয়
    - OPTIC: ক্যামেরা থেকে ভিজুয়াল ইনপুট নেয়
    - HEAP-NODE: সব ইভেন্ট রিয়েল-টাইমে মেমোরিতে রাখে
    """

    def __init__(self, bus, atlas, cache):
        super().__init__("BUS-CTRL-SEN", bus, atlas, cache)

        # সেন্সরি এজেন্টগুলো ইনিশিয়ালাইজ করা হচ্ছে
        self.audio_in = AudioIn()
        self.audio_out = AudioOut()
        self.optic = Optic()
        self.heap = HeapNode(atlas, cache)

        print("[BUS-CTRL-SEN] All sensory agents registered.")

    async def start(self):
        """সব সেন্সরি এজেন্ট একসাথে চালু করে।"""
        self.running = True
        print("[BUS-CTRL-SEN] Activating sensory layer...")

        # সিগন্যাল বাসে সাবস্ক্রাইব করা হচ্ছে
        await self.bus.subscribe("SPEAK", self._handle_speak)
        await self.bus.subscribe("LISTEN_ONCE", self._handle_listen)
        await self.bus.subscribe("START_CAMERA", self._handle_camera_start)
        await self.bus.subscribe("STOP_SPEECH", self._handle_stop_speech)

        # ব্যাকগ্রাউন্ড ইনপুট লুপ শুরু
        self.audio_in.start_continuous_listen()
        self.audio_out.start_queue_worker()

        print("[BUS-CTRL-SEN] Sensory layer ACTIVE.")

        # ক্রমাগত AUDIO-IN কিউ থেকে কমান্ড চেক করা হচ্ছে এবং APEX-এ পাঠানো হচ্ছে
        while self.running:
            command = self.audio_in.get_command(block=False)
            if command:
                # STOP কমান্ড চেক
                if self.audio_in.is_stop_command(command):
                    self.audio_out.interrupt()
                    await self.bus.emit("BUS-CTRL-SEN", "SPEECH_STOPPED", {"reason": "User said stop"})
                # Wake-word চেক
                elif self.audio_in.is_wake_word(command):
                    await self.bus.emit("BUS-CTRL-SEN", "WAKE_WORD_DETECTED", {"text": command})
                else:
                    # সাধারণ কমান্ড — APEX-এ পাঠানো হচ্ছে
                    self.heap.record_conversation("Adil", command, "AUDIO-IN")
                    await self.bus.emit("BUS-CTRL-SEN", "USER_INPUT", command)

            await asyncio.sleep(0.1)

    async def _handle_speak(self, signal):
        """SPEAK সিগন্যাল পেলে AUDIO-OUT কে কথা বলতে দেয়।"""
        text = signal["data"]
        if isinstance(text, dict):
            text = text.get("text", "")
        if text:
            self.heap.record_conversation("JARVIS", text, "AUDIO-OUT")
            self.audio_out.speak_async(text)

    async def _handle_listen(self, signal):
        """একবার মাইক শুনে রেসপন্স পাঠায়।"""
        text = self.audio_in.listen_once()
        if text:
            await self.bus.emit("BUS-CTRL-SEN", "HEARD", {"text": text})

    async def _handle_camera_start(self, signal):
        """ক্যামেরা ফিড শুরু করে।"""
        self.optic.start_feed()
        await self.bus.emit("BUS-CTRL-SEN", "CAMERA_ACTIVE", {"status": "live"})

    async def _handle_stop_speech(self, signal):
        """AUDIO-OUT ইন্টারাপ্ট করে।"""
        self.audio_out.interrupt()

    async def stop(self):
        """সব সেন্সরি এজেন্ট বন্ধ করে।"""
        self.running = False
        self.audio_in.stop()
        self.audio_out.stop()
        self.optic.stop()
        print("[BUS-CTRL-SEN] Sensory layer OFFLINE.")


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    from KERNEL.scheduler import SignalBus
    from HEAP.database import Atlas
    from HEAP.cache import CacheNode

    async def run_test():
        bus = SignalBus()
        atlas = Atlas()
        cache = CacheNode()

        ctrl = BusCtrlSen(bus, atlas, cache)

        # টেস্ট: SPEAK সিগন্যাল পাঠানো
        await bus.subscribe("USER_INPUT", lambda s: print(f"  [TEST-HOOK] User said: {s['data']}"))
        await bus.emit("TEST", "SPEAK", {"text": "Bus Controller Sensory test successful."})
        await asyncio.sleep(4)

        await ctrl.stop()

    print("=" * 50)
    print("  BUS-CTRL-SEN — Unit Test")
    print("=" * 50)
    asyncio.run(run_test())
    print("\n[BUS-CTRL-SEN] Unit test complete. ✓")
