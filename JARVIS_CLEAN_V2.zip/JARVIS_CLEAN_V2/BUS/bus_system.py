# ================================================================
# JARVIS AETHER-CORE V2.0 — BUS-CTRL-SYS (BUS CONTROLLER)
# ================================================================
# Codename : BUS-CTRL-SYS
# Role     : System Bus Controller — manages L3_FORGE + L7_LAUNCHER
# Controls : SENTINEL, FORGE-SYS, FORGE-FILE, FORGE-PROC, LAUNCHER
# ================================================================

import sys
import os
import asyncio

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from BUS.base_bus import BaseBusController
from EXECUTOR.monitor import Sentinel
from EXECUTOR.syscall import ForgeSys
from EXECUTOR.filesystem import ForgeFile
from EXECUTOR.process import ForgeProc
from DRIVER.launcher import Launcher
from DRIVER.browser_agent import DriverBrowser


class BusCtrlSys(BaseBusController):
    """
    JARVIS BUS-CTRL-SYS — সিস্টেম বাস কন্ট্রোলার।
    পিসি কন্ট্রোল, ফাইল ম্যানেজমেন্ট, এবং অ্যাপ লঞ্চ করা।
    """

    def __init__(self, bus, atlas, cache):
        super().__init__("BUS-CTRL-SYS", bus, atlas, cache)
        self.sentinel = Sentinel()
        self.forge_sys = ForgeSys()
        self.forge_file = ForgeFile()
        self.forge_proc = ForgeProc()
        self.launcher = Launcher()
        self.browser = DriverBrowser(headless=True)
        print("[BUS-CTRL-SYS] All system agents registered.")

    async def start(self):
        """সিস্টেম কন্ট্রোল লেয়ার চালু করে।"""
        self.running = True
        print("[BUS-CTRL-SYS] Activating system control layer...")

        await self.bus.subscribe("SYS_STATS_REQUEST", self._handle_stats)
        await self.bus.subscribe("SYS_VOLUME_UP", self._handle_vol_up)
        await self.bus.subscribe("SYS_VOLUME_DOWN", self._handle_vol_down)
        await self.bus.subscribe("SYS_MUTE", self._handle_mute)
        await self.bus.subscribe("SYS_BRIGHTNESS", self._handle_brightness)
        await self.bus.subscribe("SYS_SCREENSHOT", self._handle_screenshot)
        await self.bus.subscribe("APP_OPEN", self._handle_app_open)
        await self.bus.subscribe("APP_CLOSE", self._handle_app_close)
        await self.bus.subscribe("FILE_CREATE", self._handle_file_create)
        await self.bus.subscribe("FILE_DELETE", self._handle_file_delete)
        await self.bus.subscribe("FILE_SEARCH", self._handle_file_search)
        await self.bus.subscribe("PROC_LIST", self._handle_proc_list)
        await self.bus.subscribe("PROC_KILL", self._handle_proc_kill)
        await self.bus.subscribe("BROWSE_OPEN", self._handle_browse_open)
        await self.bus.subscribe("BROWSE_SEARCH", self._handle_browse_search)
        await self.bus.subscribe("BROWSE_READ", self._handle_browse_read)
        await self.bus.subscribe("BROWSE_SCREENSHOT", self._handle_browse_screenshot)
        await self.bus.subscribe("BROWSE_FILL", self._handle_browse_fill)
        await self.bus.subscribe("BROWSE_LOGIN", self._handle_browse_login)

        print("[BUS-CTRL-SYS] System control layer ACTIVE.")
        while self.running:
            await asyncio.sleep(1)

    # ── SENTINEL handlers ──────────────────────────
    async def _handle_stats(self, signal):
        report = self.sentinel.get_full_report()
        await self.bus.emit("BUS-CTRL-SYS", "SYS_STATS_REPORT", report)

    # ── FORGE-SYS handlers ─────────────────────────
    async def _handle_vol_up(self, signal):
        steps = signal["data"].get("steps", 5) if isinstance(signal["data"], dict) else 5
        result = self.forge_sys.volume_up(steps)
        await self.bus.emit("BUS-CTRL-SYS", "SYS_ACTION_RESULT", {"action": "volume_up", "result": result})

    async def _handle_vol_down(self, signal):
        steps = signal["data"].get("steps", 5) if isinstance(signal["data"], dict) else 5
        result = self.forge_sys.volume_down(steps)
        await self.bus.emit("BUS-CTRL-SYS", "SYS_ACTION_RESULT", {"action": "volume_down", "result": result})

    async def _handle_mute(self, signal):
        result = self.forge_sys.mute()
        await self.bus.emit("BUS-CTRL-SYS", "SYS_ACTION_RESULT", {"action": "mute", "result": result})

    async def _handle_brightness(self, signal):
        level = signal["data"].get("level", 50) if isinstance(signal["data"], dict) else 50
        result = self.forge_sys.set_brightness(level)
        await self.bus.emit("BUS-CTRL-SYS", "SYS_ACTION_RESULT", {"action": "brightness", "result": result})

    async def _handle_screenshot(self, signal):
        result = self.forge_sys.take_screenshot()
        await self.bus.emit("BUS-CTRL-SYS", "SYS_ACTION_RESULT", {"action": "screenshot", "result": result})

    # ── LAUNCHER handlers ──────────────────────────
    async def _handle_app_open(self, signal):
        app_name = signal["data"] if isinstance(signal["data"], str) else signal["data"].get("name", "")
        result = self.launcher.open_app(app_name)
        await self.bus.emit("BUS-CTRL-SYS", "APP_ACTION_RESULT", {"action": "open", "result": result})

    async def _handle_app_close(self, signal):
        app_name = signal["data"] if isinstance(signal["data"], str) else signal["data"].get("name", "")
        result = self.launcher.close_app(app_name)
        await self.bus.emit("BUS-CTRL-SYS", "APP_ACTION_RESULT", {"action": "close", "result": result})

    # ── FORGE-FILE handlers ────────────────────────
    async def _handle_file_create(self, signal):
        d = signal["data"]
        result = self.forge_file.create_file(d.get("path", ""), d.get("content", ""))
        await self.bus.emit("BUS-CTRL-SYS", "FILE_ACTION_RESULT", {"action": "create", "result": result})

    async def _handle_file_delete(self, signal):
        d = signal["data"]
        path = d.get("path", "") if isinstance(d, dict) else str(d)
        result = self.forge_file.delete_file(path)
        await self.bus.emit("BUS-CTRL-SYS", "FILE_ACTION_RESULT", {"action": "delete", "result": result})

    async def _handle_file_search(self, signal):
        d = signal["data"]
        directory = d.get("directory", os.path.expanduser("~"))
        pattern = d.get("pattern", "*")
        results = self.forge_file.search(directory, pattern)
        await self.bus.emit("BUS-CTRL-SYS", "FILE_SEARCH_RESULT", {"results": results})

    # ── FORGE-PROC handlers ────────────────────────
    async def _handle_proc_list(self, signal):
        count = signal["data"].get("count", 10) if isinstance(signal["data"], dict) else 10
        procs = self.forge_proc.list_processes(count)
        await self.bus.emit("BUS-CTRL-SYS", "PROC_LIST_RESULT", {"processes": procs})

    async def _handle_proc_kill(self, signal):
        d = signal["data"]
        if isinstance(d, dict):
            result = self.forge_proc.kill_process(pid=d.get("pid"), name=d.get("name"))
        else:
            result = self.forge_proc.kill_process(name=str(d))
        await self.bus.emit("BUS-CTRL-SYS", "PROC_ACTION_RESULT", {"action": "kill", "result": result})

    # ── DRIVER-BROWSER handlers ───────────────────────
    async def _handle_browse_open(self, signal):
        d = signal["data"]
        url = d.get("url", d.get("text", "")) if isinstance(d, dict) else str(d)
        result = self.browser.open_url(url)
        await self.bus.emit("BUS-CTRL-SYS", "BROWSE_RESULT", {"action": "open", "result": result})

    async def _handle_browse_search(self, signal):
        d = signal["data"]
        query = d.get("query", d.get("text", "")) if isinstance(d, dict) else str(d)
        search_type = d.get("type", "google") if isinstance(d, dict) else "google"
        if search_type == "youtube":
            result = self.browser.youtube_search(query)
        else:
            result = self.browser.google_search(query)
        await self.bus.emit("BUS-CTRL-SYS", "BROWSE_RESULT", {"action": "search", "result": result})

    async def _handle_browse_read(self, signal):
        d = signal["data"]
        url = d.get("url", d.get("text", "")) if isinstance(d, dict) else str(d)
        result = self.browser.read_page(url)
        await self.bus.emit("BUS-CTRL-SYS", "BROWSE_RESULT", {"action": "read", "result": result})

    async def _handle_browse_screenshot(self, signal):
        d = signal["data"]
        url = d.get("url", d.get("text", "")) if isinstance(d, dict) else str(d)
        filename = d.get("filename") if isinstance(d, dict) else None
        result = self.browser.take_screenshot(url, filename)
        await self.bus.emit("BUS-CTRL-SYS", "BROWSE_RESULT", {"action": "screenshot", "result": result})

    async def _handle_browse_fill(self, signal):
        d = signal["data"]
        url = d.get("url", "") if isinstance(d, dict) else ""
        fields = d.get("fields", {}) if isinstance(d, dict) else {}
        result = self.browser.fill_form(url, fields)
        await self.bus.emit("BUS-CTRL-SYS", "BROWSE_RESULT", {"action": "fill", "result": result})

    async def _handle_browse_login(self, signal):
        d = signal["data"]
        if not isinstance(d, dict):
            await self.bus.emit("BUS-CTRL-SYS", "BROWSE_RESULT", {"action": "login", "result": {"success": False, "error": "Invalid data"}})
            return
        result = self.browser.login(
            url=d.get("url", ""),
            username_sel=d.get("username_sel", "#username"),
            password_sel=d.get("password_sel", "#password"),
            submit_sel=d.get("submit_sel", "button[type=submit]"),
            username=d.get("username", ""),
            password=d.get("password", ""),
        )
        await self.bus.emit("BUS-CTRL-SYS", "BROWSE_RESULT", {"action": "login", "result": result})

    async def stop(self):
        if hasattr(self, 'browser'):
            self.browser.close()
        self.running = False
        print("[BUS-CTRL-SYS] System control layer OFFLINE.")


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    from KERNEL.scheduler import SignalBus
    from HEAP.database import Atlas
    from HEAP.cache import CacheNode

    async def run_test():
        bus = SignalBus()
        atlas = Atlas()
        cache = CacheNode()
        ctrl = BusCtrlSys(bus, atlas, cache)

        async def on_stats(signal):
            d = signal['data']
            print(f"  [CPU] {d['cpu']['percent']}% | [RAM] {d['ram']['percent']}%")

        await bus.subscribe("SYS_STATS_REPORT", on_stats)
        asyncio.create_task(ctrl.start())
        await asyncio.sleep(1)
        await bus.emit("TEST", "SYS_STATS_REQUEST", {})
        await asyncio.sleep(2)
        await ctrl.stop()

    print("=" * 50)
    print("  BUS-CTRL-SYS — Unit Test")
    print("=" * 50)
    asyncio.run(run_test())
    print("\n[BUS-CTRL-SYS] Unit test complete. ✓")
