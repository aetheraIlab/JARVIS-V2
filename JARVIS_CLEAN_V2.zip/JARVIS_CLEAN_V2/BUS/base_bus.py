# ================================================================
# JARVIS AETHER-CORE V2.0 — BASE-BUS-CONTROLLER
# ================================================================
# Codename: BASE-BUS-CONTROLLER
# Role: Abstract Parent Class for all Bus Controllers

import asyncio

class BaseBusController:
    """
    JARVIS Bus Controller Base Class.
    সব বাস কন্ট্রোলার (Sensory, Intelligence, etc.) এখান থেকে ইনহেরিট করবে।
    """
    def __init__(self, codename, bus, atlas, cache):
        self.codename = codename
        self.bus = bus
        self.atlas = atlas
        self.cache = cache
        self.running = False
        print(f"[{self.codename}] Controller Initialized.")

    async def start(self):
        """কন্ট্রোলার রান করা শুরু করে।"""
        self.running = True
        print(f"[{self.codename}] Operational.")
        await self.main_loop()

    async def stop(self):
        """কন্ট্রোলার বন্ধ করে।"""
        self.running = False
        print(f"[{self.codename}] Shutdown.")

    async def main_loop(self):
        """প্রতিটি কন্ট্রোলারের নিজস্ব লজিক এখানে থাকবে। (Abstract)"""
        while self.running:
            await asyncio.sleep(1)

    async def log_event(self, action, status="OK", detail=""):
        """সিস্টেম ইভেন্ট ডাটাবেসে সেভ করে।"""
        print(f"[{self.codename}] {action} - {status}")
        self.atlas.commit_signal(self.codename, "ATLAS", "LOG", f"{action}: {detail}")
