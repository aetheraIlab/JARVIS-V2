# ================================================================
# JARVIS AETHER-CORE V2.0 — BUS-CTRL-SEC (BUS CONTROLLER)
# ================================================================
# Codename : BUS-CTRL-SEC
# Role     : Security Bus Controller
# Controls : CIPHER-FACE, CIPHER-VAULT, CIPHER-GATE
# ================================================================

import sys, os, asyncio
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from BUS.base_bus import BaseBusController
from GATEWAY.auth import AuthGateway
from HEAP.vault import CipherVault
from GATEWAY.guest import CipherGate


class BusCtrlSec(BaseBusController):
    """
    JARVIS BUS-CTRL-SEC — সিকিউরিটি বাস কন্ট্রোলার।
    মালিক শনাক্তকরণ, ভল্ট অ্যাক্সেস, এবং পারমিশন ম্যানেজ করে।
    """

    def __init__(self, bus, atlas, cache):
        super().__init__("BUS-CTRL-SEC", bus, atlas, cache)
        self.face = AuthGateway()
        self.vault = CipherVault()
        self.gate = CipherGate()
        print("[BUS-CTRL-SEC] All security agents registered.")

    async def start(self):
        self.running = True
        await self.bus.subscribe("VERIFY_OWNER", self._handle_verify)
        await self.bus.subscribe("CHECK_PERMISSION", self._handle_permission)
        await self.bus.subscribe("VAULT_STORE", self._handle_vault_store)
        await self.bus.subscribe("VAULT_RETRIEVE", self._handle_vault_get)
        await self.bus.subscribe("REGISTER_FACE", self._handle_register_face)

        print("[BUS-CTRL-SEC] Security layer ACTIVE.")
        while self.running:
            await asyncio.sleep(1)

    async def _handle_verify(self, signal):
        frame = signal["data"].get("frame") if isinstance(signal["data"], dict) else None
        if frame is not None:
            is_owner = self.face.is_owner(frame)
            self.gate.set_owner_verified(is_owner)
            await self.bus.emit("BUS-CTRL-SEC", "OWNER_VERIFIED", {"is_owner": is_owner})
        else:
            await self.bus.emit("BUS-CTRL-SEC", "OWNER_VERIFIED", {"is_owner": False, "reason": "No frame"})

    async def _handle_permission(self, signal):
        action = signal["data"].get("action", "") if isinstance(signal["data"], dict) else str(signal["data"])
        allowed = self.gate.check_permission(action)
        result = {"action": action, "allowed": allowed}
        if not allowed:
            result["message"] = self.gate.get_denial_message(action)
        await self.bus.emit("BUS-CTRL-SEC", "PERMISSION_RESULT", result)

    async def _handle_vault_store(self, signal):
        d = signal["data"]
        self.vault.store(d.get("key", ""), d.get("value", ""))
        await self.bus.emit("BUS-CTRL-SEC", "VAULT_STORED", {"key": d.get("key")})

    async def _handle_vault_get(self, signal):
        d = signal["data"]
        value = self.vault.retrieve(d.get("key", ""))
        await self.bus.emit("BUS-CTRL-SEC", "VAULT_VALUE", {"key": d.get("key"), "value": value})

    async def _handle_register_face(self, signal):
        d = signal["data"]
        result = self.face.register_face(d.get("image_path", ""), d.get("name", "Adil"))
        await self.bus.emit("BUS-CTRL-SEC", "FACE_REGISTERED", {"result": result})

    async def stop(self):
        self.running = False
        self.vault.close()
        print("[BUS-CTRL-SEC] Security layer OFFLINE.")


if __name__ == "__main__":
    from KERNEL.scheduler import SignalBus
    from HEAP.database import Atlas
    from HEAP.cache import CacheNode

    async def run_test():
        bus = SignalBus()
        ctrl = BusCtrlSec(bus, Atlas(), CacheNode())
        asyncio.create_task(ctrl.start())
        await asyncio.sleep(1)
        await bus.emit("TEST", "CHECK_PERMISSION", {"action": "AI_QUERY"})
        await asyncio.sleep(1)
        await ctrl.stop()

    print("=" * 50)
    print("  BUS-CTRL-SEC — Unit Test")
    print("=" * 50)
    asyncio.run(run_test())
    print("\n[BUS-CTRL-SEC] Unit test complete. ✓")
