# ================================================================
# JARVIS AETHER-CORE V2.0 — BUS-CTRL-AWR (BUS CONTROLLER)
# ================================================================
# Codename : BUS-CTRL-AWR
# Role     : Awareness Bus Controller
# Controls : WATCHDOG, HERALD, CHRONO, BEACON, REMINDER-AGENT
# ================================================================

import sys
import os
import asyncio

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from BUS.base_bus import BaseBusController
from DAEMON.watchdog import SystemWatchdog
from DAEMON.synthesizer import Herald
from DAEMON.tracker import ActivityTracker
from DAEMON.reminder import Beacon
from DAEMON.reminder_agent import ReminderAgent


class BusCtrlAwr(BaseBusController):
    """
    JARVIS BUS-CTRL-AWR — সচেতনতা বাস কন্ট্রোলার।
    পরিস্থিতি সচেতনতা, রিমাইন্ডার, এবং নোটিফিকেশন ম্যানেজ করে।

    ইন্টিগ্রেটেড এজেন্ট:
    - SystemWatchdog: সিস্টেম স্বাস্থ্য পর্যবেক্ষণ
    - Herald: কনটেক্সট-সচেতন বক্তব্য
    - ActivityTracker: ইউজার কার্যকলাপ ট্র্যাকিং
    - Beacon: ডেস্কটপ নোটিফিকেশন
    - ReminderAgent: রিমাইন্ডার ম্যানেজমেন্ট
    """

    def __init__(self, bus, atlas, cache):
        super().__init__("BUS-CTRL-AWR", bus, atlas, cache)
        self.watchdog = SystemWatchdog()
        self.herald = Herald()
        self.chrono = ActivityTracker()
        self.beacon = Beacon()
        self.reminder = ReminderAgent(atlas=atlas)
        print("[BUS-CTRL-AWR] All awareness agents registered.")

    async def start(self):
        """সচেতনতা স্তর চালু করে।"""
        self.running = True

        # সিগন্যাল সাবস্ক্রিপশন
        await self.bus.subscribe("ADD_REMINDER", self._handle_add_reminder)
        await self.bus.subscribe("LIST_REMINDERS", self._handle_list_reminders)
        await self.bus.subscribe("CANCEL_REMINDER", self._handle_cancel_reminder)
        await self.bus.subscribe("SEND_NOTIFICATION", self._handle_notify)
        await self.bus.subscribe("GET_CONTEXT_SPEECH", self._handle_context)
        await self.bus.subscribe("GET_ACTIVE_WINDOW", self._handle_window)
        await self.bus.subscribe("SYS_HEALTH", self._handle_health)

        # ব্যাকগ্রাউন্ড সার্ভিস চালু
        self.watchdog.start(interval=10)
        self.chrono.start(interval=5)
        self.reminder.start(check_interval=30)

        print("[BUS-CTRL-AWR] Awareness layer ACTIVE.")
        while self.running:
            await asyncio.sleep(1)

    async def _handle_add_reminder(self, signal):
        """রিমাইন্ডার যোগ করার হ্যান্ডলার।"""
        d = signal["data"]
        msg = d.get("message", d.get("raw_text", "")) if isinstance(d, dict) else str(d)

        if not msg:
            return

        result = self.reminder.add_reminder(msg, source="bus_signal")

        await self.bus.emit("BUS-CTRL-AWR", "REMINDER_ADDED", {
            "id": result["id"],
            "message": result["message"],
            "trigger_time": result["trigger_time"],
            "minutes_until": result["minutes_until"],
        })

    async def _handle_list_reminders(self, signal):
        """অ্যাক্টিভ রিমাইন্ডার তালিকা হ্যান্ডলার।"""
        active = self.reminder.get_active_reminders()
        summary = self.reminder.get_reminder_summary()

        await self.bus.emit("BUS-CTRL-AWR", "REMINDERS_LIST", {
            "reminders": active,
            "summary": summary,
            "count": len(active),
        })

    async def _handle_cancel_reminder(self, signal):
        """রিমাইন্ডার বাতিল হ্যান্ডলার।"""
        d = signal["data"]
        reminder_id = d.get("id") if isinstance(d, dict) else None
        if reminder_id:
            self.reminder.cancel_reminder(reminder_id)
            await self.bus.emit("BUS-CTRL-AWR", "REMINDER_CANCELLED", {
                "id": reminder_id,
            })

    async def _handle_notify(self, signal):
        """ডেস্কটপ নোটিফিকেশন হ্যান্ডলার।"""
        d = signal["data"]
        title = d.get("title", "JARVIS") if isinstance(d, dict) else "JARVIS"
        message = d.get("message", str(d)) if isinstance(d, dict) else str(d)
        self.beacon.notify(title, message)

    async def _handle_context(self, signal):
        """কনটেক্সট স্পিচ হ্যান্ডলার।"""
        window = self.chrono.get_active_window()
        speech = self.herald.generate_context_speech(active_window=window)
        await self.bus.emit("BUS-CTRL-AWR", "CONTEXT_SPEECH", {"text": speech})

    async def _handle_window(self, signal):
        """অ্যাক্টিভ উইন্ডো হ্যান্ডলার।"""
        window = self.chrono.get_active_window()
        await self.bus.emit("BUS-CTRL-AWR", "ACTIVE_WINDOW", {"window": window})

    async def _handle_health(self, signal):
        """সিস্টেম হেলথ হ্যান্ডলার।"""
        status = self.watchdog.get_status()
        await self.bus.emit("BUS-CTRL-AWR", "SYS_HEALTH_REPORT", status)

    async def stop(self):
        """সচেতনতা স্তর বন্ধ করে।"""
        self.running = False
        self.watchdog.stop()
        self.chrono.stop()
        self.reminder.stop()
        print("[BUS-CTRL-AWR] Awareness layer OFFLINE.")


if __name__ == "__main__":
    from KERNEL.scheduler import SignalBus
    from HEAP.database import Atlas
    from HEAP.cache import CacheNode

    async def run_test():
        bus = SignalBus()
        ctrl = BusCtrlAwr(bus, Atlas(), CacheNode())
        asyncio.create_task(ctrl.start())
        await asyncio.sleep(1)

        # Test reminder
        await bus.emit("TEST", "ADD_REMINDER", {"message": "test reminder in 1 minute"})
        await asyncio.sleep(1)

        await bus.emit("TEST", "GET_ACTIVE_WINDOW", {})
        await asyncio.sleep(2)
        await ctrl.stop()

    print("=" * 50)
    print("  BUS-CTRL-AWR — Unit Test")
    print("=" * 50)
    asyncio.run(run_test())
    print("\n[BUS-CTRL-AWR] Unit test complete. [OK]")
