# ================================================================
# JARVIS AETHER-CORE V2.0 — BUS-CTRL-INT (BUS CONTROLLER)
# ================================================================
# Codename : BUS-CTRL-INT
# Role     : Intelligence Bus Controller — manages L2_CORTEX agents
# Controls : CORTEX-ONLINE, CORTEX-OFFLINE, ARBITER
# ================================================================

import sys
import os
import asyncio

# প্রজেক্ট রুট পাথ সেটআপ
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from BUS.base_bus import BaseBusController
from INFERENCE.pipeline import Arbiter


class BusCtrlInt(BaseBusController):
    """
    JARVIS BUS-CTRL-INT — ইন্টেলিজেন্স বাস কন্ট্রোলার।
    সব AI এজেন্টদের ম্যানেজ করে:
    - ARBITER: সিদ্ধান্ত নেয় কোন AI মডেল ব্যবহার হবে
    - CORTEX-ONLINE: অনলাইন AI (Groq/Gemini)
    - CORTEX-OFFLINE: অফলাইন AI (Ollama)
    """

    def __init__(self, bus, atlas, cache):
        super().__init__("BUS-CTRL-INT", bus, atlas, cache)

        # ARBITER-ই CORTEX-ONLINE এবং CORTEX-OFFLINE ম্যানেজ করে
        self.arbiter = Arbiter()
        print("[BUS-CTRL-INT] Intelligence layer registered.")

    async def start(self):
        """ইন্টেলিজেন্স লেয়ার চালু করে।"""
        self.running = True
        print("[BUS-CTRL-INT] Activating intelligence layer...")

        # সিগন্যাল বাসে সাবস্ক্রাইব — যখন AI প্রসেস রিকোয়েস্ট আসবে
        await self.bus.subscribe("AI_PROCESS_REQUEST", self._handle_ai_request)
        await self.bus.subscribe("AI_CLEAR_HISTORY", self._handle_clear_history)
        await self.bus.subscribe("AI_STATUS_REQUEST", self._handle_status_request)

        print("[BUS-CTRL-INT] Intelligence layer ACTIVE.")

        # মেইন লুপ — চালু থাকবে যতক্ষণ সিস্টেম চলবে
        while self.running:
            await asyncio.sleep(1)

    async def _handle_ai_request(self, signal):
        """
        AI প্রসেস রিকোয়েস্ট পেলে ARBITER-কে চিন্তা করতে দেয়।
        ARBITER নিজেই Groq → Gemini → Ollama ফলব্যাক চেইন ম্যানেজ করে।
        """
        data = signal["data"]
        if isinstance(data, dict):
            user_text = data.get("text", "")
        else:
            user_text = str(data)

        if not user_text:
            return

        print(f"[BUS-CTRL-INT] Processing: \"{user_text[:60]}...\"")

        # ARBITER-কে চিন্তা করতে দেওয়া হচ্ছে (ব্লকিং — আলাদা থ্রেডে চাপানো যায় পরে)
        loop = asyncio.get_event_loop()
        response, provider = await loop.run_in_executor(
            None, self.arbiter.think, user_text
        )

        # রেসপন্স সিগন্যাল বাসে পাবলিশ করা হচ্ছে
        await self.bus.emit("BUS-CTRL-INT", "AI_RESPONSE", {
            "text": response,
            "provider": provider,
            "query": user_text
        })

        # ATLAS-এ লগ করা হচ্ছে
        self.atlas.commit_signal("BUS-CTRL-INT", "APEX", "AI_RESPONSE", response[:500])

    async def _handle_clear_history(self, signal):
        """কথোপকথনের ইতিহাস মুছে দেয়।"""
        self.arbiter.clear_history()
        await self.bus.emit("BUS-CTRL-INT", "AI_HISTORY_CLEARED", {"status": "done"})

    async def _handle_status_request(self, signal):
        """AI সিস্টেমের বর্তমান অবস্থা রিপোর্ট করে।"""
        status = self.arbiter.get_status()
        await self.bus.emit("BUS-CTRL-INT", "AI_STATUS_REPORT", status)

    async def stop(self):
        """ইন্টেলিজেন্স লেয়ার বন্ধ করে।"""
        self.running = False
        print("[BUS-CTRL-INT] Intelligence layer OFFLINE.")


# ================================================================
# UNIT TEST
# ================================================================
if __name__ == "__main__":
    from KERNEL.scheduler import SignalBus
    from HEAP.database import Atlas
    from HEAP.cache import CacheNode

    async def run_test():
        bus = SignalBus()
        atlas = Atlas()
        cache = CacheNode()

        ctrl = BusCtrlInt(bus, atlas, cache)

        # রেসপন্স ক্যাচ করার জন্য সাবস্ক্রাইব
        async def on_response(signal):
            print(f"\n  [TEST-RESPONSE] Provider: {signal['data']['provider']}")
            print(f"  [TEST-RESPONSE] Answer: {signal['data']['text'][:200]}")

        await bus.subscribe("AI_RESPONSE", on_response)

        # কন্ট্রোলার ব্যাকগ্রাউন্ডে স্টার্ট
        asyncio.create_task(ctrl.start())
        await asyncio.sleep(1)

        # AI রিকোয়েস্ট পাঠানো
        await bus.emit("TEST", "AI_PROCESS_REQUEST", {"text": "What is Python?"})
        await asyncio.sleep(10)

        await ctrl.stop()

    print("=" * 50)
    print("  BUS-CTRL-INT — Unit Test")
    print("=" * 50)
    asyncio.run(run_test())
    print("\n[BUS-CTRL-INT] Unit test complete. ✓")
