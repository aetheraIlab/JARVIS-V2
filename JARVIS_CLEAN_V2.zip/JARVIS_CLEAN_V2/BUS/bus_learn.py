# ================================================================
# JARVIS AETHER-CORE V2.0 — BUS-CTRL-LRN (BUS CONTROLLER)
# ================================================================
# Codename : BUS-CTRL-LRN
# Role     : Learning Bus Controller
# Controls : NEURAL, PATCH, LEXICON
# ================================================================

import sys, os, asyncio
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from BUS.base_bus import BaseBusController
from TRAINER.learner import Neural
from TRAINER.updater import Patch
from TRAINER.indexer import Lexicon


class BusCtrlLrn(BaseBusController):
    """
    JARVIS BUS-CTRL-LRN — লার্নিং বাস কন্ট্রোলার।
    শেখা, জ্ঞানভাণ্ডার, এবং আপডেট ম্যানেজ করে।
    """

    def __init__(self, bus, atlas, cache):
        super().__init__("BUS-CTRL-LRN", bus, atlas, cache)
        self.neural = Neural(atlas)
        self.patch = Patch()
        self.lexicon = Lexicon(atlas)
        print("[BUS-CTRL-LRN] All learning agents registered.")

    async def start(self):
        self.running = True
        await self.bus.subscribe("LEARN_TOPIC", self._handle_learn)
        await self.bus.subscribe("SEARCH_KNOWLEDGE", self._handle_search)
        await self.bus.subscribe("ANALYZE_CONVERSATIONS", self._handle_analyze)
        await self.bus.subscribe("CHECK_UPDATES", self._handle_updates)
        await self.bus.subscribe("GET_INSIGHT", self._handle_insight)

        print("[BUS-CTRL-LRN] Learning layer ACTIVE.")
        while self.running:
            await asyncio.sleep(1)

    async def _handle_learn(self, signal):
        d = signal["data"]
        topic = d.get("topic", "") if isinstance(d, dict) else str(d)
        content = d.get("content", "") if isinstance(d, dict) else ""
        result = self.lexicon.learn(topic, content)
        await self.bus.emit("BUS-CTRL-LRN", "LEARNED", {"result": result})

    async def _handle_search(self, signal):
        d = signal["data"]
        query = d.get("query", "") if isinstance(d, dict) else str(d)
        results = self.lexicon.search(query)
        await self.bus.emit("BUS-CTRL-LRN", "KNOWLEDGE_RESULTS", {"results": results})

    async def _handle_analyze(self, signal):
        loop = asyncio.get_event_loop()
        analysis = await loop.run_in_executor(None, self.neural.analyze_conversations)
        await self.bus.emit("BUS-CTRL-LRN", "ANALYSIS_REPORT", analysis)

    async def _handle_updates(self, signal):
        loop = asyncio.get_event_loop()
        outdated = await loop.run_in_executor(None, self.patch.check_outdated)
        await self.bus.emit("BUS-CTRL-LRN", "UPDATE_REPORT", {"outdated": outdated})

    async def _handle_insight(self, signal):
        insight = self.neural.get_insight()
        await self.bus.emit("BUS-CTRL-LRN", "INSIGHT_REPORT", insight)

    async def stop(self):
        self.running = False
        print("[BUS-CTRL-LRN] Learning layer OFFLINE.")


if __name__ == "__main__":
    from KERNEL.scheduler import SignalBus
    from HEAP.database import Atlas
    from HEAP.cache import CacheNode

    async def run_test():
        bus = SignalBus()
        ctrl = BusCtrlLrn(bus, Atlas(), CacheNode())
        asyncio.create_task(ctrl.start())
        await asyncio.sleep(1)
        await bus.emit("TEST", "LEARN_TOPIC", {"topic": "Test", "content": "Unit test data"})
        await asyncio.sleep(1)
        await ctrl.stop()

    print("=" * 50)
    print("  BUS-CTRL-LRN — Unit Test")
    print("=" * 50)
    asyncio.run(run_test())
    print("\n[BUS-CTRL-LRN] Unit test complete. ✓")
