# ================================================================
# JARVIS AETHER-CORE V2.0 — CACHE-NODE (LAYER 10)
# ================================================================
# Codename: CACHE-NODE
# Role: Fast Session Memory (JSON Cache)

import json
import os
import sys
from datetime import datetime

# Path Resolver ইমপোর্ট করা হচ্ছে
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from CONFIG.config import CACHE_PATH

class CacheNode:
    """
    JARVIS Active Memory (RAM equivalent).
    Stores temporary session data, tokens, and system states.
    """
    def __init__(self, max_entries=500):
        self.cache_file = CACHE_PATH
        self.max_entries = max_entries
        self.data = self._load_cache()
        print(f"[CACHE-NODE] Active cache loaded -> {len(self.data)} nodes")

    def _load_cache(self):
        """ডিস্ক থেকে ক্যাশ ফাইল লোড করে।"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _persist(self):
        """ক্যাশ ডাটা ডিস্কে সেভ করে।"""
        with open(self.cache_file, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, indent=4)

    def set(self, key, value):
        """একটি ডাটা ক্যাশ-এ সেভ করে।"""
        if len(self.data) >= self.max_entries:
            # খুব বেশি এন্ট্রি হয়ে গেলে সবচেয়ে পুরোনোটি ডিলিট করে (FIFO)
            first_key = next(iter(self.data))
            del self.data[first_key]
            
        self.data[key] = {
            "val": value,
            "ts": datetime.now().isoformat()
        }
        self._persist()

    def get(self, key, default=None):
        """ক্যাশ থেকে ডাটা রিড করে।"""
        node = self.data.get(key)
        if node:
            return node["val"]
        return default

    def delete(self, key):
        """নির্দিষ্ট কি-এর ডাটা ডিলিট করে।"""
        if key in self.data:
            del self.data[key]
            self._persist()

    def clear(self):
        """পুরো ক্যাশ ক্লিয়ার করে।"""
        self.data = {}
        self._persist()
        print("[CACHE-NODE] Memory purge complete.")

if __name__ == "__main__":
    cache = CacheNode()
    cache.set("system_mode", "active")
    cache.set("last_query", "What time is it?")
    
    print(f"[TEST] System Mode: {cache.get('system_mode')}")
    print(f"[TEST] last_query: {cache.get('last_query')}")
    
    # cache.clear()
    print("[CACHE-NODE] Unit test complete.")
