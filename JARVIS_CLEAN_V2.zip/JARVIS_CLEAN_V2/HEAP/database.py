# ================================================================
# JARVIS AETHER-CORE V2.0 — ATLAS (LAYER 10)
# ================================================================
# Codename: ATLAS
# Role: Permanent Database Manager (SQLite3)

import sqlite3
import sys
import os
from datetime import datetime

# Path Resolver ইমপোর্ট করা হচ্ছে
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from CONFIG.config import DB_PATH

class Atlas:
    """
    JARVIS Long-term Memory.
    Stores conversations, tasks, and system knowledge.
    """
    def __init__(self, db_path=None):
        self.db_path = db_path if db_path else DB_PATH
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._initialize_schema()
        print(f"[ATLAS] Neural database linked -> {self.db_path}")

    def execute(self, sql, params=None):
        if params:
            return self.conn.execute(sql, params)
        return self.conn.execute(sql)

    def _initialize_schema(self):
        """ডাটাবেস টেবিলগুলো তৈরি করে যদি না থাকে।"""
        cursor = self.conn.cursor()
        
        # ১. কথোপকথন টেবিল (Conversations)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                sender TEXT NOT NULL,
                receiver TEXT NOT NULL,
                signal_type TEXT NOT NULL,
                data TEXT NOT NULL,
                is_processed INTEGER DEFAULT 0
            )
        """)

        # ২. লং-টার্ম মেমোরি টেবিল (Memories)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                memory_fragment TEXT NOT NULL,
                importance_score INTEGER DEFAULT 1,
                context_tags TEXT
            )
        """)

        # ৩. ইউজার প্রোফাইল (Identity)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS identity (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                attribute TEXT UNIQUE NOT NULL,
                value TEXT NOT NULL,
                last_updated TEXT NOT NULL
            )
        """)
        
        self.conn.commit()

    def commit_signal(self, sender, receiver, signal_type, data):
        """একটি সিগন্যাল বা মেসেজ ডাটাবেসে সেভ করে।"""
        now = datetime.now().isoformat()
        self.conn.execute(
            "INSERT INTO signals (timestamp, sender, receiver, signal_type, data) VALUES (?, ?, ?, ?, ?)",
            (now, sender, receiver, signal_type, data)
        )
        self.conn.commit()

    def add_memory(self, fragment, importance=1, tags=""):
        """নতুন মেমোরি ফ্র্যাগমেন্ট সেভ করে।"""
        now = datetime.now().isoformat()
        self.conn.execute(
            "INSERT INTO memories (timestamp, memory_fragment, importance_score, context_tags) VALUES (?, ?, ?, ?)",
            (now, fragment, importance, tags)
        )
        self.conn.commit()

    def update_identity(self, attribute, value):
        """ইউজার বা সিস্টেমের কোনো তথ্য আপডেট করে।"""
        now = datetime.now().isoformat()
        self.conn.execute(
            "INSERT OR REPLACE INTO identity (attribute, value, last_updated) VALUES (?, ?, ?)",
            (attribute, value, now)
        )
        self.conn.commit()

    def query(self, sql, params=()):
        """কাস্টম কুয়েরি চালানোর জন্য।"""
        cursor = self.conn.cursor()
        cursor.execute(sql, params)
        return cursor.fetchall()

    def close(self):
        self.conn.close()

if __name__ == "__main__":
    db = Atlas()
    db.commit_signal("APEX", "AUDIO-OUT", "BOOT_MSG", "Hello Sir, I am Online.")
    db.update_identity("owner_name", "Adil")
    db.add_memory("Project AETHER-CORE started", importance=5)
    
    res = db.query("SELECT * FROM identity WHERE attribute='owner_name'")
    print(f"[TEST] Owner Name: {res[0]['value']}")
    
    db.close()
    print("[ATLAS] Unit test complete.")
