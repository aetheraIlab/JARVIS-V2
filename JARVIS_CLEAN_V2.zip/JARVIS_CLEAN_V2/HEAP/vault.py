import os
import sys
import sqlite3
import logging
import base64
from pathlib import Path
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import gc
import ctypes

# .env ফোল্ডার লোড করার চেষ্টা করা হচ্ছে
try:
    from dotenv import load_dotenv
    _has_dotenv = True
except ImportError:
    _has_dotenv = False

# লগার সেটআপ
logger = logging.getLogger("VAULT")
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

class Vault:
    """
    নিরাপদ স্টোরেজ সিস্টেম (AES-256 Encryption)।
    সেনসিটিভ ডেটা (যেমন API Keys, Passwords) এনক্রিপ্ট করে SQLite এ স্টোর করে।
    """

    def __init__(self):
        # প্রজেক্ট ডিরেক্টরি সেটআপ (Cross-platform)
        self.base_dir = Path(__file__).resolve().parent.parent
        
        if _has_dotenv:
            load_dotenv(dotenv_path=self.base_dir / ".env")
            
        self.db_path = Path(__file__).resolve().parent / "vault.db"
        self._init_db()
        
        # মাস্টার কী লোড করা (.env থেকে)
        self._master_key = os.environ.get("VAULT_MASTER_KEY", "jarvis_fallback_secure_key_999!")
        self.cipher = self._initialize_cipher()
        logger.info("Vault initialized successfully. AES-256 Encryption Active.")

    def _initialize_cipher(self) -> Fernet:
        """PBKDF2HMAC ব্যবহার করে মাস্টার পাসওয়ার্ড থেকে AES-256 (Fernet) কী তৈরি করে।"""
        # Load salt from .env or generate a new one
        salt_hex = os.environ.get("VAULT_SALT")
        if salt_hex:
            salt = bytes.fromhex(salt_hex)
        else:
            salt = os.urandom(32)
            salt_hex = salt.hex()
            os.environ["VAULT_SALT"] = salt_hex
            env_path = self.base_dir / ".env"
            try:
                with open(env_path, "a", encoding="utf-8") as f:
                    f.write(f"\nVAULT_SALT={salt_hex}\n")
                logger.info("Generated new vault salt and saved to .env")
            except Exception as e:
                logger.error(f"Failed to save vault salt to .env: {e}")

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=480000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(self._master_key.encode('utf-8')))
        
        # Red-Team Security Patch: Scrub environment to prevent memory dump attacks
        os.environ.pop("VAULT_MASTER_KEY", None)
        os.environ.pop("VAULT_SALT", None)
        
        return Fernet(key)

    def _init_db(self):
        """SQLite ডাটাবেস এবং টেবিল তৈরি করে।"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS secrets (
                        key_name TEXT PRIMARY KEY,
                        encrypted_value TEXT NOT NULL
                    )
                ''')
                conn.commit()
        except Exception as e:
            logger.error(f"Failed to initialize vault database: {e}")

    def store(self, key: str, value: str) -> bool:
        """ভ্যালু এনক্রিপ্ট করে ডাটাবেসে স্টোর করে। (Raw value is never logged)"""
        try:
            encrypted_data = self.cipher.encrypt(value.encode('utf-8')).decode('utf-8')
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO secrets (key_name, encrypted_value)
                    VALUES (?, ?)
                ''', (key, encrypted_data))
                conn.commit()
            logger.info(f"Secret securely stored for key: {key}")
            return True
        except Exception as e:
            logger.error(f"Failed to store secret for key '{key}': {e}")
            return False

    def retrieve(self, key: str) -> str:
        """এনক্রিপ্টেড ভ্যালু ডাটাবেস থেকে রিট্রিভ করে ডিক্রিপ্ট করে।"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT encrypted_value FROM secrets WHERE key_name = ?', (key,))
                row = cursor.fetchone()
                
            if row:
                encrypted_data = row[0]
                decrypted_value = self.cipher.decrypt(encrypted_data.encode('utf-8')).decode('utf-8')
                
                # Stack Trace Protection: Remove local vars if exception happens later
                del encrypted_data
                del row
                gc.collect()
                
                return decrypted_value
            else:
                logger.warning(f"No secret found for key: {key}")
                return None
        except Exception as e:
            # Mask the exact error if it contains decrypted fragments
            logger.error(f"Failed to retrieve/decrypt secret for key '{key}'. (Error masked for security)")
            return None

    def delete(self, key: str) -> bool:
        """ডাটাবেস থেকে একটি নির্দিষ্ট কী-এর সিক্রেট রিমুভ করে।"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM secrets WHERE key_name = ?', (key,))
                if cursor.rowcount > 0:
                    conn.commit()
                    logger.info(f"Secret deleted successfully for key: {key}")
                    return True
                else:
                    logger.warning(f"Secret not found for deletion: {key}")
                    return False
        except Exception as e:
            logger.error(f"Failed to delete secret for key '{key}': {e}")
            return False

    def list_keys(self) -> list:
        """স্টোর করা সমস্ত কী এর নাম রিটার্ন করে (Value রিটার্ন করে না)।"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT key_name FROM secrets')
                rows = cursor.fetchall()
            return [row[0] for row in rows]
        except Exception as e:
            logger.error(f"Failed to list vault keys: {e}")
            return []

if __name__ == "__main__":
    print("="*50)
    print(" VAULT SECURE STORAGE UNIT TEST ")
    print("="*50)
    
    vault = Vault()
    test_key = "test_system_key"
    test_val = "super_secret_password_123"
    
    # Store
    print(f"\n[1] Storing secret for '{test_key}'...")
    vault.store(test_key, test_val)
    
    # Retrieve
    print(f"\n[2] Retrieving secret for '{test_key}'...")
    retrieved = vault.retrieve(test_key)
    if retrieved == test_val:
        print("    -> Match Verified! Decryption successful.")
    else:
        print("    -> Match Failed!")
        
    # List Keys
    print("\n[3] Listing all secure keys...")
    print(f"    -> {vault.list_keys()}")
    
    # Delete
    print(f"\n[4] Deleting secret '{test_key}'...")
    vault.delete(test_key)
    
    # Verify Deletion
    print("\n[5] Listing keys after deletion...")
    print(f"    -> {vault.list_keys()}")
    
    print("\n[VAULT] Test Complete.")
