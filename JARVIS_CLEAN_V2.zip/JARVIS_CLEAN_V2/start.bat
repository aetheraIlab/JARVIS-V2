@echo off
title JARVIS Launcher
color 0B

echo ================================================================
echo    J.A.R.V.I.S  AETHER-CORE  V2.0  —  SYSTEM LAUNCHER
echo    Joint Autonomous Responsive Virtual Intelligent System
echo ================================================================
echo.

REM ── Check if Python is available ──────────────────────────────
where python >nul 2>&1
if %ERRORLEVEL% neq 0 (
    color 0C
    echo [FAIL] Python not found in PATH.
    echo        Please install Python 3.11+ and add to PATH.
    pause
    exit /b 1
)

REM ── Check if port 5000 is already in use ──────────────────────
netstat -ano | findstr ":5000 " | findstr "LISTENING" >nul 2>&1
if %ERRORLEVEL% equ 0 (
    color 0E
    echo [WARN] Port 5000 (NeuralInterface API) is already in use.
    echo        JARVIS may already be running.
    echo.
    choice /C YN /M "Continue anyway? (Y/N)"
    if %ERRORLEVEL% equ 2 exit /b 0
    echo.
)

echo [BOOT] Starting JARVIS Core Engine...
echo.

REM ── Start JARVIS in a new CMD window with venv activated ──────
if exist "%~dp0venv\Scripts\activate.bat" (
    start "JARVIS Core" cmd /k "cd /d %~dp0 && call venv\Scripts\activate.bat && python main.py"
) else (
    start "JARVIS Core" cmd /k "cd /d %~dp0 && python main.py"
)

REM ── Wait for server to initialize ─────────────────────────────
echo [WAIT] Waiting for Neural Interface to come online...
timeout /t 5 /nobreak >nul

REM ── Open HUD in default browser ───────────────────────────────
echo [HUD]  Opening PRISM Dashboard...
start http://localhost:5000

echo.
echo ================================================================
echo    JARVIS is ONLINE.
echo    HUD:  http://localhost:5000
echo    To stop: run stop.bat or close the JARVIS Core window.
echo ================================================================
echo.
pause
